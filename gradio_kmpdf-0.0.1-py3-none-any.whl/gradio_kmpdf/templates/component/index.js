import { I as f } from "./Index-Bo6-Bozu.js";
export {
  f as default
};
