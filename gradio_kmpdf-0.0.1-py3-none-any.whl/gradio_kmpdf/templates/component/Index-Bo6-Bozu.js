var Jn = Object.defineProperty;
var _n = (i) => {
  throw TypeError(i);
};
var Zn = (i, t, n) => t in i ? Jn(i, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : i[t] = n;
var Kt = (i, t, n) => Zn(i, typeof t != "symbol" ? t + "" : t, n), xe = (i, t, n) => t.has(i) || _n("Cannot " + n);
var r = (i, t, n) => (xe(i, t, "read from private field"), n ? n.call(i) : t.get(i)), at = (i, t, n) => t.has(i) ? _n("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(i) : t.set(i, n), lt = (i, t, n, e) => (xe(i, t, "write to private field"), e ? e.call(i, n) : t.set(i, n), n), Z = (i, t, n) => (xe(i, t, "access private method"), n);
var he = (i, t, n, e) => ({
  set _(s) {
    lt(i, t, s, n);
  },
  get _() {
    return r(i, t, e);
  }
});
const {
  SvelteComponent: SvelteComponent$g,
  append: append$f,
  attr: attr$f,
  detach: detach$g,
  init: init$g,
  insert: insert$g,
  noop: noop$8,
  safe_not_equal: safe_not_equal$h,
  svg_element: svg_element$6
} = window.__gradio__svelte__internal;
function create_fragment$g(i) {
  let t, n, e;
  return {
    c() {
      t = svg_element$6("svg"), n = svg_element$6("path"), e = svg_element$6("polyline"), attr$f(n, "d", "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"), attr$f(e, "points", "13 2 13 9 20 9"), attr$f(t, "xmlns", "http://www.w3.org/2000/svg"), attr$f(t, "width", "100%"), attr$f(t, "height", "100%"), attr$f(t, "viewBox", "0 0 24 24"), attr$f(t, "fill", "none"), attr$f(t, "stroke", "currentColor"), attr$f(t, "stroke-width", "1.5"), attr$f(t, "stroke-linecap", "round"), attr$f(t, "stroke-linejoin", "round"), attr$f(t, "class", "feather feather-file");
    },
    m(s, c) {
      insert$g(s, t, c), append$f(t, n), append$f(t, e);
    },
    p: noop$8,
    i: noop$8,
    o: noop$8,
    d(s) {
      s && detach$g(t);
    }
  };
}
let File$1 = class extends SvelteComponent$g {
  constructor(t) {
    super(), init$g(this, t, null, create_fragment$g, safe_not_equal$h, {});
  }
};
const {
  SvelteComponent: SvelteComponent$f,
  append: append$e,
  attr: attr$e,
  detach: detach$f,
  init: init$f,
  insert: insert$f,
  noop: noop$7,
  safe_not_equal: safe_not_equal$g,
  svg_element: svg_element$5
} = window.__gradio__svelte__internal;
function create_fragment$f(i) {
  let t, n, e, s;
  return {
    c() {
      t = svg_element$5("svg"), n = svg_element$5("path"), e = svg_element$5("polyline"), s = svg_element$5("line"), attr$e(n, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), attr$e(e, "points", "17 8 12 3 7 8"), attr$e(s, "x1", "12"), attr$e(s, "y1", "3"), attr$e(s, "x2", "12"), attr$e(s, "y2", "15"), attr$e(t, "xmlns", "http://www.w3.org/2000/svg"), attr$e(t, "width", "90%"), attr$e(t, "height", "90%"), attr$e(t, "viewBox", "0 0 24 24"), attr$e(t, "fill", "none"), attr$e(t, "stroke", "currentColor"), attr$e(t, "stroke-width", "2"), attr$e(t, "stroke-linecap", "round"), attr$e(t, "stroke-linejoin", "round"), attr$e(t, "class", "feather feather-upload");
    },
    m(c, h) {
      insert$f(c, t, h), append$e(t, n), append$e(t, e), append$e(t, s);
    },
    p: noop$7,
    i: noop$7,
    o: noop$7,
    d(c) {
      c && detach$f(t);
    }
  };
}
let Upload$1 = class extends SvelteComponent$f {
  constructor(t) {
    super(), init$f(this, t, null, create_fragment$f, safe_not_equal$g, {});
  }
};
const {
  SvelteComponent: SvelteComponent$e,
  append: append$d,
  attr: attr$d,
  create_component: create_component$6,
  destroy_component: destroy_component$6,
  detach: detach$e,
  element: element$a,
  init: init$e,
  insert: insert$e,
  mount_component: mount_component$6,
  safe_not_equal: safe_not_equal$f,
  text: text$5,
  toggle_class: toggle_class$9,
  transition_in: transition_in$9,
  transition_out: transition_out$9
} = window.__gradio__svelte__internal;
function create_fragment$e(i) {
  let t, n, e, s, c, h, b;
  return e = new Upload$1({}), {
    c() {
      t = element$a("div"), n = element$a("span"), create_component$6(e.$$.fragment), s = text$5(`
    Drop PDF
    `), c = element$a("span"), c.textContent = "- or -", h = text$5(`
    Click to Upload`), attr$d(n, "class", "icon-wrap svelte-kzcjhc"), toggle_class$9(
        n,
        "hovered",
        /*hovered*/
        i[0]
      ), attr$d(c, "class", "or svelte-kzcjhc"), attr$d(t, "class", "wrap svelte-kzcjhc");
    },
    m(o, l) {
      insert$e(o, t, l), append$d(t, n), mount_component$6(e, n, null), append$d(t, s), append$d(t, c), append$d(t, h), b = !0;
    },
    p(o, [l]) {
      (!b || l & /*hovered*/
      1) && toggle_class$9(
        n,
        "hovered",
        /*hovered*/
        o[0]
      );
    },
    i(o) {
      b || (transition_in$9(e.$$.fragment, o), b = !0);
    },
    o(o) {
      transition_out$9(e.$$.fragment, o), b = !1;
    },
    d(o) {
      o && detach$e(t), destroy_component$6(e);
    }
  };
}
function instance$a(i, t, n) {
  let { hovered: e = !1 } = t;
  return i.$$set = (s) => {
    "hovered" in s && n(0, e = s.hovered);
  }, [e];
}
class PdfUploadText extends SvelteComponent$e {
  constructor(t) {
    super(), init$e(this, t, instance$a, create_fragment$e, safe_not_equal$f, { hovered: 0 });
  }
}
const {
  SvelteComponent: SvelteComponent$d,
  assign: assign$1,
  create_slot: create_slot$3,
  detach: detach$d,
  element: element$9,
  get_all_dirty_from_scope: get_all_dirty_from_scope$3,
  get_slot_changes: get_slot_changes$3,
  get_spread_update: get_spread_update$1,
  init: init$d,
  insert: insert$d,
  safe_not_equal: safe_not_equal$e,
  set_dynamic_element_data,
  set_style: set_style$8,
  toggle_class: toggle_class$8,
  transition_in: transition_in$8,
  transition_out: transition_out$8,
  update_slot_base: update_slot_base$3
} = window.__gradio__svelte__internal;
function create_dynamic_element(i) {
  let t, n, e;
  const s = (
    /*#slots*/
    i[18].default
  ), c = create_slot$3(
    s,
    i,
    /*$$scope*/
    i[17],
    null
  );
  let h = [
    { "data-testid": (
      /*test_id*/
      i[7]
    ) },
    { id: (
      /*elem_id*/
      i[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      i[3].join(" ") + " svelte-nl1om8"
    }
  ], b = {};
  for (let o = 0; o < h.length; o += 1)
    b = assign$1(b, h[o]);
  return {
    c() {
      t = element$9(
        /*tag*/
        i[14]
      ), c && c.c(), set_dynamic_element_data(
        /*tag*/
        i[14]
      )(t, b), toggle_class$8(
        t,
        "hidden",
        /*visible*/
        i[10] === !1
      ), toggle_class$8(
        t,
        "padded",
        /*padding*/
        i[6]
      ), toggle_class$8(
        t,
        "border_focus",
        /*border_mode*/
        i[5] === "focus"
      ), toggle_class$8(
        t,
        "border_contrast",
        /*border_mode*/
        i[5] === "contrast"
      ), toggle_class$8(t, "hide-container", !/*explicit_call*/
      i[8] && !/*container*/
      i[9]), set_style$8(
        t,
        "height",
        /*get_dimension*/
        i[15](
          /*height*/
          i[0]
        )
      ), set_style$8(t, "width", typeof /*width*/
      i[1] == "number" ? `calc(min(${/*width*/
      i[1]}px, 100%))` : (
        /*get_dimension*/
        i[15](
          /*width*/
          i[1]
        )
      )), set_style$8(
        t,
        "border-style",
        /*variant*/
        i[4]
      ), set_style$8(
        t,
        "overflow",
        /*allow_overflow*/
        i[11] ? "visible" : "hidden"
      ), set_style$8(
        t,
        "flex-grow",
        /*scale*/
        i[12]
      ), set_style$8(t, "min-width", `calc(min(${/*min_width*/
      i[13]}px, 100%))`), set_style$8(t, "border-width", "var(--block-border-width)");
    },
    m(o, l) {
      insert$d(o, t, l), c && c.m(t, null), e = !0;
    },
    p(o, l) {
      c && c.p && (!e || l & /*$$scope*/
      131072) && update_slot_base$3(
        c,
        s,
        o,
        /*$$scope*/
        o[17],
        e ? get_slot_changes$3(
          s,
          /*$$scope*/
          o[17],
          l,
          null
        ) : get_all_dirty_from_scope$3(
          /*$$scope*/
          o[17]
        ),
        null
      ), set_dynamic_element_data(
        /*tag*/
        o[14]
      )(t, b = get_spread_update$1(h, [
        (!e || l & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          o[7]
        ) },
        (!e || l & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          o[2]
        ) },
        (!e || l & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        o[3].join(" ") + " svelte-nl1om8")) && { class: n }
      ])), toggle_class$8(
        t,
        "hidden",
        /*visible*/
        o[10] === !1
      ), toggle_class$8(
        t,
        "padded",
        /*padding*/
        o[6]
      ), toggle_class$8(
        t,
        "border_focus",
        /*border_mode*/
        o[5] === "focus"
      ), toggle_class$8(
        t,
        "border_contrast",
        /*border_mode*/
        o[5] === "contrast"
      ), toggle_class$8(t, "hide-container", !/*explicit_call*/
      o[8] && !/*container*/
      o[9]), l & /*height*/
      1 && set_style$8(
        t,
        "height",
        /*get_dimension*/
        o[15](
          /*height*/
          o[0]
        )
      ), l & /*width*/
      2 && set_style$8(t, "width", typeof /*width*/
      o[1] == "number" ? `calc(min(${/*width*/
      o[1]}px, 100%))` : (
        /*get_dimension*/
        o[15](
          /*width*/
          o[1]
        )
      )), l & /*variant*/
      16 && set_style$8(
        t,
        "border-style",
        /*variant*/
        o[4]
      ), l & /*allow_overflow*/
      2048 && set_style$8(
        t,
        "overflow",
        /*allow_overflow*/
        o[11] ? "visible" : "hidden"
      ), l & /*scale*/
      4096 && set_style$8(
        t,
        "flex-grow",
        /*scale*/
        o[12]
      ), l & /*min_width*/
      8192 && set_style$8(t, "min-width", `calc(min(${/*min_width*/
      o[13]}px, 100%))`);
    },
    i(o) {
      e || (transition_in$8(c, o), e = !0);
    },
    o(o) {
      transition_out$8(c, o), e = !1;
    },
    d(o) {
      o && detach$d(t), c && c.d(o);
    }
  };
}
function create_fragment$d(i) {
  let t, n = (
    /*tag*/
    i[14] && create_dynamic_element(i)
  );
  return {
    c() {
      n && n.c();
    },
    m(e, s) {
      n && n.m(e, s), t = !0;
    },
    p(e, [s]) {
      /*tag*/
      e[14] && n.p(e, s);
    },
    i(e) {
      t || (transition_in$8(n, e), t = !0);
    },
    o(e) {
      transition_out$8(n, e), t = !1;
    },
    d(e) {
      n && n.d(e);
    }
  };
}
function instance$9(i, t, n) {
  let { $$slots: e = {}, $$scope: s } = t, { height: c = void 0 } = t, { width: h = void 0 } = t, { elem_id: b = "" } = t, { elem_classes: o = [] } = t, { variant: l = "solid" } = t, { border_mode: a = "base" } = t, { padding: T = !0 } = t, { type: P = "normal" } = t, { test_id: v = void 0 } = t, { explicit_call: k = !1 } = t, { container: x = !0 } = t, { visible: S = !0 } = t, { allow_overflow: E = !0 } = t, { scale: w = null } = t, { min_width: M = 0 } = t, g = P === "fieldset" ? "fieldset" : "div";
  const p = (_) => {
    if (_ !== void 0) {
      if (typeof _ == "number")
        return _ + "px";
      if (typeof _ == "string")
        return _;
    }
  };
  return i.$$set = (_) => {
    "height" in _ && n(0, c = _.height), "width" in _ && n(1, h = _.width), "elem_id" in _ && n(2, b = _.elem_id), "elem_classes" in _ && n(3, o = _.elem_classes), "variant" in _ && n(4, l = _.variant), "border_mode" in _ && n(5, a = _.border_mode), "padding" in _ && n(6, T = _.padding), "type" in _ && n(16, P = _.type), "test_id" in _ && n(7, v = _.test_id), "explicit_call" in _ && n(8, k = _.explicit_call), "container" in _ && n(9, x = _.container), "visible" in _ && n(10, S = _.visible), "allow_overflow" in _ && n(11, E = _.allow_overflow), "scale" in _ && n(12, w = _.scale), "min_width" in _ && n(13, M = _.min_width), "$$scope" in _ && n(17, s = _.$$scope);
  }, [
    c,
    h,
    b,
    o,
    l,
    a,
    T,
    v,
    k,
    x,
    S,
    E,
    w,
    M,
    g,
    p,
    P,
    s,
    e
  ];
}
class Block extends SvelteComponent$d {
  constructor(t) {
    super(), init$d(this, t, instance$9, create_fragment$d, safe_not_equal$e, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: SvelteComponent$c,
  append: append$c,
  attr: attr$c,
  create_component: create_component$5,
  destroy_component: destroy_component$5,
  detach: detach$c,
  element: element$8,
  init: init$c,
  insert: insert$c,
  mount_component: mount_component$5,
  safe_not_equal: safe_not_equal$d,
  set_data: set_data$4,
  space: space$7,
  text: text$4,
  toggle_class: toggle_class$7,
  transition_in: transition_in$7,
  transition_out: transition_out$7
} = window.__gradio__svelte__internal;
function create_fragment$c(i) {
  let t, n, e, s, c, h;
  return e = new /*Icon*/
  i[1]({}), {
    c() {
      t = element$8("label"), n = element$8("span"), create_component$5(e.$$.fragment), s = space$7(), c = text$4(
        /*label*/
        i[0]
      ), attr$c(n, "class", "svelte-9gxdi0"), attr$c(t, "for", ""), attr$c(t, "data-testid", "block-label"), attr$c(t, "class", "svelte-9gxdi0"), toggle_class$7(t, "hide", !/*show_label*/
      i[2]), toggle_class$7(t, "sr-only", !/*show_label*/
      i[2]), toggle_class$7(
        t,
        "float",
        /*float*/
        i[4]
      ), toggle_class$7(
        t,
        "hide-label",
        /*disable*/
        i[3]
      );
    },
    m(b, o) {
      insert$c(b, t, o), append$c(t, n), mount_component$5(e, n, null), append$c(t, s), append$c(t, c), h = !0;
    },
    p(b, [o]) {
      (!h || o & /*label*/
      1) && set_data$4(
        c,
        /*label*/
        b[0]
      ), (!h || o & /*show_label*/
      4) && toggle_class$7(t, "hide", !/*show_label*/
      b[2]), (!h || o & /*show_label*/
      4) && toggle_class$7(t, "sr-only", !/*show_label*/
      b[2]), (!h || o & /*float*/
      16) && toggle_class$7(
        t,
        "float",
        /*float*/
        b[4]
      ), (!h || o & /*disable*/
      8) && toggle_class$7(
        t,
        "hide-label",
        /*disable*/
        b[3]
      );
    },
    i(b) {
      h || (transition_in$7(e.$$.fragment, b), h = !0);
    },
    o(b) {
      transition_out$7(e.$$.fragment, b), h = !1;
    },
    d(b) {
      b && detach$c(t), destroy_component$5(e);
    }
  };
}
function instance$8(i, t, n) {
  let { label: e = null } = t, { Icon: s } = t, { show_label: c = !0 } = t, { disable: h = !1 } = t, { float: b = !0 } = t;
  return i.$$set = (o) => {
    "label" in o && n(0, e = o.label), "Icon" in o && n(1, s = o.Icon), "show_label" in o && n(2, c = o.show_label), "disable" in o && n(3, h = o.disable), "float" in o && n(4, b = o.float);
  }, [e, s, c, h, b];
}
class BlockLabel extends SvelteComponent$c {
  constructor(t) {
    super(), init$c(this, t, instance$8, create_fragment$c, safe_not_equal$d, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: SvelteComponent$b,
  append: append$b,
  attr: attr$b,
  bubble: bubble$3,
  create_component: create_component$4,
  destroy_component: destroy_component$4,
  detach: detach$b,
  element: element$7,
  init: init$b,
  insert: insert$b,
  listen: listen$3,
  mount_component: mount_component$4,
  safe_not_equal: safe_not_equal$c,
  set_data: set_data$3,
  set_style: set_style$7,
  space: space$6,
  text: text$3,
  toggle_class: toggle_class$6,
  transition_in: transition_in$6,
  transition_out: transition_out$6
} = window.__gradio__svelte__internal;
function create_if_block$5(i) {
  let t, n;
  return {
    c() {
      t = element$7("span"), n = text$3(
        /*label*/
        i[1]
      ), attr$b(t, "class", "svelte-1lrphxw");
    },
    m(e, s) {
      insert$b(e, t, s), append$b(t, n);
    },
    p(e, s) {
      s & /*label*/
      2 && set_data$3(
        n,
        /*label*/
        e[1]
      );
    },
    d(e) {
      e && detach$b(t);
    }
  };
}
function create_fragment$b(i) {
  let t, n, e, s, c, h, b, o = (
    /*show_label*/
    i[2] && create_if_block$5(i)
  );
  return s = new /*Icon*/
  i[0]({}), {
    c() {
      t = element$7("button"), o && o.c(), n = space$6(), e = element$7("div"), create_component$4(s.$$.fragment), attr$b(e, "class", "svelte-1lrphxw"), toggle_class$6(
        e,
        "small",
        /*size*/
        i[4] === "small"
      ), toggle_class$6(
        e,
        "large",
        /*size*/
        i[4] === "large"
      ), toggle_class$6(
        e,
        "medium",
        /*size*/
        i[4] === "medium"
      ), t.disabled = /*disabled*/
      i[7], attr$b(
        t,
        "aria-label",
        /*label*/
        i[1]
      ), attr$b(
        t,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), attr$b(
        t,
        "title",
        /*label*/
        i[1]
      ), attr$b(t, "class", "svelte-1lrphxw"), toggle_class$6(
        t,
        "pending",
        /*pending*/
        i[3]
      ), toggle_class$6(
        t,
        "padded",
        /*padded*/
        i[5]
      ), toggle_class$6(
        t,
        "highlight",
        /*highlight*/
        i[6]
      ), toggle_class$6(
        t,
        "transparent",
        /*transparent*/
        i[9]
      ), set_style$7(t, "color", !/*disabled*/
      i[7] && /*_color*/
      i[12] ? (
        /*_color*/
        i[12]
      ) : "var(--block-label-text-color)"), set_style$7(t, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      )), set_style$7(
        t,
        "margin-left",
        /*offset*/
        i[11] + "px"
      );
    },
    m(l, a) {
      insert$b(l, t, a), o && o.m(t, null), append$b(t, n), append$b(t, e), mount_component$4(s, e, null), c = !0, h || (b = listen$3(
        t,
        "click",
        /*click_handler*/
        i[14]
      ), h = !0);
    },
    p(l, [a]) {
      /*show_label*/
      l[2] ? o ? o.p(l, a) : (o = create_if_block$5(l), o.c(), o.m(t, n)) : o && (o.d(1), o = null), (!c || a & /*size*/
      16) && toggle_class$6(
        e,
        "small",
        /*size*/
        l[4] === "small"
      ), (!c || a & /*size*/
      16) && toggle_class$6(
        e,
        "large",
        /*size*/
        l[4] === "large"
      ), (!c || a & /*size*/
      16) && toggle_class$6(
        e,
        "medium",
        /*size*/
        l[4] === "medium"
      ), (!c || a & /*disabled*/
      128) && (t.disabled = /*disabled*/
      l[7]), (!c || a & /*label*/
      2) && attr$b(
        t,
        "aria-label",
        /*label*/
        l[1]
      ), (!c || a & /*hasPopup*/
      256) && attr$b(
        t,
        "aria-haspopup",
        /*hasPopup*/
        l[8]
      ), (!c || a & /*label*/
      2) && attr$b(
        t,
        "title",
        /*label*/
        l[1]
      ), (!c || a & /*pending*/
      8) && toggle_class$6(
        t,
        "pending",
        /*pending*/
        l[3]
      ), (!c || a & /*padded*/
      32) && toggle_class$6(
        t,
        "padded",
        /*padded*/
        l[5]
      ), (!c || a & /*highlight*/
      64) && toggle_class$6(
        t,
        "highlight",
        /*highlight*/
        l[6]
      ), (!c || a & /*transparent*/
      512) && toggle_class$6(
        t,
        "transparent",
        /*transparent*/
        l[9]
      ), a & /*disabled, _color*/
      4224 && set_style$7(t, "color", !/*disabled*/
      l[7] && /*_color*/
      l[12] ? (
        /*_color*/
        l[12]
      ) : "var(--block-label-text-color)"), a & /*disabled, background*/
      1152 && set_style$7(t, "--bg-color", /*disabled*/
      l[7] ? "auto" : (
        /*background*/
        l[10]
      )), a & /*offset*/
      2048 && set_style$7(
        t,
        "margin-left",
        /*offset*/
        l[11] + "px"
      );
    },
    i(l) {
      c || (transition_in$6(s.$$.fragment, l), c = !0);
    },
    o(l) {
      transition_out$6(s.$$.fragment, l), c = !1;
    },
    d(l) {
      l && detach$b(t), o && o.d(), destroy_component$4(s), h = !1, b();
    }
  };
}
function instance$7(i, t, n) {
  let e, { Icon: s } = t, { label: c = "" } = t, { show_label: h = !1 } = t, { pending: b = !1 } = t, { size: o = "small" } = t, { padded: l = !0 } = t, { highlight: a = !1 } = t, { disabled: T = !1 } = t, { hasPopup: P = !1 } = t, { color: v = "var(--block-label-text-color)" } = t, { transparent: k = !1 } = t, { background: x = "var(--background-fill-primary)" } = t, { offset: S = 0 } = t;
  function E(w) {
    bubble$3.call(this, i, w);
  }
  return i.$$set = (w) => {
    "Icon" in w && n(0, s = w.Icon), "label" in w && n(1, c = w.label), "show_label" in w && n(2, h = w.show_label), "pending" in w && n(3, b = w.pending), "size" in w && n(4, o = w.size), "padded" in w && n(5, l = w.padded), "highlight" in w && n(6, a = w.highlight), "disabled" in w && n(7, T = w.disabled), "hasPopup" in w && n(8, P = w.hasPopup), "color" in w && n(13, v = w.color), "transparent" in w && n(9, k = w.transparent), "background" in w && n(10, x = w.background), "offset" in w && n(11, S = w.offset);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    8256 && n(12, e = a ? "var(--color-accent)" : v);
  }, [
    s,
    c,
    h,
    b,
    o,
    l,
    a,
    T,
    P,
    k,
    x,
    S,
    e,
    v,
    E
  ];
}
let IconButton$1 = class extends SvelteComponent$b {
  constructor(t) {
    super(), init$b(this, t, instance$7, create_fragment$b, safe_not_equal$c, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      offset: 11
    });
  }
};
const color_values = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], tw_colors = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
color_values.reduce(
  (i, { color: t, primary: n, secondary: e }) => ({
    ...i,
    [t]: {
      primary: tw_colors[t][n],
      secondary: tw_colors[t][e]
    }
  }),
  {}
);
new Intl.Collator(0, { numeric: 1 }).compare;
function is_url$1(i) {
  try {
    const t = new URL(i);
    return t.protocol === "http:" || t.protocol === "https:";
  } catch {
    return !1;
  }
}
function get_fetchable_url_or_file$1(i, t, n) {
  return i == null ? n ? `/proxy=${n}file=` : `${t}/file=` : is_url$1(i) ? i : n ? `/proxy=${n}file=${i}` : `${t}/file=${i}`;
}
const {
  SvelteComponent: SvelteComponent$a,
  append: append$a,
  attr: attr$a,
  bubble: bubble$2,
  check_outros: check_outros$3,
  create_slot: create_slot$2,
  detach: detach$a,
  element: element$6,
  empty: empty$2,
  get_all_dirty_from_scope: get_all_dirty_from_scope$2,
  get_slot_changes: get_slot_changes$2,
  group_outros: group_outros$3,
  init: init$a,
  insert: insert$a,
  listen: listen$2,
  safe_not_equal: safe_not_equal$b,
  set_style: set_style$6,
  space: space$5,
  src_url_equal,
  toggle_class: toggle_class$5,
  transition_in: transition_in$5,
  transition_out: transition_out$5,
  update_slot_base: update_slot_base$2
} = window.__gradio__svelte__internal;
function create_else_block$2(i) {
  let t, n, e, s, c, h, b = (
    /*icon*/
    i[7] && create_if_block_2$1(i)
  );
  const o = (
    /*#slots*/
    i[15].default
  ), l = create_slot$2(
    o,
    i,
    /*$$scope*/
    i[14],
    null
  );
  return {
    c() {
      t = element$6("button"), b && b.c(), n = space$5(), l && l.c(), attr$a(t, "class", e = /*size*/
      i[4] + " " + /*variant*/
      i[3] + " " + /*elem_classes*/
      i[1].join(" ") + " svelte-8huxfn"), attr$a(
        t,
        "id",
        /*elem_id*/
        i[0]
      ), t.disabled = /*disabled*/
      i[8], toggle_class$5(t, "hidden", !/*visible*/
      i[2]), set_style$6(
        t,
        "flex-grow",
        /*scale*/
        i[9]
      ), set_style$6(
        t,
        "width",
        /*scale*/
        i[9] === 0 ? "fit-content" : null
      ), set_style$6(t, "min-width", typeof /*min_width*/
      i[10] == "number" ? `calc(min(${/*min_width*/
      i[10]}px, 100%))` : null);
    },
    m(a, T) {
      insert$a(a, t, T), b && b.m(t, null), append$a(t, n), l && l.m(t, null), s = !0, c || (h = listen$2(
        t,
        "click",
        /*click_handler*/
        i[16]
      ), c = !0);
    },
    p(a, T) {
      /*icon*/
      a[7] ? b ? b.p(a, T) : (b = create_if_block_2$1(a), b.c(), b.m(t, n)) : b && (b.d(1), b = null), l && l.p && (!s || T & /*$$scope*/
      16384) && update_slot_base$2(
        l,
        o,
        a,
        /*$$scope*/
        a[14],
        s ? get_slot_changes$2(
          o,
          /*$$scope*/
          a[14],
          T,
          null
        ) : get_all_dirty_from_scope$2(
          /*$$scope*/
          a[14]
        ),
        null
      ), (!s || T & /*size, variant, elem_classes*/
      26 && e !== (e = /*size*/
      a[4] + " " + /*variant*/
      a[3] + " " + /*elem_classes*/
      a[1].join(" ") + " svelte-8huxfn")) && attr$a(t, "class", e), (!s || T & /*elem_id*/
      1) && attr$a(
        t,
        "id",
        /*elem_id*/
        a[0]
      ), (!s || T & /*disabled*/
      256) && (t.disabled = /*disabled*/
      a[8]), (!s || T & /*size, variant, elem_classes, visible*/
      30) && toggle_class$5(t, "hidden", !/*visible*/
      a[2]), T & /*scale*/
      512 && set_style$6(
        t,
        "flex-grow",
        /*scale*/
        a[9]
      ), T & /*scale*/
      512 && set_style$6(
        t,
        "width",
        /*scale*/
        a[9] === 0 ? "fit-content" : null
      ), T & /*min_width*/
      1024 && set_style$6(t, "min-width", typeof /*min_width*/
      a[10] == "number" ? `calc(min(${/*min_width*/
      a[10]}px, 100%))` : null);
    },
    i(a) {
      s || (transition_in$5(l, a), s = !0);
    },
    o(a) {
      transition_out$5(l, a), s = !1;
    },
    d(a) {
      a && detach$a(t), b && b.d(), l && l.d(a), c = !1, h();
    }
  };
}
function create_if_block$4(i) {
  let t, n, e, s, c = (
    /*icon*/
    i[7] && create_if_block_1$3(i)
  );
  const h = (
    /*#slots*/
    i[15].default
  ), b = create_slot$2(
    h,
    i,
    /*$$scope*/
    i[14],
    null
  );
  return {
    c() {
      t = element$6("a"), c && c.c(), n = space$5(), b && b.c(), attr$a(
        t,
        "href",
        /*link*/
        i[6]
      ), attr$a(t, "rel", "noopener noreferrer"), attr$a(
        t,
        "aria-disabled",
        /*disabled*/
        i[8]
      ), attr$a(t, "class", e = /*size*/
      i[4] + " " + /*variant*/
      i[3] + " " + /*elem_classes*/
      i[1].join(" ") + " svelte-8huxfn"), attr$a(
        t,
        "id",
        /*elem_id*/
        i[0]
      ), toggle_class$5(t, "hidden", !/*visible*/
      i[2]), toggle_class$5(
        t,
        "disabled",
        /*disabled*/
        i[8]
      ), set_style$6(
        t,
        "flex-grow",
        /*scale*/
        i[9]
      ), set_style$6(
        t,
        "pointer-events",
        /*disabled*/
        i[8] ? "none" : null
      ), set_style$6(
        t,
        "width",
        /*scale*/
        i[9] === 0 ? "fit-content" : null
      ), set_style$6(t, "min-width", typeof /*min_width*/
      i[10] == "number" ? `calc(min(${/*min_width*/
      i[10]}px, 100%))` : null);
    },
    m(o, l) {
      insert$a(o, t, l), c && c.m(t, null), append$a(t, n), b && b.m(t, null), s = !0;
    },
    p(o, l) {
      /*icon*/
      o[7] ? c ? c.p(o, l) : (c = create_if_block_1$3(o), c.c(), c.m(t, n)) : c && (c.d(1), c = null), b && b.p && (!s || l & /*$$scope*/
      16384) && update_slot_base$2(
        b,
        h,
        o,
        /*$$scope*/
        o[14],
        s ? get_slot_changes$2(
          h,
          /*$$scope*/
          o[14],
          l,
          null
        ) : get_all_dirty_from_scope$2(
          /*$$scope*/
          o[14]
        ),
        null
      ), (!s || l & /*link*/
      64) && attr$a(
        t,
        "href",
        /*link*/
        o[6]
      ), (!s || l & /*disabled*/
      256) && attr$a(
        t,
        "aria-disabled",
        /*disabled*/
        o[8]
      ), (!s || l & /*size, variant, elem_classes*/
      26 && e !== (e = /*size*/
      o[4] + " " + /*variant*/
      o[3] + " " + /*elem_classes*/
      o[1].join(" ") + " svelte-8huxfn")) && attr$a(t, "class", e), (!s || l & /*elem_id*/
      1) && attr$a(
        t,
        "id",
        /*elem_id*/
        o[0]
      ), (!s || l & /*size, variant, elem_classes, visible*/
      30) && toggle_class$5(t, "hidden", !/*visible*/
      o[2]), (!s || l & /*size, variant, elem_classes, disabled*/
      282) && toggle_class$5(
        t,
        "disabled",
        /*disabled*/
        o[8]
      ), l & /*scale*/
      512 && set_style$6(
        t,
        "flex-grow",
        /*scale*/
        o[9]
      ), l & /*disabled*/
      256 && set_style$6(
        t,
        "pointer-events",
        /*disabled*/
        o[8] ? "none" : null
      ), l & /*scale*/
      512 && set_style$6(
        t,
        "width",
        /*scale*/
        o[9] === 0 ? "fit-content" : null
      ), l & /*min_width*/
      1024 && set_style$6(t, "min-width", typeof /*min_width*/
      o[10] == "number" ? `calc(min(${/*min_width*/
      o[10]}px, 100%))` : null);
    },
    i(o) {
      s || (transition_in$5(b, o), s = !0);
    },
    o(o) {
      transition_out$5(b, o), s = !1;
    },
    d(o) {
      o && detach$a(t), c && c.d(), b && b.d(o);
    }
  };
}
function create_if_block_2$1(i) {
  let t, n, e;
  return {
    c() {
      t = element$6("img"), attr$a(t, "class", "button-icon svelte-8huxfn"), src_url_equal(t.src, n = /*icon_path*/
      i[11]) || attr$a(t, "src", n), attr$a(t, "alt", e = `${/*value*/
      i[5]} icon`);
    },
    m(s, c) {
      insert$a(s, t, c);
    },
    p(s, c) {
      c & /*icon_path*/
      2048 && !src_url_equal(t.src, n = /*icon_path*/
      s[11]) && attr$a(t, "src", n), c & /*value*/
      32 && e !== (e = `${/*value*/
      s[5]} icon`) && attr$a(t, "alt", e);
    },
    d(s) {
      s && detach$a(t);
    }
  };
}
function create_if_block_1$3(i) {
  let t, n, e;
  return {
    c() {
      t = element$6("img"), attr$a(t, "class", "button-icon svelte-8huxfn"), src_url_equal(t.src, n = /*icon_path*/
      i[11]) || attr$a(t, "src", n), attr$a(t, "alt", e = `${/*value*/
      i[5]} icon`);
    },
    m(s, c) {
      insert$a(s, t, c);
    },
    p(s, c) {
      c & /*icon_path*/
      2048 && !src_url_equal(t.src, n = /*icon_path*/
      s[11]) && attr$a(t, "src", n), c & /*value*/
      32 && e !== (e = `${/*value*/
      s[5]} icon`) && attr$a(t, "alt", e);
    },
    d(s) {
      s && detach$a(t);
    }
  };
}
function create_fragment$a(i) {
  let t, n, e, s;
  const c = [create_if_block$4, create_else_block$2], h = [];
  function b(o, l) {
    return (
      /*link*/
      o[6] && /*link*/
      o[6].length > 0 ? 0 : 1
    );
  }
  return t = b(i), n = h[t] = c[t](i), {
    c() {
      n.c(), e = empty$2();
    },
    m(o, l) {
      h[t].m(o, l), insert$a(o, e, l), s = !0;
    },
    p(o, [l]) {
      let a = t;
      t = b(o), t === a ? h[t].p(o, l) : (group_outros$3(), transition_out$5(h[a], 1, 1, () => {
        h[a] = null;
      }), check_outros$3(), n = h[t], n ? n.p(o, l) : (n = h[t] = c[t](o), n.c()), transition_in$5(n, 1), n.m(e.parentNode, e));
    },
    i(o) {
      s || (transition_in$5(n), s = !0);
    },
    o(o) {
      transition_out$5(n), s = !1;
    },
    d(o) {
      o && detach$a(e), h[t].d(o);
    }
  };
}
function instance$6(i, t, n) {
  let e, { $$slots: s = {}, $$scope: c } = t, { elem_id: h = "" } = t, { elem_classes: b = [] } = t, { visible: o = !0 } = t, { variant: l = "secondary" } = t, { size: a = "lg" } = t, { value: T = null } = t, { link: P = null } = t, { icon: v = null } = t, { disabled: k = !1 } = t, { scale: x = null } = t, { min_width: S = void 0 } = t, { root: E = "" } = t, { proxy_url: w = null } = t;
  function M(g) {
    bubble$2.call(this, i, g);
  }
  return i.$$set = (g) => {
    "elem_id" in g && n(0, h = g.elem_id), "elem_classes" in g && n(1, b = g.elem_classes), "visible" in g && n(2, o = g.visible), "variant" in g && n(3, l = g.variant), "size" in g && n(4, a = g.size), "value" in g && n(5, T = g.value), "link" in g && n(6, P = g.link), "icon" in g && n(7, v = g.icon), "disabled" in g && n(8, k = g.disabled), "scale" in g && n(9, x = g.scale), "min_width" in g && n(10, S = g.min_width), "root" in g && n(12, E = g.root), "proxy_url" in g && n(13, w = g.proxy_url), "$$scope" in g && n(14, c = g.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*icon, root, proxy_url*/
    12416 && n(11, e = get_fetchable_url_or_file$1(v, E, w));
  }, [
    h,
    b,
    o,
    l,
    a,
    T,
    P,
    v,
    k,
    x,
    S,
    e,
    E,
    w,
    c,
    s,
    M
  ];
}
class Button extends SvelteComponent$a {
  constructor(t) {
    super(), init$a(this, t, instance$6, create_fragment$a, safe_not_equal$b, {
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      variant: 3,
      size: 4,
      value: 5,
      link: 6,
      icon: 7,
      disabled: 8,
      scale: 9,
      min_width: 10,
      root: 12,
      proxy_url: 13
    });
  }
}
function pretty_si(i) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; i > 1e3 && n < t.length - 1; )
    i /= 1e3, n++;
  let e = t[n];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + e;
}
function noop$6() {
}
function safe_not_equal$a(i, t) {
  return i != i ? t == t : i !== t || i && typeof i == "object" || typeof i == "function";
}
const is_client = typeof window < "u";
let now = is_client ? () => window.performance.now() : () => Date.now(), raf = is_client ? (i) => requestAnimationFrame(i) : noop$6;
const tasks = /* @__PURE__ */ new Set();
function run_tasks(i) {
  tasks.forEach((t) => {
    t.c(i) || (tasks.delete(t), t.f());
  }), tasks.size !== 0 && raf(run_tasks);
}
function loop(i) {
  let t;
  return tasks.size === 0 && raf(run_tasks), {
    promise: new Promise((n) => {
      tasks.add(t = { c: i, f: n });
    }),
    abort() {
      tasks.delete(t);
    }
  };
}
const subscriber_queue = [];
function writable(i, t = noop$6) {
  let n;
  const e = /* @__PURE__ */ new Set();
  function s(b) {
    if (safe_not_equal$a(i, b) && (i = b, n)) {
      const o = !subscriber_queue.length;
      for (const l of e)
        l[1](), subscriber_queue.push(l, i);
      if (o) {
        for (let l = 0; l < subscriber_queue.length; l += 2)
          subscriber_queue[l][0](subscriber_queue[l + 1]);
        subscriber_queue.length = 0;
      }
    }
  }
  function c(b) {
    s(b(i));
  }
  function h(b, o = noop$6) {
    const l = [b, o];
    return e.add(l), e.size === 1 && (n = t(s, c) || noop$6), b(i), () => {
      e.delete(l), e.size === 0 && n && (n(), n = null);
    };
  }
  return { set: s, update: c, subscribe: h };
}
function is_date(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function tick_spring(i, t, n, e) {
  if (typeof n == "number" || is_date(n)) {
    const s = e - n, c = (n - t) / (i.dt || 1 / 60), h = i.opts.stiffness * s, b = i.opts.damping * c, o = (h - b) * i.inv_mass, l = (c + o) * i.dt;
    return Math.abs(l) < i.opts.precision && Math.abs(s) < i.opts.precision ? e : (i.settled = !1, is_date(n) ? new Date(n.getTime() + l) : n + l);
  } else {
    if (Array.isArray(n))
      return n.map(
        (s, c) => tick_spring(i, t[c], n[c], e[c])
      );
    if (typeof n == "object") {
      const s = {};
      for (const c in n)
        s[c] = tick_spring(i, t[c], n[c], e[c]);
      return s;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function spring(i, t = {}) {
  const n = writable(i), { stiffness: e = 0.15, damping: s = 0.8, precision: c = 0.01 } = t;
  let h, b, o, l = i, a = i, T = 1, P = 0, v = !1;
  function k(S, E = {}) {
    a = S;
    const w = o = {};
    return i == null || E.hard || x.stiffness >= 1 && x.damping >= 1 ? (v = !0, h = now(), l = S, n.set(i = a), Promise.resolve()) : (E.soft && (P = 1 / ((E.soft === !0 ? 0.5 : +E.soft) * 60), T = 0), b || (h = now(), v = !1, b = loop((M) => {
      if (v)
        return v = !1, b = null, !1;
      T = Math.min(T + P, 1);
      const g = {
        inv_mass: T,
        opts: x,
        settled: !0,
        dt: (M - h) * 60 / 1e3
      }, p = tick_spring(g, l, i, a);
      return h = M, l = i, n.set(i = p), g.settled && (b = null), !g.settled;
    })), new Promise((M) => {
      b.promise.then(() => {
        w === o && M();
      });
    }));
  }
  const x = {
    set: k,
    update: (S, E) => k(S(a, i), E),
    subscribe: n.subscribe,
    stiffness: e,
    damping: s,
    precision: c
  };
  return x;
}
const {
  SvelteComponent: SvelteComponent$9,
  append: append$9,
  attr: attr$9,
  component_subscribe,
  detach: detach$9,
  element: element$5,
  init: init$9,
  insert: insert$9,
  noop: noop$5,
  safe_not_equal: safe_not_equal$9,
  set_style: set_style$5,
  svg_element: svg_element$4,
  toggle_class: toggle_class$4
} = window.__gradio__svelte__internal, { onMount } = window.__gradio__svelte__internal;
function create_fragment$9(i) {
  let t, n, e, s, c, h, b, o, l, a, T, P;
  return {
    c() {
      t = element$5("div"), n = svg_element$4("svg"), e = svg_element$4("g"), s = svg_element$4("path"), c = svg_element$4("path"), h = svg_element$4("path"), b = svg_element$4("path"), o = svg_element$4("g"), l = svg_element$4("path"), a = svg_element$4("path"), T = svg_element$4("path"), P = svg_element$4("path"), attr$9(s, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), attr$9(s, "fill", "#FF7C00"), attr$9(s, "fill-opacity", "0.4"), attr$9(s, "class", "svelte-43sxxs"), attr$9(c, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), attr$9(c, "fill", "#FF7C00"), attr$9(c, "class", "svelte-43sxxs"), attr$9(h, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), attr$9(h, "fill", "#FF7C00"), attr$9(h, "fill-opacity", "0.4"), attr$9(h, "class", "svelte-43sxxs"), attr$9(b, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), attr$9(b, "fill", "#FF7C00"), attr$9(b, "class", "svelte-43sxxs"), set_style$5(e, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), attr$9(l, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), attr$9(l, "fill", "#FF7C00"), attr$9(l, "fill-opacity", "0.4"), attr$9(l, "class", "svelte-43sxxs"), attr$9(a, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), attr$9(a, "fill", "#FF7C00"), attr$9(a, "class", "svelte-43sxxs"), attr$9(T, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), attr$9(T, "fill", "#FF7C00"), attr$9(T, "fill-opacity", "0.4"), attr$9(T, "class", "svelte-43sxxs"), attr$9(P, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), attr$9(P, "fill", "#FF7C00"), attr$9(P, "class", "svelte-43sxxs"), set_style$5(o, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), attr$9(n, "viewBox", "-1200 -1200 3000 3000"), attr$9(n, "fill", "none"), attr$9(n, "xmlns", "http://www.w3.org/2000/svg"), attr$9(n, "class", "svelte-43sxxs"), attr$9(t, "class", "svelte-43sxxs"), toggle_class$4(
        t,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(v, k) {
      insert$9(v, t, k), append$9(t, n), append$9(n, e), append$9(e, s), append$9(e, c), append$9(e, h), append$9(e, b), append$9(n, o), append$9(o, l), append$9(o, a), append$9(o, T), append$9(o, P);
    },
    p(v, [k]) {
      k & /*$top*/
      2 && set_style$5(e, "transform", "translate(" + /*$top*/
      v[1][0] + "px, " + /*$top*/
      v[1][1] + "px)"), k & /*$bottom*/
      4 && set_style$5(o, "transform", "translate(" + /*$bottom*/
      v[2][0] + "px, " + /*$bottom*/
      v[2][1] + "px)"), k & /*margin*/
      1 && toggle_class$4(
        t,
        "margin",
        /*margin*/
        v[0]
      );
    },
    i: noop$5,
    o: noop$5,
    d(v) {
      v && detach$9(t);
    }
  };
}
function instance$5(i, t, n) {
  let e, s;
  var c = this && this.__awaiter || function(v, k, x, S) {
    function E(w) {
      return w instanceof x ? w : new x(function(M) {
        M(w);
      });
    }
    return new (x || (x = Promise))(function(w, M) {
      function g(f) {
        try {
          _(S.next(f));
        } catch (A) {
          M(A);
        }
      }
      function p(f) {
        try {
          _(S.throw(f));
        } catch (A) {
          M(A);
        }
      }
      function _(f) {
        f.done ? w(f.value) : E(f.value).then(g, p);
      }
      _((S = S.apply(v, k || [])).next());
    });
  };
  let { margin: h = !0 } = t;
  const b = spring([0, 0]);
  component_subscribe(i, b, (v) => n(1, e = v));
  const o = spring([0, 0]);
  component_subscribe(i, o, (v) => n(2, s = v));
  let l;
  function a() {
    return c(this, void 0, void 0, function* () {
      yield Promise.all([b.set([125, 140]), o.set([-125, -140])]), yield Promise.all([b.set([-125, 140]), o.set([125, -140])]), yield Promise.all([b.set([-125, 0]), o.set([125, -0])]), yield Promise.all([b.set([125, 0]), o.set([-125, 0])]);
    });
  }
  function T() {
    return c(this, void 0, void 0, function* () {
      yield a(), l || T();
    });
  }
  function P() {
    return c(this, void 0, void 0, function* () {
      yield Promise.all([b.set([125, 0]), o.set([-125, 0])]), T();
    });
  }
  return onMount(() => (P(), () => l = !0)), i.$$set = (v) => {
    "margin" in v && n(0, h = v.margin);
  }, [h, e, s, b, o];
}
class Loader extends SvelteComponent$9 {
  constructor(t) {
    super(), init$9(this, t, instance$5, create_fragment$9, safe_not_equal$9, { margin: 0 });
  }
}
const {
  SvelteComponent: SvelteComponent$8,
  append: append$8,
  attr: attr$8,
  detach: detach$8,
  init: init$8,
  insert: insert$8,
  noop: noop$4,
  safe_not_equal: safe_not_equal$8,
  set_style: set_style$4,
  svg_element: svg_element$3
} = window.__gradio__svelte__internal;
function create_fragment$8(i) {
  let t, n, e, s;
  return {
    c() {
      t = svg_element$3("svg"), n = svg_element$3("g"), e = svg_element$3("path"), s = svg_element$3("path"), attr$8(e, "d", "M18,6L6.087,17.913"), set_style$4(e, "fill", "none"), set_style$4(e, "fill-rule", "nonzero"), set_style$4(e, "stroke-width", "2px"), attr$8(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), attr$8(s, "d", "M4.364,4.364L19.636,19.636"), set_style$4(s, "fill", "none"), set_style$4(s, "fill-rule", "nonzero"), set_style$4(s, "stroke-width", "2px"), attr$8(t, "width", "100%"), attr$8(t, "height", "100%"), attr$8(t, "viewBox", "0 0 24 24"), attr$8(t, "version", "1.1"), attr$8(t, "xmlns", "http://www.w3.org/2000/svg"), attr$8(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), attr$8(t, "xml:space", "preserve"), attr$8(t, "stroke", "currentColor"), set_style$4(t, "fill-rule", "evenodd"), set_style$4(t, "clip-rule", "evenodd"), set_style$4(t, "stroke-linecap", "round"), set_style$4(t, "stroke-linejoin", "round");
    },
    m(c, h) {
      insert$8(c, t, h), append$8(t, n), append$8(n, e), append$8(t, s);
    },
    p: noop$4,
    i: noop$4,
    o: noop$4,
    d(c) {
      c && detach$8(t);
    }
  };
}
let Clear$1 = class extends SvelteComponent$8 {
  constructor(t) {
    super(), init$8(this, t, null, create_fragment$8, safe_not_equal$8, {});
  }
};
const {
  SvelteComponent: SvelteComponent$7,
  append: append$7,
  attr: attr$7,
  binding_callbacks: binding_callbacks$2,
  check_outros: check_outros$2,
  create_component: create_component$3,
  create_slot: create_slot$1,
  destroy_component: destroy_component$3,
  destroy_each,
  detach: detach$7,
  element: element$4,
  empty: empty$1,
  ensure_array_like,
  get_all_dirty_from_scope: get_all_dirty_from_scope$1,
  get_slot_changes: get_slot_changes$1,
  group_outros: group_outros$2,
  init: init$7,
  insert: insert$7,
  mount_component: mount_component$3,
  noop: noop$3,
  safe_not_equal: safe_not_equal$7,
  set_data: set_data$2,
  set_style: set_style$3,
  space: space$4,
  text: text$2,
  toggle_class: toggle_class$3,
  transition_in: transition_in$4,
  transition_out: transition_out$4,
  update_slot_base: update_slot_base$1
} = window.__gradio__svelte__internal, { tick: tick$2 } = window.__gradio__svelte__internal, { onDestroy } = window.__gradio__svelte__internal, { createEventDispatcher: createEventDispatcher$2 } = window.__gradio__svelte__internal, get_error_slot_changes = (i) => ({}), get_error_slot_context = (i) => ({}), get_additional_loading_text_slot_changes = (i) => ({}), get_additional_loading_text_slot_context = (i) => ({});
function get_each_context(i, t, n) {
  const e = i.slice();
  return e[41] = t[n], e[43] = n, e;
}
function get_each_context_1(i, t, n) {
  const e = i.slice();
  return e[41] = t[n], e;
}
function create_if_block_17(i) {
  let t, n, e, s, c = (
    /*i18n*/
    i[1]("common.error") + ""
  ), h, b, o;
  n = new IconButton$1({
    props: {
      Icon: Clear$1,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), n.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const l = (
    /*#slots*/
    i[30].error
  ), a = create_slot$1(
    l,
    i,
    /*$$scope*/
    i[29],
    get_error_slot_context
  );
  return {
    c() {
      t = element$4("div"), create_component$3(n.$$.fragment), e = space$4(), s = element$4("span"), h = text$2(c), b = space$4(), a && a.c(), attr$7(t, "class", "clear-status svelte-v0wucf"), attr$7(s, "class", "error svelte-v0wucf");
    },
    m(T, P) {
      insert$7(T, t, P), mount_component$3(n, t, null), insert$7(T, e, P), insert$7(T, s, P), append$7(s, h), insert$7(T, b, P), a && a.m(T, P), o = !0;
    },
    p(T, P) {
      const v = {};
      P[0] & /*i18n*/
      2 && (v.label = /*i18n*/
      T[1]("common.clear")), n.$set(v), (!o || P[0] & /*i18n*/
      2) && c !== (c = /*i18n*/
      T[1]("common.error") + "") && set_data$2(h, c), a && a.p && (!o || P[0] & /*$$scope*/
      536870912) && update_slot_base$1(
        a,
        l,
        T,
        /*$$scope*/
        T[29],
        o ? get_slot_changes$1(
          l,
          /*$$scope*/
          T[29],
          P,
          get_error_slot_changes
        ) : get_all_dirty_from_scope$1(
          /*$$scope*/
          T[29]
        ),
        get_error_slot_context
      );
    },
    i(T) {
      o || (transition_in$4(n.$$.fragment, T), transition_in$4(a, T), o = !0);
    },
    o(T) {
      transition_out$4(n.$$.fragment, T), transition_out$4(a, T), o = !1;
    },
    d(T) {
      T && (detach$7(t), detach$7(e), detach$7(s), detach$7(b)), destroy_component$3(n), a && a.d(T);
    }
  };
}
function create_if_block$3(i) {
  let t, n, e, s, c, h, b, o, l, a = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && create_if_block_16(i)
  );
  function T(M, g) {
    if (
      /*progress*/
      M[7]
    ) return create_if_block_11;
    if (
      /*queue_position*/
      M[2] !== null && /*queue_size*/
      M[3] !== void 0 && /*queue_position*/
      M[2] >= 0
    ) return create_if_block_14;
    if (
      /*queue_position*/
      M[2] === 0
    ) return create_if_block_15;
  }
  let P = T(i), v = P && P(i), k = (
    /*timer*/
    i[5] && create_if_block_10(i)
  );
  const x = [create_if_block_2, create_if_block_9], S = [];
  function E(M, g) {
    return (
      /*last_progress_level*/
      M[15] != null ? 0 : (
        /*show_progress*/
        M[6] === "full" ? 1 : -1
      )
    );
  }
  ~(c = E(i)) && (h = S[c] = x[c](i));
  let w = !/*timer*/
  i[5] && create_if_block_1$2(i);
  return {
    c() {
      a && a.c(), t = space$4(), n = element$4("div"), v && v.c(), e = space$4(), k && k.c(), s = space$4(), h && h.c(), b = space$4(), w && w.c(), o = empty$1(), attr$7(n, "class", "progress-text svelte-v0wucf"), toggle_class$3(
        n,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), toggle_class$3(
        n,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(M, g) {
      a && a.m(M, g), insert$7(M, t, g), insert$7(M, n, g), v && v.m(n, null), append$7(n, e), k && k.m(n, null), insert$7(M, s, g), ~c && S[c].m(M, g), insert$7(M, b, g), w && w.m(M, g), insert$7(M, o, g), l = !0;
    },
    p(M, g) {
      /*variant*/
      M[8] === "default" && /*show_eta_bar*/
      M[18] && /*show_progress*/
      M[6] === "full" ? a ? a.p(M, g) : (a = create_if_block_16(M), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null), P === (P = T(M)) && v ? v.p(M, g) : (v && v.d(1), v = P && P(M), v && (v.c(), v.m(n, e))), /*timer*/
      M[5] ? k ? k.p(M, g) : (k = create_if_block_10(M), k.c(), k.m(n, null)) : k && (k.d(1), k = null), (!l || g[0] & /*variant*/
      256) && toggle_class$3(
        n,
        "meta-text-center",
        /*variant*/
        M[8] === "center"
      ), (!l || g[0] & /*variant*/
      256) && toggle_class$3(
        n,
        "meta-text",
        /*variant*/
        M[8] === "default"
      );
      let p = c;
      c = E(M), c === p ? ~c && S[c].p(M, g) : (h && (group_outros$2(), transition_out$4(S[p], 1, 1, () => {
        S[p] = null;
      }), check_outros$2()), ~c ? (h = S[c], h ? h.p(M, g) : (h = S[c] = x[c](M), h.c()), transition_in$4(h, 1), h.m(b.parentNode, b)) : h = null), /*timer*/
      M[5] ? w && (group_outros$2(), transition_out$4(w, 1, 1, () => {
        w = null;
      }), check_outros$2()) : w ? (w.p(M, g), g[0] & /*timer*/
      32 && transition_in$4(w, 1)) : (w = create_if_block_1$2(M), w.c(), transition_in$4(w, 1), w.m(o.parentNode, o));
    },
    i(M) {
      l || (transition_in$4(h), transition_in$4(w), l = !0);
    },
    o(M) {
      transition_out$4(h), transition_out$4(w), l = !1;
    },
    d(M) {
      M && (detach$7(t), detach$7(n), detach$7(s), detach$7(b), detach$7(o)), a && a.d(M), v && v.d(), k && k.d(), ~c && S[c].d(M), w && w.d(M);
    }
  };
}
function create_if_block_16(i) {
  let t, n = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = element$4("div"), attr$7(t, "class", "eta-bar svelte-v0wucf"), set_style$3(t, "transform", n);
    },
    m(e, s) {
      insert$7(e, t, s);
    },
    p(e, s) {
      s[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (e[17] || 0) * 100 - 100}%)`) && set_style$3(t, "transform", n);
    },
    d(e) {
      e && detach$7(t);
    }
  };
}
function create_if_block_15(i) {
  let t;
  return {
    c() {
      t = text$2("processing |");
    },
    m(n, e) {
      insert$7(n, t, e);
    },
    p: noop$3,
    d(n) {
      n && detach$7(t);
    }
  };
}
function create_if_block_14(i) {
  let t, n = (
    /*queue_position*/
    i[2] + 1 + ""
  ), e, s, c, h;
  return {
    c() {
      t = text$2("queue: "), e = text$2(n), s = text$2("/"), c = text$2(
        /*queue_size*/
        i[3]
      ), h = text$2(" |");
    },
    m(b, o) {
      insert$7(b, t, o), insert$7(b, e, o), insert$7(b, s, o), insert$7(b, c, o), insert$7(b, h, o);
    },
    p(b, o) {
      o[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      b[2] + 1 + "") && set_data$2(e, n), o[0] & /*queue_size*/
      8 && set_data$2(
        c,
        /*queue_size*/
        b[3]
      );
    },
    d(b) {
      b && (detach$7(t), detach$7(e), detach$7(s), detach$7(c), detach$7(h));
    }
  };
}
function create_if_block_11(i) {
  let t, n = ensure_array_like(
    /*progress*/
    i[7]
  ), e = [];
  for (let s = 0; s < n.length; s += 1)
    e[s] = create_each_block_1(get_each_context_1(i, n, s));
  return {
    c() {
      for (let s = 0; s < e.length; s += 1)
        e[s].c();
      t = empty$1();
    },
    m(s, c) {
      for (let h = 0; h < e.length; h += 1)
        e[h] && e[h].m(s, c);
      insert$7(s, t, c);
    },
    p(s, c) {
      if (c[0] & /*progress*/
      128) {
        n = ensure_array_like(
          /*progress*/
          s[7]
        );
        let h;
        for (h = 0; h < n.length; h += 1) {
          const b = get_each_context_1(s, n, h);
          e[h] ? e[h].p(b, c) : (e[h] = create_each_block_1(b), e[h].c(), e[h].m(t.parentNode, t));
        }
        for (; h < e.length; h += 1)
          e[h].d(1);
        e.length = n.length;
      }
    },
    d(s) {
      s && detach$7(t), destroy_each(e, s);
    }
  };
}
function create_if_block_12(i) {
  let t, n = (
    /*p*/
    i[41].unit + ""
  ), e, s, c = " ", h;
  function b(a, T) {
    return (
      /*p*/
      a[41].length != null ? create_if_block_13 : create_else_block$1
    );
  }
  let o = b(i), l = o(i);
  return {
    c() {
      l.c(), t = space$4(), e = text$2(n), s = text$2(" | "), h = text$2(c);
    },
    m(a, T) {
      l.m(a, T), insert$7(a, t, T), insert$7(a, e, T), insert$7(a, s, T), insert$7(a, h, T);
    },
    p(a, T) {
      o === (o = b(a)) && l ? l.p(a, T) : (l.d(1), l = o(a), l && (l.c(), l.m(t.parentNode, t))), T[0] & /*progress*/
      128 && n !== (n = /*p*/
      a[41].unit + "") && set_data$2(e, n);
    },
    d(a) {
      a && (detach$7(t), detach$7(e), detach$7(s), detach$7(h)), l.d(a);
    }
  };
}
function create_else_block$1(i) {
  let t = pretty_si(
    /*p*/
    i[41].index || 0
  ) + "", n;
  return {
    c() {
      n = text$2(t);
    },
    m(e, s) {
      insert$7(e, n, s);
    },
    p(e, s) {
      s[0] & /*progress*/
      128 && t !== (t = pretty_si(
        /*p*/
        e[41].index || 0
      ) + "") && set_data$2(n, t);
    },
    d(e) {
      e && detach$7(n);
    }
  };
}
function create_if_block_13(i) {
  let t = pretty_si(
    /*p*/
    i[41].index || 0
  ) + "", n, e, s = pretty_si(
    /*p*/
    i[41].length
  ) + "", c;
  return {
    c() {
      n = text$2(t), e = text$2("/"), c = text$2(s);
    },
    m(h, b) {
      insert$7(h, n, b), insert$7(h, e, b), insert$7(h, c, b);
    },
    p(h, b) {
      b[0] & /*progress*/
      128 && t !== (t = pretty_si(
        /*p*/
        h[41].index || 0
      ) + "") && set_data$2(n, t), b[0] & /*progress*/
      128 && s !== (s = pretty_si(
        /*p*/
        h[41].length
      ) + "") && set_data$2(c, s);
    },
    d(h) {
      h && (detach$7(n), detach$7(e), detach$7(c));
    }
  };
}
function create_each_block_1(i) {
  let t, n = (
    /*p*/
    i[41].index != null && create_if_block_12(i)
  );
  return {
    c() {
      n && n.c(), t = empty$1();
    },
    m(e, s) {
      n && n.m(e, s), insert$7(e, t, s);
    },
    p(e, s) {
      /*p*/
      e[41].index != null ? n ? n.p(e, s) : (n = create_if_block_12(e), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(e) {
      e && detach$7(t), n && n.d(e);
    }
  };
}
function create_if_block_10(i) {
  let t, n = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), e, s;
  return {
    c() {
      t = text$2(
        /*formatted_timer*/
        i[20]
      ), e = text$2(n), s = text$2("s");
    },
    m(c, h) {
      insert$7(c, t, h), insert$7(c, e, h), insert$7(c, s, h);
    },
    p(c, h) {
      h[0] & /*formatted_timer*/
      1048576 && set_data$2(
        t,
        /*formatted_timer*/
        c[20]
      ), h[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      c[0] ? `/${/*formatted_eta*/
      c[19]}` : "") && set_data$2(e, n);
    },
    d(c) {
      c && (detach$7(t), detach$7(e), detach$7(s));
    }
  };
}
function create_if_block_9(i) {
  let t, n;
  return t = new Loader({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      create_component$3(t.$$.fragment);
    },
    m(e, s) {
      mount_component$3(t, e, s), n = !0;
    },
    p(e, s) {
      const c = {};
      s[0] & /*variant*/
      256 && (c.margin = /*variant*/
      e[8] === "default"), t.$set(c);
    },
    i(e) {
      n || (transition_in$4(t.$$.fragment, e), n = !0);
    },
    o(e) {
      transition_out$4(t.$$.fragment, e), n = !1;
    },
    d(e) {
      destroy_component$3(t, e);
    }
  };
}
function create_if_block_2(i) {
  let t, n, e, s, c, h = `${/*last_progress_level*/
  i[15] * 100}%`, b = (
    /*progress*/
    i[7] != null && create_if_block_3(i)
  );
  return {
    c() {
      t = element$4("div"), n = element$4("div"), b && b.c(), e = space$4(), s = element$4("div"), c = element$4("div"), attr$7(n, "class", "progress-level-inner svelte-v0wucf"), attr$7(c, "class", "progress-bar svelte-v0wucf"), set_style$3(c, "width", h), attr$7(s, "class", "progress-bar-wrap svelte-v0wucf"), attr$7(t, "class", "progress-level svelte-v0wucf");
    },
    m(o, l) {
      insert$7(o, t, l), append$7(t, n), b && b.m(n, null), append$7(t, e), append$7(t, s), append$7(s, c), i[31](c);
    },
    p(o, l) {
      /*progress*/
      o[7] != null ? b ? b.p(o, l) : (b = create_if_block_3(o), b.c(), b.m(n, null)) : b && (b.d(1), b = null), l[0] & /*last_progress_level*/
      32768 && h !== (h = `${/*last_progress_level*/
      o[15] * 100}%`) && set_style$3(c, "width", h);
    },
    i: noop$3,
    o: noop$3,
    d(o) {
      o && detach$7(t), b && b.d(), i[31](null);
    }
  };
}
function create_if_block_3(i) {
  let t, n = ensure_array_like(
    /*progress*/
    i[7]
  ), e = [];
  for (let s = 0; s < n.length; s += 1)
    e[s] = create_each_block(get_each_context(i, n, s));
  return {
    c() {
      for (let s = 0; s < e.length; s += 1)
        e[s].c();
      t = empty$1();
    },
    m(s, c) {
      for (let h = 0; h < e.length; h += 1)
        e[h] && e[h].m(s, c);
      insert$7(s, t, c);
    },
    p(s, c) {
      if (c[0] & /*progress_level, progress*/
      16512) {
        n = ensure_array_like(
          /*progress*/
          s[7]
        );
        let h;
        for (h = 0; h < n.length; h += 1) {
          const b = get_each_context(s, n, h);
          e[h] ? e[h].p(b, c) : (e[h] = create_each_block(b), e[h].c(), e[h].m(t.parentNode, t));
        }
        for (; h < e.length; h += 1)
          e[h].d(1);
        e.length = n.length;
      }
    },
    d(s) {
      s && detach$7(t), destroy_each(e, s);
    }
  };
}
function create_if_block_4(i) {
  let t, n, e, s, c = (
    /*i*/
    i[43] !== 0 && create_if_block_8()
  ), h = (
    /*p*/
    i[41].desc != null && create_if_block_7(i)
  ), b = (
    /*p*/
    i[41].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[43]
    ] != null && create_if_block_6()
  ), o = (
    /*progress_level*/
    i[14] != null && create_if_block_5(i)
  );
  return {
    c() {
      c && c.c(), t = space$4(), h && h.c(), n = space$4(), b && b.c(), e = space$4(), o && o.c(), s = empty$1();
    },
    m(l, a) {
      c && c.m(l, a), insert$7(l, t, a), h && h.m(l, a), insert$7(l, n, a), b && b.m(l, a), insert$7(l, e, a), o && o.m(l, a), insert$7(l, s, a);
    },
    p(l, a) {
      /*p*/
      l[41].desc != null ? h ? h.p(l, a) : (h = create_if_block_7(l), h.c(), h.m(n.parentNode, n)) : h && (h.d(1), h = null), /*p*/
      l[41].desc != null && /*progress_level*/
      l[14] && /*progress_level*/
      l[14][
        /*i*/
        l[43]
      ] != null ? b || (b = create_if_block_6(), b.c(), b.m(e.parentNode, e)) : b && (b.d(1), b = null), /*progress_level*/
      l[14] != null ? o ? o.p(l, a) : (o = create_if_block_5(l), o.c(), o.m(s.parentNode, s)) : o && (o.d(1), o = null);
    },
    d(l) {
      l && (detach$7(t), detach$7(n), detach$7(e), detach$7(s)), c && c.d(l), h && h.d(l), b && b.d(l), o && o.d(l);
    }
  };
}
function create_if_block_8(i) {
  let t;
  return {
    c() {
      t = text$2(" /");
    },
    m(n, e) {
      insert$7(n, t, e);
    },
    d(n) {
      n && detach$7(t);
    }
  };
}
function create_if_block_7(i) {
  let t = (
    /*p*/
    i[41].desc + ""
  ), n;
  return {
    c() {
      n = text$2(t);
    },
    m(e, s) {
      insert$7(e, n, s);
    },
    p(e, s) {
      s[0] & /*progress*/
      128 && t !== (t = /*p*/
      e[41].desc + "") && set_data$2(n, t);
    },
    d(e) {
      e && detach$7(n);
    }
  };
}
function create_if_block_6(i) {
  let t;
  return {
    c() {
      t = text$2("-");
    },
    m(n, e) {
      insert$7(n, t, e);
    },
    d(n) {
      n && detach$7(t);
    }
  };
}
function create_if_block_5(i) {
  let t = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[43]
  ] || 0)).toFixed(1) + "", n, e;
  return {
    c() {
      n = text$2(t), e = text$2("%");
    },
    m(s, c) {
      insert$7(s, n, c), insert$7(s, e, c);
    },
    p(s, c) {
      c[0] & /*progress_level*/
      16384 && t !== (t = (100 * /*progress_level*/
      (s[14][
        /*i*/
        s[43]
      ] || 0)).toFixed(1) + "") && set_data$2(n, t);
    },
    d(s) {
      s && (detach$7(n), detach$7(e));
    }
  };
}
function create_each_block(i) {
  let t, n = (
    /*p*/
    (i[41].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[43]
    ] != null) && create_if_block_4(i)
  );
  return {
    c() {
      n && n.c(), t = empty$1();
    },
    m(e, s) {
      n && n.m(e, s), insert$7(e, t, s);
    },
    p(e, s) {
      /*p*/
      e[41].desc != null || /*progress_level*/
      e[14] && /*progress_level*/
      e[14][
        /*i*/
        e[43]
      ] != null ? n ? n.p(e, s) : (n = create_if_block_4(e), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(e) {
      e && detach$7(t), n && n.d(e);
    }
  };
}
function create_if_block_1$2(i) {
  let t, n, e, s;
  const c = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), h = create_slot$1(
    c,
    i,
    /*$$scope*/
    i[29],
    get_additional_loading_text_slot_context
  );
  return {
    c() {
      t = element$4("p"), n = text$2(
        /*loading_text*/
        i[9]
      ), e = space$4(), h && h.c(), attr$7(t, "class", "loading svelte-v0wucf");
    },
    m(b, o) {
      insert$7(b, t, o), append$7(t, n), insert$7(b, e, o), h && h.m(b, o), s = !0;
    },
    p(b, o) {
      (!s || o[0] & /*loading_text*/
      512) && set_data$2(
        n,
        /*loading_text*/
        b[9]
      ), h && h.p && (!s || o[0] & /*$$scope*/
      536870912) && update_slot_base$1(
        h,
        c,
        b,
        /*$$scope*/
        b[29],
        s ? get_slot_changes$1(
          c,
          /*$$scope*/
          b[29],
          o,
          get_additional_loading_text_slot_changes
        ) : get_all_dirty_from_scope$1(
          /*$$scope*/
          b[29]
        ),
        get_additional_loading_text_slot_context
      );
    },
    i(b) {
      s || (transition_in$4(h, b), s = !0);
    },
    o(b) {
      transition_out$4(h, b), s = !1;
    },
    d(b) {
      b && (detach$7(t), detach$7(e)), h && h.d(b);
    }
  };
}
function create_fragment$7(i) {
  let t, n, e, s, c;
  const h = [create_if_block$3, create_if_block_17], b = [];
  function o(l, a) {
    return (
      /*status*/
      l[4] === "pending" ? 0 : (
        /*status*/
        l[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = o(i)) && (e = b[n] = h[n](i)), {
    c() {
      t = element$4("div"), e && e.c(), attr$7(t, "class", s = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-v0wucf"), toggle_class$3(t, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden"), toggle_class$3(
        t,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), toggle_class$3(
        t,
        "generating",
        /*status*/
        i[4] === "generating" && /*show_progress*/
        i[6] === "full"
      ), toggle_class$3(
        t,
        "border",
        /*border*/
        i[12]
      ), set_style$3(
        t,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), set_style$3(
        t,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(l, a) {
      insert$7(l, t, a), ~n && b[n].m(t, null), i[33](t), c = !0;
    },
    p(l, a) {
      let T = n;
      n = o(l), n === T ? ~n && b[n].p(l, a) : (e && (group_outros$2(), transition_out$4(b[T], 1, 1, () => {
        b[T] = null;
      }), check_outros$2()), ~n ? (e = b[n], e ? e.p(l, a) : (e = b[n] = h[n](l), e.c()), transition_in$4(e, 1), e.m(t, null)) : e = null), (!c || a[0] & /*variant, show_progress*/
      320 && s !== (s = "wrap " + /*variant*/
      l[8] + " " + /*show_progress*/
      l[6] + " svelte-v0wucf")) && attr$7(t, "class", s), (!c || a[0] & /*variant, show_progress, status, show_progress*/
      336) && toggle_class$3(t, "hide", !/*status*/
      l[4] || /*status*/
      l[4] === "complete" || /*show_progress*/
      l[6] === "hidden"), (!c || a[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && toggle_class$3(
        t,
        "translucent",
        /*variant*/
        l[8] === "center" && /*status*/
        (l[4] === "pending" || /*status*/
        l[4] === "error") || /*translucent*/
        l[11] || /*show_progress*/
        l[6] === "minimal"
      ), (!c || a[0] & /*variant, show_progress, status, show_progress*/
      336) && toggle_class$3(
        t,
        "generating",
        /*status*/
        l[4] === "generating" && /*show_progress*/
        l[6] === "full"
      ), (!c || a[0] & /*variant, show_progress, border*/
      4416) && toggle_class$3(
        t,
        "border",
        /*border*/
        l[12]
      ), a[0] & /*absolute*/
      1024 && set_style$3(
        t,
        "position",
        /*absolute*/
        l[10] ? "absolute" : "static"
      ), a[0] & /*absolute*/
      1024 && set_style$3(
        t,
        "padding",
        /*absolute*/
        l[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(l) {
      c || (transition_in$4(e), c = !0);
    },
    o(l) {
      transition_out$4(e), c = !1;
    },
    d(l) {
      l && detach$7(t), ~n && b[n].d(), i[33](null);
    }
  };
}
var __awaiter = function(i, t, n, e) {
  function s(c) {
    return c instanceof n ? c : new n(function(h) {
      h(c);
    });
  }
  return new (n || (n = Promise))(function(c, h) {
    function b(a) {
      try {
        l(e.next(a));
      } catch (T) {
        h(T);
      }
    }
    function o(a) {
      try {
        l(e.throw(a));
      } catch (T) {
        h(T);
      }
    }
    function l(a) {
      a.done ? c(a.value) : s(a.value).then(b, o);
    }
    l((e = e.apply(i, t || [])).next());
  });
};
let items = [], called = !1;
function scroll_into_view(i) {
  return __awaiter(this, arguments, void 0, function* (t, n = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && n !== !0)) {
      if (items.push(t), !called) called = !0;
      else return;
      yield tick$2(), requestAnimationFrame(() => {
        let e = [0, 0];
        for (let s = 0; s < items.length; s++) {
          const h = items[s].getBoundingClientRect();
          (s === 0 || h.top + window.scrollY <= e[0]) && (e[0] = h.top + window.scrollY, e[1] = s);
        }
        window.scrollTo({ top: e[0] - 20, behavior: "smooth" }), called = !1, items = [];
      });
    }
  });
}
function instance$4(i, t, n) {
  let e, { $$slots: s = {}, $$scope: c } = t;
  this && this.__awaiter;
  const h = createEventDispatcher$2();
  let { i18n: b } = t, { eta: o = null } = t, { queue_position: l } = t, { queue_size: a } = t, { status: T } = t, { scroll_to_output: P = !1 } = t, { timer: v = !0 } = t, { show_progress: k = "full" } = t, { message: x = null } = t, { progress: S = null } = t, { variant: E = "default" } = t, { loading_text: w = "Loading..." } = t, { absolute: M = !0 } = t, { translucent: g = !1 } = t, { border: p = !1 } = t, { autoscroll: _ } = t, f, A = !1, C = 0, W = 0, m = null, I = null, q = 0, Y = null, X, z = null, L = !0;
  const et = () => {
    n(0, o = n(27, m = n(19, Q = null))), n(25, C = performance.now()), n(26, W = 0), A = !0, D();
  };
  function D() {
    requestAnimationFrame(() => {
      n(26, W = (performance.now() - C) / 1e3), A && D();
    });
  }
  function G() {
    n(26, W = 0), n(0, o = n(27, m = n(19, Q = null))), A && (A = !1);
  }
  onDestroy(() => {
    A && G();
  });
  let Q = null;
  function F(y) {
    binding_callbacks$2[y ? "unshift" : "push"](() => {
      z = y, n(16, z), n(7, S), n(14, Y), n(15, X);
    });
  }
  const d = () => {
    h("clear_status");
  };
  function u(y) {
    binding_callbacks$2[y ? "unshift" : "push"](() => {
      f = y, n(13, f);
    });
  }
  return i.$$set = (y) => {
    "i18n" in y && n(1, b = y.i18n), "eta" in y && n(0, o = y.eta), "queue_position" in y && n(2, l = y.queue_position), "queue_size" in y && n(3, a = y.queue_size), "status" in y && n(4, T = y.status), "scroll_to_output" in y && n(22, P = y.scroll_to_output), "timer" in y && n(5, v = y.timer), "show_progress" in y && n(6, k = y.show_progress), "message" in y && n(23, x = y.message), "progress" in y && n(7, S = y.progress), "variant" in y && n(8, E = y.variant), "loading_text" in y && n(9, w = y.loading_text), "absolute" in y && n(10, M = y.absolute), "translucent" in y && n(11, g = y.translucent), "border" in y && n(12, p = y.border), "autoscroll" in y && n(24, _ = y.autoscroll), "$$scope" in y && n(29, c = y.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (o === null && n(0, o = m), o != null && m !== o && (n(28, I = (performance.now() - C) / 1e3 + o), n(19, Q = I.toFixed(1)), n(27, m = o))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && n(17, q = I === null || I <= 0 || !W ? null : Math.min(W / I, 1)), i.$$.dirty[0] & /*progress*/
    128 && S != null && n(18, L = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (S != null ? n(14, Y = S.map((y) => {
      if (y.index != null && y.length != null)
        return y.index / y.length;
      if (y.progress != null)
        return y.progress;
    })) : n(14, Y = null), Y ? (n(15, X = Y[Y.length - 1]), z && (X === 0 ? n(16, z.style.transition = "0", z) : n(16, z.style.transition = "150ms", z))) : n(15, X = void 0)), i.$$.dirty[0] & /*status*/
    16 && (T === "pending" ? et() : G()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && f && P && (T === "pending" || T === "complete") && scroll_into_view(f, _), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && n(20, e = W.toFixed(1));
  }, [
    o,
    b,
    l,
    a,
    T,
    v,
    k,
    S,
    E,
    w,
    M,
    g,
    p,
    f,
    Y,
    X,
    z,
    q,
    L,
    Q,
    e,
    h,
    P,
    x,
    _,
    C,
    W,
    m,
    I,
    c,
    s,
    F,
    d,
    u
  ];
}
class Static extends SvelteComponent$7 {
  constructor(t) {
    super(), init$7(
      this,
      t,
      instance$4,
      create_fragment$7,
      safe_not_equal$7,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
var fn = new Intl.Collator(0, { numeric: 1 }).compare;
function semiver(i, t, n) {
  return i = i.split("."), t = t.split("."), fn(i[0], t[0]) || fn(i[1], t[1]) || (t[2] = t.slice(2).join("."), n = /[.-]/.test(i[2] = i.slice(2).join(".")), n == /[.-]/.test(t[2]) ? fn(i[2], t[2]) : n ? -1 : 1);
}
function resolve_root(i, t, n) {
  return t.startsWith("http://") || t.startsWith("https://") ? n ? i : t : i + t;
}
function determine_protocol(i) {
  if (i.startsWith("http")) {
    const { protocol: t, host: n } = new URL(i);
    return n.endsWith("hf.space") ? {
      ws_protocol: "wss",
      host: n,
      http_protocol: t
    } : {
      ws_protocol: t === "https:" ? "wss" : "ws",
      http_protocol: t,
      host: n
    };
  } else if (i.startsWith("file:"))
    return {
      ws_protocol: "ws",
      http_protocol: "http:",
      host: "lite.local"
      // Special fake hostname only used for this case. This matches the hostname allowed in `is_self_host()` in `js/wasm/network/host.ts`.
    };
  return {
    ws_protocol: "wss",
    http_protocol: "https:",
    host: i
  };
}
const RE_SPACE_NAME = /^[^\/]*\/[^\/]*$/, RE_SPACE_DOMAIN = /.*hf\.space\/{0,1}$/;
async function process_endpoint(i, t) {
  const n = {};
  t && (n.Authorization = `Bearer ${t}`);
  const e = i.trim();
  if (RE_SPACE_NAME.test(e))
    try {
      const s = await fetch(
        `https://huggingface.co/api/spaces/${e}/host`,
        { headers: n }
      );
      if (s.status !== 200)
        throw new Error("Space metadata could not be loaded.");
      const c = (await s.json()).host;
      return {
        space_id: i,
        ...determine_protocol(c)
      };
    } catch (s) {
      throw new Error("Space metadata could not be loaded." + s.message);
    }
  if (RE_SPACE_DOMAIN.test(e)) {
    const { ws_protocol: s, http_protocol: c, host: h } = determine_protocol(e);
    return {
      space_id: h.replace(".hf.space", ""),
      ws_protocol: s,
      http_protocol: c,
      host: h
    };
  }
  return {
    space_id: !1,
    ...determine_protocol(e)
  };
}
function map_names_to_ids(i) {
  let t = {};
  return i.forEach(({ api_name: n }, e) => {
    n && (t[n] = e);
  }), t;
}
const RE_DISABLED_DISCUSSION = /^(?=[^]*\b[dD]iscussions{0,1}\b)(?=[^]*\b[dD]isabled\b)[^]*$/;
async function discussions_enabled(i) {
  try {
    const n = (await fetch(
      `https://huggingface.co/api/spaces/${i}/discussions`,
      {
        method: "HEAD"
      }
    )).headers.get("x-error-message");
    return !(n && RE_DISABLED_DISCUSSION.test(n));
  } catch {
    return !1;
  }
}
function normalise_file$1(i, t, n) {
  if (i == null)
    return null;
  if (Array.isArray(i)) {
    const e = [];
    for (const s of i)
      s == null ? e.push(null) : e.push(normalise_file$1(s, t, n));
    return e;
  }
  return i.is_stream ? n == null ? new FileData({
    ...i,
    url: t + "/stream/" + i.path
  }) : new FileData({
    ...i,
    url: "/proxy=" + n + "stream/" + i.path
  }) : new FileData({
    ...i,
    url: get_fetchable_url_or_file(i.path, t, n)
  });
}
function is_url(i) {
  try {
    const t = new URL(i);
    return t.protocol === "http:" || t.protocol === "https:";
  } catch {
    return !1;
  }
}
function get_fetchable_url_or_file(i, t, n) {
  return i == null ? n ? `/proxy=${n}file=` : `${t}/file=` : is_url(i) ? i : n ? `/proxy=${n}file=${i}` : `${t}/file=${i}`;
}
async function upload(i, t, n = upload_files) {
  let e = (Array.isArray(i) ? i : [i]).map(
    (s) => s.blob
  );
  return await Promise.all(
    await n(t, e).then(
      async (s) => {
        if (s.error)
          throw new Error(s.error);
        return s.files ? s.files.map((c, h) => {
          const b = new FileData({ ...i[h], path: c });
          return normalise_file$1(b, t, null);
        }) : [];
      }
    )
  );
}
async function prepare_files(i, t) {
  return i.map(
    (n, e) => new FileData({
      path: n.name,
      orig_name: n.name,
      blob: n,
      size: n.size,
      mime_type: n.type,
      is_stream: t
    })
  );
}
class FileData {
  constructor({
    path: t,
    url: n,
    orig_name: e,
    size: s,
    blob: c,
    is_stream: h,
    mime_type: b,
    alt_text: o
  }) {
    this.path = t, this.url = n, this.orig_name = e, this.size = s, this.blob = n ? void 0 : c, this.is_stream = h, this.mime_type = b, this.alt_text = o;
  }
}
const QUEUE_FULL_MSG = "This application is too busy. Keep trying!", BROKEN_CONNECTION_MSG = "Connection errored out.";
let NodeBlob;
function api_factory(i, t) {
  return { post_data: n, upload_files: e, client: s, handle_blob: c };
  async function n(h, b, o) {
    const l = { "Content-Type": "application/json" };
    o && (l.Authorization = `Bearer ${o}`);
    try {
      var a = await i(h, {
        method: "POST",
        body: JSON.stringify(b),
        headers: l
      });
    } catch {
      return [{ error: BROKEN_CONNECTION_MSG }, 500];
    }
    return [await a.json(), a.status];
  }
  async function e(h, b, o) {
    const l = {};
    o && (l.Authorization = `Bearer ${o}`);
    const a = 1e3, T = [];
    for (let v = 0; v < b.length; v += a) {
      const k = b.slice(v, v + a), x = new FormData();
      k.forEach((E) => {
        x.append("files", E);
      });
      try {
        var P = await i(`${h}/upload`, {
          method: "POST",
          body: x,
          headers: l
        });
      } catch {
        return { error: BROKEN_CONNECTION_MSG };
      }
      const S = await P.json();
      T.push(...S);
    }
    return { files: T };
  }
  async function s(h, b = { normalise_files: !0 }) {
    return new Promise(async (o) => {
      const { status_callback: l, hf_token: a, normalise_files: T } = b, P = {
        predict: W,
        submit: m,
        view_api: q,
        component_server: I
      }, v = T ?? !0;
      if ((typeof window > "u" || !("WebSocket" in window)) && !global.Websocket) {
        const Y = await import("./wrapper-98f94c21-C3Jwu8tT.js");
        NodeBlob = (await Promise.resolve().then(() => __viteBrowserExternal)).Blob, global.WebSocket = Y.WebSocket;
      }
      const { ws_protocol: k, http_protocol: x, host: S, space_id: E } = await process_endpoint(h, a), w = Math.random().toString(36).substring(2), M = {};
      let g, p = {}, _ = !1;
      a && E && (_ = await get_jwt(E, a));
      async function f(Y) {
        if (g = Y, p = map_names_to_ids((Y == null ? void 0 : Y.dependencies) || []), g.auth_required)
          return {
            config: g,
            ...P
          };
        try {
          A = await q(g);
        } catch (X) {
          console.error(`Could not get api details: ${X.message}`);
        }
        return {
          config: g,
          ...P
        };
      }
      let A;
      async function C(Y) {
        if (l && l(Y), Y.status === "running")
          try {
            g = await resolve_config(
              i,
              `${x}//${S}`,
              a
            );
            const X = await f(g);
            o(X);
          } catch (X) {
            console.error(X), l && l({
              status: "error",
              message: "Could not load this space.",
              load_status: "error",
              detail: "NOT_FOUND"
            });
          }
      }
      try {
        g = await resolve_config(
          i,
          `${x}//${S}`,
          a
        );
        const Y = await f(g);
        o(Y);
      } catch (Y) {
        console.error(Y), E ? check_space_status(
          E,
          RE_SPACE_NAME.test(E) ? "space_name" : "subdomain",
          C
        ) : l && l({
          status: "error",
          message: "Could not load this space.",
          load_status: "error",
          detail: "NOT_FOUND"
        });
      }
      function W(Y, X, z) {
        let L = !1, et = !1, D;
        if (typeof Y == "number")
          D = g.dependencies[Y];
        else {
          const G = Y.replace(/^\//, "");
          D = g.dependencies[p[G]];
        }
        if (D.types.continuous)
          throw new Error(
            "Cannot call predict on this function as it may run forever. Use submit instead"
          );
        return new Promise((G, Q) => {
          const F = m(Y, X, z);
          let d;
          F.on("data", (u) => {
            et && (F.destroy(), G(u)), L = !0, d = u;
          }).on("status", (u) => {
            u.stage === "error" && Q(u), u.stage === "complete" && (et = !0, L && (F.destroy(), G(d)));
          });
        });
      }
      function m(Y, X, z) {
        let L, et;
        if (typeof Y == "number")
          L = Y, et = A.unnamed_endpoints[L];
        else {
          const gt = Y.replace(/^\//, "");
          L = p[gt], et = A.named_endpoints[Y.trim()];
        }
        if (typeof L != "number")
          throw new Error(
            "There is no endpoint matching that name of fn_index matching that number."
          );
        let D, G, Q = g.protocol ?? "sse";
        const F = typeof Y == "number" ? "/predict" : Y;
        let d, u = null, y = !1;
        const B = {};
        let N = "";
        typeof window < "u" && (N = new URLSearchParams(window.location.search).toString()), c(
          `${x}//${resolve_root(S, g.path, !0)}`,
          X,
          et,
          a
        ).then((gt) => {
          if (d = { data: gt || [], event_data: z, fn_index: L }, skip_queue(L, g))
            $({
              type: "status",
              endpoint: F,
              stage: "pending",
              queue: !1,
              fn_index: L,
              time: /* @__PURE__ */ new Date()
            }), n(
              `${x}//${resolve_root(S, g.path, !0)}/run${F.startsWith("/") ? F : `/${F}`}${N ? "?" + N : ""}`,
              {
                ...d,
                session_hash: w
              },
              a
            ).then(([ut, tt]) => {
              const it = v ? transform_output(
                ut.data,
                et,
                g.root,
                g.root_url
              ) : ut.data;
              tt == 200 ? ($({
                type: "data",
                endpoint: F,
                fn_index: L,
                data: it,
                time: /* @__PURE__ */ new Date()
              }), $({
                type: "status",
                endpoint: F,
                fn_index: L,
                stage: "complete",
                eta: ut.average_duration,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              })) : $({
                type: "status",
                stage: "error",
                endpoint: F,
                fn_index: L,
                message: ut.error,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              });
            }).catch((ut) => {
              $({
                type: "status",
                stage: "error",
                message: ut.message,
                endpoint: F,
                fn_index: L,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              });
            });
          else if (Q == "ws") {
            $({
              type: "status",
              stage: "pending",
              queue: !0,
              endpoint: F,
              fn_index: L,
              time: /* @__PURE__ */ new Date()
            });
            let ut = new URL(`${k}://${resolve_root(
              S,
              g.path,
              !0
            )}
							/queue/join${N ? "?" + N : ""}`);
            _ && ut.searchParams.set("__sign", _), D = t(ut), D.onclose = (tt) => {
              tt.wasClean || $({
                type: "status",
                stage: "error",
                broken: !0,
                message: BROKEN_CONNECTION_MSG,
                queue: !0,
                endpoint: F,
                fn_index: L,
                time: /* @__PURE__ */ new Date()
              });
            }, D.onmessage = function(tt) {
              const it = JSON.parse(tt.data), { type: R, status: U, data: J } = handle_message(
                it,
                M[L]
              );
              if (R === "update" && U && !y)
                $({
                  type: "status",
                  endpoint: F,
                  fn_index: L,
                  time: /* @__PURE__ */ new Date(),
                  ...U
                }), U.stage === "error" && D.close();
              else if (R === "hash") {
                D.send(JSON.stringify({ fn_index: L, session_hash: w }));
                return;
              } else R === "data" ? D.send(JSON.stringify({ ...d, session_hash: w })) : R === "complete" ? y = U : R === "log" ? $({
                type: "log",
                log: J.log,
                level: J.level,
                endpoint: F,
                fn_index: L
              }) : R === "generating" && $({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...U,
                stage: U == null ? void 0 : U.stage,
                queue: !0,
                endpoint: F,
                fn_index: L
              });
              J && ($({
                type: "data",
                time: /* @__PURE__ */ new Date(),
                data: v ? transform_output(
                  J.data,
                  et,
                  g.root,
                  g.root_url
                ) : J.data,
                endpoint: F,
                fn_index: L
              }), y && ($({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...y,
                stage: U == null ? void 0 : U.stage,
                queue: !0,
                endpoint: F,
                fn_index: L
              }), D.close()));
            }, semiver(g.version || "2.0.0", "3.6") < 0 && addEventListener(
              "open",
              () => D.send(JSON.stringify({ hash: w }))
            );
          } else {
            $({
              type: "status",
              stage: "pending",
              queue: !0,
              endpoint: F,
              fn_index: L,
              time: /* @__PURE__ */ new Date()
            });
            var mt = new URLSearchParams({
              fn_index: L.toString(),
              session_hash: w
            }).toString();
            let ut = new URL(
              `${x}//${resolve_root(
                S,
                g.path,
                !0
              )}/queue/join?${mt}`
            );
            G = new EventSource(ut), G.onmessage = async function(tt) {
              const it = JSON.parse(tt.data), { type: R, status: U, data: J } = handle_message(
                it,
                M[L]
              );
              if (R === "update" && U && !y)
                $({
                  type: "status",
                  endpoint: F,
                  fn_index: L,
                  time: /* @__PURE__ */ new Date(),
                  ...U
                }), U.stage === "error" && G.close();
              else if (R === "data") {
                u = it.event_id;
                let [rt, _t] = await n(
                  `${x}//${resolve_root(
                    S,
                    g.path,
                    !0
                  )}/queue/data`,
                  {
                    ...d,
                    session_hash: w,
                    event_id: u
                  },
                  a
                );
                _t !== 200 && ($({
                  type: "status",
                  stage: "error",
                  message: BROKEN_CONNECTION_MSG,
                  queue: !0,
                  endpoint: F,
                  fn_index: L,
                  time: /* @__PURE__ */ new Date()
                }), G.close());
              } else R === "complete" ? y = U : R === "log" ? $({
                type: "log",
                log: J.log,
                level: J.level,
                endpoint: F,
                fn_index: L
              }) : R === "generating" && $({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...U,
                stage: U == null ? void 0 : U.stage,
                queue: !0,
                endpoint: F,
                fn_index: L
              });
              J && ($({
                type: "data",
                time: /* @__PURE__ */ new Date(),
                data: v ? transform_output(
                  J.data,
                  et,
                  g.root,
                  g.root_url
                ) : J.data,
                endpoint: F,
                fn_index: L
              }), y && ($({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...y,
                stage: U == null ? void 0 : U.stage,
                queue: !0,
                endpoint: F,
                fn_index: L
              }), G.close()));
            };
          }
        });
        function $(gt) {
          const ut = B[gt.type] || [];
          ut == null || ut.forEach((tt) => tt(gt));
        }
        function K(gt, mt) {
          const ut = B, tt = ut[gt] || [];
          return ut[gt] = tt, tt == null || tt.push(mt), { on: K, off: st, cancel: dt, destroy: pt };
        }
        function st(gt, mt) {
          const ut = B;
          let tt = ut[gt] || [];
          return tt = tt == null ? void 0 : tt.filter((it) => it !== mt), ut[gt] = tt, { on: K, off: st, cancel: dt, destroy: pt };
        }
        async function dt() {
          const gt = {
            stage: "complete",
            queue: !1,
            time: /* @__PURE__ */ new Date()
          };
          y = gt, $({
            ...gt,
            type: "status",
            endpoint: F,
            fn_index: L
          });
          let mt = {};
          Q === "ws" ? (D && D.readyState === 0 ? D.addEventListener("open", () => {
            D.close();
          }) : D.close(), mt = { fn_index: L, session_hash: w }) : (G.close(), mt = { event_id: u });
          try {
            await i(
              `${x}//${resolve_root(
                S,
                g.path,
                !0
              )}/reset`,
              {
                headers: { "Content-Type": "application/json" },
                method: "POST",
                body: JSON.stringify(mt)
              }
            );
          } catch {
            console.warn(
              "The `/reset` endpoint could not be called. Subsequent endpoint results may be unreliable."
            );
          }
        }
        function pt() {
          for (const gt in B)
            B[gt].forEach((mt) => {
              st(gt, mt);
            });
        }
        return {
          on: K,
          off: st,
          cancel: dt,
          destroy: pt
        };
      }
      async function I(Y, X, z) {
        var L;
        const et = { "Content-Type": "application/json" };
        a && (et.Authorization = `Bearer ${a}`);
        let D, G = g.components.find(
          (d) => d.id === Y
        );
        (L = G == null ? void 0 : G.props) != null && L.root_url ? D = G.props.root_url : D = `${x}//${resolve_root(
          S,
          g.path,
          !0
        )}/`;
        const Q = await i(
          `${D}component_server/`,
          {
            method: "POST",
            body: JSON.stringify({
              data: z,
              component_id: Y,
              fn_name: X,
              session_hash: w
            }),
            headers: et
          }
        );
        if (!Q.ok)
          throw new Error(
            "Could not connect to component server: " + Q.statusText
          );
        return await Q.json();
      }
      async function q(Y) {
        if (A)
          return A;
        const X = { "Content-Type": "application/json" };
        a && (X.Authorization = `Bearer ${a}`);
        let z;
        if (semiver(Y.version || "2.0.0", "3.30") < 0 ? z = await i(
          "https://gradio-space-api-fetcher-v2.hf.space/api",
          {
            method: "POST",
            body: JSON.stringify({
              serialize: !1,
              config: JSON.stringify(Y)
            }),
            headers: X
          }
        ) : z = await i(`${Y.root}/info`, {
          headers: X
        }), !z.ok)
          throw new Error(BROKEN_CONNECTION_MSG);
        let L = await z.json();
        return "api" in L && (L = L.api), L.named_endpoints["/predict"] && !L.unnamed_endpoints[0] && (L.unnamed_endpoints[0] = L.named_endpoints["/predict"]), transform_api_info(L, Y, p);
      }
    });
  }
  async function c(h, b, o, l) {
    const a = await walk_and_store_blobs(
      b,
      void 0,
      [],
      !0,
      o
    );
    return Promise.all(
      a.map(async ({ path: T, blob: P, type: v }) => {
        if (P) {
          const k = (await e(h, [P], l)).files[0];
          return { path: T, file_url: k, type: v, name: P == null ? void 0 : P.name };
        }
        return { path: T, type: v };
      })
    ).then((T) => (T.forEach(({ path: P, file_url: v, type: k, name: x }) => {
      if (k === "Gallery")
        update_object(b, v, P);
      else if (v) {
        const S = new FileData({ path: v, orig_name: x });
        update_object(b, S, P);
      }
    }), b));
  }
}
const { post_data, upload_files, client, handle_blob } = api_factory(
  fetch,
  (...i) => new WebSocket(...i)
);
function transform_output(i, t, n, e) {
  return i.map((s, c) => {
    var h, b, o, l;
    return ((b = (h = t == null ? void 0 : t.returns) == null ? void 0 : h[c]) == null ? void 0 : b.component) === "File" ? normalise_file$1(s, n, e) : ((l = (o = t == null ? void 0 : t.returns) == null ? void 0 : o[c]) == null ? void 0 : l.component) === "Gallery" ? s.map((a) => Array.isArray(a) ? [normalise_file$1(a[0], n, e), a[1]] : [normalise_file$1(a, n, e), null]) : typeof s == "object" && s.path ? normalise_file$1(s, n, e) : s;
  });
}
function get_type(i, t, n, e) {
  switch (i.type) {
    case "string":
      return "string";
    case "boolean":
      return "boolean";
    case "number":
      return "number";
  }
  if (n === "JSONSerializable" || n === "StringSerializable")
    return "any";
  if (n === "ListStringSerializable")
    return "string[]";
  if (t === "Image")
    return e === "parameter" ? "Blob | File | Buffer" : "string";
  if (n === "FileSerializable")
    return (i == null ? void 0 : i.type) === "array" ? e === "parameter" ? "(Blob | File | Buffer)[]" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}[]" : e === "parameter" ? "Blob | File | Buffer" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}";
  if (n === "GallerySerializable")
    return e === "parameter" ? "[(Blob | File | Buffer), (string | null)][]" : "[{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}, (string | null))][]";
}
function get_description(i, t) {
  return t === "GallerySerializable" ? "array of [file, label] tuples" : t === "ListStringSerializable" ? "array of strings" : t === "FileSerializable" ? "array of files or single file" : i.description;
}
function transform_api_info(i, t, n) {
  const e = {
    named_endpoints: {},
    unnamed_endpoints: {}
  };
  for (const s in i) {
    const c = i[s];
    for (const h in c) {
      const b = t.dependencies[h] ? h : n[h.replace("/", "")], o = c[h];
      e[s][h] = {}, e[s][h].parameters = {}, e[s][h].returns = {}, e[s][h].type = t.dependencies[b].types, e[s][h].parameters = o.parameters.map(
        ({ label: l, component: a, type: T, serializer: P }) => ({
          label: l,
          component: a,
          type: get_type(T, a, P, "parameter"),
          description: get_description(T, P)
        })
      ), e[s][h].returns = o.returns.map(
        ({ label: l, component: a, type: T, serializer: P }) => ({
          label: l,
          component: a,
          type: get_type(T, a, P, "return"),
          description: get_description(T, P)
        })
      );
    }
  }
  return e;
}
async function get_jwt(i, t) {
  try {
    return (await (await fetch(`https://huggingface.co/api/spaces/${i}/jwt`, {
      headers: {
        Authorization: `Bearer ${t}`
      }
    })).json()).token || !1;
  } catch (n) {
    return console.error(n), !1;
  }
}
function update_object(i, t, n) {
  for (; n.length > 1; )
    i = i[n.shift()];
  i[n.shift()] = t;
}
async function walk_and_store_blobs(i, t = void 0, n = [], e = !1, s = void 0) {
  if (Array.isArray(i)) {
    let c = [];
    return await Promise.all(
      i.map(async (h, b) => {
        var o;
        let l = n.slice();
        l.push(b);
        const a = await walk_and_store_blobs(
          i[b],
          e ? ((o = s == null ? void 0 : s.parameters[b]) == null ? void 0 : o.component) || void 0 : t,
          l,
          !1,
          s
        );
        c = c.concat(a);
      })
    ), c;
  } else {
    if (globalThis.Buffer && i instanceof globalThis.Buffer)
      return [
        {
          path: n,
          blob: t === "Image" ? !1 : new NodeBlob([i]),
          type: t
        }
      ];
    if (typeof i == "object") {
      let c = [];
      for (let h in i)
        if (i.hasOwnProperty(h)) {
          let b = n.slice();
          b.push(h), c = c.concat(
            await walk_and_store_blobs(
              i[h],
              void 0,
              b,
              !1,
              s
            )
          );
        }
      return c;
    }
  }
  return [];
}
function skip_queue(i, t) {
  var n, e, s, c;
  return !(((e = (n = t == null ? void 0 : t.dependencies) == null ? void 0 : n[i]) == null ? void 0 : e.queue) === null ? t.enable_queue : (c = (s = t == null ? void 0 : t.dependencies) == null ? void 0 : s[i]) != null && c.queue) || !1;
}
async function resolve_config(i, t, n) {
  const e = {};
  if (n && (e.Authorization = `Bearer ${n}`), typeof window < "u" && window.gradio_config && location.origin !== "http://localhost:9876" && !window.gradio_config.dev_mode) {
    const s = window.gradio_config.root, c = window.gradio_config;
    return c.root = resolve_root(t, c.root, !1), { ...c, path: s };
  } else if (t) {
    let s = await i(`${t}/config`, {
      headers: e
    });
    if (s.status === 200) {
      const c = await s.json();
      return c.path = c.path ?? "", c.root = t, c;
    }
    throw new Error("Could not get config.");
  }
  throw new Error("No config or app endpoint found");
}
async function check_space_status(i, t, n) {
  let e = t === "subdomain" ? `https://huggingface.co/api/spaces/by-subdomain/${i}` : `https://huggingface.co/api/spaces/${i}`, s, c;
  try {
    if (s = await fetch(e), c = s.status, c !== 200)
      throw new Error();
    s = await s.json();
  } catch {
    n({
      status: "error",
      load_status: "error",
      message: "Could not get space status",
      detail: "NOT_FOUND"
    });
    return;
  }
  if (!s || c !== 200)
    return;
  const {
    runtime: { stage: h },
    id: b
  } = s;
  switch (h) {
    case "STOPPED":
    case "SLEEPING":
      n({
        status: "sleeping",
        load_status: "pending",
        message: "Space is asleep. Waking it up...",
        detail: h
      }), setTimeout(() => {
        check_space_status(i, t, n);
      }, 1e3);
      break;
    case "PAUSED":
      n({
        status: "paused",
        load_status: "error",
        message: "This space has been paused by the author. If you would like to try this demo, consider duplicating the space.",
        detail: h,
        discussions_enabled: await discussions_enabled(b)
      });
      break;
    case "RUNNING":
    case "RUNNING_BUILDING":
      n({
        status: "running",
        load_status: "complete",
        message: "",
        detail: h
      });
      break;
    case "BUILDING":
      n({
        status: "building",
        load_status: "pending",
        message: "Space is building...",
        detail: h
      }), setTimeout(() => {
        check_space_status(i, t, n);
      }, 1e3);
      break;
    default:
      n({
        status: "space_error",
        load_status: "error",
        message: "This space is experiencing an issue.",
        detail: h,
        discussions_enabled: await discussions_enabled(b)
      });
      break;
  }
}
function handle_message(i, t) {
  switch (i.msg) {
    case "send_data":
      return { type: "data" };
    case "send_hash":
      return { type: "hash" };
    case "queue_full":
      return {
        type: "update",
        status: {
          queue: !0,
          message: QUEUE_FULL_MSG,
          stage: "error",
          code: i.code,
          success: i.success
        }
      };
    case "estimation":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: t || "pending",
          code: i.code,
          size: i.queue_size,
          position: i.rank,
          eta: i.rank_eta,
          success: i.success
        }
      };
    case "progress":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: i.code,
          progress_data: i.progress_data,
          success: i.success
        }
      };
    case "log":
      return { type: "log", data: i };
    case "process_generating":
      return {
        type: "generating",
        status: {
          queue: !0,
          message: i.success ? null : i.output.error,
          stage: i.success ? "generating" : "error",
          code: i.code,
          progress_data: i.progress_data,
          eta: i.average_duration
        },
        data: i.success ? i.output : null
      };
    case "process_completed":
      return "error" in i.output ? {
        type: "update",
        status: {
          queue: !0,
          message: i.output.error,
          stage: "error",
          code: i.code,
          success: i.success
        }
      } : {
        type: "complete",
        status: {
          queue: !0,
          message: i.success ? void 0 : i.output.error,
          stage: i.success ? "complete" : "error",
          code: i.code,
          progress_data: i.progress_data,
          eta: i.output.average_duration
        },
        data: i.success ? i.output : null
      };
    case "process_starts":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: i.code,
          size: i.rank,
          position: 0,
          success: i.success
        }
      };
  }
  return { type: "none", status: { stage: "error", queue: !0 } };
}
const {
  SvelteComponent: SvelteComponent$6,
  append: append$6,
  attr: attr$6,
  binding_callbacks: binding_callbacks$1,
  bubble: bubble$1,
  create_slot,
  detach: detach$6,
  element: element$3,
  get_all_dirty_from_scope,
  get_slot_changes,
  init: init$6,
  insert: insert$6,
  listen: listen$1,
  prevent_default,
  run_all,
  safe_not_equal: safe_not_equal$6,
  space: space$3,
  stop_propagation,
  toggle_class: toggle_class$2,
  transition_in: transition_in$3,
  transition_out: transition_out$3,
  update_slot_base
} = window.__gradio__svelte__internal, { createEventDispatcher: createEventDispatcher$1, tick: tick$1, getContext } = window.__gradio__svelte__internal;
function create_fragment$6(i) {
  let t, n, e, s, c, h, b, o, l;
  const a = (
    /*#slots*/
    i[16].default
  ), T = create_slot(
    a,
    i,
    /*$$scope*/
    i[15],
    null
  );
  return {
    c() {
      t = element$3("button"), T && T.c(), n = space$3(), e = element$3("input"), attr$6(e, "type", "file"), attr$6(
        e,
        "accept",
        /*filetype*/
        i[0]
      ), e.multiple = s = /*file_count*/
      i[4] === "multiple" || void 0, attr$6(e, "webkitdirectory", c = /*file_count*/
      i[4] === "directory" || void 0), attr$6(e, "mozdirectory", h = /*file_count*/
      i[4] === "directory" || void 0), attr$6(e, "class", "svelte-18dlsnh"), attr$6(t, "class", "svelte-18dlsnh"), toggle_class$2(
        t,
        "hidden",
        /*hidden*/
        i[5]
      ), toggle_class$2(
        t,
        "center",
        /*center*/
        i[2]
      ), toggle_class$2(
        t,
        "boundedheight",
        /*boundedheight*/
        i[1]
      ), toggle_class$2(
        t,
        "flex",
        /*flex*/
        i[3]
      );
    },
    m(P, v) {
      insert$6(P, t, v), T && T.m(t, null), append$6(t, n), append$6(t, e), i[24](e), b = !0, o || (l = [
        listen$1(
          e,
          "change",
          /*load_files_from_upload*/
          i[9]
        ),
        listen$1(t, "drag", stop_propagation(prevent_default(
          /*drag_handler*/
          i[17]
        ))),
        listen$1(t, "dragstart", stop_propagation(prevent_default(
          /*dragstart_handler*/
          i[18]
        ))),
        listen$1(t, "dragend", stop_propagation(prevent_default(
          /*dragend_handler*/
          i[19]
        ))),
        listen$1(t, "dragover", stop_propagation(prevent_default(
          /*dragover_handler*/
          i[20]
        ))),
        listen$1(t, "dragenter", stop_propagation(prevent_default(
          /*dragenter_handler*/
          i[21]
        ))),
        listen$1(t, "dragleave", stop_propagation(prevent_default(
          /*dragleave_handler*/
          i[22]
        ))),
        listen$1(t, "drop", stop_propagation(prevent_default(
          /*drop_handler*/
          i[23]
        ))),
        listen$1(
          t,
          "click",
          /*open_file_upload*/
          i[6]
        ),
        listen$1(
          t,
          "drop",
          /*loadFilesFromDrop*/
          i[10]
        ),
        listen$1(
          t,
          "dragenter",
          /*updateDragging*/
          i[8]
        ),
        listen$1(
          t,
          "dragleave",
          /*updateDragging*/
          i[8]
        )
      ], o = !0);
    },
    p(P, [v]) {
      T && T.p && (!b || v & /*$$scope*/
      32768) && update_slot_base(
        T,
        a,
        P,
        /*$$scope*/
        P[15],
        b ? get_slot_changes(
          a,
          /*$$scope*/
          P[15],
          v,
          null
        ) : get_all_dirty_from_scope(
          /*$$scope*/
          P[15]
        ),
        null
      ), (!b || v & /*filetype*/
      1) && attr$6(
        e,
        "accept",
        /*filetype*/
        P[0]
      ), (!b || v & /*file_count*/
      16 && s !== (s = /*file_count*/
      P[4] === "multiple" || void 0)) && (e.multiple = s), (!b || v & /*file_count*/
      16 && c !== (c = /*file_count*/
      P[4] === "directory" || void 0)) && attr$6(e, "webkitdirectory", c), (!b || v & /*file_count*/
      16 && h !== (h = /*file_count*/
      P[4] === "directory" || void 0)) && attr$6(e, "mozdirectory", h), (!b || v & /*hidden*/
      32) && toggle_class$2(
        t,
        "hidden",
        /*hidden*/
        P[5]
      ), (!b || v & /*center*/
      4) && toggle_class$2(
        t,
        "center",
        /*center*/
        P[2]
      ), (!b || v & /*boundedheight*/
      2) && toggle_class$2(
        t,
        "boundedheight",
        /*boundedheight*/
        P[1]
      ), (!b || v & /*flex*/
      8) && toggle_class$2(
        t,
        "flex",
        /*flex*/
        P[3]
      );
    },
    i(P) {
      b || (transition_in$3(T, P), b = !0);
    },
    o(P) {
      transition_out$3(T, P), b = !1;
    },
    d(P) {
      P && detach$6(t), T && T.d(P), i[24](null), o = !1, run_all(l);
    }
  };
}
function is_valid_mimetype(i, t) {
  return !i || i === "*" ? !0 : i.endsWith("/*") ? t.startsWith(i.slice(0, -1)) : i === t;
}
function instance$3(i, t, n) {
  let { $$slots: e = {}, $$scope: s } = t;
  var c = this && this.__awaiter || function(z, L, et, D) {
    function G(Q) {
      return Q instanceof et ? Q : new et(function(F) {
        F(Q);
      });
    }
    return new (et || (et = Promise))(function(Q, F) {
      function d(B) {
        try {
          y(D.next(B));
        } catch (N) {
          F(N);
        }
      }
      function u(B) {
        try {
          y(D.throw(B));
        } catch (N) {
          F(N);
        }
      }
      function y(B) {
        B.done ? Q(B.value) : G(B.value).then(d, u);
      }
      y((D = D.apply(z, L || [])).next());
    });
  };
  let { filetype: h = null } = t, { dragging: b = !1 } = t, { boundedheight: o = !0 } = t, { center: l = !0 } = t, { flex: a = !0 } = t, { file_count: T = "single" } = t, { disable_click: P = !1 } = t, { root: v } = t, { hidden: k = !1 } = t;
  const x = getContext("upload_files");
  let S;
  const E = createEventDispatcher$1();
  function w() {
    n(11, b = !b);
  }
  function M() {
    P || (n(7, S.value = "", S), S.click());
  }
  function g(z) {
    return c(this, void 0, void 0, function* () {
      yield tick$1();
      const L = yield upload(z, v, x);
      return E("load", T === "single" ? L == null ? void 0 : L[0] : L), L || [];
    });
  }
  function p(z) {
    return c(this, void 0, void 0, function* () {
      if (!z.length)
        return;
      let L = z.map((D) => new File([D], D.name)), et = yield prepare_files(L);
      return yield g(et);
    });
  }
  function _(z) {
    return c(this, void 0, void 0, function* () {
      const L = z.target;
      L.files && (yield p(Array.from(L.files)));
    });
  }
  function f(z) {
    return c(this, void 0, void 0, function* () {
      var L;
      if (n(11, b = !1), !(!((L = z.dataTransfer) === null || L === void 0) && L.files)) return;
      const et = Array.from(z.dataTransfer.files).filter((D) => h != null && h.split(",").some((G) => is_valid_mimetype(G, D.type)) ? !0 : (E("error", `Invalid file type only ${h} allowed.`), !1));
      yield p(et);
    });
  }
  function A(z) {
    bubble$1.call(this, i, z);
  }
  function C(z) {
    bubble$1.call(this, i, z);
  }
  function W(z) {
    bubble$1.call(this, i, z);
  }
  function m(z) {
    bubble$1.call(this, i, z);
  }
  function I(z) {
    bubble$1.call(this, i, z);
  }
  function q(z) {
    bubble$1.call(this, i, z);
  }
  function Y(z) {
    bubble$1.call(this, i, z);
  }
  function X(z) {
    binding_callbacks$1[z ? "unshift" : "push"](() => {
      S = z, n(7, S);
    });
  }
  return i.$$set = (z) => {
    "filetype" in z && n(0, h = z.filetype), "dragging" in z && n(11, b = z.dragging), "boundedheight" in z && n(1, o = z.boundedheight), "center" in z && n(2, l = z.center), "flex" in z && n(3, a = z.flex), "file_count" in z && n(4, T = z.file_count), "disable_click" in z && n(12, P = z.disable_click), "root" in z && n(13, v = z.root), "hidden" in z && n(5, k = z.hidden), "$$scope" in z && n(15, s = z.$$scope);
  }, [
    h,
    o,
    l,
    a,
    T,
    k,
    M,
    S,
    w,
    _,
    f,
    b,
    P,
    v,
    p,
    s,
    e,
    A,
    C,
    W,
    m,
    I,
    q,
    Y,
    X
  ];
}
class Upload extends SvelteComponent$6 {
  constructor(t) {
    super(), init$6(this, t, instance$3, create_fragment$6, safe_not_equal$6, {
      filetype: 0,
      dragging: 11,
      boundedheight: 1,
      center: 2,
      flex: 3,
      file_count: 4,
      disable_click: 12,
      root: 13,
      hidden: 5,
      open_file_upload: 6,
      load_files: 14
    });
  }
  get open_file_upload() {
    return this.$$.ctx[6];
  }
  get load_files() {
    return this.$$.ctx[14];
  }
}
const {
  SvelteComponent: SvelteComponent$5,
  append: append$5,
  attr: attr$5,
  bubble,
  create_component: create_component$2,
  destroy_component: destroy_component$2,
  detach: detach$5,
  element: element$2,
  init: init$5,
  insert: insert$5,
  listen,
  mount_component: mount_component$2,
  safe_not_equal: safe_not_equal$5,
  set_data: set_data$1,
  space: space$2,
  text: text$1,
  toggle_class: toggle_class$1,
  transition_in: transition_in$2,
  transition_out: transition_out$2
} = window.__gradio__svelte__internal;
function create_if_block$2(i) {
  let t, n;
  return {
    c() {
      t = element$2("span"), n = text$1(
        /*label*/
        i[1]
      ), attr$5(t, "class", "svelte-xtz2g8");
    },
    m(e, s) {
      insert$5(e, t, s), append$5(t, n);
    },
    p(e, s) {
      s & /*label*/
      2 && set_data$1(
        n,
        /*label*/
        e[1]
      );
    },
    d(e) {
      e && detach$5(t);
    }
  };
}
function create_fragment$5(i) {
  let t, n, e, s, c, h, b, o = (
    /*show_label*/
    i[2] && create_if_block$2(i)
  );
  return s = new /*Icon*/
  i[0]({}), {
    c() {
      t = element$2("button"), o && o.c(), n = space$2(), e = element$2("div"), create_component$2(s.$$.fragment), attr$5(e, "class", "svelte-xtz2g8"), toggle_class$1(
        e,
        "small",
        /*size*/
        i[4] === "small"
      ), toggle_class$1(
        e,
        "large",
        /*size*/
        i[4] === "large"
      ), attr$5(
        t,
        "aria-label",
        /*label*/
        i[1]
      ), attr$5(
        t,
        "title",
        /*label*/
        i[1]
      ), attr$5(t, "class", "svelte-xtz2g8"), toggle_class$1(
        t,
        "pending",
        /*pending*/
        i[3]
      ), toggle_class$1(
        t,
        "padded",
        /*padded*/
        i[5]
      );
    },
    m(l, a) {
      insert$5(l, t, a), o && o.m(t, null), append$5(t, n), append$5(t, e), mount_component$2(s, e, null), c = !0, h || (b = listen(
        t,
        "click",
        /*click_handler*/
        i[6]
      ), h = !0);
    },
    p(l, [a]) {
      /*show_label*/
      l[2] ? o ? o.p(l, a) : (o = create_if_block$2(l), o.c(), o.m(t, n)) : o && (o.d(1), o = null), (!c || a & /*size*/
      16) && toggle_class$1(
        e,
        "small",
        /*size*/
        l[4] === "small"
      ), (!c || a & /*size*/
      16) && toggle_class$1(
        e,
        "large",
        /*size*/
        l[4] === "large"
      ), (!c || a & /*label*/
      2) && attr$5(
        t,
        "aria-label",
        /*label*/
        l[1]
      ), (!c || a & /*label*/
      2) && attr$5(
        t,
        "title",
        /*label*/
        l[1]
      ), (!c || a & /*pending*/
      8) && toggle_class$1(
        t,
        "pending",
        /*pending*/
        l[3]
      ), (!c || a & /*padded*/
      32) && toggle_class$1(
        t,
        "padded",
        /*padded*/
        l[5]
      );
    },
    i(l) {
      c || (transition_in$2(s.$$.fragment, l), c = !0);
    },
    o(l) {
      transition_out$2(s.$$.fragment, l), c = !1;
    },
    d(l) {
      l && detach$5(t), o && o.d(), destroy_component$2(s), h = !1, b();
    }
  };
}
function instance$2(i, t, n) {
  let { Icon: e } = t, { label: s = "" } = t, { show_label: c = !1 } = t, { pending: h = !1 } = t, { size: b = "small" } = t, { padded: o = !0 } = t;
  function l(a) {
    bubble.call(this, i, a);
  }
  return i.$$set = (a) => {
    "Icon" in a && n(0, e = a.Icon), "label" in a && n(1, s = a.label), "show_label" in a && n(2, c = a.show_label), "pending" in a && n(3, h = a.pending), "size" in a && n(4, b = a.size), "padded" in a && n(5, o = a.padded);
  }, [e, s, c, h, b, o, l];
}
class IconButton extends SvelteComponent$5 {
  constructor(t) {
    super(), init$5(this, t, instance$2, create_fragment$5, safe_not_equal$5, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5
    });
  }
}
const {
  SvelteComponent: SvelteComponent$4,
  append: append$4,
  attr: attr$4,
  detach: detach$4,
  init: init$4,
  insert: insert$4,
  noop: noop$2,
  safe_not_equal: safe_not_equal$4,
  set_style: set_style$2,
  svg_element: svg_element$2
} = window.__gradio__svelte__internal;
function create_fragment$4(i) {
  let t, n, e, s;
  return {
    c() {
      t = svg_element$2("svg"), n = svg_element$2("g"), e = svg_element$2("path"), s = svg_element$2("path"), attr$4(e, "d", "M18,6L6.087,17.913"), set_style$2(e, "fill", "none"), set_style$2(e, "fill-rule", "nonzero"), set_style$2(e, "stroke-width", "2px"), attr$4(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), attr$4(s, "d", "M4.364,4.364L19.636,19.636"), set_style$2(s, "fill", "none"), set_style$2(s, "fill-rule", "nonzero"), set_style$2(s, "stroke-width", "2px"), attr$4(t, "width", "100%"), attr$4(t, "height", "100%"), attr$4(t, "viewBox", "0 0 24 24"), attr$4(t, "version", "1.1"), attr$4(t, "xmlns", "http://www.w3.org/2000/svg"), attr$4(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), attr$4(t, "xml:space", "preserve"), attr$4(t, "stroke", "currentColor"), set_style$2(t, "fill-rule", "evenodd"), set_style$2(t, "clip-rule", "evenodd"), set_style$2(t, "stroke-linecap", "round"), set_style$2(t, "stroke-linejoin", "round");
    },
    m(c, h) {
      insert$4(c, t, h), append$4(t, n), append$4(n, e), append$4(t, s);
    },
    p: noop$2,
    i: noop$2,
    o: noop$2,
    d(c) {
      c && detach$4(t);
    }
  };
}
class Clear extends SvelteComponent$4 {
  constructor(t) {
    super(), init$4(this, t, null, create_fragment$4, safe_not_equal$4, {});
  }
}
const {
  SvelteComponent: SvelteComponent$3,
  append: append$3,
  attr: attr$3,
  detach: detach$3,
  init: init$3,
  insert: insert$3,
  noop: noop$1,
  safe_not_equal: safe_not_equal$3,
  svg_element: svg_element$1
} = window.__gradio__svelte__internal;
function create_fragment$3(i) {
  let t, n;
  return {
    c() {
      t = svg_element$1("svg"), n = svg_element$1("path"), attr$3(n, "d", "M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"), attr$3(t, "xmlns", "http://www.w3.org/2000/svg"), attr$3(t, "width", "100%"), attr$3(t, "height", "100%"), attr$3(t, "viewBox", "0 0 24 24"), attr$3(t, "fill", "none"), attr$3(t, "stroke", "currentColor"), attr$3(t, "stroke-width", "1.5"), attr$3(t, "stroke-linecap", "round"), attr$3(t, "stroke-linejoin", "round"), attr$3(t, "class", "feather feather-edit-2");
    },
    m(e, s) {
      insert$3(e, t, s), append$3(t, n);
    },
    p: noop$1,
    i: noop$1,
    o: noop$1,
    d(e) {
      e && detach$3(t);
    }
  };
}
class Edit extends SvelteComponent$3 {
  constructor(t) {
    super(), init$3(this, t, null, create_fragment$3, safe_not_equal$3, {});
  }
}
const {
  SvelteComponent: SvelteComponent$2,
  append: append$2,
  attr: attr$2,
  detach: detach$2,
  init: init$2,
  insert: insert$2,
  noop,
  safe_not_equal: safe_not_equal$2,
  svg_element
} = window.__gradio__svelte__internal;
function create_fragment$2(i) {
  let t, n, e;
  return {
    c() {
      t = svg_element("svg"), n = svg_element("polyline"), e = svg_element("path"), attr$2(n, "points", "1 4 1 10 7 10"), attr$2(e, "d", "M3.51 15a9 9 0 1 0 2.13-9.36L1 10"), attr$2(t, "xmlns", "http://www.w3.org/2000/svg"), attr$2(t, "width", "100%"), attr$2(t, "height", "100%"), attr$2(t, "viewBox", "0 0 24 24"), attr$2(t, "fill", "none"), attr$2(t, "stroke", "currentColor"), attr$2(t, "stroke-width", "2"), attr$2(t, "stroke-linecap", "round"), attr$2(t, "stroke-linejoin", "round"), attr$2(t, "class", "feather feather-rotate-ccw");
    },
    m(s, c) {
      insert$2(s, t, c), append$2(t, n), append$2(t, e);
    },
    p: noop,
    i: noop,
    o: noop,
    d(s) {
      s && detach$2(t);
    }
  };
}
class Undo extends SvelteComponent$2 {
  constructor(t) {
    super(), init$2(this, t, null, create_fragment$2, safe_not_equal$2, {});
  }
}
const {
  SvelteComponent: SvelteComponent$1,
  append: append$1,
  attr: attr$1,
  check_outros: check_outros$1,
  create_component: create_component$1,
  destroy_component: destroy_component$1,
  detach: detach$1,
  element: element$1,
  group_outros: group_outros$1,
  init: init$1,
  insert: insert$1,
  mount_component: mount_component$1,
  safe_not_equal: safe_not_equal$1,
  set_style: set_style$1,
  space: space$1,
  toggle_class,
  transition_in: transition_in$1,
  transition_out: transition_out$1
} = window.__gradio__svelte__internal, { createEventDispatcher } = window.__gradio__svelte__internal;
function create_if_block_1$1(i) {
  let t, n;
  return t = new IconButton({
    props: {
      Icon: Edit,
      label: (
        /*i18n*/
        i[3]("common.edit")
      )
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[5]
  ), {
    c() {
      create_component$1(t.$$.fragment);
    },
    m(e, s) {
      mount_component$1(t, e, s), n = !0;
    },
    p(e, s) {
      const c = {};
      s & /*i18n*/
      8 && (c.label = /*i18n*/
      e[3]("common.edit")), t.$set(c);
    },
    i(e) {
      n || (transition_in$1(t.$$.fragment, e), n = !0);
    },
    o(e) {
      transition_out$1(t.$$.fragment, e), n = !1;
    },
    d(e) {
      destroy_component$1(t, e);
    }
  };
}
function create_if_block$1(i) {
  let t, n;
  return t = new IconButton({
    props: {
      Icon: Undo,
      label: (
        /*i18n*/
        i[3]("common.undo")
      )
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    i[6]
  ), {
    c() {
      create_component$1(t.$$.fragment);
    },
    m(e, s) {
      mount_component$1(t, e, s), n = !0;
    },
    p(e, s) {
      const c = {};
      s & /*i18n*/
      8 && (c.label = /*i18n*/
      e[3]("common.undo")), t.$set(c);
    },
    i(e) {
      n || (transition_in$1(t.$$.fragment, e), n = !0);
    },
    o(e) {
      transition_out$1(t.$$.fragment, e), n = !1;
    },
    d(e) {
      destroy_component$1(t, e);
    }
  };
}
function create_fragment$1(i) {
  let t, n, e, s, c, h = (
    /*editable*/
    i[0] && create_if_block_1$1(i)
  ), b = (
    /*undoable*/
    i[1] && create_if_block$1(i)
  );
  return s = new IconButton({
    props: {
      Icon: Clear,
      label: (
        /*i18n*/
        i[3]("common.clear")
      )
    }
  }), s.$on(
    "click",
    /*click_handler_2*/
    i[7]
  ), {
    c() {
      t = element$1("div"), h && h.c(), n = space$1(), b && b.c(), e = space$1(), create_component$1(s.$$.fragment), attr$1(t, "class", "svelte-1wj0ocy"), toggle_class(t, "not-absolute", !/*absolute*/
      i[2]), set_style$1(
        t,
        "position",
        /*absolute*/
        i[2] ? "absolute" : "static"
      );
    },
    m(o, l) {
      insert$1(o, t, l), h && h.m(t, null), append$1(t, n), b && b.m(t, null), append$1(t, e), mount_component$1(s, t, null), c = !0;
    },
    p(o, [l]) {
      /*editable*/
      o[0] ? h ? (h.p(o, l), l & /*editable*/
      1 && transition_in$1(h, 1)) : (h = create_if_block_1$1(o), h.c(), transition_in$1(h, 1), h.m(t, n)) : h && (group_outros$1(), transition_out$1(h, 1, 1, () => {
        h = null;
      }), check_outros$1()), /*undoable*/
      o[1] ? b ? (b.p(o, l), l & /*undoable*/
      2 && transition_in$1(b, 1)) : (b = create_if_block$1(o), b.c(), transition_in$1(b, 1), b.m(t, e)) : b && (group_outros$1(), transition_out$1(b, 1, 1, () => {
        b = null;
      }), check_outros$1());
      const a = {};
      l & /*i18n*/
      8 && (a.label = /*i18n*/
      o[3]("common.clear")), s.$set(a), (!c || l & /*absolute*/
      4) && toggle_class(t, "not-absolute", !/*absolute*/
      o[2]), l & /*absolute*/
      4 && set_style$1(
        t,
        "position",
        /*absolute*/
        o[2] ? "absolute" : "static"
      );
    },
    i(o) {
      c || (transition_in$1(h), transition_in$1(b), transition_in$1(s.$$.fragment, o), c = !0);
    },
    o(o) {
      transition_out$1(h), transition_out$1(b), transition_out$1(s.$$.fragment, o), c = !1;
    },
    d(o) {
      o && detach$1(t), h && h.d(), b && b.d(), destroy_component$1(s);
    }
  };
}
function instance$1(i, t, n) {
  let { editable: e = !1 } = t, { undoable: s = !1 } = t, { absolute: c = !0 } = t, { i18n: h } = t;
  const b = createEventDispatcher(), o = () => b("edit"), l = () => b("undo"), a = (T) => {
    b("clear"), T.stopPropagation();
  };
  return i.$$set = (T) => {
    "editable" in T && n(0, e = T.editable), "undoable" in T && n(1, s = T.undoable), "absolute" in T && n(2, c = T.absolute), "i18n" in T && n(3, h = T.i18n);
  }, [
    e,
    s,
    c,
    h,
    b,
    o,
    l,
    a
  ];
}
class ModifyUpload extends SvelteComponent$1 {
  constructor(t) {
    super(), init$1(this, t, instance$1, create_fragment$1, safe_not_equal$1, {
      editable: 0,
      undoable: 1,
      absolute: 2,
      i18n: 3
    });
  }
}
function getAugmentedNamespace(i) {
  if (i.__esModule) return i;
  var t = i.default;
  if (typeof t == "function") {
    var n = function e() {
      return this instanceof e ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments);
    };
    n.prototype = t.prototype;
  } else n = {};
  return Object.defineProperty(n, "__esModule", { value: !0 }), Object.keys(i).forEach(function(e) {
    var s = Object.getOwnPropertyDescriptor(i, e);
    Object.defineProperty(n, e, s.get ? s : {
      enumerable: !0,
      get: function() {
        return i[e];
      }
    });
  }), n;
}
function commonjsRequire(i) {
  throw new Error('Could not dynamically require "' + i + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var pdf = { exports: {} };
const require$$5$1 = {}, __viteBrowserExternal = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: require$$5$1
}, Symbol.toStringTag, { value: "Module" })), require$$5 = /* @__PURE__ */ getAugmentedNamespace(__viteBrowserExternal);
(function(module, exports) {
  (function(t, n) {
    module.exports = t.pdfjsLib = n();
  })(globalThis, () => (
    /******/
    (() => {
      var __webpack_modules__ = [
        ,
        /* 1 */
        /***/
        (i, t) => {
          var Vt;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.VerbosityLevel = t.Util = t.UnknownErrorException = t.UnexpectedResponseException = t.TextRenderingMode = t.RenderingIntentFlag = t.PromiseCapability = t.PermissionFlag = t.PasswordResponses = t.PasswordException = t.PageActionEventType = t.OPS = t.MissingPDFException = t.MAX_IMAGE_SIZE_TO_CACHE = t.LINE_FACTOR = t.LINE_DESCENT_FACTOR = t.InvalidPDFException = t.ImageKind = t.IDENTITY_MATRIX = t.FormatError = t.FeatureTest = t.FONT_IDENTITY_MATRIX = t.DocumentActionEventType = t.CMapCompressionType = t.BaseException = t.BASELINE_FACTOR = t.AnnotationType = t.AnnotationReplyType = t.AnnotationPrefix = t.AnnotationMode = t.AnnotationFlag = t.AnnotationFieldFlag = t.AnnotationEditorType = t.AnnotationEditorPrefix = t.AnnotationEditorParamsType = t.AnnotationBorderStyleType = t.AnnotationActionEventType = t.AbortException = void 0, t.assert = D, t.bytesToString = dt, t.createValidAbsoluteUrl = Q, t.getModificationDate = Et, t.getUuid = $t, t.getVerbosityLevel = X, t.info = z, t.isArrayBuffer = nt, t.isArrayEqual = kt, t.isNodeJS = void 0, t.normalizeUnicode = Mt, t.objectFromMap = ut, t.objectSize = mt, t.setVerbosityLevel = Y, t.shadow = F, t.string32 = gt, t.stringToBytes = pt, t.stringToPDFString = _t, t.stringToUTF8String = wt, t.unreachable = et, t.utf8StringToString = vt, t.warn = L;
          const n = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser");
          t.isNodeJS = n;
          const e = [1, 0, 0, 1, 0, 0];
          t.IDENTITY_MATRIX = e;
          const s = [1e-3, 0, 0, 1e-3, 0, 0];
          t.FONT_IDENTITY_MATRIX = s;
          const c = 1e7;
          t.MAX_IMAGE_SIZE_TO_CACHE = c;
          const h = 1.35;
          t.LINE_FACTOR = h;
          const b = 0.35;
          t.LINE_DESCENT_FACTOR = b;
          const o = b / h;
          t.BASELINE_FACTOR = o;
          const l = {
            ANY: 1,
            DISPLAY: 2,
            PRINT: 4,
            SAVE: 8,
            ANNOTATIONS_FORMS: 16,
            ANNOTATIONS_STORAGE: 32,
            ANNOTATIONS_DISABLE: 64,
            OPLIST: 256
          };
          t.RenderingIntentFlag = l;
          const a = {
            DISABLE: 0,
            ENABLE: 1,
            ENABLE_FORMS: 2,
            ENABLE_STORAGE: 3
          };
          t.AnnotationMode = a;
          const T = "pdfjs_internal_editor_";
          t.AnnotationEditorPrefix = T;
          const P = {
            DISABLE: -1,
            NONE: 0,
            FREETEXT: 3,
            STAMP: 13,
            INK: 15
          };
          t.AnnotationEditorType = P;
          const v = {
            RESIZE: 1,
            CREATE: 2,
            FREETEXT_SIZE: 11,
            FREETEXT_COLOR: 12,
            FREETEXT_OPACITY: 13,
            INK_COLOR: 21,
            INK_THICKNESS: 22,
            INK_OPACITY: 23
          };
          t.AnnotationEditorParamsType = v;
          const k = {
            PRINT: 4,
            MODIFY_CONTENTS: 8,
            COPY: 16,
            MODIFY_ANNOTATIONS: 32,
            FILL_INTERACTIVE_FORMS: 256,
            COPY_FOR_ACCESSIBILITY: 512,
            ASSEMBLE: 1024,
            PRINT_HIGH_QUALITY: 2048
          };
          t.PermissionFlag = k;
          const x = {
            FILL: 0,
            STROKE: 1,
            FILL_STROKE: 2,
            INVISIBLE: 3,
            FILL_ADD_TO_PATH: 4,
            STROKE_ADD_TO_PATH: 5,
            FILL_STROKE_ADD_TO_PATH: 6,
            ADD_TO_PATH: 7,
            FILL_STROKE_MASK: 3,
            ADD_TO_PATH_FLAG: 4
          };
          t.TextRenderingMode = x;
          const S = {
            GRAYSCALE_1BPP: 1,
            RGB_24BPP: 2,
            RGBA_32BPP: 3
          };
          t.ImageKind = S;
          const E = {
            TEXT: 1,
            LINK: 2,
            FREETEXT: 3,
            LINE: 4,
            SQUARE: 5,
            CIRCLE: 6,
            POLYGON: 7,
            POLYLINE: 8,
            HIGHLIGHT: 9,
            UNDERLINE: 10,
            SQUIGGLY: 11,
            STRIKEOUT: 12,
            STAMP: 13,
            CARET: 14,
            INK: 15,
            POPUP: 16,
            FILEATTACHMENT: 17,
            SOUND: 18,
            MOVIE: 19,
            WIDGET: 20,
            SCREEN: 21,
            PRINTERMARK: 22,
            TRAPNET: 23,
            WATERMARK: 24,
            THREED: 25,
            REDACT: 26
          };
          t.AnnotationType = E;
          const w = {
            GROUP: "Group",
            REPLY: "R"
          };
          t.AnnotationReplyType = w;
          const M = {
            INVISIBLE: 1,
            HIDDEN: 2,
            PRINT: 4,
            NOZOOM: 8,
            NOROTATE: 16,
            NOVIEW: 32,
            READONLY: 64,
            LOCKED: 128,
            TOGGLENOVIEW: 256,
            LOCKEDCONTENTS: 512
          };
          t.AnnotationFlag = M;
          const g = {
            READONLY: 1,
            REQUIRED: 2,
            NOEXPORT: 4,
            MULTILINE: 4096,
            PASSWORD: 8192,
            NOTOGGLETOOFF: 16384,
            RADIO: 32768,
            PUSHBUTTON: 65536,
            COMBO: 131072,
            EDIT: 262144,
            SORT: 524288,
            FILESELECT: 1048576,
            MULTISELECT: 2097152,
            DONOTSPELLCHECK: 4194304,
            DONOTSCROLL: 8388608,
            COMB: 16777216,
            RICHTEXT: 33554432,
            RADIOSINUNISON: 33554432,
            COMMITONSELCHANGE: 67108864
          };
          t.AnnotationFieldFlag = g;
          const p = {
            SOLID: 1,
            DASHED: 2,
            BEVELED: 3,
            INSET: 4,
            UNDERLINE: 5
          };
          t.AnnotationBorderStyleType = p;
          const _ = {
            E: "Mouse Enter",
            X: "Mouse Exit",
            D: "Mouse Down",
            U: "Mouse Up",
            Fo: "Focus",
            Bl: "Blur",
            PO: "PageOpen",
            PC: "PageClose",
            PV: "PageVisible",
            PI: "PageInvisible",
            K: "Keystroke",
            F: "Format",
            V: "Validate",
            C: "Calculate"
          };
          t.AnnotationActionEventType = _;
          const f = {
            WC: "WillClose",
            WS: "WillSave",
            DS: "DidSave",
            WP: "WillPrint",
            DP: "DidPrint"
          };
          t.DocumentActionEventType = f;
          const A = {
            O: "PageOpen",
            C: "PageClose"
          };
          t.PageActionEventType = A;
          const C = {
            ERRORS: 0,
            WARNINGS: 1,
            INFOS: 5
          };
          t.VerbosityLevel = C;
          const W = {
            NONE: 0,
            BINARY: 1
          };
          t.CMapCompressionType = W;
          const m = {
            dependency: 1,
            setLineWidth: 2,
            setLineCap: 3,
            setLineJoin: 4,
            setMiterLimit: 5,
            setDash: 6,
            setRenderingIntent: 7,
            setFlatness: 8,
            setGState: 9,
            save: 10,
            restore: 11,
            transform: 12,
            moveTo: 13,
            lineTo: 14,
            curveTo: 15,
            curveTo2: 16,
            curveTo3: 17,
            closePath: 18,
            rectangle: 19,
            stroke: 20,
            closeStroke: 21,
            fill: 22,
            eoFill: 23,
            fillStroke: 24,
            eoFillStroke: 25,
            closeFillStroke: 26,
            closeEOFillStroke: 27,
            endPath: 28,
            clip: 29,
            eoClip: 30,
            beginText: 31,
            endText: 32,
            setCharSpacing: 33,
            setWordSpacing: 34,
            setHScale: 35,
            setLeading: 36,
            setFont: 37,
            setTextRenderingMode: 38,
            setTextRise: 39,
            moveText: 40,
            setLeadingMoveText: 41,
            setTextMatrix: 42,
            nextLine: 43,
            showText: 44,
            showSpacedText: 45,
            nextLineShowText: 46,
            nextLineSetSpacingShowText: 47,
            setCharWidth: 48,
            setCharWidthAndBounds: 49,
            setStrokeColorSpace: 50,
            setFillColorSpace: 51,
            setStrokeColor: 52,
            setStrokeColorN: 53,
            setFillColor: 54,
            setFillColorN: 55,
            setStrokeGray: 56,
            setFillGray: 57,
            setStrokeRGBColor: 58,
            setFillRGBColor: 59,
            setStrokeCMYKColor: 60,
            setFillCMYKColor: 61,
            shadingFill: 62,
            beginInlineImage: 63,
            beginImageData: 64,
            endInlineImage: 65,
            paintXObject: 66,
            markPoint: 67,
            markPointProps: 68,
            beginMarkedContent: 69,
            beginMarkedContentProps: 70,
            endMarkedContent: 71,
            beginCompat: 72,
            endCompat: 73,
            paintFormXObjectBegin: 74,
            paintFormXObjectEnd: 75,
            beginGroup: 76,
            endGroup: 77,
            beginAnnotation: 80,
            endAnnotation: 81,
            paintImageMaskXObject: 83,
            paintImageMaskXObjectGroup: 84,
            paintImageXObject: 85,
            paintInlineImageXObject: 86,
            paintInlineImageXObjectGroup: 87,
            paintImageXObjectRepeat: 88,
            paintImageMaskXObjectRepeat: 89,
            paintSolidColorImageMask: 90,
            constructPath: 91
          };
          t.OPS = m;
          const I = {
            NEED_PASSWORD: 1,
            INCORRECT_PASSWORD: 2
          };
          t.PasswordResponses = I;
          let q = C.WARNINGS;
          function Y(At) {
            Number.isInteger(At) && (q = At);
          }
          function X() {
            return q;
          }
          function z(At) {
            q >= C.INFOS && console.log(`Info: ${At}`);
          }
          function L(At) {
            q >= C.WARNINGS && console.log(`Warning: ${At}`);
          }
          function et(At) {
            throw new Error(At);
          }
          function D(At, ot) {
            At || et(ot);
          }
          function G(At) {
            switch (At == null ? void 0 : At.protocol) {
              case "http:":
              case "https:":
              case "ftp:":
              case "mailto:":
              case "tel:":
                return !0;
              default:
                return !1;
            }
          }
          function Q(At, ot = null, ct = null) {
            if (!At)
              return null;
            try {
              if (ct && typeof At == "string") {
                if (ct.addDefaultProtocol && At.startsWith("www.")) {
                  const Ht = At.match(/\./g);
                  (Ht == null ? void 0 : Ht.length) >= 2 && (At = `http://${At}`);
                }
                if (ct.tryConvertEncoding)
                  try {
                    At = wt(At);
                  } catch {
                  }
              }
              const Ft = ot ? new URL(At, ot) : new URL(At);
              if (G(Ft))
                return Ft;
            } catch {
            }
            return null;
          }
          function F(At, ot, ct, Ft = !1) {
            return Object.defineProperty(At, ot, {
              value: ct,
              enumerable: !Ft,
              configurable: !0,
              writable: !1
            }), ct;
          }
          const d = function() {
            function ot(ct, Ft) {
              this.constructor === ot && et("Cannot initialize BaseException."), this.message = ct, this.name = Ft;
            }
            return ot.prototype = new Error(), ot.constructor = ot, ot;
          }();
          t.BaseException = d;
          class u extends d {
            constructor(ot, ct) {
              super(ot, "PasswordException"), this.code = ct;
            }
          }
          t.PasswordException = u;
          class y extends d {
            constructor(ot, ct) {
              super(ot, "UnknownErrorException"), this.details = ct;
            }
          }
          t.UnknownErrorException = y;
          class B extends d {
            constructor(ot) {
              super(ot, "InvalidPDFException");
            }
          }
          t.InvalidPDFException = B;
          class N extends d {
            constructor(ot) {
              super(ot, "MissingPDFException");
            }
          }
          t.MissingPDFException = N;
          class $ extends d {
            constructor(ot, ct) {
              super(ot, "UnexpectedResponseException"), this.status = ct;
            }
          }
          t.UnexpectedResponseException = $;
          class K extends d {
            constructor(ot) {
              super(ot, "FormatError");
            }
          }
          t.FormatError = K;
          class st extends d {
            constructor(ot) {
              super(ot, "AbortException");
            }
          }
          t.AbortException = st;
          function dt(At) {
            (typeof At != "object" || (At == null ? void 0 : At.length) === void 0) && et("Invalid argument for bytesToString");
            const ot = At.length, ct = 8192;
            if (ot < ct)
              return String.fromCharCode.apply(null, At);
            const Ft = [];
            for (let Ht = 0; Ht < ot; Ht += ct) {
              const Wt = Math.min(Ht + ct, ot), H = At.subarray(Ht, Wt);
              Ft.push(String.fromCharCode.apply(null, H));
            }
            return Ft.join("");
          }
          function pt(At) {
            typeof At != "string" && et("Invalid argument for stringToBytes");
            const ot = At.length, ct = new Uint8Array(ot);
            for (let Ft = 0; Ft < ot; ++Ft)
              ct[Ft] = At.charCodeAt(Ft) & 255;
            return ct;
          }
          function gt(At) {
            return String.fromCharCode(At >> 24 & 255, At >> 16 & 255, At >> 8 & 255, At & 255);
          }
          function mt(At) {
            return Object.keys(At).length;
          }
          function ut(At) {
            const ot = /* @__PURE__ */ Object.create(null);
            for (const [ct, Ft] of At)
              ot[ct] = Ft;
            return ot;
          }
          function tt() {
            const At = new Uint8Array(4);
            return At[0] = 1, new Uint32Array(At.buffer, 0, 1)[0] === 1;
          }
          function it() {
            try {
              return new Function(""), !0;
            } catch {
              return !1;
            }
          }
          class R {
            static get isLittleEndian() {
              return F(this, "isLittleEndian", tt());
            }
            static get isEvalSupported() {
              return F(this, "isEvalSupported", it());
            }
            static get isOffscreenCanvasSupported() {
              return F(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
            }
            static get platform() {
              return typeof navigator > "u" ? F(this, "platform", {
                isWin: !1,
                isMac: !1
              }) : F(this, "platform", {
                isWin: navigator.platform.includes("Win"),
                isMac: navigator.platform.includes("Mac")
              });
            }
            static get isCSSRoundSupported() {
              var ot, ct;
              return F(this, "isCSSRoundSupported", (ct = (ot = globalThis.CSS) == null ? void 0 : ot.supports) == null ? void 0 : ct.call(ot, "width: round(1.5px, 1px)"));
            }
          }
          t.FeatureTest = R;
          const U = [...Array(256).keys()].map((At) => At.toString(16).padStart(2, "0"));
          class J {
            static makeHexColor(ot, ct, Ft) {
              return `#${U[ot]}${U[ct]}${U[Ft]}`;
            }
            static scaleMinMax(ot, ct) {
              let Ft;
              ot[0] ? (ot[0] < 0 && (Ft = ct[0], ct[0] = ct[1], ct[1] = Ft), ct[0] *= ot[0], ct[1] *= ot[0], ot[3] < 0 && (Ft = ct[2], ct[2] = ct[3], ct[3] = Ft), ct[2] *= ot[3], ct[3] *= ot[3]) : (Ft = ct[0], ct[0] = ct[2], ct[2] = Ft, Ft = ct[1], ct[1] = ct[3], ct[3] = Ft, ot[1] < 0 && (Ft = ct[2], ct[2] = ct[3], ct[3] = Ft), ct[2] *= ot[1], ct[3] *= ot[1], ot[2] < 0 && (Ft = ct[0], ct[0] = ct[1], ct[1] = Ft), ct[0] *= ot[2], ct[1] *= ot[2]), ct[0] += ot[4], ct[1] += ot[4], ct[2] += ot[5], ct[3] += ot[5];
            }
            static transform(ot, ct) {
              return [ot[0] * ct[0] + ot[2] * ct[1], ot[1] * ct[0] + ot[3] * ct[1], ot[0] * ct[2] + ot[2] * ct[3], ot[1] * ct[2] + ot[3] * ct[3], ot[0] * ct[4] + ot[2] * ct[5] + ot[4], ot[1] * ct[4] + ot[3] * ct[5] + ot[5]];
            }
            static applyTransform(ot, ct) {
              const Ft = ot[0] * ct[0] + ot[1] * ct[2] + ct[4], Ht = ot[0] * ct[1] + ot[1] * ct[3] + ct[5];
              return [Ft, Ht];
            }
            static applyInverseTransform(ot, ct) {
              const Ft = ct[0] * ct[3] - ct[1] * ct[2], Ht = (ot[0] * ct[3] - ot[1] * ct[2] + ct[2] * ct[5] - ct[4] * ct[3]) / Ft, Wt = (-ot[0] * ct[1] + ot[1] * ct[0] + ct[4] * ct[1] - ct[5] * ct[0]) / Ft;
              return [Ht, Wt];
            }
            static getAxialAlignedBoundingBox(ot, ct) {
              const Ft = this.applyTransform(ot, ct), Ht = this.applyTransform(ot.slice(2, 4), ct), Wt = this.applyTransform([ot[0], ot[3]], ct), H = this.applyTransform([ot[2], ot[1]], ct);
              return [Math.min(Ft[0], Ht[0], Wt[0], H[0]), Math.min(Ft[1], Ht[1], Wt[1], H[1]), Math.max(Ft[0], Ht[0], Wt[0], H[0]), Math.max(Ft[1], Ht[1], Wt[1], H[1])];
            }
            static inverseTransform(ot) {
              const ct = ot[0] * ot[3] - ot[1] * ot[2];
              return [ot[3] / ct, -ot[1] / ct, -ot[2] / ct, ot[0] / ct, (ot[2] * ot[5] - ot[4] * ot[3]) / ct, (ot[4] * ot[1] - ot[5] * ot[0]) / ct];
            }
            static singularValueDecompose2dScale(ot) {
              const ct = [ot[0], ot[2], ot[1], ot[3]], Ft = ot[0] * ct[0] + ot[1] * ct[2], Ht = ot[0] * ct[1] + ot[1] * ct[3], Wt = ot[2] * ct[0] + ot[3] * ct[2], H = ot[2] * ct[1] + ot[3] * ct[3], bt = (Ft + H) / 2, Ct = Math.sqrt((Ft + H) ** 2 - 4 * (Ft * H - Wt * Ht)) / 2, Dt = bt + Ct || 1, Ot = bt - Ct || 1;
              return [Math.sqrt(Dt), Math.sqrt(Ot)];
            }
            static normalizeRect(ot) {
              const ct = ot.slice(0);
              return ot[0] > ot[2] && (ct[0] = ot[2], ct[2] = ot[0]), ot[1] > ot[3] && (ct[1] = ot[3], ct[3] = ot[1]), ct;
            }
            static intersect(ot, ct) {
              const Ft = Math.max(Math.min(ot[0], ot[2]), Math.min(ct[0], ct[2])), Ht = Math.min(Math.max(ot[0], ot[2]), Math.max(ct[0], ct[2]));
              if (Ft > Ht)
                return null;
              const Wt = Math.max(Math.min(ot[1], ot[3]), Math.min(ct[1], ct[3])), H = Math.min(Math.max(ot[1], ot[3]), Math.max(ct[1], ct[3]));
              return Wt > H ? null : [Ft, Wt, Ht, H];
            }
            static bezierBoundingBox(ot, ct, Ft, Ht, Wt, H, bt, Ct) {
              const Dt = [], Ot = [[], []];
              let Pt, j, O, V, ht, ft, yt, St;
              for (let jt = 0; jt < 2; ++jt) {
                if (jt === 0 ? (j = 6 * ot - 12 * Ft + 6 * Wt, Pt = -3 * ot + 9 * Ft - 9 * Wt + 3 * bt, O = 3 * Ft - 3 * ot) : (j = 6 * ct - 12 * Ht + 6 * H, Pt = -3 * ct + 9 * Ht - 9 * H + 3 * Ct, O = 3 * Ht - 3 * ct), Math.abs(Pt) < 1e-12) {
                  if (Math.abs(j) < 1e-12)
                    continue;
                  V = -O / j, 0 < V && V < 1 && Dt.push(V);
                  continue;
                }
                yt = j * j - 4 * O * Pt, St = Math.sqrt(yt), !(yt < 0) && (ht = (-j + St) / (2 * Pt), 0 < ht && ht < 1 && Dt.push(ht), ft = (-j - St) / (2 * Pt), 0 < ft && ft < 1 && Dt.push(ft));
              }
              let It = Dt.length, Rt;
              const Tt = It;
              for (; It--; )
                V = Dt[It], Rt = 1 - V, Ot[0][It] = Rt * Rt * Rt * ot + 3 * Rt * Rt * V * Ft + 3 * Rt * V * V * Wt + V * V * V * bt, Ot[1][It] = Rt * Rt * Rt * ct + 3 * Rt * Rt * V * Ht + 3 * Rt * V * V * H + V * V * V * Ct;
              return Ot[0][Tt] = ot, Ot[1][Tt] = ct, Ot[0][Tt + 1] = bt, Ot[1][Tt + 1] = Ct, Ot[0].length = Ot[1].length = Tt + 2, [Math.min(...Ot[0]), Math.min(...Ot[1]), Math.max(...Ot[0]), Math.max(...Ot[1])];
            }
          }
          t.Util = J;
          const rt = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 728, 711, 710, 729, 733, 731, 730, 732, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8226, 8224, 8225, 8230, 8212, 8211, 402, 8260, 8249, 8250, 8722, 8240, 8222, 8220, 8221, 8216, 8217, 8218, 8482, 64257, 64258, 321, 338, 352, 376, 381, 305, 322, 339, 353, 382, 0, 8364];
          function _t(At) {
            if (At[0] >= "ï") {
              let ct;
              if (At[0] === "þ" && At[1] === "ÿ" ? ct = "utf-16be" : At[0] === "ÿ" && At[1] === "þ" ? ct = "utf-16le" : At[0] === "ï" && At[1] === "»" && At[2] === "¿" && (ct = "utf-8"), ct)
                try {
                  const Ft = new TextDecoder(ct, {
                    fatal: !0
                  }), Ht = pt(At);
                  return Ft.decode(Ht);
                } catch (Ft) {
                  L(`stringToPDFString: "${Ft}".`);
                }
            }
            const ot = [];
            for (let ct = 0, Ft = At.length; ct < Ft; ct++) {
              const Ht = rt[At.charCodeAt(ct)];
              ot.push(Ht ? String.fromCharCode(Ht) : At.charAt(ct));
            }
            return ot.join("");
          }
          function wt(At) {
            return decodeURIComponent(escape(At));
          }
          function vt(At) {
            return unescape(encodeURIComponent(At));
          }
          function nt(At) {
            return typeof At == "object" && (At == null ? void 0 : At.byteLength) !== void 0;
          }
          function kt(At, ot) {
            if (At.length !== ot.length)
              return !1;
            for (let ct = 0, Ft = At.length; ct < Ft; ct++)
              if (At[ct] !== ot[ct])
                return !1;
            return !0;
          }
          function Et(At = /* @__PURE__ */ new Date()) {
            return [At.getUTCFullYear().toString(), (At.getUTCMonth() + 1).toString().padStart(2, "0"), At.getUTCDate().toString().padStart(2, "0"), At.getUTCHours().toString().padStart(2, "0"), At.getUTCMinutes().toString().padStart(2, "0"), At.getUTCSeconds().toString().padStart(2, "0")].join("");
          }
          class Ut {
            constructor() {
              at(this, Vt, !1);
              this.promise = new Promise((ot, ct) => {
                this.resolve = (Ft) => {
                  lt(this, Vt, !0), ot(Ft);
                }, this.reject = (Ft) => {
                  lt(this, Vt, !0), ct(Ft);
                };
              });
            }
            get settled() {
              return r(this, Vt);
            }
          }
          Vt = new WeakMap(), t.PromiseCapability = Ut;
          let Nt = null, zt = null;
          function Mt(At) {
            return Nt || (Nt = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, zt = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), At.replaceAll(Nt, (ot, ct, Ft) => ct ? ct.normalize("NFKC") : zt.get(Ft));
          }
          function $t() {
            if (typeof crypto < "u" && typeof (crypto == null ? void 0 : crypto.randomUUID) == "function")
              return crypto.randomUUID();
            const At = new Uint8Array(32);
            if (typeof crypto < "u" && typeof (crypto == null ? void 0 : crypto.getRandomValues) == "function")
              crypto.getRandomValues(At);
            else
              for (let ot = 0; ot < 32; ot++)
                At[ot] = Math.floor(Math.random() * 255);
            return dt(At);
          }
          const Gt = "pdfjs_internal_id_";
          t.AnnotationPrefix = Gt;
        },
        /* 2 */
        /***/
        (__unused_webpack_module, exports, __w_pdfjs_require__) => {
          var i, n, e, s, re, be, b, o, l, a, T, P, v, k, x, ye, E, w, De, g, p;
          Object.defineProperty(exports, "__esModule", {
            value: !0
          }), exports.RenderTask = exports.PDFWorkerUtil = exports.PDFWorker = exports.PDFPageProxy = exports.PDFDocumentProxy = exports.PDFDocumentLoadingTask = exports.PDFDataRangeTransport = exports.LoopbackPort = exports.DefaultStandardFontDataFactory = exports.DefaultFilterFactory = exports.DefaultCanvasFactory = exports.DefaultCMapReaderFactory = void 0, Object.defineProperty(exports, "SVGGraphics", {
            enumerable: !0,
            get: function() {
              return _displaySvg.SVGGraphics;
            }
          }), exports.build = void 0, exports.getDocument = getDocument, exports.version = void 0;
          var _util = __w_pdfjs_require__(1), _annotation_storage = __w_pdfjs_require__(3), _display_utils = __w_pdfjs_require__(6), _font_loader = __w_pdfjs_require__(9), _displayNode_utils = __w_pdfjs_require__(10), _canvas = __w_pdfjs_require__(11), _worker_options = __w_pdfjs_require__(14), _message_handler = __w_pdfjs_require__(15), _metadata = __w_pdfjs_require__(16), _optional_content_config = __w_pdfjs_require__(17), _transport_stream = __w_pdfjs_require__(18), _displayFetch_stream = __w_pdfjs_require__(19), _displayNetwork = __w_pdfjs_require__(22), _displayNode_stream = __w_pdfjs_require__(23), _displaySvg = __w_pdfjs_require__(24), _xfa_text = __w_pdfjs_require__(25);
          const DEFAULT_RANGE_CHUNK_SIZE = 65536, RENDERING_CANCELLED_TIMEOUT = 100, DELAYED_CLEANUP_TIMEOUT = 5e3, DefaultCanvasFactory = _util.isNodeJS ? _displayNode_utils.NodeCanvasFactory : _display_utils.DOMCanvasFactory;
          exports.DefaultCanvasFactory = DefaultCanvasFactory;
          const DefaultCMapReaderFactory = _util.isNodeJS ? _displayNode_utils.NodeCMapReaderFactory : _display_utils.DOMCMapReaderFactory;
          exports.DefaultCMapReaderFactory = DefaultCMapReaderFactory;
          const DefaultFilterFactory = _util.isNodeJS ? _displayNode_utils.NodeFilterFactory : _display_utils.DOMFilterFactory;
          exports.DefaultFilterFactory = DefaultFilterFactory;
          const DefaultStandardFontDataFactory = _util.isNodeJS ? _displayNode_utils.NodeStandardFontDataFactory : _display_utils.DOMStandardFontDataFactory;
          exports.DefaultStandardFontDataFactory = DefaultStandardFontDataFactory;
          function getDocument(f) {
            if (typeof f == "string" || f instanceof URL ? f = {
              url: f
            } : (0, _util.isArrayBuffer)(f) && (f = {
              data: f
            }), typeof f != "object")
              throw new Error("Invalid parameter in getDocument, need parameter object.");
            if (!f.url && !f.data && !f.range)
              throw new Error("Invalid parameter object: need either .data, .range or .url");
            const A = new PDFDocumentLoadingTask(), {
              docId: C
            } = A, W = f.url ? getUrlProp(f.url) : null, m = f.data ? getDataProp(f.data) : null, I = f.httpHeaders || null, q = f.withCredentials === !0, Y = f.password ?? null, X = f.range instanceof PDFDataRangeTransport ? f.range : null, z = Number.isInteger(f.rangeChunkSize) && f.rangeChunkSize > 0 ? f.rangeChunkSize : DEFAULT_RANGE_CHUNK_SIZE;
            let L = f.worker instanceof PDFWorker ? f.worker : null;
            const et = f.verbosity, D = typeof f.docBaseUrl == "string" && !(0, _display_utils.isDataScheme)(f.docBaseUrl) ? f.docBaseUrl : null, G = typeof f.cMapUrl == "string" ? f.cMapUrl : null, Q = f.cMapPacked !== !1, F = f.CMapReaderFactory || DefaultCMapReaderFactory, d = typeof f.standardFontDataUrl == "string" ? f.standardFontDataUrl : null, u = f.StandardFontDataFactory || DefaultStandardFontDataFactory, y = f.stopAtErrors !== !0, B = Number.isInteger(f.maxImageSize) && f.maxImageSize > -1 ? f.maxImageSize : -1, N = f.isEvalSupported !== !1, $ = typeof f.isOffscreenCanvasSupported == "boolean" ? f.isOffscreenCanvasSupported : !_util.isNodeJS, K = Number.isInteger(f.canvasMaxAreaInBytes) ? f.canvasMaxAreaInBytes : -1, st = typeof f.disableFontFace == "boolean" ? f.disableFontFace : _util.isNodeJS, dt = f.fontExtraProperties === !0, pt = f.enableXfa === !0, gt = f.ownerDocument || globalThis.document, mt = f.disableRange === !0, ut = f.disableStream === !0, tt = f.disableAutoFetch === !0, it = f.pdfBug === !0, R = X ? X.length : f.length ?? NaN, U = typeof f.useSystemFonts == "boolean" ? f.useSystemFonts : !_util.isNodeJS && !st, J = typeof f.useWorkerFetch == "boolean" ? f.useWorkerFetch : F === _display_utils.DOMCMapReaderFactory && u === _display_utils.DOMStandardFontDataFactory && G && d && (0, _display_utils.isValidFetchUrl)(G, document.baseURI) && (0, _display_utils.isValidFetchUrl)(d, document.baseURI), rt = f.canvasFactory || new DefaultCanvasFactory({
              ownerDocument: gt
            }), _t = f.filterFactory || new DefaultFilterFactory({
              docId: C,
              ownerDocument: gt
            }), wt = null;
            (0, _util.setVerbosityLevel)(et);
            const vt = {
              canvasFactory: rt,
              filterFactory: _t
            };
            if (J || (vt.cMapReaderFactory = new F({
              baseUrl: G,
              isCompressed: Q
            }), vt.standardFontDataFactory = new u({
              baseUrl: d
            })), !L) {
              const Et = {
                verbosity: et,
                port: _worker_options.GlobalWorkerOptions.workerPort
              };
              L = Et.port ? PDFWorker.fromPort(Et) : new PDFWorker(Et), A._worker = L;
            }
            const nt = {
              docId: C,
              apiVersion: "3.11.174",
              data: m,
              password: Y,
              disableAutoFetch: tt,
              rangeChunkSize: z,
              length: R,
              docBaseUrl: D,
              enableXfa: pt,
              evaluatorOptions: {
                maxImageSize: B,
                disableFontFace: st,
                ignoreErrors: y,
                isEvalSupported: N,
                isOffscreenCanvasSupported: $,
                canvasMaxAreaInBytes: K,
                fontExtraProperties: dt,
                useSystemFonts: U,
                cMapUrl: J ? G : null,
                standardFontDataUrl: J ? d : null
              }
            }, kt = {
              ignoreErrors: y,
              isEvalSupported: N,
              disableFontFace: st,
              fontExtraProperties: dt,
              enableXfa: pt,
              ownerDocument: gt,
              disableAutoFetch: tt,
              pdfBug: it,
              styleElement: wt
            };
            return L.promise.then(function() {
              if (A.destroyed)
                throw new Error("Loading aborted");
              const Et = _fetchDocument(L, nt), Ut = new Promise(function(Nt) {
                let zt;
                X ? zt = new _transport_stream.PDFDataTransportStream({
                  length: R,
                  initialData: X.initialData,
                  progressiveDone: X.progressiveDone,
                  contentDispositionFilename: X.contentDispositionFilename,
                  disableRange: mt,
                  disableStream: ut
                }, X) : m || (zt = (($t) => _util.isNodeJS ? new _displayNode_stream.PDFNodeStream($t) : (0, _display_utils.isValidFetchUrl)($t.url) ? new _displayFetch_stream.PDFFetchStream($t) : new _displayNetwork.PDFNetworkStream($t))({
                  url: W,
                  length: R,
                  httpHeaders: I,
                  withCredentials: q,
                  rangeChunkSize: z,
                  disableRange: mt,
                  disableStream: ut
                })), Nt(zt);
              });
              return Promise.all([Et, Ut]).then(function([Nt, zt]) {
                if (A.destroyed)
                  throw new Error("Loading aborted");
                const Mt = new _message_handler.MessageHandler(C, Nt, L.port), $t = new WorkerTransport(Mt, A, zt, kt, vt);
                A._transport = $t, Mt.send("Ready", null);
              });
            }).catch(A._capability.reject), A;
          }
          async function _fetchDocument(f, A) {
            if (f.destroyed)
              throw new Error("Worker was destroyed");
            const C = await f.messageHandler.sendWithPromise("GetDocRequest", A, A.data ? [A.data.buffer] : null);
            if (f.destroyed)
              throw new Error("Worker was destroyed");
            return C;
          }
          function getUrlProp(f) {
            if (f instanceof URL)
              return f.href;
            try {
              return new URL(f, window.location).href;
            } catch {
              if (_util.isNodeJS && typeof f == "string")
                return f;
            }
            throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
          }
          function getDataProp(f) {
            if (_util.isNodeJS && typeof Buffer < "u" && f instanceof Buffer)
              throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
            if (f instanceof Uint8Array && f.byteLength === f.buffer.byteLength)
              return f;
            if (typeof f == "string")
              return (0, _util.stringToBytes)(f);
            if (typeof f == "object" && !isNaN(f == null ? void 0 : f.length) || (0, _util.isArrayBuffer)(f))
              return new Uint8Array(f);
            throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
          }
          const t = class t {
            constructor() {
              this._capability = new _util.PromiseCapability(), this._transport = null, this._worker = null, this.docId = `d${he(t, i)._++}`, this.destroyed = !1, this.onPassword = null, this.onProgress = null;
            }
            get promise() {
              return this._capability.promise;
            }
            async destroy() {
              var A, C, W;
              this.destroyed = !0;
              try {
                (A = this._worker) != null && A.port && (this._worker._pendingDestroy = !0), await ((C = this._transport) == null ? void 0 : C.destroy());
              } catch (m) {
                throw (W = this._worker) != null && W.port && delete this._worker._pendingDestroy, m;
              }
              this._transport = null, this._worker && (this._worker.destroy(), this._worker = null);
            }
          };
          i = new WeakMap(), at(t, i, 0);
          let PDFDocumentLoadingTask = t;
          exports.PDFDocumentLoadingTask = PDFDocumentLoadingTask;
          class PDFDataRangeTransport {
            constructor(A, C, W = !1, m = null) {
              this.length = A, this.initialData = C, this.progressiveDone = W, this.contentDispositionFilename = m, this._rangeListeners = [], this._progressListeners = [], this._progressiveReadListeners = [], this._progressiveDoneListeners = [], this._readyCapability = new _util.PromiseCapability();
            }
            addRangeListener(A) {
              this._rangeListeners.push(A);
            }
            addProgressListener(A) {
              this._progressListeners.push(A);
            }
            addProgressiveReadListener(A) {
              this._progressiveReadListeners.push(A);
            }
            addProgressiveDoneListener(A) {
              this._progressiveDoneListeners.push(A);
            }
            onDataRange(A, C) {
              for (const W of this._rangeListeners)
                W(A, C);
            }
            onDataProgress(A, C) {
              this._readyCapability.promise.then(() => {
                for (const W of this._progressListeners)
                  W(A, C);
              });
            }
            onDataProgressiveRead(A) {
              this._readyCapability.promise.then(() => {
                for (const C of this._progressiveReadListeners)
                  C(A);
              });
            }
            onDataProgressiveDone() {
              this._readyCapability.promise.then(() => {
                for (const A of this._progressiveDoneListeners)
                  A();
              });
            }
            transportReady() {
              this._readyCapability.resolve();
            }
            requestDataRange(A, C) {
              (0, _util.unreachable)("Abstract method PDFDataRangeTransport.requestDataRange");
            }
            abort() {
            }
          }
          exports.PDFDataRangeTransport = PDFDataRangeTransport;
          class PDFDocumentProxy {
            constructor(A, C) {
              this._pdfInfo = A, this._transport = C, Object.defineProperty(this, "getJavaScript", {
                value: () => ((0, _display_utils.deprecated)("`PDFDocumentProxy.getJavaScript`, please use `PDFDocumentProxy.getJSActions` instead."), this.getJSActions().then((W) => {
                  if (!W)
                    return W;
                  const m = [];
                  for (const I in W)
                    m.push(...W[I]);
                  return m;
                }))
              });
            }
            get annotationStorage() {
              return this._transport.annotationStorage;
            }
            get filterFactory() {
              return this._transport.filterFactory;
            }
            get numPages() {
              return this._pdfInfo.numPages;
            }
            get fingerprints() {
              return this._pdfInfo.fingerprints;
            }
            get isPureXfa() {
              return (0, _util.shadow)(this, "isPureXfa", !!this._transport._htmlForXfa);
            }
            get allXfaHtml() {
              return this._transport._htmlForXfa;
            }
            getPage(A) {
              return this._transport.getPage(A);
            }
            getPageIndex(A) {
              return this._transport.getPageIndex(A);
            }
            getDestinations() {
              return this._transport.getDestinations();
            }
            getDestination(A) {
              return this._transport.getDestination(A);
            }
            getPageLabels() {
              return this._transport.getPageLabels();
            }
            getPageLayout() {
              return this._transport.getPageLayout();
            }
            getPageMode() {
              return this._transport.getPageMode();
            }
            getViewerPreferences() {
              return this._transport.getViewerPreferences();
            }
            getOpenAction() {
              return this._transport.getOpenAction();
            }
            getAttachments() {
              return this._transport.getAttachments();
            }
            getJSActions() {
              return this._transport.getDocJSActions();
            }
            getOutline() {
              return this._transport.getOutline();
            }
            getOptionalContentConfig() {
              return this._transport.getOptionalContentConfig();
            }
            getPermissions() {
              return this._transport.getPermissions();
            }
            getMetadata() {
              return this._transport.getMetadata();
            }
            getMarkInfo() {
              return this._transport.getMarkInfo();
            }
            getData() {
              return this._transport.getData();
            }
            saveDocument() {
              return this._transport.saveDocument();
            }
            getDownloadInfo() {
              return this._transport.downloadInfoCapability.promise;
            }
            cleanup(A = !1) {
              return this._transport.startCleanup(A || this.isPureXfa);
            }
            destroy() {
              return this.loadingTask.destroy();
            }
            get loadingParams() {
              return this._transport.loadingParams;
            }
            get loadingTask() {
              return this._transport.loadingTask;
            }
            getFieldObjects() {
              return this._transport.getFieldObjects();
            }
            hasJSActions() {
              return this._transport.hasJSActions();
            }
            getCalculationOrderIds() {
              return this._transport.getCalculationOrderIds();
            }
          }
          exports.PDFDocumentProxy = PDFDocumentProxy;
          class PDFPageProxy {
            constructor(A, C, W, m = !1) {
              at(this, s);
              at(this, n, null);
              at(this, e, !1);
              this._pageIndex = A, this._pageInfo = C, this._transport = W, this._stats = m ? new _display_utils.StatTimer() : null, this._pdfBug = m, this.commonObjs = W.commonObjs, this.objs = new PDFObjects(), this._maybeCleanupAfterRender = !1, this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1;
            }
            get pageNumber() {
              return this._pageIndex + 1;
            }
            get rotate() {
              return this._pageInfo.rotate;
            }
            get ref() {
              return this._pageInfo.ref;
            }
            get userUnit() {
              return this._pageInfo.userUnit;
            }
            get view() {
              return this._pageInfo.view;
            }
            getViewport({
              scale: A,
              rotation: C = this.rotate,
              offsetX: W = 0,
              offsetY: m = 0,
              dontFlip: I = !1
            } = {}) {
              return new _display_utils.PageViewport({
                viewBox: this.view,
                scale: A,
                rotation: C,
                offsetX: W,
                offsetY: m,
                dontFlip: I
              });
            }
            getAnnotations({
              intent: A = "display"
            } = {}) {
              const C = this._transport.getRenderingIntent(A);
              return this._transport.getAnnotations(this._pageIndex, C.renderingIntent);
            }
            getJSActions() {
              return this._transport.getPageJSActions(this._pageIndex);
            }
            get filterFactory() {
              return this._transport.filterFactory;
            }
            get isPureXfa() {
              return (0, _util.shadow)(this, "isPureXfa", !!this._transport._htmlForXfa);
            }
            async getXfa() {
              var A;
              return ((A = this._transport._htmlForXfa) == null ? void 0 : A.children[this._pageIndex]) || null;
            }
            render({
              canvasContext: A,
              viewport: C,
              intent: W = "display",
              annotationMode: m = _util.AnnotationMode.ENABLE,
              transform: I = null,
              background: q = null,
              optionalContentConfigPromise: Y = null,
              annotationCanvasMap: X = null,
              pageColors: z = null,
              printAnnotationStorage: L = null
            }) {
              var u, y;
              (u = this._stats) == null || u.time("Overall");
              const et = this._transport.getRenderingIntent(W, m, L);
              lt(this, e, !1), Z(this, s, be).call(this), Y || (Y = this._transport.getOptionalContentConfig());
              let D = this._intentStates.get(et.cacheKey);
              D || (D = /* @__PURE__ */ Object.create(null), this._intentStates.set(et.cacheKey, D)), D.streamReaderCancelTimeout && (clearTimeout(D.streamReaderCancelTimeout), D.streamReaderCancelTimeout = null);
              const G = !!(et.renderingIntent & _util.RenderingIntentFlag.PRINT);
              D.displayReadyCapability || (D.displayReadyCapability = new _util.PromiseCapability(), D.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
              }, (y = this._stats) == null || y.time("Page Request"), this._pumpOperatorList(et));
              const Q = (B) => {
                var N, $;
                D.renderTasks.delete(F), (this._maybeCleanupAfterRender || G) && lt(this, e, !0), Z(this, s, re).call(this, !G), B ? (F.capability.reject(B), this._abortOperatorList({
                  intentState: D,
                  reason: B instanceof Error ? B : new Error(B)
                })) : F.capability.resolve(), (N = this._stats) == null || N.timeEnd("Rendering"), ($ = this._stats) == null || $.timeEnd("Overall");
              }, F = new InternalRenderTask({
                callback: Q,
                params: {
                  canvasContext: A,
                  viewport: C,
                  transform: I,
                  background: q
                },
                objs: this.objs,
                commonObjs: this.commonObjs,
                annotationCanvasMap: X,
                operatorList: D.operatorList,
                pageIndex: this._pageIndex,
                canvasFactory: this._transport.canvasFactory,
                filterFactory: this._transport.filterFactory,
                useRequestAnimationFrame: !G,
                pdfBug: this._pdfBug,
                pageColors: z
              });
              (D.renderTasks || (D.renderTasks = /* @__PURE__ */ new Set())).add(F);
              const d = F.task;
              return Promise.all([D.displayReadyCapability.promise, Y]).then(([B, N]) => {
                var $;
                if (this.destroyed) {
                  Q();
                  return;
                }
                ($ = this._stats) == null || $.time("Rendering"), F.initializeGraphics({
                  transparency: B,
                  optionalContentConfig: N
                }), F.operatorListChanged();
              }).catch(Q), d;
            }
            getOperatorList({
              intent: A = "display",
              annotationMode: C = _util.AnnotationMode.ENABLE,
              printAnnotationStorage: W = null
            } = {}) {
              var X;
              function m() {
                q.operatorList.lastChunk && (q.opListReadCapability.resolve(q.operatorList), q.renderTasks.delete(Y));
              }
              const I = this._transport.getRenderingIntent(A, C, W, !0);
              let q = this._intentStates.get(I.cacheKey);
              q || (q = /* @__PURE__ */ Object.create(null), this._intentStates.set(I.cacheKey, q));
              let Y;
              return q.opListReadCapability || (Y = /* @__PURE__ */ Object.create(null), Y.operatorListChanged = m, q.opListReadCapability = new _util.PromiseCapability(), (q.renderTasks || (q.renderTasks = /* @__PURE__ */ new Set())).add(Y), q.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
              }, (X = this._stats) == null || X.time("Page Request"), this._pumpOperatorList(I)), q.opListReadCapability.promise;
            }
            streamTextContent({
              includeMarkedContent: A = !1,
              disableNormalization: C = !1
            } = {}) {
              return this._transport.messageHandler.sendWithStream("GetTextContent", {
                pageIndex: this._pageIndex,
                includeMarkedContent: A === !0,
                disableNormalization: C === !0
              }, {
                highWaterMark: 100,
                size(m) {
                  return m.items.length;
                }
              });
            }
            getTextContent(A = {}) {
              if (this._transport._htmlForXfa)
                return this.getXfa().then((W) => _xfa_text.XfaText.textContent(W));
              const C = this.streamTextContent(A);
              return new Promise(function(W, m) {
                function I() {
                  q.read().then(function({
                    value: X,
                    done: z
                  }) {
                    if (z) {
                      W(Y);
                      return;
                    }
                    Object.assign(Y.styles, X.styles), Y.items.push(...X.items), I();
                  }, m);
                }
                const q = C.getReader(), Y = {
                  items: [],
                  styles: /* @__PURE__ */ Object.create(null)
                };
                I();
              });
            }
            getStructTree() {
              return this._transport.getStructTree(this._pageIndex);
            }
            _destroy() {
              this.destroyed = !0;
              const A = [];
              for (const C of this._intentStates.values())
                if (this._abortOperatorList({
                  intentState: C,
                  reason: new Error("Page was destroyed."),
                  force: !0
                }), !C.opListReadCapability)
                  for (const W of C.renderTasks)
                    A.push(W.completed), W.cancel();
              return this.objs.clear(), lt(this, e, !1), Z(this, s, be).call(this), Promise.all(A);
            }
            cleanup(A = !1) {
              lt(this, e, !0);
              const C = Z(this, s, re).call(this, !1);
              return A && C && this._stats && (this._stats = new _display_utils.StatTimer()), C;
            }
            _startRenderPage(A, C) {
              var m, I;
              const W = this._intentStates.get(C);
              W && ((m = this._stats) == null || m.timeEnd("Page Request"), (I = W.displayReadyCapability) == null || I.resolve(A));
            }
            _renderPageChunk(A, C) {
              for (let W = 0, m = A.length; W < m; W++)
                C.operatorList.fnArray.push(A.fnArray[W]), C.operatorList.argsArray.push(A.argsArray[W]);
              C.operatorList.lastChunk = A.lastChunk, C.operatorList.separateAnnots = A.separateAnnots;
              for (const W of C.renderTasks)
                W.operatorListChanged();
              A.lastChunk && Z(this, s, re).call(this, !0);
            }
            _pumpOperatorList({
              renderingIntent: A,
              cacheKey: C,
              annotationStorageSerializable: W
            }) {
              const {
                map: m,
                transfers: I
              } = W, Y = this._transport.messageHandler.sendWithStream("GetOperatorList", {
                pageIndex: this._pageIndex,
                intent: A,
                cacheKey: C,
                annotationStorage: m
              }, I).getReader(), X = this._intentStates.get(C);
              X.streamReader = Y;
              const z = () => {
                Y.read().then(({
                  value: L,
                  done: et
                }) => {
                  if (et) {
                    X.streamReader = null;
                    return;
                  }
                  this._transport.destroyed || (this._renderPageChunk(L, X), z());
                }, (L) => {
                  if (X.streamReader = null, !this._transport.destroyed) {
                    if (X.operatorList) {
                      X.operatorList.lastChunk = !0;
                      for (const et of X.renderTasks)
                        et.operatorListChanged();
                      Z(this, s, re).call(this, !0);
                    }
                    if (X.displayReadyCapability)
                      X.displayReadyCapability.reject(L);
                    else if (X.opListReadCapability)
                      X.opListReadCapability.reject(L);
                    else
                      throw L;
                  }
                });
              };
              z();
            }
            _abortOperatorList({
              intentState: A,
              reason: C,
              force: W = !1
            }) {
              if (A.streamReader) {
                if (A.streamReaderCancelTimeout && (clearTimeout(A.streamReaderCancelTimeout), A.streamReaderCancelTimeout = null), !W) {
                  if (A.renderTasks.size > 0)
                    return;
                  if (C instanceof _display_utils.RenderingCancelledException) {
                    let m = RENDERING_CANCELLED_TIMEOUT;
                    C.extraDelay > 0 && C.extraDelay < 1e3 && (m += C.extraDelay), A.streamReaderCancelTimeout = setTimeout(() => {
                      A.streamReaderCancelTimeout = null, this._abortOperatorList({
                        intentState: A,
                        reason: C,
                        force: !0
                      });
                    }, m);
                    return;
                  }
                }
                if (A.streamReader.cancel(new _util.AbortException(C.message)).catch(() => {
                }), A.streamReader = null, !this._transport.destroyed) {
                  for (const [m, I] of this._intentStates)
                    if (I === A) {
                      this._intentStates.delete(m);
                      break;
                    }
                  this.cleanup();
                }
              }
            }
            get stats() {
              return this._stats;
            }
          }
          n = new WeakMap(), e = new WeakMap(), s = new WeakSet(), re = function(A = !1) {
            if (Z(this, s, be).call(this), !r(this, e) || this.destroyed)
              return !1;
            if (A)
              return lt(this, n, setTimeout(() => {
                lt(this, n, null), Z(this, s, re).call(this, !1);
              }, DELAYED_CLEANUP_TIMEOUT)), !1;
            for (const {
              renderTasks: C,
              operatorList: W
            } of this._intentStates.values())
              if (C.size > 0 || !W.lastChunk)
                return !1;
            return this._intentStates.clear(), this.objs.clear(), lt(this, e, !1), !0;
          }, be = function() {
            r(this, n) && (clearTimeout(r(this, n)), lt(this, n, null));
          }, exports.PDFPageProxy = PDFPageProxy;
          class LoopbackPort {
            constructor() {
              at(this, b, /* @__PURE__ */ new Set());
              at(this, o, Promise.resolve());
            }
            postMessage(A, C) {
              const W = {
                data: structuredClone(A, C ? {
                  transfer: C
                } : null)
              };
              r(this, o).then(() => {
                for (const m of r(this, b))
                  m.call(this, W);
              });
            }
            addEventListener(A, C) {
              r(this, b).add(C);
            }
            removeEventListener(A, C) {
              r(this, b).delete(C);
            }
            terminate() {
              r(this, b).clear();
            }
          }
          b = new WeakMap(), o = new WeakMap(), exports.LoopbackPort = LoopbackPort;
          const PDFWorkerUtil = {
            isWorkerDisabled: !1,
            fallbackWorkerSrc: null,
            fakeWorkerId: 0
          };
          exports.PDFWorkerUtil = PDFWorkerUtil;
          {
            if (_util.isNodeJS && typeof commonjsRequire == "function")
              PDFWorkerUtil.isWorkerDisabled = !0, PDFWorkerUtil.fallbackWorkerSrc = "./pdf.worker.js";
            else if (typeof document == "object") {
              const f = (l = document == null ? void 0 : document.currentScript) == null ? void 0 : l.src;
              f && (PDFWorkerUtil.fallbackWorkerSrc = f.replace(/(\.(?:min\.)?js)(\?.*)?$/i, ".worker$1$2"));
            }
            PDFWorkerUtil.isSameOrigin = function(f, A) {
              let C;
              try {
                if (C = new URL(f), !C.origin || C.origin === "null")
                  return !1;
              } catch {
                return !1;
              }
              const W = new URL(A, C);
              return C.origin === W.origin;
            }, PDFWorkerUtil.createCDNWrapper = function(f) {
              const A = `importScripts("${f}");`;
              return URL.createObjectURL(new Blob([A]));
            };
          }
          const _PDFWorker = class _PDFWorker {
            constructor({
              name: f = null,
              port: A = null,
              verbosity: C = (0, _util.getVerbosityLevel)()
            } = {}) {
              var W;
              if (this.name = f, this.destroyed = !1, this.verbosity = C, this._readyCapability = new _util.PromiseCapability(), this._port = null, this._webWorker = null, this._messageHandler = null, A) {
                if ((W = r(_PDFWorker, a)) != null && W.has(A))
                  throw new Error("Cannot use more than one PDFWorker per port.");
                (r(_PDFWorker, a) || lt(_PDFWorker, a, /* @__PURE__ */ new WeakMap())).set(A, this), this._initializeFromPort(A);
                return;
              }
              this._initialize();
            }
            get promise() {
              return this._readyCapability.promise;
            }
            get port() {
              return this._port;
            }
            get messageHandler() {
              return this._messageHandler;
            }
            _initializeFromPort(f) {
              this._port = f, this._messageHandler = new _message_handler.MessageHandler("main", "worker", f), this._messageHandler.on("ready", function() {
              }), this._readyCapability.resolve(), this._messageHandler.send("configure", {
                verbosity: this.verbosity
              });
            }
            _initialize() {
              if (!PDFWorkerUtil.isWorkerDisabled && !_PDFWorker._mainThreadWorkerMessageHandler) {
                let {
                  workerSrc: f
                } = _PDFWorker;
                try {
                  PDFWorkerUtil.isSameOrigin(window.location.href, f) || (f = PDFWorkerUtil.createCDNWrapper(new URL(f, window.location).href));
                  const A = new Worker(f), C = new _message_handler.MessageHandler("main", "worker", A), W = () => {
                    A.removeEventListener("error", m), C.destroy(), A.terminate(), this.destroyed ? this._readyCapability.reject(new Error("Worker was destroyed")) : this._setupFakeWorker();
                  }, m = () => {
                    this._webWorker || W();
                  };
                  A.addEventListener("error", m), C.on("test", (q) => {
                    if (A.removeEventListener("error", m), this.destroyed) {
                      W();
                      return;
                    }
                    q ? (this._messageHandler = C, this._port = A, this._webWorker = A, this._readyCapability.resolve(), C.send("configure", {
                      verbosity: this.verbosity
                    })) : (this._setupFakeWorker(), C.destroy(), A.terminate());
                  }), C.on("ready", (q) => {
                    if (A.removeEventListener("error", m), this.destroyed) {
                      W();
                      return;
                    }
                    try {
                      I();
                    } catch {
                      this._setupFakeWorker();
                    }
                  });
                  const I = () => {
                    const q = new Uint8Array();
                    C.send("test", q, [q.buffer]);
                  };
                  I();
                  return;
                } catch {
                  (0, _util.info)("The worker has been disabled.");
                }
              }
              this._setupFakeWorker();
            }
            _setupFakeWorker() {
              PDFWorkerUtil.isWorkerDisabled || ((0, _util.warn)("Setting up fake worker."), PDFWorkerUtil.isWorkerDisabled = !0), _PDFWorker._setupFakeWorkerGlobal.then((f) => {
                if (this.destroyed) {
                  this._readyCapability.reject(new Error("Worker was destroyed"));
                  return;
                }
                const A = new LoopbackPort();
                this._port = A;
                const C = `fake${PDFWorkerUtil.fakeWorkerId++}`, W = new _message_handler.MessageHandler(C + "_worker", C, A);
                f.setup(W, A);
                const m = new _message_handler.MessageHandler(C, C + "_worker", A);
                this._messageHandler = m, this._readyCapability.resolve(), m.send("configure", {
                  verbosity: this.verbosity
                });
              }).catch((f) => {
                this._readyCapability.reject(new Error(`Setting up fake worker failed: "${f.message}".`));
              });
            }
            destroy() {
              var f;
              this.destroyed = !0, this._webWorker && (this._webWorker.terminate(), this._webWorker = null), (f = r(_PDFWorker, a)) == null || f.delete(this._port), this._port = null, this._messageHandler && (this._messageHandler.destroy(), this._messageHandler = null);
            }
            static fromPort(f) {
              var C;
              if (!(f != null && f.port))
                throw new Error("PDFWorker.fromPort - invalid method signature.");
              const A = (C = r(this, a)) == null ? void 0 : C.get(f.port);
              if (A) {
                if (A._pendingDestroy)
                  throw new Error("PDFWorker.fromPort - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
                return A;
              }
              return new _PDFWorker(f);
            }
            static get workerSrc() {
              if (_worker_options.GlobalWorkerOptions.workerSrc)
                return _worker_options.GlobalWorkerOptions.workerSrc;
              if (PDFWorkerUtil.fallbackWorkerSrc !== null)
                return _util.isNodeJS || (0, _display_utils.deprecated)('No "GlobalWorkerOptions.workerSrc" specified.'), PDFWorkerUtil.fallbackWorkerSrc;
              throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
            }
            static get _mainThreadWorkerMessageHandler() {
              var f;
              try {
                return ((f = globalThis.pdfjsWorker) == null ? void 0 : f.WorkerMessageHandler) || null;
              } catch {
                return null;
              }
            }
            static get _setupFakeWorkerGlobal() {
              const loader = async () => {
                const mainWorkerMessageHandler = this._mainThreadWorkerMessageHandler;
                if (mainWorkerMessageHandler)
                  return mainWorkerMessageHandler;
                if (_util.isNodeJS && typeof commonjsRequire == "function") {
                  const worker = eval("require")(this.workerSrc);
                  return worker.WorkerMessageHandler;
                }
                return await (0, _display_utils.loadScript)(this.workerSrc), window.pdfjsWorker.WorkerMessageHandler;
              };
              return (0, _util.shadow)(this, "_setupFakeWorkerGlobal", loader());
            }
          };
          a = new WeakMap(), at(_PDFWorker, a);
          let PDFWorker = _PDFWorker;
          exports.PDFWorker = PDFWorker;
          class WorkerTransport {
            constructor(A, C, W, m, I) {
              at(this, x);
              at(this, T, /* @__PURE__ */ new Map());
              at(this, P, /* @__PURE__ */ new Map());
              at(this, v, /* @__PURE__ */ new Map());
              at(this, k, null);
              this.messageHandler = A, this.loadingTask = C, this.commonObjs = new PDFObjects(), this.fontLoader = new _font_loader.FontLoader({
                ownerDocument: m.ownerDocument,
                styleElement: m.styleElement
              }), this._params = m, this.canvasFactory = I.canvasFactory, this.filterFactory = I.filterFactory, this.cMapReaderFactory = I.cMapReaderFactory, this.standardFontDataFactory = I.standardFontDataFactory, this.destroyed = !1, this.destroyCapability = null, this._networkStream = W, this._fullReader = null, this._lastProgress = null, this.downloadInfoCapability = new _util.PromiseCapability(), this.setupMessageHandler();
            }
            get annotationStorage() {
              return (0, _util.shadow)(this, "annotationStorage", new _annotation_storage.AnnotationStorage());
            }
            getRenderingIntent(A, C = _util.AnnotationMode.ENABLE, W = null, m = !1) {
              let I = _util.RenderingIntentFlag.DISPLAY, q = _annotation_storage.SerializableEmpty;
              switch (A) {
                case "any":
                  I = _util.RenderingIntentFlag.ANY;
                  break;
                case "display":
                  break;
                case "print":
                  I = _util.RenderingIntentFlag.PRINT;
                  break;
                default:
                  (0, _util.warn)(`getRenderingIntent - invalid intent: ${A}`);
              }
              switch (C) {
                case _util.AnnotationMode.DISABLE:
                  I += _util.RenderingIntentFlag.ANNOTATIONS_DISABLE;
                  break;
                case _util.AnnotationMode.ENABLE:
                  break;
                case _util.AnnotationMode.ENABLE_FORMS:
                  I += _util.RenderingIntentFlag.ANNOTATIONS_FORMS;
                  break;
                case _util.AnnotationMode.ENABLE_STORAGE:
                  I += _util.RenderingIntentFlag.ANNOTATIONS_STORAGE, q = (I & _util.RenderingIntentFlag.PRINT && W instanceof _annotation_storage.PrintAnnotationStorage ? W : this.annotationStorage).serializable;
                  break;
                default:
                  (0, _util.warn)(`getRenderingIntent - invalid annotationMode: ${C}`);
              }
              return m && (I += _util.RenderingIntentFlag.OPLIST), {
                renderingIntent: I,
                cacheKey: `${I}_${q.hash}`,
                annotationStorageSerializable: q
              };
            }
            destroy() {
              var W;
              if (this.destroyCapability)
                return this.destroyCapability.promise;
              this.destroyed = !0, this.destroyCapability = new _util.PromiseCapability(), (W = r(this, k)) == null || W.reject(new Error("Worker was destroyed during onPassword callback"));
              const A = [];
              for (const m of r(this, P).values())
                A.push(m._destroy());
              r(this, P).clear(), r(this, v).clear(), this.hasOwnProperty("annotationStorage") && this.annotationStorage.resetModified();
              const C = this.messageHandler.sendWithPromise("Terminate", null);
              return A.push(C), Promise.all(A).then(() => {
                var m;
                this.commonObjs.clear(), this.fontLoader.clear(), r(this, T).clear(), this.filterFactory.destroy(), (m = this._networkStream) == null || m.cancelAllRequests(new _util.AbortException("Worker was terminated.")), this.messageHandler && (this.messageHandler.destroy(), this.messageHandler = null), this.destroyCapability.resolve();
              }, this.destroyCapability.reject), this.destroyCapability.promise;
            }
            setupMessageHandler() {
              const {
                messageHandler: A,
                loadingTask: C
              } = this;
              A.on("GetReader", (W, m) => {
                (0, _util.assert)(this._networkStream, "GetReader - no `IPDFStream` instance available."), this._fullReader = this._networkStream.getFullReader(), this._fullReader.onProgress = (I) => {
                  this._lastProgress = {
                    loaded: I.loaded,
                    total: I.total
                  };
                }, m.onPull = () => {
                  this._fullReader.read().then(function({
                    value: I,
                    done: q
                  }) {
                    if (q) {
                      m.close();
                      return;
                    }
                    (0, _util.assert)(I instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), m.enqueue(new Uint8Array(I), 1, [I]);
                  }).catch((I) => {
                    m.error(I);
                  });
                }, m.onCancel = (I) => {
                  this._fullReader.cancel(I), m.ready.catch((q) => {
                    if (!this.destroyed)
                      throw q;
                  });
                };
              }), A.on("ReaderHeadersReady", (W) => {
                const m = new _util.PromiseCapability(), I = this._fullReader;
                return I.headersReady.then(() => {
                  var q;
                  (!I.isStreamingSupported || !I.isRangeSupported) && (this._lastProgress && ((q = C.onProgress) == null || q.call(C, this._lastProgress)), I.onProgress = (Y) => {
                    var X;
                    (X = C.onProgress) == null || X.call(C, {
                      loaded: Y.loaded,
                      total: Y.total
                    });
                  }), m.resolve({
                    isStreamingSupported: I.isStreamingSupported,
                    isRangeSupported: I.isRangeSupported,
                    contentLength: I.contentLength
                  });
                }, m.reject), m.promise;
              }), A.on("GetRangeReader", (W, m) => {
                (0, _util.assert)(this._networkStream, "GetRangeReader - no `IPDFStream` instance available.");
                const I = this._networkStream.getRangeReader(W.begin, W.end);
                if (!I) {
                  m.close();
                  return;
                }
                m.onPull = () => {
                  I.read().then(function({
                    value: q,
                    done: Y
                  }) {
                    if (Y) {
                      m.close();
                      return;
                    }
                    (0, _util.assert)(q instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), m.enqueue(new Uint8Array(q), 1, [q]);
                  }).catch((q) => {
                    m.error(q);
                  });
                }, m.onCancel = (q) => {
                  I.cancel(q), m.ready.catch((Y) => {
                    if (!this.destroyed)
                      throw Y;
                  });
                };
              }), A.on("GetDoc", ({
                pdfInfo: W
              }) => {
                this._numPages = W.numPages, this._htmlForXfa = W.htmlForXfa, delete W.htmlForXfa, C._capability.resolve(new PDFDocumentProxy(W, this));
              }), A.on("DocException", function(W) {
                let m;
                switch (W.name) {
                  case "PasswordException":
                    m = new _util.PasswordException(W.message, W.code);
                    break;
                  case "InvalidPDFException":
                    m = new _util.InvalidPDFException(W.message);
                    break;
                  case "MissingPDFException":
                    m = new _util.MissingPDFException(W.message);
                    break;
                  case "UnexpectedResponseException":
                    m = new _util.UnexpectedResponseException(W.message, W.status);
                    break;
                  case "UnknownErrorException":
                    m = new _util.UnknownErrorException(W.message, W.details);
                    break;
                  default:
                    (0, _util.unreachable)("DocException - expected a valid Error.");
                }
                C._capability.reject(m);
              }), A.on("PasswordRequest", (W) => {
                if (lt(this, k, new _util.PromiseCapability()), C.onPassword) {
                  const m = (I) => {
                    I instanceof Error ? r(this, k).reject(I) : r(this, k).resolve({
                      password: I
                    });
                  };
                  try {
                    C.onPassword(m, W.code);
                  } catch (I) {
                    r(this, k).reject(I);
                  }
                } else
                  r(this, k).reject(new _util.PasswordException(W.message, W.code));
                return r(this, k).promise;
              }), A.on("DataLoaded", (W) => {
                var m;
                (m = C.onProgress) == null || m.call(C, {
                  loaded: W.length,
                  total: W.length
                }), this.downloadInfoCapability.resolve(W);
              }), A.on("StartRenderPage", (W) => {
                if (this.destroyed)
                  return;
                r(this, P).get(W.pageIndex)._startRenderPage(W.transparency, W.cacheKey);
              }), A.on("commonobj", ([W, m, I]) => {
                var q;
                if (!this.destroyed && !this.commonObjs.has(W))
                  switch (m) {
                    case "Font":
                      const Y = this._params;
                      if ("error" in I) {
                        const L = I.error;
                        (0, _util.warn)(`Error during font loading: ${L}`), this.commonObjs.resolve(W, L);
                        break;
                      }
                      const X = Y.pdfBug && ((q = globalThis.FontInspector) != null && q.enabled) ? (L, et) => globalThis.FontInspector.fontAdded(L, et) : null, z = new _font_loader.FontFaceObject(I, {
                        isEvalSupported: Y.isEvalSupported,
                        disableFontFace: Y.disableFontFace,
                        ignoreErrors: Y.ignoreErrors,
                        inspectFont: X
                      });
                      this.fontLoader.bind(z).catch((L) => A.sendWithPromise("FontFallback", {
                        id: W
                      })).finally(() => {
                        !Y.fontExtraProperties && z.data && (z.data = null), this.commonObjs.resolve(W, z);
                      });
                      break;
                    case "FontPath":
                    case "Image":
                    case "Pattern":
                      this.commonObjs.resolve(W, I);
                      break;
                    default:
                      throw new Error(`Got unknown common object type ${m}`);
                  }
              }), A.on("obj", ([W, m, I, q]) => {
                var X;
                if (this.destroyed)
                  return;
                const Y = r(this, P).get(m);
                if (!Y.objs.has(W))
                  switch (I) {
                    case "Image":
                      if (Y.objs.resolve(W, q), q) {
                        let z;
                        if (q.bitmap) {
                          const {
                            width: L,
                            height: et
                          } = q;
                          z = L * et * 4;
                        } else
                          z = ((X = q.data) == null ? void 0 : X.length) || 0;
                        z > _util.MAX_IMAGE_SIZE_TO_CACHE && (Y._maybeCleanupAfterRender = !0);
                      }
                      break;
                    case "Pattern":
                      Y.objs.resolve(W, q);
                      break;
                    default:
                      throw new Error(`Got unknown object type ${I}`);
                  }
              }), A.on("DocProgress", (W) => {
                var m;
                this.destroyed || (m = C.onProgress) == null || m.call(C, {
                  loaded: W.loaded,
                  total: W.total
                });
              }), A.on("FetchBuiltInCMap", (W) => this.destroyed ? Promise.reject(new Error("Worker was destroyed.")) : this.cMapReaderFactory ? this.cMapReaderFactory.fetch(W) : Promise.reject(new Error("CMapReaderFactory not initialized, see the `useWorkerFetch` parameter."))), A.on("FetchStandardFontData", (W) => this.destroyed ? Promise.reject(new Error("Worker was destroyed.")) : this.standardFontDataFactory ? this.standardFontDataFactory.fetch(W) : Promise.reject(new Error("StandardFontDataFactory not initialized, see the `useWorkerFetch` parameter.")));
            }
            getData() {
              return this.messageHandler.sendWithPromise("GetData", null);
            }
            saveDocument() {
              var W;
              this.annotationStorage.size <= 0 && (0, _util.warn)("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
              const {
                map: A,
                transfers: C
              } = this.annotationStorage.serializable;
              return this.messageHandler.sendWithPromise("SaveDocument", {
                isPureXfa: !!this._htmlForXfa,
                numPages: this._numPages,
                annotationStorage: A,
                filename: ((W = this._fullReader) == null ? void 0 : W.filename) ?? null
              }, C).finally(() => {
                this.annotationStorage.resetModified();
              });
            }
            getPage(A) {
              if (!Number.isInteger(A) || A <= 0 || A > this._numPages)
                return Promise.reject(new Error("Invalid page request."));
              const C = A - 1, W = r(this, v).get(C);
              if (W)
                return W;
              const m = this.messageHandler.sendWithPromise("GetPage", {
                pageIndex: C
              }).then((I) => {
                if (this.destroyed)
                  throw new Error("Transport destroyed");
                const q = new PDFPageProxy(C, I, this, this._params.pdfBug);
                return r(this, P).set(C, q), q;
              });
              return r(this, v).set(C, m), m;
            }
            getPageIndex(A) {
              return typeof A != "object" || A === null || !Number.isInteger(A.num) || A.num < 0 || !Number.isInteger(A.gen) || A.gen < 0 ? Promise.reject(new Error("Invalid pageIndex request.")) : this.messageHandler.sendWithPromise("GetPageIndex", {
                num: A.num,
                gen: A.gen
              });
            }
            getAnnotations(A, C) {
              return this.messageHandler.sendWithPromise("GetAnnotations", {
                pageIndex: A,
                intent: C
              });
            }
            getFieldObjects() {
              return Z(this, x, ye).call(this, "GetFieldObjects");
            }
            hasJSActions() {
              return Z(this, x, ye).call(this, "HasJSActions");
            }
            getCalculationOrderIds() {
              return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
            }
            getDestinations() {
              return this.messageHandler.sendWithPromise("GetDestinations", null);
            }
            getDestination(A) {
              return typeof A != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
                id: A
              });
            }
            getPageLabels() {
              return this.messageHandler.sendWithPromise("GetPageLabels", null);
            }
            getPageLayout() {
              return this.messageHandler.sendWithPromise("GetPageLayout", null);
            }
            getPageMode() {
              return this.messageHandler.sendWithPromise("GetPageMode", null);
            }
            getViewerPreferences() {
              return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
            }
            getOpenAction() {
              return this.messageHandler.sendWithPromise("GetOpenAction", null);
            }
            getAttachments() {
              return this.messageHandler.sendWithPromise("GetAttachments", null);
            }
            getDocJSActions() {
              return Z(this, x, ye).call(this, "GetDocJSActions");
            }
            getPageJSActions(A) {
              return this.messageHandler.sendWithPromise("GetPageJSActions", {
                pageIndex: A
              });
            }
            getStructTree(A) {
              return this.messageHandler.sendWithPromise("GetStructTree", {
                pageIndex: A
              });
            }
            getOutline() {
              return this.messageHandler.sendWithPromise("GetOutline", null);
            }
            getOptionalContentConfig() {
              return this.messageHandler.sendWithPromise("GetOptionalContentConfig", null).then((A) => new _optional_content_config.OptionalContentConfig(A));
            }
            getPermissions() {
              return this.messageHandler.sendWithPromise("GetPermissions", null);
            }
            getMetadata() {
              const A = "GetMetadata", C = r(this, T).get(A);
              if (C)
                return C;
              const W = this.messageHandler.sendWithPromise(A, null).then((m) => {
                var I, q;
                return {
                  info: m[0],
                  metadata: m[1] ? new _metadata.Metadata(m[1]) : null,
                  contentDispositionFilename: ((I = this._fullReader) == null ? void 0 : I.filename) ?? null,
                  contentLength: ((q = this._fullReader) == null ? void 0 : q.contentLength) ?? null
                };
              });
              return r(this, T).set(A, W), W;
            }
            getMarkInfo() {
              return this.messageHandler.sendWithPromise("GetMarkInfo", null);
            }
            async startCleanup(A = !1) {
              if (!this.destroyed) {
                await this.messageHandler.sendWithPromise("Cleanup", null);
                for (const C of r(this, P).values())
                  if (!C.cleanup())
                    throw new Error(`startCleanup: Page ${C.pageNumber} is currently rendering.`);
                this.commonObjs.clear(), A || this.fontLoader.clear(), r(this, T).clear(), this.filterFactory.destroy(!0);
              }
            }
            get loadingParams() {
              const {
                disableAutoFetch: A,
                enableXfa: C
              } = this._params;
              return (0, _util.shadow)(this, "loadingParams", {
                disableAutoFetch: A,
                enableXfa: C
              });
            }
          }
          T = new WeakMap(), P = new WeakMap(), v = new WeakMap(), k = new WeakMap(), x = new WeakSet(), ye = function(A, C = null) {
            const W = r(this, T).get(A);
            if (W)
              return W;
            const m = this.messageHandler.sendWithPromise(A, C);
            return r(this, T).set(A, m), m;
          };
          class PDFObjects {
            constructor() {
              at(this, w);
              at(this, E, /* @__PURE__ */ Object.create(null));
            }
            get(A, C = null) {
              if (C) {
                const m = Z(this, w, De).call(this, A);
                return m.capability.promise.then(() => C(m.data)), null;
              }
              const W = r(this, E)[A];
              if (!(W != null && W.capability.settled))
                throw new Error(`Requesting object that isn't resolved yet ${A}.`);
              return W.data;
            }
            has(A) {
              const C = r(this, E)[A];
              return (C == null ? void 0 : C.capability.settled) || !1;
            }
            resolve(A, C = null) {
              const W = Z(this, w, De).call(this, A);
              W.data = C, W.capability.resolve();
            }
            clear() {
              var A;
              for (const C in r(this, E)) {
                const {
                  data: W
                } = r(this, E)[C];
                (A = W == null ? void 0 : W.bitmap) == null || A.close();
              }
              lt(this, E, /* @__PURE__ */ Object.create(null));
            }
          }
          E = new WeakMap(), w = new WeakSet(), De = function(A) {
            var C;
            return (C = r(this, E))[A] || (C[A] = {
              capability: new _util.PromiseCapability(),
              data: null
            });
          };
          class RenderTask {
            constructor(A) {
              at(this, g, null);
              lt(this, g, A), this.onContinue = null;
            }
            get promise() {
              return r(this, g).capability.promise;
            }
            cancel(A = 0) {
              r(this, g).cancel(null, A);
            }
            get separateAnnots() {
              const {
                separateAnnots: A
              } = r(this, g).operatorList;
              if (!A)
                return !1;
              const {
                annotationCanvasMap: C
              } = r(this, g);
              return A.form || A.canvas && (C == null ? void 0 : C.size) > 0;
            }
          }
          g = new WeakMap(), exports.RenderTask = RenderTask;
          const _ = class _ {
            constructor({
              callback: A,
              params: C,
              objs: W,
              commonObjs: m,
              annotationCanvasMap: I,
              operatorList: q,
              pageIndex: Y,
              canvasFactory: X,
              filterFactory: z,
              useRequestAnimationFrame: L = !1,
              pdfBug: et = !1,
              pageColors: D = null
            }) {
              this.callback = A, this.params = C, this.objs = W, this.commonObjs = m, this.annotationCanvasMap = I, this.operatorListIdx = null, this.operatorList = q, this._pageIndex = Y, this.canvasFactory = X, this.filterFactory = z, this._pdfBug = et, this.pageColors = D, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = L === !0 && typeof window < "u", this.cancelled = !1, this.capability = new _util.PromiseCapability(), this.task = new RenderTask(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = C.canvasContext.canvas;
            }
            get completed() {
              return this.capability.promise.catch(function() {
              });
            }
            initializeGraphics({
              transparency: A = !1,
              optionalContentConfig: C
            }) {
              var Y, X;
              if (this.cancelled)
                return;
              if (this._canvas) {
                if (r(_, p).has(this._canvas))
                  throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
                r(_, p).add(this._canvas);
              }
              this._pdfBug && ((Y = globalThis.StepperManager) != null && Y.enabled) && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
              const {
                canvasContext: W,
                viewport: m,
                transform: I,
                background: q
              } = this.params;
              this.gfx = new _canvas.CanvasGraphics(W, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                optionalContentConfig: C
              }, this.annotationCanvasMap, this.pageColors), this.gfx.beginDrawing({
                transform: I,
                viewport: m,
                transparency: A,
                background: q
              }), this.operatorListIdx = 0, this.graphicsReady = !0, (X = this.graphicsReadyCallback) == null || X.call(this);
            }
            cancel(A = null, C = 0) {
              var W;
              this.running = !1, this.cancelled = !0, (W = this.gfx) == null || W.endDrawing(), r(_, p).delete(this._canvas), this.callback(A || new _display_utils.RenderingCancelledException(`Rendering cancelled, page ${this._pageIndex + 1}`, C));
            }
            operatorListChanged() {
              var A;
              if (!this.graphicsReady) {
                this.graphicsReadyCallback || (this.graphicsReadyCallback = this._continueBound);
                return;
              }
              (A = this.stepper) == null || A.updateOperatorList(this.operatorList), !this.running && this._continue();
            }
            _continue() {
              this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
            }
            _scheduleNext() {
              this._useRequestAnimationFrame ? window.requestAnimationFrame(() => {
                this._nextBound().catch(this._cancelBound);
              }) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
            }
            async _next() {
              this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), r(_, p).delete(this._canvas), this.callback())));
            }
          };
          p = new WeakMap(), at(_, p, /* @__PURE__ */ new WeakSet());
          let InternalRenderTask = _;
          const version = "3.11.174";
          exports.version = version;
          const build = "ce8716743";
          exports.build = build;
        },
        /* 3 */
        /***/
        (i, t, n) => {
          var l, a, T, mn, v;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.SerializableEmpty = t.PrintAnnotationStorage = t.AnnotationStorage = void 0;
          var e = n(1), s = n(4), c = n(8);
          const h = Object.freeze({
            map: null,
            hash: "",
            transfers: void 0
          });
          t.SerializableEmpty = h;
          class b {
            constructor() {
              at(this, T);
              at(this, l, !1);
              at(this, a, /* @__PURE__ */ new Map());
              this.onSetModified = null, this.onResetModified = null, this.onAnnotationEditor = null;
            }
            getValue(x, S) {
              const E = r(this, a).get(x);
              return E === void 0 ? S : Object.assign(S, E);
            }
            getRawValue(x) {
              return r(this, a).get(x);
            }
            remove(x) {
              if (r(this, a).delete(x), r(this, a).size === 0 && this.resetModified(), typeof this.onAnnotationEditor == "function") {
                for (const S of r(this, a).values())
                  if (S instanceof s.AnnotationEditor)
                    return;
                this.onAnnotationEditor(null);
              }
            }
            setValue(x, S) {
              const E = r(this, a).get(x);
              let w = !1;
              if (E !== void 0)
                for (const [M, g] of Object.entries(S))
                  E[M] !== g && (w = !0, E[M] = g);
              else
                w = !0, r(this, a).set(x, S);
              w && Z(this, T, mn).call(this), S instanceof s.AnnotationEditor && typeof this.onAnnotationEditor == "function" && this.onAnnotationEditor(S.constructor._type);
            }
            has(x) {
              return r(this, a).has(x);
            }
            getAll() {
              return r(this, a).size > 0 ? (0, e.objectFromMap)(r(this, a)) : null;
            }
            setAll(x) {
              for (const [S, E] of Object.entries(x))
                this.setValue(S, E);
            }
            get size() {
              return r(this, a).size;
            }
            resetModified() {
              r(this, l) && (lt(this, l, !1), typeof this.onResetModified == "function" && this.onResetModified());
            }
            get print() {
              return new o(this);
            }
            get serializable() {
              if (r(this, a).size === 0)
                return h;
              const x = /* @__PURE__ */ new Map(), S = new c.MurmurHash3_64(), E = [], w = /* @__PURE__ */ Object.create(null);
              let M = !1;
              for (const [g, p] of r(this, a)) {
                const _ = p instanceof s.AnnotationEditor ? p.serialize(!1, w) : p;
                _ && (x.set(g, _), S.update(`${g}:${JSON.stringify(_)}`), M || (M = !!_.bitmap));
              }
              if (M)
                for (const g of x.values())
                  g.bitmap && E.push(g.bitmap);
              return x.size > 0 ? {
                map: x,
                hash: S.hexdigest(),
                transfers: E
              } : h;
            }
          }
          l = new WeakMap(), a = new WeakMap(), T = new WeakSet(), mn = function() {
            r(this, l) || (lt(this, l, !0), typeof this.onSetModified == "function" && this.onSetModified());
          }, t.AnnotationStorage = b;
          class o extends b {
            constructor(S) {
              super();
              at(this, v);
              const {
                map: E,
                hash: w,
                transfers: M
              } = S.serializable, g = structuredClone(E, M ? {
                transfer: M
              } : null);
              lt(this, v, {
                map: g,
                hash: w,
                transfers: M
              });
            }
            get print() {
              (0, e.unreachable)("Should not call PrintAnnotationStorage.print");
            }
            get serializable() {
              return r(this, v);
            }
          }
          v = new WeakMap(), t.PrintAnnotationStorage = o;
        },
        /* 4 */
        /***/
        (i, t, n) => {
          var o, l, a, T, P, v, k, x, S, E, w, M, g, p, _, Ie, Le, C, Oe, $e, bn, yn, An, Ne, vn;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.AnnotationEditor = void 0;
          var e = n(5), s = n(1), c = n(6);
          const L = class L {
            constructor(D) {
              at(this, _);
              at(this, o, "");
              at(this, l, !1);
              at(this, a, null);
              at(this, T, null);
              at(this, P, null);
              at(this, v, !1);
              at(this, k, null);
              at(this, x, this.focusin.bind(this));
              at(this, S, this.focusout.bind(this));
              at(this, E, !1);
              at(this, w, !1);
              at(this, M, !1);
              Kt(this, "_initialOptions", /* @__PURE__ */ Object.create(null));
              Kt(this, "_uiManager", null);
              Kt(this, "_focusEventsAllowed", !0);
              Kt(this, "_l10nPromise", null);
              at(this, g, !1);
              at(this, p, L._zIndex++);
              this.constructor === L && (0, s.unreachable)("Cannot initialize AnnotationEditor."), this.parent = D.parent, this.id = D.id, this.width = this.height = null, this.pageIndex = D.parent.pageIndex, this.name = D.name, this.div = null, this._uiManager = D.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = D.isCentered, this._structTreeParentId = null;
              const {
                rotation: G,
                rawDims: {
                  pageWidth: Q,
                  pageHeight: F,
                  pageX: d,
                  pageY: u
                }
              } = this.parent.viewport;
              this.rotation = G, this.pageRotation = (360 + G - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [Q, F], this.pageTranslation = [d, u];
              const [y, B] = this.parentDimensions;
              this.x = D.x / y, this.y = D.y / B, this.isAttachedToDOM = !1, this.deleted = !1;
            }
            get editorType() {
              return Object.getPrototypeOf(this).constructor._type;
            }
            static get _defaultLineColor() {
              return (0, s.shadow)(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
            }
            static deleteAnnotationElement(D) {
              const G = new b({
                id: D.parent.getNextId(),
                parent: D.parent,
                uiManager: D._uiManager
              });
              G.annotationElementId = D.annotationElementId, G.deleted = !0, G._uiManager.addToAnnotationStorage(G);
            }
            static initialize(D, G = null) {
              if (L._l10nPromise || (L._l10nPromise = new Map(["editor_alt_text_button_label", "editor_alt_text_edit_button_label", "editor_alt_text_decorative_tooltip"].map((F) => [F, D.get(F)]))), G != null && G.strings)
                for (const F of G.strings)
                  L._l10nPromise.set(F, D.get(F));
              if (L._borderLineWidth !== -1)
                return;
              const Q = getComputedStyle(document.documentElement);
              L._borderLineWidth = parseFloat(Q.getPropertyValue("--outline-width")) || 0;
            }
            static updateDefaultParams(D, G) {
            }
            static get defaultPropertiesToUpdate() {
              return [];
            }
            static isHandlingMimeForPasting(D) {
              return !1;
            }
            static paste(D, G) {
              (0, s.unreachable)("Not implemented");
            }
            get propertiesToUpdate() {
              return [];
            }
            get _isDraggable() {
              return r(this, g);
            }
            set _isDraggable(D) {
              var G;
              lt(this, g, D), (G = this.div) == null || G.classList.toggle("draggable", D);
            }
            center() {
              const [D, G] = this.pageDimensions;
              switch (this.parentRotation) {
                case 90:
                  this.x -= this.height * G / (D * 2), this.y += this.width * D / (G * 2);
                  break;
                case 180:
                  this.x += this.width / 2, this.y += this.height / 2;
                  break;
                case 270:
                  this.x += this.height * G / (D * 2), this.y -= this.width * D / (G * 2);
                  break;
                default:
                  this.x -= this.width / 2, this.y -= this.height / 2;
                  break;
              }
              this.fixAndSetPosition();
            }
            addCommands(D) {
              this._uiManager.addCommands(D);
            }
            get currentLayer() {
              return this._uiManager.currentLayer;
            }
            setInBackground() {
              this.div.style.zIndex = 0;
            }
            setInForeground() {
              this.div.style.zIndex = r(this, p);
            }
            setParent(D) {
              D !== null && (this.pageIndex = D.pageIndex, this.pageDimensions = D.pageDimensions), this.parent = D;
            }
            focusin(D) {
              this._focusEventsAllowed && (r(this, E) ? lt(this, E, !1) : this.parent.setSelected(this));
            }
            focusout(D) {
              var Q;
              if (!this._focusEventsAllowed || !this.isAttachedToDOM)
                return;
              const G = D.relatedTarget;
              G != null && G.closest(`#${this.id}`) || (D.preventDefault(), (Q = this.parent) != null && Q.isMultipleSelection || this.commitOrRemove());
            }
            commitOrRemove() {
              this.isEmpty() ? this.remove() : this.commit();
            }
            commit() {
              this.addToAnnotationStorage();
            }
            addToAnnotationStorage() {
              this._uiManager.addToAnnotationStorage(this);
            }
            setAt(D, G, Q, F) {
              const [d, u] = this.parentDimensions;
              [Q, F] = this.screenToPageTranslation(Q, F), this.x = (D + Q) / d, this.y = (G + F) / u, this.fixAndSetPosition();
            }
            translate(D, G) {
              Z(this, _, Ie).call(this, this.parentDimensions, D, G);
            }
            translateInPage(D, G) {
              Z(this, _, Ie).call(this, this.pageDimensions, D, G), this.div.scrollIntoView({
                block: "nearest"
              });
            }
            drag(D, G) {
              const [Q, F] = this.parentDimensions;
              if (this.x += D / Q, this.y += G / F, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
                const {
                  x: N,
                  y: $
                } = this.div.getBoundingClientRect();
                this.parent.findNewParent(this, N, $) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
              }
              let {
                x: d,
                y: u
              } = this;
              const [y, B] = Z(this, _, Le).call(this);
              d += y, u += B, this.div.style.left = `${(100 * d).toFixed(2)}%`, this.div.style.top = `${(100 * u).toFixed(2)}%`, this.div.scrollIntoView({
                block: "nearest"
              });
            }
            fixAndSetPosition() {
              const [D, G] = this.pageDimensions;
              let {
                x: Q,
                y: F,
                width: d,
                height: u
              } = this;
              switch (d *= D, u *= G, Q *= D, F *= G, this.rotation) {
                case 0:
                  Q = Math.max(0, Math.min(D - d, Q)), F = Math.max(0, Math.min(G - u, F));
                  break;
                case 90:
                  Q = Math.max(0, Math.min(D - u, Q)), F = Math.min(G, Math.max(d, F));
                  break;
                case 180:
                  Q = Math.min(D, Math.max(d, Q)), F = Math.min(G, Math.max(u, F));
                  break;
                case 270:
                  Q = Math.min(D, Math.max(u, Q)), F = Math.max(0, Math.min(G - d, F));
                  break;
              }
              this.x = Q /= D, this.y = F /= G;
              const [y, B] = Z(this, _, Le).call(this);
              Q += y, F += B;
              const {
                style: N
              } = this.div;
              N.left = `${(100 * Q).toFixed(2)}%`, N.top = `${(100 * F).toFixed(2)}%`, this.moveInDOM();
            }
            screenToPageTranslation(D, G) {
              var Q;
              return Z(Q = L, C, Oe).call(Q, D, G, this.parentRotation);
            }
            pageTranslationToScreen(D, G) {
              var Q;
              return Z(Q = L, C, Oe).call(Q, D, G, 360 - this.parentRotation);
            }
            get parentScale() {
              return this._uiManager.viewParameters.realScale;
            }
            get parentRotation() {
              return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
            }
            get parentDimensions() {
              const {
                parentScale: D,
                pageDimensions: [G, Q]
              } = this, F = G * D, d = Q * D;
              return s.FeatureTest.isCSSRoundSupported ? [Math.round(F), Math.round(d)] : [F, d];
            }
            setDims(D, G) {
              var d;
              const [Q, F] = this.parentDimensions;
              this.div.style.width = `${(100 * D / Q).toFixed(2)}%`, r(this, v) || (this.div.style.height = `${(100 * G / F).toFixed(2)}%`), (d = r(this, a)) == null || d.classList.toggle("small", D < L.SMALL_EDITOR_SIZE || G < L.SMALL_EDITOR_SIZE);
            }
            fixDims() {
              const {
                style: D
              } = this.div, {
                height: G,
                width: Q
              } = D, F = Q.endsWith("%"), d = !r(this, v) && G.endsWith("%");
              if (F && d)
                return;
              const [u, y] = this.parentDimensions;
              F || (D.width = `${(100 * parseFloat(Q) / u).toFixed(2)}%`), !r(this, v) && !d && (D.height = `${(100 * parseFloat(G) / y).toFixed(2)}%`);
            }
            getInitialTranslation() {
              return [0, 0];
            }
            async addAltTextButton() {
              if (r(this, a))
                return;
              const D = lt(this, a, document.createElement("button"));
              D.className = "altText";
              const G = await L._l10nPromise.get("editor_alt_text_button_label");
              D.textContent = G, D.setAttribute("aria-label", G), D.tabIndex = "0", D.addEventListener("contextmenu", c.noContextMenu), D.addEventListener("pointerdown", (Q) => Q.stopPropagation()), D.addEventListener("click", (Q) => {
                Q.preventDefault(), this._uiManager.editAltText(this);
              }, {
                capture: !0
              }), D.addEventListener("keydown", (Q) => {
                Q.target === D && Q.key === "Enter" && (Q.preventDefault(), this._uiManager.editAltText(this));
              }), Z(this, _, Ne).call(this), this.div.append(D), L.SMALL_EDITOR_SIZE || (L.SMALL_EDITOR_SIZE = Math.min(128, Math.round(D.getBoundingClientRect().width * 1.4)));
            }
            getClientDimensions() {
              return this.div.getBoundingClientRect();
            }
            get altTextData() {
              return {
                altText: r(this, o),
                decorative: r(this, l)
              };
            }
            set altTextData({
              altText: D,
              decorative: G
            }) {
              r(this, o) === D && r(this, l) === G || (lt(this, o, D), lt(this, l, G), Z(this, _, Ne).call(this));
            }
            render() {
              this.div = document.createElement("div"), this.div.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), this.div.className = this.name, this.div.setAttribute("id", this.id), this.div.setAttribute("tabIndex", 0), this.setInForeground(), this.div.addEventListener("focusin", r(this, x)), this.div.addEventListener("focusout", r(this, S));
              const [D, G] = this.parentDimensions;
              this.parentRotation % 180 !== 0 && (this.div.style.maxWidth = `${(100 * G / D).toFixed(2)}%`, this.div.style.maxHeight = `${(100 * D / G).toFixed(2)}%`);
              const [Q, F] = this.getInitialTranslation();
              return this.translate(Q, F), (0, e.bindEvents)(this, this.div, ["pointerdown"]), this.div;
            }
            pointerdown(D) {
              const {
                isMac: G
              } = s.FeatureTest.platform;
              if (D.button !== 0 || D.ctrlKey && G) {
                D.preventDefault();
                return;
              }
              lt(this, E, !0), Z(this, _, vn).call(this, D);
            }
            moveInDOM() {
              var D;
              (D = this.parent) == null || D.moveEditorInDOM(this);
            }
            _setParentAndPosition(D, G, Q) {
              D.changeParent(this), this.x = G, this.y = Q, this.fixAndSetPosition();
            }
            getRect(D, G) {
              const Q = this.parentScale, [F, d] = this.pageDimensions, [u, y] = this.pageTranslation, B = D / Q, N = G / Q, $ = this.x * F, K = this.y * d, st = this.width * F, dt = this.height * d;
              switch (this.rotation) {
                case 0:
                  return [$ + B + u, d - K - N - dt + y, $ + B + st + u, d - K - N + y];
                case 90:
                  return [$ + N + u, d - K + B + y, $ + N + dt + u, d - K + B + st + y];
                case 180:
                  return [$ - B - st + u, d - K + N + y, $ - B + u, d - K + N + dt + y];
                case 270:
                  return [$ - N - dt + u, d - K - B - st + y, $ - N + u, d - K - B + y];
                default:
                  throw new Error("Invalid rotation");
              }
            }
            getRectInCurrentCoords(D, G) {
              const [Q, F, d, u] = D, y = d - Q, B = u - F;
              switch (this.rotation) {
                case 0:
                  return [Q, G - u, y, B];
                case 90:
                  return [Q, G - F, B, y];
                case 180:
                  return [d, G - F, y, B];
                case 270:
                  return [d, G - u, B, y];
                default:
                  throw new Error("Invalid rotation");
              }
            }
            onceAdded() {
            }
            isEmpty() {
              return !1;
            }
            enableEditMode() {
              lt(this, M, !0);
            }
            disableEditMode() {
              lt(this, M, !1);
            }
            isInEditMode() {
              return r(this, M);
            }
            shouldGetKeyboardEvents() {
              return !1;
            }
            needsToBeRebuilt() {
              return this.div && !this.isAttachedToDOM;
            }
            rebuild() {
              var D, G;
              (D = this.div) == null || D.addEventListener("focusin", r(this, x)), (G = this.div) == null || G.addEventListener("focusout", r(this, S));
            }
            serialize(D = !1, G = null) {
              (0, s.unreachable)("An editor must be serializable");
            }
            static deserialize(D, G, Q) {
              const F = new this.prototype.constructor({
                parent: G,
                id: G.getNextId(),
                uiManager: Q
              });
              F.rotation = D.rotation;
              const [d, u] = F.pageDimensions, [y, B, N, $] = F.getRectInCurrentCoords(D.rect, u);
              return F.x = y / d, F.y = B / u, F.width = N / d, F.height = $ / u, F;
            }
            remove() {
              var D;
              this.div.removeEventListener("focusin", r(this, x)), this.div.removeEventListener("focusout", r(this, S)), this.isEmpty() || this.commit(), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), (D = r(this, a)) == null || D.remove(), lt(this, a, null), lt(this, T, null);
            }
            get isResizable() {
              return !1;
            }
            makeResizable() {
              this.isResizable && (Z(this, _, bn).call(this), r(this, k).classList.remove("hidden"));
            }
            select() {
              var D;
              this.makeResizable(), (D = this.div) == null || D.classList.add("selectedEditor");
            }
            unselect() {
              var D, G, Q;
              (D = r(this, k)) == null || D.classList.add("hidden"), (G = this.div) == null || G.classList.remove("selectedEditor"), (Q = this.div) != null && Q.contains(document.activeElement) && this._uiManager.currentLayer.div.focus();
            }
            updateParams(D, G) {
            }
            disableEditing() {
              r(this, a) && (r(this, a).hidden = !0);
            }
            enableEditing() {
              r(this, a) && (r(this, a).hidden = !1);
            }
            enterInEditMode() {
            }
            get contentDiv() {
              return this.div;
            }
            get isEditing() {
              return r(this, w);
            }
            set isEditing(D) {
              lt(this, w, D), this.parent && (D ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
            }
            setAspectRatio(D, G) {
              lt(this, v, !0);
              const Q = D / G, {
                style: F
              } = this.div;
              F.aspectRatio = Q, F.height = "auto";
            }
            static get MIN_SIZE() {
              return 16;
            }
          };
          o = new WeakMap(), l = new WeakMap(), a = new WeakMap(), T = new WeakMap(), P = new WeakMap(), v = new WeakMap(), k = new WeakMap(), x = new WeakMap(), S = new WeakMap(), E = new WeakMap(), w = new WeakMap(), M = new WeakMap(), g = new WeakMap(), p = new WeakMap(), _ = new WeakSet(), Ie = function([D, G], Q, F) {
            [Q, F] = this.screenToPageTranslation(Q, F), this.x += Q / D, this.y += F / G, this.fixAndSetPosition();
          }, Le = function() {
            const [D, G] = this.parentDimensions, {
              _borderLineWidth: Q
            } = L, F = Q / D, d = Q / G;
            switch (this.rotation) {
              case 90:
                return [-F, d];
              case 180:
                return [F, d];
              case 270:
                return [F, -d];
              default:
                return [-F, -d];
            }
          }, C = new WeakSet(), Oe = function(D, G, Q) {
            switch (Q) {
              case 90:
                return [G, -D];
              case 180:
                return [-D, -G];
              case 270:
                return [-G, D];
              default:
                return [D, G];
            }
          }, $e = function(D) {
            switch (D) {
              case 90: {
                const [G, Q] = this.pageDimensions;
                return [0, -G / Q, Q / G, 0];
              }
              case 180:
                return [-1, 0, 0, -1];
              case 270: {
                const [G, Q] = this.pageDimensions;
                return [0, G / Q, -Q / G, 0];
              }
              default:
                return [1, 0, 0, 1];
            }
          }, bn = function() {
            if (r(this, k))
              return;
            lt(this, k, document.createElement("div")), r(this, k).classList.add("resizers");
            const D = ["topLeft", "topRight", "bottomRight", "bottomLeft"];
            this._willKeepAspectRatio || D.push("topMiddle", "middleRight", "bottomMiddle", "middleLeft");
            for (const G of D) {
              const Q = document.createElement("div");
              r(this, k).append(Q), Q.classList.add("resizer", G), Q.addEventListener("pointerdown", Z(this, _, yn).bind(this, G)), Q.addEventListener("contextmenu", c.noContextMenu);
            }
            this.div.prepend(r(this, k));
          }, yn = function(D, G) {
            G.preventDefault();
            const {
              isMac: Q
            } = s.FeatureTest.platform;
            if (G.button !== 0 || G.ctrlKey && Q)
              return;
            const F = Z(this, _, An).bind(this, D), d = this._isDraggable;
            this._isDraggable = !1;
            const u = {
              passive: !0,
              capture: !0
            };
            window.addEventListener("pointermove", F, u);
            const y = this.x, B = this.y, N = this.width, $ = this.height, K = this.parent.div.style.cursor, st = this.div.style.cursor;
            this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(G.target).cursor;
            const dt = () => {
              this._isDraggable = d, window.removeEventListener("pointerup", dt), window.removeEventListener("blur", dt), window.removeEventListener("pointermove", F, u), this.parent.div.style.cursor = K, this.div.style.cursor = st;
              const pt = this.x, gt = this.y, mt = this.width, ut = this.height;
              pt === y && gt === B && mt === N && ut === $ || this.addCommands({
                cmd: () => {
                  this.width = mt, this.height = ut, this.x = pt, this.y = gt;
                  const [tt, it] = this.parentDimensions;
                  this.setDims(tt * mt, it * ut), this.fixAndSetPosition();
                },
                undo: () => {
                  this.width = N, this.height = $, this.x = y, this.y = B;
                  const [tt, it] = this.parentDimensions;
                  this.setDims(tt * N, it * $), this.fixAndSetPosition();
                },
                mustExec: !0
              });
            };
            window.addEventListener("pointerup", dt), window.addEventListener("blur", dt);
          }, An = function(D, G) {
            const [Q, F] = this.parentDimensions, d = this.x, u = this.y, y = this.width, B = this.height, N = L.MIN_SIZE / Q, $ = L.MIN_SIZE / F, K = (Mt) => Math.round(Mt * 1e4) / 1e4, st = Z(this, _, $e).call(this, this.rotation), dt = (Mt, $t) => [st[0] * Mt + st[2] * $t, st[1] * Mt + st[3] * $t], pt = Z(this, _, $e).call(this, 360 - this.rotation), gt = (Mt, $t) => [pt[0] * Mt + pt[2] * $t, pt[1] * Mt + pt[3] * $t];
            let mt, ut, tt = !1, it = !1;
            switch (D) {
              case "topLeft":
                tt = !0, mt = (Mt, $t) => [0, 0], ut = (Mt, $t) => [Mt, $t];
                break;
              case "topMiddle":
                mt = (Mt, $t) => [Mt / 2, 0], ut = (Mt, $t) => [Mt / 2, $t];
                break;
              case "topRight":
                tt = !0, mt = (Mt, $t) => [Mt, 0], ut = (Mt, $t) => [0, $t];
                break;
              case "middleRight":
                it = !0, mt = (Mt, $t) => [Mt, $t / 2], ut = (Mt, $t) => [0, $t / 2];
                break;
              case "bottomRight":
                tt = !0, mt = (Mt, $t) => [Mt, $t], ut = (Mt, $t) => [0, 0];
                break;
              case "bottomMiddle":
                mt = (Mt, $t) => [Mt / 2, $t], ut = (Mt, $t) => [Mt / 2, 0];
                break;
              case "bottomLeft":
                tt = !0, mt = (Mt, $t) => [0, $t], ut = (Mt, $t) => [Mt, 0];
                break;
              case "middleLeft":
                it = !0, mt = (Mt, $t) => [0, $t / 2], ut = (Mt, $t) => [Mt, $t / 2];
                break;
            }
            const R = mt(y, B), U = ut(y, B);
            let J = dt(...U);
            const rt = K(d + J[0]), _t = K(u + J[1]);
            let wt = 1, vt = 1, [nt, kt] = this.screenToPageTranslation(G.movementX, G.movementY);
            if ([nt, kt] = gt(nt / Q, kt / F), tt) {
              const Mt = Math.hypot(y, B);
              wt = vt = Math.max(Math.min(Math.hypot(U[0] - R[0] - nt, U[1] - R[1] - kt) / Mt, 1 / y, 1 / B), N / y, $ / B);
            } else it ? wt = Math.max(N, Math.min(1, Math.abs(U[0] - R[0] - nt))) / y : vt = Math.max($, Math.min(1, Math.abs(U[1] - R[1] - kt))) / B;
            const Et = K(y * wt), Ut = K(B * vt);
            J = dt(...ut(Et, Ut));
            const Nt = rt - J[0], zt = _t - J[1];
            this.width = Et, this.height = Ut, this.x = Nt, this.y = zt, this.setDims(Q * Et, F * Ut), this.fixAndSetPosition();
          }, Ne = async function() {
            var Q;
            const D = r(this, a);
            if (!D)
              return;
            if (!r(this, o) && !r(this, l)) {
              D.classList.remove("done"), (Q = r(this, T)) == null || Q.remove();
              return;
            }
            L._l10nPromise.get("editor_alt_text_edit_button_label").then((F) => {
              D.setAttribute("aria-label", F);
            });
            let G = r(this, T);
            if (!G) {
              lt(this, T, G = document.createElement("span")), G.className = "tooltip", G.setAttribute("role", "tooltip");
              const F = G.id = `alt-text-tooltip-${this.id}`;
              D.setAttribute("aria-describedby", F);
              const d = 100;
              D.addEventListener("mouseenter", () => {
                lt(this, P, setTimeout(() => {
                  lt(this, P, null), r(this, T).classList.add("show"), this._uiManager._eventBus.dispatch("reporttelemetry", {
                    source: this,
                    details: {
                      type: "editing",
                      subtype: this.editorType,
                      data: {
                        action: "alt_text_tooltip"
                      }
                    }
                  });
                }, d));
              }), D.addEventListener("mouseleave", () => {
                var u;
                clearTimeout(r(this, P)), lt(this, P, null), (u = r(this, T)) == null || u.classList.remove("show");
              });
            }
            D.classList.add("done"), G.innerText = r(this, l) ? await L._l10nPromise.get("editor_alt_text_decorative_tooltip") : r(this, o), G.parentNode || D.append(G);
          }, vn = function(D) {
            if (!this._isDraggable)
              return;
            const G = this._uiManager.isSelected(this);
            this._uiManager.setUpDragSession();
            let Q, F;
            G && (Q = {
              passive: !0,
              capture: !0
            }, F = (u) => {
              const [y, B] = this.screenToPageTranslation(u.movementX, u.movementY);
              this._uiManager.dragSelectedEditors(y, B);
            }, window.addEventListener("pointermove", F, Q));
            const d = () => {
              if (window.removeEventListener("pointerup", d), window.removeEventListener("blur", d), G && window.removeEventListener("pointermove", F, Q), lt(this, E, !1), !this._uiManager.endDragSession()) {
                const {
                  isMac: u
                } = s.FeatureTest.platform;
                D.ctrlKey && !u || D.shiftKey || D.metaKey && u ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
              }
            };
            window.addEventListener("pointerup", d), window.addEventListener("blur", d);
          }, at(L, C), Kt(L, "_borderLineWidth", -1), Kt(L, "_colorManager", new e.ColorManager()), Kt(L, "_zIndex", 1), Kt(L, "SMALL_EDITOR_SIZE", 0);
          let h = L;
          t.AnnotationEditor = h;
          class b extends h {
            constructor(D) {
              super(D), this.annotationElementId = D.annotationElementId, this.deleted = !0;
            }
            serialize() {
              return {
                id: this.annotationElementId,
                deleted: !0,
                pageIndex: this.pageIndex
              };
            }
          }
        },
        /* 5 */
        /***/
        (i, t, n) => {
          var v, k, x, S, E, Be, g, p, _, f, A, wn, m, I, q, Y, X, z, L, et, D, G, Q, F, d, u, y, B, N, $, K, st, dt, pt, gt, mt, ut, tt, it, R, U, J, rt, _t, wt, vt, nt, Sn, Ue, je, Ae, qe, We, Qt, de, En, Cn, He, ue, ze;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.KeyboardManager = t.CommandManager = t.ColorManager = t.AnnotationEditorUIManager = void 0, t.bindEvents = c, t.opacityToHex = h;
          var e = n(1), s = n(6);
          function c(Wt, H, bt) {
            for (const Ct of bt)
              H.addEventListener(Ct, Wt[Ct].bind(Wt));
          }
          function h(Wt) {
            return Math.round(Math.min(255, Math.max(1, 255 * Wt))).toString(16).padStart(2, "0");
          }
          class b {
            constructor() {
              at(this, v, 0);
            }
            getId() {
              return `${e.AnnotationEditorPrefix}${he(this, v)._++}`;
            }
          }
          v = new WeakMap();
          const M = class M {
            constructor() {
              at(this, E);
              at(this, k, (0, e.getUuid)());
              at(this, x, 0);
              at(this, S, null);
            }
            static get _isSVGFittingCanvas() {
              const H = 'data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>', Ct = new OffscreenCanvas(1, 3).getContext("2d"), Dt = new Image();
              Dt.src = H;
              const Ot = Dt.decode().then(() => (Ct.drawImage(Dt, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(Ct.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
              return (0, e.shadow)(this, "_isSVGFittingCanvas", Ot);
            }
            async getFromFile(H) {
              const {
                lastModified: bt,
                name: Ct,
                size: Dt,
                type: Ot
              } = H;
              return Z(this, E, Be).call(this, `${bt}_${Ct}_${Dt}_${Ot}`, H);
            }
            async getFromUrl(H) {
              return Z(this, E, Be).call(this, H, H);
            }
            async getFromId(H) {
              r(this, S) || lt(this, S, /* @__PURE__ */ new Map());
              const bt = r(this, S).get(H);
              return bt ? bt.bitmap ? (bt.refCounter += 1, bt) : bt.file ? this.getFromFile(bt.file) : this.getFromUrl(bt.url) : null;
            }
            getSvgUrl(H) {
              const bt = r(this, S).get(H);
              return bt != null && bt.isSvg ? bt.svgUrl : null;
            }
            deleteId(H) {
              r(this, S) || lt(this, S, /* @__PURE__ */ new Map());
              const bt = r(this, S).get(H);
              bt && (bt.refCounter -= 1, bt.refCounter === 0 && (bt.bitmap = null));
            }
            isValidId(H) {
              return H.startsWith(`image_${r(this, k)}_`);
            }
          };
          k = new WeakMap(), x = new WeakMap(), S = new WeakMap(), E = new WeakSet(), Be = async function(H, bt) {
            r(this, S) || lt(this, S, /* @__PURE__ */ new Map());
            let Ct = r(this, S).get(H);
            if (Ct === null)
              return null;
            if (Ct != null && Ct.bitmap)
              return Ct.refCounter += 1, Ct;
            try {
              Ct || (Ct = {
                bitmap: null,
                id: `image_${r(this, k)}_${he(this, x)._++}`,
                refCounter: 0,
                isSvg: !1
              });
              let Dt;
              if (typeof bt == "string") {
                Ct.url = bt;
                const Ot = await fetch(bt);
                if (!Ot.ok)
                  throw new Error(Ot.statusText);
                Dt = await Ot.blob();
              } else
                Dt = Ct.file = bt;
              if (Dt.type === "image/svg+xml") {
                const Ot = M._isSVGFittingCanvas, Pt = new FileReader(), j = new Image(), O = new Promise((V, ht) => {
                  j.onload = () => {
                    Ct.bitmap = j, Ct.isSvg = !0, V();
                  }, Pt.onload = async () => {
                    const ft = Ct.svgUrl = Pt.result;
                    j.src = await Ot ? `${ft}#svgView(preserveAspectRatio(none))` : ft;
                  }, j.onerror = Pt.onerror = ht;
                });
                Pt.readAsDataURL(Dt), await O;
              } else
                Ct.bitmap = await createImageBitmap(Dt);
              Ct.refCounter = 1;
            } catch (Dt) {
              console.error(Dt), Ct = null;
            }
            return r(this, S).set(H, Ct), Ct && r(this, S).set(Ct.id, Ct), Ct;
          };
          let o = M;
          class l {
            constructor(H = 128) {
              at(this, g, []);
              at(this, p, !1);
              at(this, _);
              at(this, f, -1);
              lt(this, _, H);
            }
            add({
              cmd: H,
              undo: bt,
              mustExec: Ct,
              type: Dt = NaN,
              overwriteIfSameType: Ot = !1,
              keepUndo: Pt = !1
            }) {
              if (Ct && H(), r(this, p))
                return;
              const j = {
                cmd: H,
                undo: bt,
                type: Dt
              };
              if (r(this, f) === -1) {
                r(this, g).length > 0 && (r(this, g).length = 0), lt(this, f, 0), r(this, g).push(j);
                return;
              }
              if (Ot && r(this, g)[r(this, f)].type === Dt) {
                Pt && (j.undo = r(this, g)[r(this, f)].undo), r(this, g)[r(this, f)] = j;
                return;
              }
              const O = r(this, f) + 1;
              O === r(this, _) ? r(this, g).splice(0, 1) : (lt(this, f, O), O < r(this, g).length && r(this, g).splice(O)), r(this, g).push(j);
            }
            undo() {
              r(this, f) !== -1 && (lt(this, p, !0), r(this, g)[r(this, f)].undo(), lt(this, p, !1), lt(this, f, r(this, f) - 1));
            }
            redo() {
              r(this, f) < r(this, g).length - 1 && (lt(this, f, r(this, f) + 1), lt(this, p, !0), r(this, g)[r(this, f)].cmd(), lt(this, p, !1));
            }
            hasSomethingToUndo() {
              return r(this, f) !== -1;
            }
            hasSomethingToRedo() {
              return r(this, f) < r(this, g).length - 1;
            }
            destroy() {
              lt(this, g, null);
            }
          }
          g = new WeakMap(), p = new WeakMap(), _ = new WeakMap(), f = new WeakMap(), t.CommandManager = l;
          class a {
            constructor(H) {
              at(this, A);
              this.buffer = [], this.callbacks = /* @__PURE__ */ new Map(), this.allKeys = /* @__PURE__ */ new Set();
              const {
                isMac: bt
              } = e.FeatureTest.platform;
              for (const [Ct, Dt, Ot = {}] of H)
                for (const Pt of Ct) {
                  const j = Pt.startsWith("mac+");
                  bt && j ? (this.callbacks.set(Pt.slice(4), {
                    callback: Dt,
                    options: Ot
                  }), this.allKeys.add(Pt.split("+").at(-1))) : !bt && !j && (this.callbacks.set(Pt, {
                    callback: Dt,
                    options: Ot
                  }), this.allKeys.add(Pt.split("+").at(-1)));
                }
            }
            exec(H, bt) {
              if (!this.allKeys.has(bt.key))
                return;
              const Ct = this.callbacks.get(Z(this, A, wn).call(this, bt));
              if (!Ct)
                return;
              const {
                callback: Dt,
                options: {
                  bubbles: Ot = !1,
                  args: Pt = [],
                  checker: j = null
                }
              } = Ct;
              j && !j(H, bt) || (Dt.bind(H, ...Pt)(), Ot || (bt.stopPropagation(), bt.preventDefault()));
            }
          }
          A = new WeakSet(), wn = function(H) {
            H.altKey && this.buffer.push("alt"), H.ctrlKey && this.buffer.push("ctrl"), H.metaKey && this.buffer.push("meta"), H.shiftKey && this.buffer.push("shift"), this.buffer.push(H.key);
            const bt = this.buffer.join("+");
            return this.buffer.length = 0, bt;
          }, t.KeyboardManager = a;
          const W = class W {
            get _colors() {
              const H = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
              return (0, s.getColorValues)(H), (0, e.shadow)(this, "_colors", H);
            }
            convert(H) {
              const bt = (0, s.getRGB)(H);
              if (!window.matchMedia("(forced-colors: active)").matches)
                return bt;
              for (const [Ct, Dt] of this._colors)
                if (Dt.every((Ot, Pt) => Ot === bt[Pt]))
                  return W._colorsMapping.get(Ct);
              return bt;
            }
            getHexCode(H) {
              const bt = this._colors.get(H);
              return bt ? e.Util.makeHexColor(...bt) : H;
            }
          };
          Kt(W, "_colorsMapping", /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]));
          let T = W;
          t.ColorManager = T;
          const Ht = class Ht {
            constructor(H, bt, Ct, Dt, Ot, Pt) {
              at(this, nt);
              at(this, m, null);
              at(this, I, /* @__PURE__ */ new Map());
              at(this, q, /* @__PURE__ */ new Map());
              at(this, Y, null);
              at(this, X, null);
              at(this, z, new l());
              at(this, L, 0);
              at(this, et, /* @__PURE__ */ new Set());
              at(this, D, null);
              at(this, G, null);
              at(this, Q, /* @__PURE__ */ new Set());
              at(this, F, null);
              at(this, d, new b());
              at(this, u, !1);
              at(this, y, !1);
              at(this, B, null);
              at(this, N, e.AnnotationEditorType.NONE);
              at(this, $, /* @__PURE__ */ new Set());
              at(this, K, null);
              at(this, st, this.blur.bind(this));
              at(this, dt, this.focus.bind(this));
              at(this, pt, this.copy.bind(this));
              at(this, gt, this.cut.bind(this));
              at(this, mt, this.paste.bind(this));
              at(this, ut, this.keydown.bind(this));
              at(this, tt, this.onEditingAction.bind(this));
              at(this, it, this.onPageChanging.bind(this));
              at(this, R, this.onScaleChanging.bind(this));
              at(this, U, this.onRotationChanging.bind(this));
              at(this, J, {
                isEditing: !1,
                isEmpty: !0,
                hasSomethingToUndo: !1,
                hasSomethingToRedo: !1,
                hasSelectedEditor: !1
              });
              at(this, rt, [0, 0]);
              at(this, _t, null);
              at(this, wt, null);
              at(this, vt, null);
              lt(this, wt, H), lt(this, vt, bt), lt(this, Y, Ct), this._eventBus = Dt, this._eventBus._on("editingaction", r(this, tt)), this._eventBus._on("pagechanging", r(this, it)), this._eventBus._on("scalechanging", r(this, R)), this._eventBus._on("rotationchanging", r(this, U)), lt(this, X, Ot.annotationStorage), lt(this, F, Ot.filterFactory), lt(this, K, Pt), this.viewParameters = {
                realScale: s.PixelsPerInch.PDF_TO_CSS_UNITS,
                rotation: 0
              };
            }
            static get _keyboardManager() {
              const H = Ht.prototype, bt = (Ot) => {
                const {
                  activeElement: Pt
                } = document;
                return Pt && r(Ot, wt).contains(Pt) && Ot.hasSomethingToControl();
              }, Ct = this.TRANSLATE_SMALL, Dt = this.TRANSLATE_BIG;
              return (0, e.shadow)(this, "_keyboardManager", new a([[["ctrl+a", "mac+meta+a"], H.selectAll], [["ctrl+z", "mac+meta+z"], H.undo], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], H.redo], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], H.delete], [["Escape", "mac+Escape"], H.unselectAll], [["ArrowLeft", "mac+ArrowLeft"], H.translateSelectedEditors, {
                args: [-Ct, 0],
                checker: bt
              }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], H.translateSelectedEditors, {
                args: [-Dt, 0],
                checker: bt
              }], [["ArrowRight", "mac+ArrowRight"], H.translateSelectedEditors, {
                args: [Ct, 0],
                checker: bt
              }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], H.translateSelectedEditors, {
                args: [Dt, 0],
                checker: bt
              }], [["ArrowUp", "mac+ArrowUp"], H.translateSelectedEditors, {
                args: [0, -Ct],
                checker: bt
              }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], H.translateSelectedEditors, {
                args: [0, -Dt],
                checker: bt
              }], [["ArrowDown", "mac+ArrowDown"], H.translateSelectedEditors, {
                args: [0, Ct],
                checker: bt
              }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], H.translateSelectedEditors, {
                args: [0, Dt],
                checker: bt
              }]]));
            }
            destroy() {
              Z(this, nt, Ae).call(this), Z(this, nt, Ue).call(this), this._eventBus._off("editingaction", r(this, tt)), this._eventBus._off("pagechanging", r(this, it)), this._eventBus._off("scalechanging", r(this, R)), this._eventBus._off("rotationchanging", r(this, U));
              for (const H of r(this, q).values())
                H.destroy();
              r(this, q).clear(), r(this, I).clear(), r(this, Q).clear(), lt(this, m, null), r(this, $).clear(), r(this, z).destroy(), r(this, Y).destroy();
            }
            get hcmFilter() {
              return (0, e.shadow)(this, "hcmFilter", r(this, K) ? r(this, F).addHCMFilter(r(this, K).foreground, r(this, K).background) : "none");
            }
            get direction() {
              return (0, e.shadow)(this, "direction", getComputedStyle(r(this, wt)).direction);
            }
            editAltText(H) {
              var bt;
              (bt = r(this, Y)) == null || bt.editAltText(this, H);
            }
            onPageChanging({
              pageNumber: H
            }) {
              lt(this, L, H - 1);
            }
            focusMainContainer() {
              r(this, wt).focus();
            }
            findParent(H, bt) {
              for (const Ct of r(this, q).values()) {
                const {
                  x: Dt,
                  y: Ot,
                  width: Pt,
                  height: j
                } = Ct.div.getBoundingClientRect();
                if (H >= Dt && H <= Dt + Pt && bt >= Ot && bt <= Ot + j)
                  return Ct;
              }
              return null;
            }
            disableUserSelect(H = !1) {
              r(this, vt).classList.toggle("noUserSelect", H);
            }
            addShouldRescale(H) {
              r(this, Q).add(H);
            }
            removeShouldRescale(H) {
              r(this, Q).delete(H);
            }
            onScaleChanging({
              scale: H
            }) {
              this.commitOrRemove(), this.viewParameters.realScale = H * s.PixelsPerInch.PDF_TO_CSS_UNITS;
              for (const bt of r(this, Q))
                bt.onScaleChanging();
            }
            onRotationChanging({
              pagesRotation: H
            }) {
              this.commitOrRemove(), this.viewParameters.rotation = H;
            }
            addToAnnotationStorage(H) {
              !H.isEmpty() && r(this, X) && !r(this, X).has(H.id) && r(this, X).setValue(H.id, H);
            }
            blur() {
              if (!this.hasSelection)
                return;
              const {
                activeElement: H
              } = document;
              for (const bt of r(this, $))
                if (bt.div.contains(H)) {
                  lt(this, B, [bt, H]), bt._focusEventsAllowed = !1;
                  break;
                }
            }
            focus() {
              if (!r(this, B))
                return;
              const [H, bt] = r(this, B);
              lt(this, B, null), bt.addEventListener("focusin", () => {
                H._focusEventsAllowed = !0;
              }, {
                once: !0
              }), bt.focus();
            }
            addEditListeners() {
              Z(this, nt, je).call(this), Z(this, nt, qe).call(this);
            }
            removeEditListeners() {
              Z(this, nt, Ae).call(this), Z(this, nt, We).call(this);
            }
            copy(H) {
              var Ct;
              if (H.preventDefault(), (Ct = r(this, m)) == null || Ct.commitOrRemove(), !this.hasSelection)
                return;
              const bt = [];
              for (const Dt of r(this, $)) {
                const Ot = Dt.serialize(!0);
                Ot && bt.push(Ot);
              }
              bt.length !== 0 && H.clipboardData.setData("application/pdfjs", JSON.stringify(bt));
            }
            cut(H) {
              this.copy(H), this.delete();
            }
            paste(H) {
              H.preventDefault();
              const {
                clipboardData: bt
              } = H;
              for (const Ot of bt.items)
                for (const Pt of r(this, G))
                  if (Pt.isHandlingMimeForPasting(Ot.type)) {
                    Pt.paste(Ot, this.currentLayer);
                    return;
                  }
              let Ct = bt.getData("application/pdfjs");
              if (!Ct)
                return;
              try {
                Ct = JSON.parse(Ct);
              } catch (Ot) {
                (0, e.warn)(`paste: "${Ot.message}".`);
                return;
              }
              if (!Array.isArray(Ct))
                return;
              this.unselectAll();
              const Dt = this.currentLayer;
              try {
                const Ot = [];
                for (const O of Ct) {
                  const V = Dt.deserialize(O);
                  if (!V)
                    return;
                  Ot.push(V);
                }
                const Pt = () => {
                  for (const O of Ot)
                    Z(this, nt, He).call(this, O);
                  Z(this, nt, ze).call(this, Ot);
                }, j = () => {
                  for (const O of Ot)
                    O.remove();
                };
                this.addCommands({
                  cmd: Pt,
                  undo: j,
                  mustExec: !0
                });
              } catch (Ot) {
                (0, e.warn)(`paste: "${Ot.message}".`);
              }
            }
            keydown(H) {
              var bt;
              (bt = this.getActive()) != null && bt.shouldGetKeyboardEvents() || Ht._keyboardManager.exec(this, H);
            }
            onEditingAction(H) {
              ["undo", "redo", "delete", "selectAll"].includes(H.name) && this[H.name]();
            }
            setEditingState(H) {
              H ? (Z(this, nt, Sn).call(this), Z(this, nt, je).call(this), Z(this, nt, qe).call(this), Z(this, nt, Qt).call(this, {
                isEditing: r(this, N) !== e.AnnotationEditorType.NONE,
                isEmpty: Z(this, nt, ue).call(this),
                hasSomethingToUndo: r(this, z).hasSomethingToUndo(),
                hasSomethingToRedo: r(this, z).hasSomethingToRedo(),
                hasSelectedEditor: !1
              })) : (Z(this, nt, Ue).call(this), Z(this, nt, Ae).call(this), Z(this, nt, We).call(this), Z(this, nt, Qt).call(this, {
                isEditing: !1
              }), this.disableUserSelect(!1));
            }
            registerEditorTypes(H) {
              if (!r(this, G)) {
                lt(this, G, H);
                for (const bt of r(this, G))
                  Z(this, nt, de).call(this, bt.defaultPropertiesToUpdate);
              }
            }
            getId() {
              return r(this, d).getId();
            }
            get currentLayer() {
              return r(this, q).get(r(this, L));
            }
            getLayer(H) {
              return r(this, q).get(H);
            }
            get currentPageIndex() {
              return r(this, L);
            }
            addLayer(H) {
              r(this, q).set(H.pageIndex, H), r(this, u) ? H.enable() : H.disable();
            }
            removeLayer(H) {
              r(this, q).delete(H.pageIndex);
            }
            updateMode(H, bt = null) {
              if (r(this, N) !== H) {
                if (lt(this, N, H), H === e.AnnotationEditorType.NONE) {
                  this.setEditingState(!1), Z(this, nt, Cn).call(this);
                  return;
                }
                this.setEditingState(!0), Z(this, nt, En).call(this), this.unselectAll();
                for (const Ct of r(this, q).values())
                  Ct.updateMode(H);
                if (bt) {
                  for (const Ct of r(this, I).values())
                    if (Ct.annotationElementId === bt) {
                      this.setSelected(Ct), Ct.enterInEditMode();
                      break;
                    }
                }
              }
            }
            updateToolbar(H) {
              H !== r(this, N) && this._eventBus.dispatch("switchannotationeditormode", {
                source: this,
                mode: H
              });
            }
            updateParams(H, bt) {
              if (r(this, G)) {
                if (H === e.AnnotationEditorParamsType.CREATE) {
                  this.currentLayer.addNewEditor(H);
                  return;
                }
                for (const Ct of r(this, $))
                  Ct.updateParams(H, bt);
                for (const Ct of r(this, G))
                  Ct.updateDefaultParams(H, bt);
              }
            }
            enableWaiting(H = !1) {
              if (r(this, y) !== H) {
                lt(this, y, H);
                for (const bt of r(this, q).values())
                  H ? bt.disableClick() : bt.enableClick(), bt.div.classList.toggle("waiting", H);
              }
            }
            getEditors(H) {
              const bt = [];
              for (const Ct of r(this, I).values())
                Ct.pageIndex === H && bt.push(Ct);
              return bt;
            }
            getEditor(H) {
              return r(this, I).get(H);
            }
            addEditor(H) {
              r(this, I).set(H.id, H);
            }
            removeEditor(H) {
              var bt;
              r(this, I).delete(H.id), this.unselect(H), (!H.annotationElementId || !r(this, et).has(H.annotationElementId)) && ((bt = r(this, X)) == null || bt.remove(H.id));
            }
            addDeletedAnnotationElement(H) {
              r(this, et).add(H.annotationElementId), H.deleted = !0;
            }
            isDeletedAnnotationElement(H) {
              return r(this, et).has(H);
            }
            removeDeletedAnnotationElement(H) {
              r(this, et).delete(H.annotationElementId), H.deleted = !1;
            }
            setActiveEditor(H) {
              r(this, m) !== H && (lt(this, m, H), H && Z(this, nt, de).call(this, H.propertiesToUpdate));
            }
            toggleSelected(H) {
              if (r(this, $).has(H)) {
                r(this, $).delete(H), H.unselect(), Z(this, nt, Qt).call(this, {
                  hasSelectedEditor: this.hasSelection
                });
                return;
              }
              r(this, $).add(H), H.select(), Z(this, nt, de).call(this, H.propertiesToUpdate), Z(this, nt, Qt).call(this, {
                hasSelectedEditor: !0
              });
            }
            setSelected(H) {
              for (const bt of r(this, $))
                bt !== H && bt.unselect();
              r(this, $).clear(), r(this, $).add(H), H.select(), Z(this, nt, de).call(this, H.propertiesToUpdate), Z(this, nt, Qt).call(this, {
                hasSelectedEditor: !0
              });
            }
            isSelected(H) {
              return r(this, $).has(H);
            }
            unselect(H) {
              H.unselect(), r(this, $).delete(H), Z(this, nt, Qt).call(this, {
                hasSelectedEditor: this.hasSelection
              });
            }
            get hasSelection() {
              return r(this, $).size !== 0;
            }
            undo() {
              r(this, z).undo(), Z(this, nt, Qt).call(this, {
                hasSomethingToUndo: r(this, z).hasSomethingToUndo(),
                hasSomethingToRedo: !0,
                isEmpty: Z(this, nt, ue).call(this)
              });
            }
            redo() {
              r(this, z).redo(), Z(this, nt, Qt).call(this, {
                hasSomethingToUndo: !0,
                hasSomethingToRedo: r(this, z).hasSomethingToRedo(),
                isEmpty: Z(this, nt, ue).call(this)
              });
            }
            addCommands(H) {
              r(this, z).add(H), Z(this, nt, Qt).call(this, {
                hasSomethingToUndo: !0,
                hasSomethingToRedo: !1,
                isEmpty: Z(this, nt, ue).call(this)
              });
            }
            delete() {
              if (this.commitOrRemove(), !this.hasSelection)
                return;
              const H = [...r(this, $)], bt = () => {
                for (const Dt of H)
                  Dt.remove();
              }, Ct = () => {
                for (const Dt of H)
                  Z(this, nt, He).call(this, Dt);
              };
              this.addCommands({
                cmd: bt,
                undo: Ct,
                mustExec: !0
              });
            }
            commitOrRemove() {
              var H;
              (H = r(this, m)) == null || H.commitOrRemove();
            }
            hasSomethingToControl() {
              return r(this, m) || this.hasSelection;
            }
            selectAll() {
              for (const H of r(this, $))
                H.commit();
              Z(this, nt, ze).call(this, r(this, I).values());
            }
            unselectAll() {
              if (r(this, m)) {
                r(this, m).commitOrRemove();
                return;
              }
              if (this.hasSelection) {
                for (const H of r(this, $))
                  H.unselect();
                r(this, $).clear(), Z(this, nt, Qt).call(this, {
                  hasSelectedEditor: !1
                });
              }
            }
            translateSelectedEditors(H, bt, Ct = !1) {
              if (Ct || this.commitOrRemove(), !this.hasSelection)
                return;
              r(this, rt)[0] += H, r(this, rt)[1] += bt;
              const [Dt, Ot] = r(this, rt), Pt = [...r(this, $)], j = 1e3;
              r(this, _t) && clearTimeout(r(this, _t)), lt(this, _t, setTimeout(() => {
                lt(this, _t, null), r(this, rt)[0] = r(this, rt)[1] = 0, this.addCommands({
                  cmd: () => {
                    for (const O of Pt)
                      r(this, I).has(O.id) && O.translateInPage(Dt, Ot);
                  },
                  undo: () => {
                    for (const O of Pt)
                      r(this, I).has(O.id) && O.translateInPage(-Dt, -Ot);
                  },
                  mustExec: !1
                });
              }, j));
              for (const O of Pt)
                O.translateInPage(H, bt);
            }
            setUpDragSession() {
              if (this.hasSelection) {
                this.disableUserSelect(!0), lt(this, D, /* @__PURE__ */ new Map());
                for (const H of r(this, $))
                  r(this, D).set(H, {
                    savedX: H.x,
                    savedY: H.y,
                    savedPageIndex: H.pageIndex,
                    newX: 0,
                    newY: 0,
                    newPageIndex: -1
                  });
              }
            }
            endDragSession() {
              if (!r(this, D))
                return !1;
              this.disableUserSelect(!1);
              const H = r(this, D);
              lt(this, D, null);
              let bt = !1;
              for (const [{
                x: Dt,
                y: Ot,
                pageIndex: Pt
              }, j] of H)
                j.newX = Dt, j.newY = Ot, j.newPageIndex = Pt, bt || (bt = Dt !== j.savedX || Ot !== j.savedY || Pt !== j.savedPageIndex);
              if (!bt)
                return !1;
              const Ct = (Dt, Ot, Pt, j) => {
                if (r(this, I).has(Dt.id)) {
                  const O = r(this, q).get(j);
                  O ? Dt._setParentAndPosition(O, Ot, Pt) : (Dt.pageIndex = j, Dt.x = Ot, Dt.y = Pt);
                }
              };
              return this.addCommands({
                cmd: () => {
                  for (const [Dt, {
                    newX: Ot,
                    newY: Pt,
                    newPageIndex: j
                  }] of H)
                    Ct(Dt, Ot, Pt, j);
                },
                undo: () => {
                  for (const [Dt, {
                    savedX: Ot,
                    savedY: Pt,
                    savedPageIndex: j
                  }] of H)
                    Ct(Dt, Ot, Pt, j);
                },
                mustExec: !0
              }), !0;
            }
            dragSelectedEditors(H, bt) {
              if (r(this, D))
                for (const Ct of r(this, D).keys())
                  Ct.drag(H, bt);
            }
            rebuild(H) {
              if (H.parent === null) {
                const bt = this.getLayer(H.pageIndex);
                bt ? (bt.changeParent(H), bt.addOrRebuild(H)) : (this.addEditor(H), this.addToAnnotationStorage(H), H.rebuild());
              } else
                H.parent.addOrRebuild(H);
            }
            isActive(H) {
              return r(this, m) === H;
            }
            getActive() {
              return r(this, m);
            }
            getMode() {
              return r(this, N);
            }
            get imageManager() {
              return (0, e.shadow)(this, "imageManager", new o());
            }
          };
          m = new WeakMap(), I = new WeakMap(), q = new WeakMap(), Y = new WeakMap(), X = new WeakMap(), z = new WeakMap(), L = new WeakMap(), et = new WeakMap(), D = new WeakMap(), G = new WeakMap(), Q = new WeakMap(), F = new WeakMap(), d = new WeakMap(), u = new WeakMap(), y = new WeakMap(), B = new WeakMap(), N = new WeakMap(), $ = new WeakMap(), K = new WeakMap(), st = new WeakMap(), dt = new WeakMap(), pt = new WeakMap(), gt = new WeakMap(), mt = new WeakMap(), ut = new WeakMap(), tt = new WeakMap(), it = new WeakMap(), R = new WeakMap(), U = new WeakMap(), J = new WeakMap(), rt = new WeakMap(), _t = new WeakMap(), wt = new WeakMap(), vt = new WeakMap(), nt = new WeakSet(), Sn = function() {
            window.addEventListener("focus", r(this, dt)), window.addEventListener("blur", r(this, st));
          }, Ue = function() {
            window.removeEventListener("focus", r(this, dt)), window.removeEventListener("blur", r(this, st));
          }, je = function() {
            window.addEventListener("keydown", r(this, ut), {
              capture: !0
            });
          }, Ae = function() {
            window.removeEventListener("keydown", r(this, ut), {
              capture: !0
            });
          }, qe = function() {
            document.addEventListener("copy", r(this, pt)), document.addEventListener("cut", r(this, gt)), document.addEventListener("paste", r(this, mt));
          }, We = function() {
            document.removeEventListener("copy", r(this, pt)), document.removeEventListener("cut", r(this, gt)), document.removeEventListener("paste", r(this, mt));
          }, Qt = function(H) {
            Object.entries(H).some(([Ct, Dt]) => r(this, J)[Ct] !== Dt) && this._eventBus.dispatch("annotationeditorstateschanged", {
              source: this,
              details: Object.assign(r(this, J), H)
            });
          }, de = function(H) {
            this._eventBus.dispatch("annotationeditorparamschanged", {
              source: this,
              details: H
            });
          }, En = function() {
            if (!r(this, u)) {
              lt(this, u, !0);
              for (const H of r(this, q).values())
                H.enable();
            }
          }, Cn = function() {
            if (this.unselectAll(), r(this, u)) {
              lt(this, u, !1);
              for (const H of r(this, q).values())
                H.disable();
            }
          }, He = function(H) {
            const bt = r(this, q).get(H.pageIndex);
            bt ? bt.addOrRebuild(H) : this.addEditor(H);
          }, ue = function() {
            if (r(this, I).size === 0)
              return !0;
            if (r(this, I).size === 1)
              for (const H of r(this, I).values())
                return H.isEmpty();
            return !1;
          }, ze = function(H) {
            r(this, $).clear();
            for (const bt of H)
              bt.isEmpty() || (r(this, $).add(bt), bt.select());
            Z(this, nt, Qt).call(this, {
              hasSelectedEditor: !0
            });
          }, Kt(Ht, "TRANSLATE_SMALL", 1), Kt(Ht, "TRANSLATE_BIG", 10);
          let P = Ht;
          t.AnnotationEditorUIManager = P;
        },
        /* 6 */
        /***/
        (i, t, n) => {
          var L, et, D, G, Q, F, d, u, y, B, N, $, ae, oe, Ge, ve, we, fe, pe;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.StatTimer = t.RenderingCancelledException = t.PixelsPerInch = t.PageViewport = t.PDFDateString = t.DOMStandardFontDataFactory = t.DOMSVGFactory = t.DOMFilterFactory = t.DOMCanvasFactory = t.DOMCMapReaderFactory = void 0, t.deprecated = f, t.getColorValues = I, t.getCurrentTransform = q, t.getCurrentTransformInverse = Y, t.getFilenameFromUrl = E, t.getPdfFilenameFromUrl = w, t.getRGB = m, t.getXfaPageViewport = W, t.isDataScheme = x, t.isPdfFile = S, t.isValidFetchUrl = g, t.loadScript = _, t.noContextMenu = p, t.setLayerDimensions = X;
          var e = n(7), s = n(1);
          const c = "http://www.w3.org/2000/svg", z = class z {
          };
          Kt(z, "CSS", 96), Kt(z, "PDF", 72), Kt(z, "PDF_TO_CSS_UNITS", z.CSS / z.PDF);
          let h = z;
          t.PixelsPerInch = h;
          class b extends e.BaseFilterFactory {
            constructor({
              docId: R,
              ownerDocument: U = globalThis.document
            } = {}) {
              super();
              at(this, $);
              at(this, L);
              at(this, et);
              at(this, D);
              at(this, G);
              at(this, Q);
              at(this, F);
              at(this, d);
              at(this, u);
              at(this, y);
              at(this, B);
              at(this, N, 0);
              lt(this, D, R), lt(this, G, U);
            }
            addFilter(R) {
              if (!R)
                return "none";
              let U = r(this, $, ae).get(R);
              if (U)
                return U;
              let J, rt, _t, wt;
              if (R.length === 1) {
                const Et = R[0], Ut = new Array(256);
                for (let Nt = 0; Nt < 256; Nt++)
                  Ut[Nt] = Et[Nt] / 255;
                wt = J = rt = _t = Ut.join(",");
              } else {
                const [Et, Ut, Nt] = R, zt = new Array(256), Mt = new Array(256), $t = new Array(256);
                for (let Gt = 0; Gt < 256; Gt++)
                  zt[Gt] = Et[Gt] / 255, Mt[Gt] = Ut[Gt] / 255, $t[Gt] = Nt[Gt] / 255;
                J = zt.join(","), rt = Mt.join(","), _t = $t.join(","), wt = `${J}${rt}${_t}`;
              }
              if (U = r(this, $, ae).get(wt), U)
                return r(this, $, ae).set(R, U), U;
              const vt = `g_${r(this, D)}_transfer_map_${he(this, N)._++}`, nt = `url(#${vt})`;
              r(this, $, ae).set(R, nt), r(this, $, ae).set(wt, nt);
              const kt = Z(this, $, ve).call(this, vt);
              return Z(this, $, fe).call(this, J, rt, _t, kt), nt;
            }
            addHCMFilter(R, U) {
              var Ut;
              const J = `${R}-${U}`;
              if (r(this, F) === J)
                return r(this, d);
              if (lt(this, F, J), lt(this, d, "none"), (Ut = r(this, Q)) == null || Ut.remove(), !R || !U)
                return r(this, d);
              const rt = Z(this, $, pe).call(this, R);
              R = s.Util.makeHexColor(...rt);
              const _t = Z(this, $, pe).call(this, U);
              if (U = s.Util.makeHexColor(..._t), r(this, $, oe).style.color = "", R === "#000000" && U === "#ffffff" || R === U)
                return r(this, d);
              const wt = new Array(256);
              for (let Nt = 0; Nt <= 255; Nt++) {
                const zt = Nt / 255;
                wt[Nt] = zt <= 0.03928 ? zt / 12.92 : ((zt + 0.055) / 1.055) ** 2.4;
              }
              const vt = wt.join(","), nt = `g_${r(this, D)}_hcm_filter`, kt = lt(this, u, Z(this, $, ve).call(this, nt));
              Z(this, $, fe).call(this, vt, vt, vt, kt), Z(this, $, Ge).call(this, kt);
              const Et = (Nt, zt) => {
                const Mt = rt[Nt] / 255, $t = _t[Nt] / 255, Gt = new Array(zt + 1);
                for (let Vt = 0; Vt <= zt; Vt++)
                  Gt[Vt] = Mt + Vt / zt * ($t - Mt);
                return Gt.join(",");
              };
              return Z(this, $, fe).call(this, Et(0, 5), Et(1, 5), Et(2, 5), kt), lt(this, d, `url(#${nt})`), r(this, d);
            }
            addHighlightHCMFilter(R, U, J, rt) {
              var $t;
              const _t = `${R}-${U}-${J}-${rt}`;
              if (r(this, y) === _t)
                return r(this, B);
              if (lt(this, y, _t), lt(this, B, "none"), ($t = r(this, u)) == null || $t.remove(), !R || !U)
                return r(this, B);
              const [wt, vt] = [R, U].map(Z(this, $, pe).bind(this));
              let nt = Math.round(0.2126 * wt[0] + 0.7152 * wt[1] + 0.0722 * wt[2]), kt = Math.round(0.2126 * vt[0] + 0.7152 * vt[1] + 0.0722 * vt[2]), [Et, Ut] = [J, rt].map(Z(this, $, pe).bind(this));
              kt < nt && ([nt, kt, Et, Ut] = [kt, nt, Ut, Et]), r(this, $, oe).style.color = "";
              const Nt = (Gt, Vt, At) => {
                const ot = new Array(256), ct = (kt - nt) / At, Ft = Gt / 255, Ht = (Vt - Gt) / (255 * At);
                let Wt = 0;
                for (let H = 0; H <= At; H++) {
                  const bt = Math.round(nt + H * ct), Ct = Ft + H * Ht;
                  for (let Dt = Wt; Dt <= bt; Dt++)
                    ot[Dt] = Ct;
                  Wt = bt + 1;
                }
                for (let H = Wt; H < 256; H++)
                  ot[H] = ot[Wt - 1];
                return ot.join(",");
              }, zt = `g_${r(this, D)}_hcm_highlight_filter`, Mt = lt(this, u, Z(this, $, ve).call(this, zt));
              return Z(this, $, Ge).call(this, Mt), Z(this, $, fe).call(this, Nt(Et[0], Ut[0], 5), Nt(Et[1], Ut[1], 5), Nt(Et[2], Ut[2], 5), Mt), lt(this, B, `url(#${zt})`), r(this, B);
            }
            destroy(R = !1) {
              R && (r(this, d) || r(this, B)) || (r(this, et) && (r(this, et).parentNode.parentNode.remove(), lt(this, et, null)), r(this, L) && (r(this, L).clear(), lt(this, L, null)), lt(this, N, 0));
            }
          }
          L = new WeakMap(), et = new WeakMap(), D = new WeakMap(), G = new WeakMap(), Q = new WeakMap(), F = new WeakMap(), d = new WeakMap(), u = new WeakMap(), y = new WeakMap(), B = new WeakMap(), N = new WeakMap(), $ = new WeakSet(), ae = function() {
            return r(this, L) || lt(this, L, /* @__PURE__ */ new Map());
          }, oe = function() {
            if (!r(this, et)) {
              const R = r(this, G).createElement("div"), {
                style: U
              } = R;
              U.visibility = "hidden", U.contain = "strict", U.width = U.height = 0, U.position = "absolute", U.top = U.left = 0, U.zIndex = -1;
              const J = r(this, G).createElementNS(c, "svg");
              J.setAttribute("width", 0), J.setAttribute("height", 0), lt(this, et, r(this, G).createElementNS(c, "defs")), R.append(J), J.append(r(this, et)), r(this, G).body.append(R);
            }
            return r(this, et);
          }, Ge = function(R) {
            const U = r(this, G).createElementNS(c, "feColorMatrix");
            U.setAttribute("type", "matrix"), U.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), R.append(U);
          }, ve = function(R) {
            const U = r(this, G).createElementNS(c, "filter");
            return U.setAttribute("color-interpolation-filters", "sRGB"), U.setAttribute("id", R), r(this, $, oe).append(U), U;
          }, we = function(R, U, J) {
            const rt = r(this, G).createElementNS(c, U);
            rt.setAttribute("type", "discrete"), rt.setAttribute("tableValues", J), R.append(rt);
          }, fe = function(R, U, J, rt) {
            const _t = r(this, G).createElementNS(c, "feComponentTransfer");
            rt.append(_t), Z(this, $, we).call(this, _t, "feFuncR", R), Z(this, $, we).call(this, _t, "feFuncG", U), Z(this, $, we).call(this, _t, "feFuncB", J);
          }, pe = function(R) {
            return r(this, $, oe).style.color = R, m(getComputedStyle(r(this, $, oe)).getPropertyValue("color"));
          }, t.DOMFilterFactory = b;
          class o extends e.BaseCanvasFactory {
            constructor({
              ownerDocument: it = globalThis.document
            } = {}) {
              super(), this._document = it;
            }
            _createCanvas(it, R) {
              const U = this._document.createElement("canvas");
              return U.width = it, U.height = R, U;
            }
          }
          t.DOMCanvasFactory = o;
          async function l(tt, it = !1) {
            if (g(tt, document.baseURI)) {
              const R = await fetch(tt);
              if (!R.ok)
                throw new Error(R.statusText);
              return it ? new Uint8Array(await R.arrayBuffer()) : (0, s.stringToBytes)(await R.text());
            }
            return new Promise((R, U) => {
              const J = new XMLHttpRequest();
              J.open("GET", tt, !0), it && (J.responseType = "arraybuffer"), J.onreadystatechange = () => {
                if (J.readyState === XMLHttpRequest.DONE) {
                  if (J.status === 200 || J.status === 0) {
                    let rt;
                    if (it && J.response ? rt = new Uint8Array(J.response) : !it && J.responseText && (rt = (0, s.stringToBytes)(J.responseText)), rt) {
                      R(rt);
                      return;
                    }
                  }
                  U(new Error(J.statusText));
                }
              }, J.send(null);
            });
          }
          class a extends e.BaseCMapReaderFactory {
            _fetchData(it, R) {
              return l(it, this.isCompressed).then((U) => ({
                cMapData: U,
                compressionType: R
              }));
            }
          }
          t.DOMCMapReaderFactory = a;
          class T extends e.BaseStandardFontDataFactory {
            _fetchData(it) {
              return l(it, !0);
            }
          }
          t.DOMStandardFontDataFactory = T;
          class P extends e.BaseSVGFactory {
            _createSVG(it) {
              return document.createElementNS(c, it);
            }
          }
          t.DOMSVGFactory = P;
          class v {
            constructor({
              viewBox: it,
              scale: R,
              rotation: U,
              offsetX: J = 0,
              offsetY: rt = 0,
              dontFlip: _t = !1
            }) {
              this.viewBox = it, this.scale = R, this.rotation = U, this.offsetX = J, this.offsetY = rt;
              const wt = (it[2] + it[0]) / 2, vt = (it[3] + it[1]) / 2;
              let nt, kt, Et, Ut;
              switch (U %= 360, U < 0 && (U += 360), U) {
                case 180:
                  nt = -1, kt = 0, Et = 0, Ut = 1;
                  break;
                case 90:
                  nt = 0, kt = 1, Et = 1, Ut = 0;
                  break;
                case 270:
                  nt = 0, kt = -1, Et = -1, Ut = 0;
                  break;
                case 0:
                  nt = 1, kt = 0, Et = 0, Ut = -1;
                  break;
                default:
                  throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
              }
              _t && (Et = -Et, Ut = -Ut);
              let Nt, zt, Mt, $t;
              nt === 0 ? (Nt = Math.abs(vt - it[1]) * R + J, zt = Math.abs(wt - it[0]) * R + rt, Mt = (it[3] - it[1]) * R, $t = (it[2] - it[0]) * R) : (Nt = Math.abs(wt - it[0]) * R + J, zt = Math.abs(vt - it[1]) * R + rt, Mt = (it[2] - it[0]) * R, $t = (it[3] - it[1]) * R), this.transform = [nt * R, kt * R, Et * R, Ut * R, Nt - nt * R * wt - Et * R * vt, zt - kt * R * wt - Ut * R * vt], this.width = Mt, this.height = $t;
            }
            get rawDims() {
              const {
                viewBox: it
              } = this;
              return (0, s.shadow)(this, "rawDims", {
                pageWidth: it[2] - it[0],
                pageHeight: it[3] - it[1],
                pageX: it[0],
                pageY: it[1]
              });
            }
            clone({
              scale: it = this.scale,
              rotation: R = this.rotation,
              offsetX: U = this.offsetX,
              offsetY: J = this.offsetY,
              dontFlip: rt = !1
            } = {}) {
              return new v({
                viewBox: this.viewBox.slice(),
                scale: it,
                rotation: R,
                offsetX: U,
                offsetY: J,
                dontFlip: rt
              });
            }
            convertToViewportPoint(it, R) {
              return s.Util.applyTransform([it, R], this.transform);
            }
            convertToViewportRectangle(it) {
              const R = s.Util.applyTransform([it[0], it[1]], this.transform), U = s.Util.applyTransform([it[2], it[3]], this.transform);
              return [R[0], R[1], U[0], U[1]];
            }
            convertToPdfPoint(it, R) {
              return s.Util.applyInverseTransform([it, R], this.transform);
            }
          }
          t.PageViewport = v;
          class k extends s.BaseException {
            constructor(it, R = 0) {
              super(it, "RenderingCancelledException"), this.extraDelay = R;
            }
          }
          t.RenderingCancelledException = k;
          function x(tt) {
            const it = tt.length;
            let R = 0;
            for (; R < it && tt[R].trim() === ""; )
              R++;
            return tt.substring(R, R + 5).toLowerCase() === "data:";
          }
          function S(tt) {
            return typeof tt == "string" && /\.pdf$/i.test(tt);
          }
          function E(tt, it = !1) {
            return it || ([tt] = tt.split(/[#?]/, 1)), tt.substring(tt.lastIndexOf("/") + 1);
          }
          function w(tt, it = "document.pdf") {
            if (typeof tt != "string")
              return it;
            if (x(tt))
              return (0, s.warn)('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), it;
            const R = /^(?:(?:[^:]+:)?\/\/[^/]+)?([^?#]*)(\?[^#]*)?(#.*)?$/, U = /[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i, J = R.exec(tt);
            let rt = U.exec(J[1]) || U.exec(J[2]) || U.exec(J[3]);
            if (rt && (rt = rt[0], rt.includes("%")))
              try {
                rt = U.exec(decodeURIComponent(rt))[0];
              } catch {
              }
            return rt || it;
          }
          class M {
            constructor() {
              Kt(this, "started", /* @__PURE__ */ Object.create(null));
              Kt(this, "times", []);
            }
            time(it) {
              it in this.started && (0, s.warn)(`Timer is already running for ${it}`), this.started[it] = Date.now();
            }
            timeEnd(it) {
              it in this.started || (0, s.warn)(`Timer has not been started for ${it}`), this.times.push({
                name: it,
                start: this.started[it],
                end: Date.now()
              }), delete this.started[it];
            }
            toString() {
              const it = [];
              let R = 0;
              for (const {
                name: U
              } of this.times)
                R = Math.max(U.length, R);
              for (const {
                name: U,
                start: J,
                end: rt
              } of this.times)
                it.push(`${U.padEnd(R)} ${rt - J}ms
`);
              return it.join("");
            }
          }
          t.StatTimer = M;
          function g(tt, it) {
            try {
              const {
                protocol: R
              } = it ? new URL(tt, it) : new URL(tt);
              return R === "http:" || R === "https:";
            } catch {
              return !1;
            }
          }
          function p(tt) {
            tt.preventDefault();
          }
          function _(tt, it = !1) {
            return new Promise((R, U) => {
              const J = document.createElement("script");
              J.src = tt, J.onload = function(rt) {
                it && J.remove(), R(rt);
              }, J.onerror = function() {
                U(new Error(`Cannot load script at: ${J.src}`));
              }, (document.head || document.documentElement).append(J);
            });
          }
          function f(tt) {
            console.log("Deprecated API usage: " + tt);
          }
          let A;
          class C {
            static toDateObject(it) {
              if (!it || typeof it != "string")
                return null;
              A || (A = new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?"));
              const R = A.exec(it);
              if (!R)
                return null;
              const U = parseInt(R[1], 10);
              let J = parseInt(R[2], 10);
              J = J >= 1 && J <= 12 ? J - 1 : 0;
              let rt = parseInt(R[3], 10);
              rt = rt >= 1 && rt <= 31 ? rt : 1;
              let _t = parseInt(R[4], 10);
              _t = _t >= 0 && _t <= 23 ? _t : 0;
              let wt = parseInt(R[5], 10);
              wt = wt >= 0 && wt <= 59 ? wt : 0;
              let vt = parseInt(R[6], 10);
              vt = vt >= 0 && vt <= 59 ? vt : 0;
              const nt = R[7] || "Z";
              let kt = parseInt(R[8], 10);
              kt = kt >= 0 && kt <= 23 ? kt : 0;
              let Et = parseInt(R[9], 10) || 0;
              return Et = Et >= 0 && Et <= 59 ? Et : 0, nt === "-" ? (_t += kt, wt += Et) : nt === "+" && (_t -= kt, wt -= Et), new Date(Date.UTC(U, J, rt, _t, wt, vt));
            }
          }
          t.PDFDateString = C;
          function W(tt, {
            scale: it = 1,
            rotation: R = 0
          }) {
            const {
              width: U,
              height: J
            } = tt.attributes.style, rt = [0, 0, parseInt(U), parseInt(J)];
            return new v({
              viewBox: rt,
              scale: it,
              rotation: R
            });
          }
          function m(tt) {
            if (tt.startsWith("#")) {
              const it = parseInt(tt.slice(1), 16);
              return [(it & 16711680) >> 16, (it & 65280) >> 8, it & 255];
            }
            return tt.startsWith("rgb(") ? tt.slice(4, -1).split(",").map((it) => parseInt(it)) : tt.startsWith("rgba(") ? tt.slice(5, -1).split(",").map((it) => parseInt(it)).slice(0, 3) : ((0, s.warn)(`Not a valid color format: "${tt}"`), [0, 0, 0]);
          }
          function I(tt) {
            const it = document.createElement("span");
            it.style.visibility = "hidden", document.body.append(it);
            for (const R of tt.keys()) {
              it.style.color = R;
              const U = window.getComputedStyle(it).color;
              tt.set(R, m(U));
            }
            it.remove();
          }
          function q(tt) {
            const {
              a: it,
              b: R,
              c: U,
              d: J,
              e: rt,
              f: _t
            } = tt.getTransform();
            return [it, R, U, J, rt, _t];
          }
          function Y(tt) {
            const {
              a: it,
              b: R,
              c: U,
              d: J,
              e: rt,
              f: _t
            } = tt.getTransform().invertSelf();
            return [it, R, U, J, rt, _t];
          }
          function X(tt, it, R = !1, U = !0) {
            if (it instanceof v) {
              const {
                pageWidth: J,
                pageHeight: rt
              } = it.rawDims, {
                style: _t
              } = tt, wt = s.FeatureTest.isCSSRoundSupported, vt = `var(--scale-factor) * ${J}px`, nt = `var(--scale-factor) * ${rt}px`, kt = wt ? `round(${vt}, 1px)` : `calc(${vt})`, Et = wt ? `round(${nt}, 1px)` : `calc(${nt})`;
              !R || it.rotation % 180 === 0 ? (_t.width = kt, _t.height = Et) : (_t.width = Et, _t.height = kt);
            }
            U && tt.setAttribute("data-main-rotation", it.rotation);
          }
        },
        /* 7 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.BaseStandardFontDataFactory = t.BaseSVGFactory = t.BaseFilterFactory = t.BaseCanvasFactory = t.BaseCMapReaderFactory = void 0;
          var e = n(1);
          class s {
            constructor() {
              this.constructor === s && (0, e.unreachable)("Cannot initialize BaseFilterFactory.");
            }
            addFilter(a) {
              return "none";
            }
            addHCMFilter(a, T) {
              return "none";
            }
            addHighlightHCMFilter(a, T, P, v) {
              return "none";
            }
            destroy(a = !1) {
            }
          }
          t.BaseFilterFactory = s;
          class c {
            constructor() {
              this.constructor === c && (0, e.unreachable)("Cannot initialize BaseCanvasFactory.");
            }
            create(a, T) {
              if (a <= 0 || T <= 0)
                throw new Error("Invalid canvas size");
              const P = this._createCanvas(a, T);
              return {
                canvas: P,
                context: P.getContext("2d")
              };
            }
            reset(a, T, P) {
              if (!a.canvas)
                throw new Error("Canvas is not specified");
              if (T <= 0 || P <= 0)
                throw new Error("Invalid canvas size");
              a.canvas.width = T, a.canvas.height = P;
            }
            destroy(a) {
              if (!a.canvas)
                throw new Error("Canvas is not specified");
              a.canvas.width = 0, a.canvas.height = 0, a.canvas = null, a.context = null;
            }
            _createCanvas(a, T) {
              (0, e.unreachable)("Abstract method `_createCanvas` called.");
            }
          }
          t.BaseCanvasFactory = c;
          class h {
            constructor({
              baseUrl: a = null,
              isCompressed: T = !0
            }) {
              this.constructor === h && (0, e.unreachable)("Cannot initialize BaseCMapReaderFactory."), this.baseUrl = a, this.isCompressed = T;
            }
            async fetch({
              name: a
            }) {
              if (!this.baseUrl)
                throw new Error('The CMap "baseUrl" parameter must be specified, ensure that the "cMapUrl" and "cMapPacked" API parameters are provided.');
              if (!a)
                throw new Error("CMap name must be specified.");
              const T = this.baseUrl + a + (this.isCompressed ? ".bcmap" : ""), P = this.isCompressed ? e.CMapCompressionType.BINARY : e.CMapCompressionType.NONE;
              return this._fetchData(T, P).catch((v) => {
                throw new Error(`Unable to load ${this.isCompressed ? "binary " : ""}CMap at: ${T}`);
              });
            }
            _fetchData(a, T) {
              (0, e.unreachable)("Abstract method `_fetchData` called.");
            }
          }
          t.BaseCMapReaderFactory = h;
          class b {
            constructor({
              baseUrl: a = null
            }) {
              this.constructor === b && (0, e.unreachable)("Cannot initialize BaseStandardFontDataFactory."), this.baseUrl = a;
            }
            async fetch({
              filename: a
            }) {
              if (!this.baseUrl)
                throw new Error('The standard font "baseUrl" parameter must be specified, ensure that the "standardFontDataUrl" API parameter is provided.');
              if (!a)
                throw new Error("Font filename must be specified.");
              const T = `${this.baseUrl}${a}`;
              return this._fetchData(T).catch((P) => {
                throw new Error(`Unable to load font data at: ${T}`);
              });
            }
            _fetchData(a) {
              (0, e.unreachable)("Abstract method `_fetchData` called.");
            }
          }
          t.BaseStandardFontDataFactory = b;
          class o {
            constructor() {
              this.constructor === o && (0, e.unreachable)("Cannot initialize BaseSVGFactory.");
            }
            create(a, T, P = !1) {
              if (a <= 0 || T <= 0)
                throw new Error("Invalid SVG dimensions");
              const v = this._createSVG("svg:svg");
              return v.setAttribute("version", "1.1"), P || (v.setAttribute("width", `${a}px`), v.setAttribute("height", `${T}px`)), v.setAttribute("preserveAspectRatio", "none"), v.setAttribute("viewBox", `0 0 ${a} ${T}`), v;
            }
            createElement(a) {
              if (typeof a != "string")
                throw new Error("Invalid SVG element type");
              return this._createSVG(a);
            }
            _createSVG(a) {
              (0, e.unreachable)("Abstract method `_createSVG` called.");
            }
          }
          t.BaseSVGFactory = o;
        },
        /* 8 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.MurmurHash3_64 = void 0;
          var e = n(1);
          const s = 3285377520, c = 4294901760, h = 65535;
          class b {
            constructor(l) {
              this.h1 = l ? l & 4294967295 : s, this.h2 = l ? l & 4294967295 : s;
            }
            update(l) {
              let a, T;
              if (typeof l == "string") {
                a = new Uint8Array(l.length * 2), T = 0;
                for (let f = 0, A = l.length; f < A; f++) {
                  const C = l.charCodeAt(f);
                  C <= 255 ? a[T++] = C : (a[T++] = C >>> 8, a[T++] = C & 255);
                }
              } else if ((0, e.isArrayBuffer)(l))
                a = l.slice(), T = a.byteLength;
              else
                throw new Error("Wrong data format in MurmurHash3_64_update. Input must be a string or array.");
              const P = T >> 2, v = T - P * 4, k = new Uint32Array(a.buffer, 0, P);
              let x = 0, S = 0, E = this.h1, w = this.h2;
              const M = 3432918353, g = 461845907, p = M & h, _ = g & h;
              for (let f = 0; f < P; f++)
                f & 1 ? (x = k[f], x = x * M & c | x * p & h, x = x << 15 | x >>> 17, x = x * g & c | x * _ & h, E ^= x, E = E << 13 | E >>> 19, E = E * 5 + 3864292196) : (S = k[f], S = S * M & c | S * p & h, S = S << 15 | S >>> 17, S = S * g & c | S * _ & h, w ^= S, w = w << 13 | w >>> 19, w = w * 5 + 3864292196);
              switch (x = 0, v) {
                case 3:
                  x ^= a[P * 4 + 2] << 16;
                case 2:
                  x ^= a[P * 4 + 1] << 8;
                case 1:
                  x ^= a[P * 4], x = x * M & c | x * p & h, x = x << 15 | x >>> 17, x = x * g & c | x * _ & h, P & 1 ? E ^= x : w ^= x;
              }
              this.h1 = E, this.h2 = w;
            }
            hexdigest() {
              let l = this.h1, a = this.h2;
              return l ^= a >>> 1, l = l * 3981806797 & c | l * 36045 & h, a = a * 4283543511 & c | ((a << 16 | l >>> 16) * 2950163797 & c) >>> 16, l ^= a >>> 1, l = l * 444984403 & c | l * 60499 & h, a = a * 3301882366 & c | ((a << 16 | l >>> 16) * 3120437893 & c) >>> 16, l ^= a >>> 1, (l >>> 0).toString(16).padStart(8, "0") + (a >>> 0).toString(16).padStart(8, "0");
            }
          }
          t.MurmurHash3_64 = b;
        },
        /* 9 */
        /***/
        (i, t, n) => {
          var h;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.FontLoader = t.FontFaceObject = void 0;
          var e = n(1);
          class s {
            constructor({
              ownerDocument: o = globalThis.document,
              styleElement: l = null
            }) {
              at(this, h, /* @__PURE__ */ new Set());
              this._document = o, this.nativeFontFaces = /* @__PURE__ */ new Set(), this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
            }
            addNativeFontFace(o) {
              this.nativeFontFaces.add(o), this._document.fonts.add(o);
            }
            removeNativeFontFace(o) {
              this.nativeFontFaces.delete(o), this._document.fonts.delete(o);
            }
            insertRule(o) {
              this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));
              const l = this.styleElement.sheet;
              l.insertRule(o, l.cssRules.length);
            }
            clear() {
              for (const o of this.nativeFontFaces)
                this._document.fonts.delete(o);
              this.nativeFontFaces.clear(), r(this, h).clear(), this.styleElement && (this.styleElement.remove(), this.styleElement = null);
            }
            async loadSystemFont(o) {
              if (!(!o || r(this, h).has(o.loadedName))) {
                if ((0, e.assert)(!this.disableFontFace, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
                  const {
                    loadedName: l,
                    src: a,
                    style: T
                  } = o, P = new FontFace(l, a, T);
                  this.addNativeFontFace(P);
                  try {
                    await P.load(), r(this, h).add(l);
                  } catch {
                    (0, e.warn)(`Cannot load system font: ${o.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(P);
                  }
                  return;
                }
                (0, e.unreachable)("Not implemented: loadSystemFont without the Font Loading API.");
              }
            }
            async bind(o) {
              if (o.attached || o.missingFile && !o.systemFontInfo)
                return;
              if (o.attached = !0, o.systemFontInfo) {
                await this.loadSystemFont(o.systemFontInfo);
                return;
              }
              if (this.isFontLoadingAPISupported) {
                const a = o.createNativeFontFace();
                if (a) {
                  this.addNativeFontFace(a);
                  try {
                    await a.loaded;
                  } catch (T) {
                    throw (0, e.warn)(`Failed to load font '${a.family}': '${T}'.`), o.disableFontFace = !0, T;
                  }
                }
                return;
              }
              const l = o.createFontFaceRule();
              if (l) {
                if (this.insertRule(l), this.isSyncFontLoadingSupported)
                  return;
                await new Promise((a) => {
                  const T = this._queueLoadingCallback(a);
                  this._prepareFontLoadEvent(o, T);
                });
              }
            }
            get isFontLoadingAPISupported() {
              var l;
              const o = !!((l = this._document) != null && l.fonts);
              return (0, e.shadow)(this, "isFontLoadingAPISupported", o);
            }
            get isSyncFontLoadingSupported() {
              let o = !1;
              return (e.isNodeJS || typeof navigator < "u" && /Mozilla\/5.0.*?rv:\d+.*? Gecko/.test(navigator.userAgent)) && (o = !0), (0, e.shadow)(this, "isSyncFontLoadingSupported", o);
            }
            _queueLoadingCallback(o) {
              function l() {
                for ((0, e.assert)(!T.done, "completeRequest() cannot be called twice."), T.done = !0; a.length > 0 && a[0].done; ) {
                  const P = a.shift();
                  setTimeout(P.callback, 0);
                }
              }
              const {
                loadingRequests: a
              } = this, T = {
                done: !1,
                complete: l,
                callback: o
              };
              return a.push(T), T;
            }
            get _loadTestFont() {
              const o = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
              return (0, e.shadow)(this, "_loadTestFont", o);
            }
            _prepareFontLoadEvent(o, l) {
              function a(m, I) {
                return m.charCodeAt(I) << 24 | m.charCodeAt(I + 1) << 16 | m.charCodeAt(I + 2) << 8 | m.charCodeAt(I + 3) & 255;
              }
              function T(m, I, q, Y) {
                const X = m.substring(0, I), z = m.substring(I + q);
                return X + Y + z;
              }
              let P, v;
              const k = this._document.createElement("canvas");
              k.width = 1, k.height = 1;
              const x = k.getContext("2d");
              let S = 0;
              function E(m, I) {
                if (++S > 30) {
                  (0, e.warn)("Load test font never loaded."), I();
                  return;
                }
                if (x.font = "30px " + m, x.fillText(".", 0, 20), x.getImageData(0, 0, 1, 1).data[3] > 0) {
                  I();
                  return;
                }
                setTimeout(E.bind(null, m, I));
              }
              const w = `lt${Date.now()}${this.loadTestFontId++}`;
              let M = this._loadTestFont;
              M = T(M, 976, w.length, w);
              const p = 16, _ = 1482184792;
              let f = a(M, p);
              for (P = 0, v = w.length - 3; P < v; P += 4)
                f = f - _ + a(w, P) | 0;
              P < w.length && (f = f - _ + a(w + "XXX", P) | 0), M = T(M, p, 4, (0, e.string32)(f));
              const A = `url(data:font/opentype;base64,${btoa(M)});`, C = `@font-face {font-family:"${w}";src:${A}}`;
              this.insertRule(C);
              const W = this._document.createElement("div");
              W.style.visibility = "hidden", W.style.width = W.style.height = "10px", W.style.position = "absolute", W.style.top = W.style.left = "0px";
              for (const m of [o.loadedName, w]) {
                const I = this._document.createElement("span");
                I.textContent = "Hi", I.style.fontFamily = m, W.append(I);
              }
              this._document.body.append(W), E(w, () => {
                W.remove(), l.complete();
              });
            }
          }
          h = new WeakMap(), t.FontLoader = s;
          class c {
            constructor(o, {
              isEvalSupported: l = !0,
              disableFontFace: a = !1,
              ignoreErrors: T = !1,
              inspectFont: P = null
            }) {
              this.compiledGlyphs = /* @__PURE__ */ Object.create(null);
              for (const v in o)
                this[v] = o[v];
              this.isEvalSupported = l !== !1, this.disableFontFace = a === !0, this.ignoreErrors = T === !0, this._inspectFont = P;
            }
            createNativeFontFace() {
              var l;
              if (!this.data || this.disableFontFace)
                return null;
              let o;
              if (!this.cssFontInfo)
                o = new FontFace(this.loadedName, this.data, {});
              else {
                const a = {
                  weight: this.cssFontInfo.fontWeight
                };
                this.cssFontInfo.italicAngle && (a.style = `oblique ${this.cssFontInfo.italicAngle}deg`), o = new FontFace(this.cssFontInfo.fontFamily, this.data, a);
              }
              return (l = this._inspectFont) == null || l.call(this, this), o;
            }
            createFontFaceRule() {
              var T;
              if (!this.data || this.disableFontFace)
                return null;
              const o = (0, e.bytesToString)(this.data), l = `url(data:${this.mimetype};base64,${btoa(o)});`;
              let a;
              if (!this.cssFontInfo)
                a = `@font-face {font-family:"${this.loadedName}";src:${l}}`;
              else {
                let P = `font-weight: ${this.cssFontInfo.fontWeight};`;
                this.cssFontInfo.italicAngle && (P += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), a = `@font-face {font-family:"${this.cssFontInfo.fontFamily}";${P}src:${l}}`;
              }
              return (T = this._inspectFont) == null || T.call(this, this, l), a;
            }
            getPathGenerator(o, l) {
              if (this.compiledGlyphs[l] !== void 0)
                return this.compiledGlyphs[l];
              let a;
              try {
                a = o.get(this.loadedName + "_path_" + l);
              } catch (T) {
                if (!this.ignoreErrors)
                  throw T;
                return (0, e.warn)(`getPathGenerator - ignoring character: "${T}".`), this.compiledGlyphs[l] = function(P, v) {
                };
              }
              if (this.isEvalSupported && e.FeatureTest.isEvalSupported) {
                const T = [];
                for (const P of a) {
                  const v = P.args !== void 0 ? P.args.join(",") : "";
                  T.push("c.", P.cmd, "(", v, `);
`);
                }
                return this.compiledGlyphs[l] = new Function("c", "size", T.join(""));
              }
              return this.compiledGlyphs[l] = function(T, P) {
                for (const v of a)
                  v.cmd === "scale" && (v.args = [P, -P]), T[v.cmd].apply(T, v.args);
              };
            }
          }
          t.FontFaceObject = c;
        },
        /* 10 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.NodeStandardFontDataFactory = t.NodeFilterFactory = t.NodeCanvasFactory = t.NodeCMapReaderFactory = void 0;
          var e = n(7);
          n(1);
          const s = function(l) {
            return new Promise((a, T) => {
              require$$5.readFile(l, (v, k) => {
                if (v || !k) {
                  T(new Error(v));
                  return;
                }
                a(new Uint8Array(k));
              });
            });
          };
          class c extends e.BaseFilterFactory {
          }
          t.NodeFilterFactory = c;
          class h extends e.BaseCanvasFactory {
            _createCanvas(a, T) {
              return require$$5.createCanvas(a, T);
            }
          }
          t.NodeCanvasFactory = h;
          class b extends e.BaseCMapReaderFactory {
            _fetchData(a, T) {
              return s(a).then((P) => ({
                cMapData: P,
                compressionType: T
              }));
            }
          }
          t.NodeCMapReaderFactory = b;
          class o extends e.BaseStandardFontDataFactory {
            _fetchData(a) {
              return s(a);
            }
          }
          t.NodeStandardFontDataFactory = o;
        },
        /* 11 */
        /***/
        (i, t, n) => {
          var et, Xe, Ve;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.CanvasGraphics = void 0;
          var e = n(1), s = n(6), c = n(12), h = n(13);
          const b = 16, o = 100, l = 4096, a = 15, T = 10, P = 1e3, v = 16;
          function k(F, d) {
            if (F._removeMirroring)
              throw new Error("Context is already forwarding operations.");
            F.__originalSave = F.save, F.__originalRestore = F.restore, F.__originalRotate = F.rotate, F.__originalScale = F.scale, F.__originalTranslate = F.translate, F.__originalTransform = F.transform, F.__originalSetTransform = F.setTransform, F.__originalResetTransform = F.resetTransform, F.__originalClip = F.clip, F.__originalMoveTo = F.moveTo, F.__originalLineTo = F.lineTo, F.__originalBezierCurveTo = F.bezierCurveTo, F.__originalRect = F.rect, F.__originalClosePath = F.closePath, F.__originalBeginPath = F.beginPath, F._removeMirroring = () => {
              F.save = F.__originalSave, F.restore = F.__originalRestore, F.rotate = F.__originalRotate, F.scale = F.__originalScale, F.translate = F.__originalTranslate, F.transform = F.__originalTransform, F.setTransform = F.__originalSetTransform, F.resetTransform = F.__originalResetTransform, F.clip = F.__originalClip, F.moveTo = F.__originalMoveTo, F.lineTo = F.__originalLineTo, F.bezierCurveTo = F.__originalBezierCurveTo, F.rect = F.__originalRect, F.closePath = F.__originalClosePath, F.beginPath = F.__originalBeginPath, delete F._removeMirroring;
            }, F.save = function() {
              d.save(), this.__originalSave();
            }, F.restore = function() {
              d.restore(), this.__originalRestore();
            }, F.translate = function(y, B) {
              d.translate(y, B), this.__originalTranslate(y, B);
            }, F.scale = function(y, B) {
              d.scale(y, B), this.__originalScale(y, B);
            }, F.transform = function(y, B, N, $, K, st) {
              d.transform(y, B, N, $, K, st), this.__originalTransform(y, B, N, $, K, st);
            }, F.setTransform = function(y, B, N, $, K, st) {
              d.setTransform(y, B, N, $, K, st), this.__originalSetTransform(y, B, N, $, K, st);
            }, F.resetTransform = function() {
              d.resetTransform(), this.__originalResetTransform();
            }, F.rotate = function(y) {
              d.rotate(y), this.__originalRotate(y);
            }, F.clip = function(y) {
              d.clip(y), this.__originalClip(y);
            }, F.moveTo = function(u, y) {
              d.moveTo(u, y), this.__originalMoveTo(u, y);
            }, F.lineTo = function(u, y) {
              d.lineTo(u, y), this.__originalLineTo(u, y);
            }, F.bezierCurveTo = function(u, y, B, N, $, K) {
              d.bezierCurveTo(u, y, B, N, $, K), this.__originalBezierCurveTo(u, y, B, N, $, K);
            }, F.rect = function(u, y, B, N) {
              d.rect(u, y, B, N), this.__originalRect(u, y, B, N);
            }, F.closePath = function() {
              d.closePath(), this.__originalClosePath();
            }, F.beginPath = function() {
              d.beginPath(), this.__originalBeginPath();
            };
          }
          class x {
            constructor(d) {
              this.canvasFactory = d, this.cache = /* @__PURE__ */ Object.create(null);
            }
            getCanvas(d, u, y) {
              let B;
              return this.cache[d] !== void 0 ? (B = this.cache[d], this.canvasFactory.reset(B, u, y)) : (B = this.canvasFactory.create(u, y), this.cache[d] = B), B;
            }
            delete(d) {
              delete this.cache[d];
            }
            clear() {
              for (const d in this.cache) {
                const u = this.cache[d];
                this.canvasFactory.destroy(u), delete this.cache[d];
              }
            }
          }
          function S(F, d, u, y, B, N, $, K, st, dt) {
            const [pt, gt, mt, ut, tt, it] = (0, s.getCurrentTransform)(F);
            if (gt === 0 && mt === 0) {
              const J = $ * pt + tt, rt = Math.round(J), _t = K * ut + it, wt = Math.round(_t), vt = ($ + st) * pt + tt, nt = Math.abs(Math.round(vt) - rt) || 1, kt = (K + dt) * ut + it, Et = Math.abs(Math.round(kt) - wt) || 1;
              return F.setTransform(Math.sign(pt), 0, 0, Math.sign(ut), rt, wt), F.drawImage(d, u, y, B, N, 0, 0, nt, Et), F.setTransform(pt, gt, mt, ut, tt, it), [nt, Et];
            }
            if (pt === 0 && ut === 0) {
              const J = K * mt + tt, rt = Math.round(J), _t = $ * gt + it, wt = Math.round(_t), vt = (K + dt) * mt + tt, nt = Math.abs(Math.round(vt) - rt) || 1, kt = ($ + st) * gt + it, Et = Math.abs(Math.round(kt) - wt) || 1;
              return F.setTransform(0, Math.sign(gt), Math.sign(mt), 0, rt, wt), F.drawImage(d, u, y, B, N, 0, 0, Et, nt), F.setTransform(pt, gt, mt, ut, tt, it), [Et, nt];
            }
            F.drawImage(d, u, y, B, N, $, K, st, dt);
            const R = Math.hypot(pt, gt), U = Math.hypot(mt, ut);
            return [R * st, U * dt];
          }
          function E(F) {
            const {
              width: d,
              height: u
            } = F;
            if (d > P || u > P)
              return null;
            const y = 1e3, B = new Uint8Array([0, 2, 4, 0, 1, 0, 5, 4, 8, 10, 0, 8, 0, 2, 1, 0]), N = d + 1;
            let $ = new Uint8Array(N * (u + 1)), K, st, dt;
            const pt = d + 7 & -8;
            let gt = new Uint8Array(pt * u), mt = 0;
            for (const U of F.data) {
              let J = 128;
              for (; J > 0; )
                gt[mt++] = U & J ? 0 : 255, J >>= 1;
            }
            let ut = 0;
            for (mt = 0, gt[mt] !== 0 && ($[0] = 1, ++ut), st = 1; st < d; st++)
              gt[mt] !== gt[mt + 1] && ($[st] = gt[mt] ? 2 : 1, ++ut), mt++;
            for (gt[mt] !== 0 && ($[st] = 2, ++ut), K = 1; K < u; K++) {
              mt = K * pt, dt = K * N, gt[mt - pt] !== gt[mt] && ($[dt] = gt[mt] ? 1 : 8, ++ut);
              let U = (gt[mt] ? 4 : 0) + (gt[mt - pt] ? 8 : 0);
              for (st = 1; st < d; st++)
                U = (U >> 2) + (gt[mt + 1] ? 4 : 0) + (gt[mt - pt + 1] ? 8 : 0), B[U] && ($[dt + st] = B[U], ++ut), mt++;
              if (gt[mt - pt] !== gt[mt] && ($[dt + st] = gt[mt] ? 2 : 4, ++ut), ut > y)
                return null;
            }
            for (mt = pt * (u - 1), dt = K * N, gt[mt] !== 0 && ($[dt] = 8, ++ut), st = 1; st < d; st++)
              gt[mt] !== gt[mt + 1] && ($[dt + st] = gt[mt] ? 4 : 8, ++ut), mt++;
            if (gt[mt] !== 0 && ($[dt + st] = 4, ++ut), ut > y)
              return null;
            const tt = new Int32Array([0, N, -1, 0, -N, 0, 0, 0, 1]), it = new Path2D();
            for (K = 0; ut && K <= u; K++) {
              let U = K * N;
              const J = U + d;
              for (; U < J && !$[U]; )
                U++;
              if (U === J)
                continue;
              it.moveTo(U % N, K);
              const rt = U;
              let _t = $[U];
              do {
                const wt = tt[_t];
                do
                  U += wt;
                while (!$[U]);
                const vt = $[U];
                vt !== 5 && vt !== 10 ? (_t = vt, $[U] = 0) : (_t = vt & 51 * _t >> 4, $[U] &= _t >> 2 | _t << 2), it.lineTo(U % N, U / N | 0), $[U] || --ut;
              } while (rt !== U);
              --K;
            }
            return gt = null, $ = null, function(U) {
              U.save(), U.scale(1 / d, -1 / u), U.translate(0, -u), U.fill(it), U.beginPath(), U.restore();
            };
          }
          class w {
            constructor(d, u) {
              this.alphaIsShape = !1, this.fontSize = 0, this.fontSizeScale = 1, this.textMatrix = e.IDENTITY_MATRIX, this.textMatrixScale = 1, this.fontMatrix = e.FONT_IDENTITY_MATRIX, this.leading = 0, this.x = 0, this.y = 0, this.lineX = 0, this.lineY = 0, this.charSpacing = 0, this.wordSpacing = 0, this.textHScale = 1, this.textRenderingMode = e.TextRenderingMode.FILL, this.textRise = 0, this.fillColor = "#000000", this.strokeColor = "#000000", this.patternFill = !1, this.fillAlpha = 1, this.strokeAlpha = 1, this.lineWidth = 1, this.activeSMask = null, this.transferMaps = "none", this.startNewPathAndClipBox([0, 0, d, u]);
            }
            clone() {
              const d = Object.create(this);
              return d.clipBox = this.clipBox.slice(), d;
            }
            setCurrentPoint(d, u) {
              this.x = d, this.y = u;
            }
            updatePathMinMax(d, u, y) {
              [u, y] = e.Util.applyTransform([u, y], d), this.minX = Math.min(this.minX, u), this.minY = Math.min(this.minY, y), this.maxX = Math.max(this.maxX, u), this.maxY = Math.max(this.maxY, y);
            }
            updateRectMinMax(d, u) {
              const y = e.Util.applyTransform(u, d), B = e.Util.applyTransform(u.slice(2), d);
              this.minX = Math.min(this.minX, y[0], B[0]), this.minY = Math.min(this.minY, y[1], B[1]), this.maxX = Math.max(this.maxX, y[0], B[0]), this.maxY = Math.max(this.maxY, y[1], B[1]);
            }
            updateScalingPathMinMax(d, u) {
              e.Util.scaleMinMax(d, u), this.minX = Math.min(this.minX, u[0]), this.maxX = Math.max(this.maxX, u[1]), this.minY = Math.min(this.minY, u[2]), this.maxY = Math.max(this.maxY, u[3]);
            }
            updateCurvePathMinMax(d, u, y, B, N, $, K, st, dt, pt) {
              const gt = e.Util.bezierBoundingBox(u, y, B, N, $, K, st, dt);
              if (pt) {
                pt[0] = Math.min(pt[0], gt[0], gt[2]), pt[1] = Math.max(pt[1], gt[0], gt[2]), pt[2] = Math.min(pt[2], gt[1], gt[3]), pt[3] = Math.max(pt[3], gt[1], gt[3]);
                return;
              }
              this.updateRectMinMax(d, gt);
            }
            getPathBoundingBox(d = c.PathType.FILL, u = null) {
              const y = [this.minX, this.minY, this.maxX, this.maxY];
              if (d === c.PathType.STROKE) {
                u || (0, e.unreachable)("Stroke bounding box must include transform.");
                const B = e.Util.singularValueDecompose2dScale(u), N = B[0] * this.lineWidth / 2, $ = B[1] * this.lineWidth / 2;
                y[0] -= N, y[1] -= $, y[2] += N, y[3] += $;
              }
              return y;
            }
            updateClipFromPath() {
              const d = e.Util.intersect(this.clipBox, this.getPathBoundingBox());
              this.startNewPathAndClipBox(d || [0, 0, 0, 0]);
            }
            isEmptyClip() {
              return this.minX === 1 / 0;
            }
            startNewPathAndClipBox(d) {
              this.clipBox = d, this.minX = 1 / 0, this.minY = 1 / 0, this.maxX = 0, this.maxY = 0;
            }
            getClippedPathBoundingBox(d = c.PathType.FILL, u = null) {
              return e.Util.intersect(this.clipBox, this.getPathBoundingBox(d, u));
            }
          }
          function M(F, d) {
            if (typeof ImageData < "u" && d instanceof ImageData) {
              F.putImageData(d, 0, 0);
              return;
            }
            const u = d.height, y = d.width, B = u % v, N = (u - B) / v, $ = B === 0 ? N : N + 1, K = F.createImageData(y, v);
            let st = 0, dt;
            const pt = d.data, gt = K.data;
            let mt, ut, tt, it;
            if (d.kind === e.ImageKind.GRAYSCALE_1BPP) {
              const R = pt.byteLength, U = new Uint32Array(gt.buffer, 0, gt.byteLength >> 2), J = U.length, rt = y + 7 >> 3, _t = 4294967295, wt = e.FeatureTest.isLittleEndian ? 4278190080 : 255;
              for (mt = 0; mt < $; mt++) {
                for (tt = mt < N ? v : B, dt = 0, ut = 0; ut < tt; ut++) {
                  const vt = R - st;
                  let nt = 0;
                  const kt = vt > rt ? y : vt * 8 - 7, Et = kt & -8;
                  let Ut = 0, Nt = 0;
                  for (; nt < Et; nt += 8)
                    Nt = pt[st++], U[dt++] = Nt & 128 ? _t : wt, U[dt++] = Nt & 64 ? _t : wt, U[dt++] = Nt & 32 ? _t : wt, U[dt++] = Nt & 16 ? _t : wt, U[dt++] = Nt & 8 ? _t : wt, U[dt++] = Nt & 4 ? _t : wt, U[dt++] = Nt & 2 ? _t : wt, U[dt++] = Nt & 1 ? _t : wt;
                  for (; nt < kt; nt++)
                    Ut === 0 && (Nt = pt[st++], Ut = 128), U[dt++] = Nt & Ut ? _t : wt, Ut >>= 1;
                }
                for (; dt < J; )
                  U[dt++] = 0;
                F.putImageData(K, 0, mt * v);
              }
            } else if (d.kind === e.ImageKind.RGBA_32BPP) {
              for (ut = 0, it = y * v * 4, mt = 0; mt < N; mt++)
                gt.set(pt.subarray(st, st + it)), st += it, F.putImageData(K, 0, ut), ut += v;
              mt < $ && (it = y * B * 4, gt.set(pt.subarray(st, st + it)), F.putImageData(K, 0, ut));
            } else if (d.kind === e.ImageKind.RGB_24BPP)
              for (tt = v, it = y * tt, mt = 0; mt < $; mt++) {
                for (mt >= N && (tt = B, it = y * tt), dt = 0, ut = it; ut--; )
                  gt[dt++] = pt[st++], gt[dt++] = pt[st++], gt[dt++] = pt[st++], gt[dt++] = 255;
                F.putImageData(K, 0, mt * v);
              }
            else
              throw new Error(`bad image kind: ${d.kind}`);
          }
          function g(F, d) {
            if (d.bitmap) {
              F.drawImage(d.bitmap, 0, 0);
              return;
            }
            const u = d.height, y = d.width, B = u % v, N = (u - B) / v, $ = B === 0 ? N : N + 1, K = F.createImageData(y, v);
            let st = 0;
            const dt = d.data, pt = K.data;
            for (let gt = 0; gt < $; gt++) {
              const mt = gt < N ? v : B;
              ({
                srcPos: st
              } = (0, h.convertBlackAndWhiteToRGBA)({
                src: dt,
                srcPos: st,
                dest: pt,
                width: y,
                height: mt,
                nonBlackColor: 0
              })), F.putImageData(K, 0, gt * v);
            }
          }
          function p(F, d) {
            const u = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
            for (const y of u)
              F[y] !== void 0 && (d[y] = F[y]);
            F.setLineDash !== void 0 && (d.setLineDash(F.getLineDash()), d.lineDashOffset = F.lineDashOffset);
          }
          function _(F) {
            if (F.strokeStyle = F.fillStyle = "#000000", F.fillRule = "nonzero", F.globalAlpha = 1, F.lineWidth = 1, F.lineCap = "butt", F.lineJoin = "miter", F.miterLimit = 10, F.globalCompositeOperation = "source-over", F.font = "10px sans-serif", F.setLineDash !== void 0 && (F.setLineDash([]), F.lineDashOffset = 0), !e.isNodeJS) {
              const {
                filter: d
              } = F;
              d !== "none" && d !== "" && (F.filter = "none");
            }
          }
          function f(F, d, u, y) {
            const B = F.length;
            for (let N = 3; N < B; N += 4) {
              const $ = F[N];
              if ($ === 0)
                F[N - 3] = d, F[N - 2] = u, F[N - 1] = y;
              else if ($ < 255) {
                const K = 255 - $;
                F[N - 3] = F[N - 3] * $ + d * K >> 8, F[N - 2] = F[N - 2] * $ + u * K >> 8, F[N - 1] = F[N - 1] * $ + y * K >> 8;
              }
            }
          }
          function A(F, d, u) {
            const y = F.length, B = 1 / 255;
            for (let N = 3; N < y; N += 4) {
              const $ = u ? u[F[N]] : F[N];
              d[N] = d[N] * $ * B | 0;
            }
          }
          function C(F, d, u) {
            const y = F.length;
            for (let B = 3; B < y; B += 4) {
              const N = F[B - 3] * 77 + F[B - 2] * 152 + F[B - 1] * 28;
              d[B] = u ? d[B] * u[N >> 8] >> 8 : d[B] * N >> 16;
            }
          }
          function W(F, d, u, y, B, N, $, K, st, dt, pt) {
            const gt = !!N, mt = gt ? N[0] : 0, ut = gt ? N[1] : 0, tt = gt ? N[2] : 0, it = B === "Luminosity" ? C : A, U = Math.min(y, Math.ceil(1048576 / u));
            for (let J = 0; J < y; J += U) {
              const rt = Math.min(U, y - J), _t = F.getImageData(K - dt, J + (st - pt), u, rt), wt = d.getImageData(K, J + st, u, rt);
              gt && f(_t.data, mt, ut, tt), it(_t.data, wt.data, $), d.putImageData(wt, K, J + st);
            }
          }
          function m(F, d, u, y) {
            const B = y[0], N = y[1], $ = y[2] - B, K = y[3] - N;
            $ === 0 || K === 0 || (W(d.context, u, $, K, d.subtype, d.backdrop, d.transferMap, B, N, d.offsetX, d.offsetY), F.save(), F.globalAlpha = 1, F.globalCompositeOperation = "source-over", F.setTransform(1, 0, 0, 1, 0, 0), F.drawImage(u.canvas, 0, 0), F.restore());
          }
          function I(F, d) {
            const u = e.Util.singularValueDecompose2dScale(F);
            u[0] = Math.fround(u[0]), u[1] = Math.fround(u[1]);
            const y = Math.fround((globalThis.devicePixelRatio || 1) * s.PixelsPerInch.PDF_TO_CSS_UNITS);
            return d !== void 0 ? d : u[0] <= y || u[1] <= y;
          }
          const q = ["butt", "round", "square"], Y = ["miter", "round", "bevel"], X = {}, z = {}, Q = class Q {
            constructor(d, u, y, B, N, {
              optionalContentConfig: $,
              markedContentStack: K = null
            }, st, dt) {
              at(this, et);
              this.ctx = d, this.current = new w(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.res = null, this.xobjs = null, this.commonObjs = u, this.objs = y, this.canvasFactory = B, this.filterFactory = N, this.groupStack = [], this.processingType3 = null, this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.smaskCounter = 0, this.tempSMask = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = K || [], this.optionalContentConfig = $, this.cachedCanvases = new x(this.canvasFactory), this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = st, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = dt, this._cachedScaleForStroking = [-1, 0], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = /* @__PURE__ */ new Map();
            }
            getObject(d, u = null) {
              return typeof d == "string" ? d.startsWith("g_") ? this.commonObjs.get(d) : this.objs.get(d) : u;
            }
            beginDrawing({
              transform: d,
              viewport: u,
              transparency: y = !1,
              background: B = null
            }) {
              const N = this.ctx.canvas.width, $ = this.ctx.canvas.height, K = this.ctx.fillStyle;
              if (this.ctx.fillStyle = B || "#ffffff", this.ctx.fillRect(0, 0, N, $), this.ctx.fillStyle = K, y) {
                const st = this.cachedCanvases.getCanvas("transparent", N, $);
                this.compositeCtx = this.ctx, this.transparentCanvas = st.canvas, this.ctx = st.context, this.ctx.save(), this.ctx.transform(...(0, s.getCurrentTransform)(this.compositeCtx));
              }
              this.ctx.save(), _(this.ctx), d && (this.ctx.transform(...d), this.outputScaleX = d[0], this.outputScaleY = d[0]), this.ctx.transform(...u.transform), this.viewportScale = u.scale, this.baseTransform = (0, s.getCurrentTransform)(this.ctx);
            }
            executeOperatorList(d, u, y, B) {
              const N = d.argsArray, $ = d.fnArray;
              let K = u || 0;
              const st = N.length;
              if (st === K)
                return K;
              const dt = st - K > T && typeof y == "function", pt = dt ? Date.now() + a : 0;
              let gt = 0;
              const mt = this.commonObjs, ut = this.objs;
              let tt;
              for (; ; ) {
                if (B !== void 0 && K === B.nextBreakPoint)
                  return B.breakIt(K, y), K;
                if (tt = $[K], tt !== e.OPS.dependency)
                  this[tt].apply(this, N[K]);
                else
                  for (const it of N[K]) {
                    const R = it.startsWith("g_") ? mt : ut;
                    if (!R.has(it))
                      return R.get(it, y), K;
                  }
                if (K++, K === st)
                  return K;
                if (dt && ++gt > T) {
                  if (Date.now() > pt)
                    return y(), K;
                  gt = 0;
                }
              }
            }
            endDrawing() {
              Z(this, et, Xe).call(this), this.cachedCanvases.clear(), this.cachedPatterns.clear();
              for (const d of this._cachedBitmapsMap.values()) {
                for (const u of d.values())
                  typeof HTMLCanvasElement < "u" && u instanceof HTMLCanvasElement && (u.width = u.height = 0);
                d.clear();
              }
              this._cachedBitmapsMap.clear(), Z(this, et, Ve).call(this);
            }
            _scaleImage(d, u) {
              const y = d.width, B = d.height;
              let N = Math.max(Math.hypot(u[0], u[1]), 1), $ = Math.max(Math.hypot(u[2], u[3]), 1), K = y, st = B, dt = "prescale1", pt, gt;
              for (; N > 2 && K > 1 || $ > 2 && st > 1; ) {
                let mt = K, ut = st;
                N > 2 && K > 1 && (mt = K >= 16384 ? Math.floor(K / 2) - 1 || 1 : Math.ceil(K / 2), N /= K / mt), $ > 2 && st > 1 && (ut = st >= 16384 ? Math.floor(st / 2) - 1 || 1 : Math.ceil(st) / 2, $ /= st / ut), pt = this.cachedCanvases.getCanvas(dt, mt, ut), gt = pt.context, gt.clearRect(0, 0, mt, ut), gt.drawImage(d, 0, 0, K, st, 0, 0, mt, ut), d = pt.canvas, K = mt, st = ut, dt = dt === "prescale1" ? "prescale2" : "prescale1";
              }
              return {
                img: d,
                paintWidth: K,
                paintHeight: st
              };
            }
            _createMaskCanvas(d) {
              const u = this.ctx, {
                width: y,
                height: B
              } = d, N = this.current.fillColor, $ = this.current.patternFill, K = (0, s.getCurrentTransform)(u);
              let st, dt, pt, gt;
              if ((d.bitmap || d.data) && d.count > 1) {
                const nt = d.bitmap || d.data.buffer;
                dt = JSON.stringify($ ? K : [K.slice(0, 4), N]), st = this._cachedBitmapsMap.get(nt), st || (st = /* @__PURE__ */ new Map(), this._cachedBitmapsMap.set(nt, st));
                const kt = st.get(dt);
                if (kt && !$) {
                  const Et = Math.round(Math.min(K[0], K[2]) + K[4]), Ut = Math.round(Math.min(K[1], K[3]) + K[5]);
                  return {
                    canvas: kt,
                    offsetX: Et,
                    offsetY: Ut
                  };
                }
                pt = kt;
              }
              pt || (gt = this.cachedCanvases.getCanvas("maskCanvas", y, B), g(gt.context, d));
              let mt = e.Util.transform(K, [1 / y, 0, 0, -1 / B, 0, 0]);
              mt = e.Util.transform(mt, [1, 0, 0, 1, 0, -B]);
              const ut = e.Util.applyTransform([0, 0], mt), tt = e.Util.applyTransform([y, B], mt), it = e.Util.normalizeRect([ut[0], ut[1], tt[0], tt[1]]), R = Math.round(it[2] - it[0]) || 1, U = Math.round(it[3] - it[1]) || 1, J = this.cachedCanvases.getCanvas("fillCanvas", R, U), rt = J.context, _t = Math.min(ut[0], tt[0]), wt = Math.min(ut[1], tt[1]);
              rt.translate(-_t, -wt), rt.transform(...mt), pt || (pt = this._scaleImage(gt.canvas, (0, s.getCurrentTransformInverse)(rt)), pt = pt.img, st && $ && st.set(dt, pt)), rt.imageSmoothingEnabled = I((0, s.getCurrentTransform)(rt), d.interpolate), S(rt, pt, 0, 0, pt.width, pt.height, 0, 0, y, B), rt.globalCompositeOperation = "source-in";
              const vt = e.Util.transform((0, s.getCurrentTransformInverse)(rt), [1, 0, 0, 1, -_t, -wt]);
              return rt.fillStyle = $ ? N.getPattern(u, this, vt, c.PathType.FILL) : N, rt.fillRect(0, 0, y, B), st && !$ && (this.cachedCanvases.delete("fillCanvas"), st.set(dt, J.canvas)), {
                canvas: J.canvas,
                offsetX: Math.round(_t),
                offsetY: Math.round(wt)
              };
            }
            setLineWidth(d) {
              d !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = d, this.ctx.lineWidth = d;
            }
            setLineCap(d) {
              this.ctx.lineCap = q[d];
            }
            setLineJoin(d) {
              this.ctx.lineJoin = Y[d];
            }
            setMiterLimit(d) {
              this.ctx.miterLimit = d;
            }
            setDash(d, u) {
              const y = this.ctx;
              y.setLineDash !== void 0 && (y.setLineDash(d), y.lineDashOffset = u);
            }
            setRenderingIntent(d) {
            }
            setFlatness(d) {
            }
            setGState(d) {
              for (const [u, y] of d)
                switch (u) {
                  case "LW":
                    this.setLineWidth(y);
                    break;
                  case "LC":
                    this.setLineCap(y);
                    break;
                  case "LJ":
                    this.setLineJoin(y);
                    break;
                  case "ML":
                    this.setMiterLimit(y);
                    break;
                  case "D":
                    this.setDash(y[0], y[1]);
                    break;
                  case "RI":
                    this.setRenderingIntent(y);
                    break;
                  case "FL":
                    this.setFlatness(y);
                    break;
                  case "Font":
                    this.setFont(y[0], y[1]);
                    break;
                  case "CA":
                    this.current.strokeAlpha = y;
                    break;
                  case "ca":
                    this.current.fillAlpha = y, this.ctx.globalAlpha = y;
                    break;
                  case "BM":
                    this.ctx.globalCompositeOperation = y;
                    break;
                  case "SMask":
                    this.current.activeSMask = y ? this.tempSMask : null, this.tempSMask = null, this.checkSMaskState();
                    break;
                  case "TR":
                    this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(y);
                    break;
                }
            }
            get inSMaskMode() {
              return !!this.suspendedCtx;
            }
            checkSMaskState() {
              const d = this.inSMaskMode;
              this.current.activeSMask && !d ? this.beginSMaskMode() : !this.current.activeSMask && d && this.endSMaskMode();
            }
            beginSMaskMode() {
              if (this.inSMaskMode)
                throw new Error("beginSMaskMode called while already in smask mode");
              const d = this.ctx.canvas.width, u = this.ctx.canvas.height, y = "smaskGroupAt" + this.groupLevel, B = this.cachedCanvases.getCanvas(y, d, u);
              this.suspendedCtx = this.ctx, this.ctx = B.context;
              const N = this.ctx;
              N.setTransform(...(0, s.getCurrentTransform)(this.suspendedCtx)), p(this.suspendedCtx, N), k(N, this.suspendedCtx), this.setGState([["BM", "source-over"], ["ca", 1], ["CA", 1]]);
            }
            endSMaskMode() {
              if (!this.inSMaskMode)
                throw new Error("endSMaskMode called while not in smask mode");
              this.ctx._removeMirroring(), p(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null;
            }
            compose(d) {
              if (!this.current.activeSMask)
                return;
              d ? (d[0] = Math.floor(d[0]), d[1] = Math.floor(d[1]), d[2] = Math.ceil(d[2]), d[3] = Math.ceil(d[3])) : d = [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
              const u = this.current.activeSMask, y = this.suspendedCtx;
              m(y, u, this.ctx, d), this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore();
            }
            save() {
              this.inSMaskMode ? (p(this.ctx, this.suspendedCtx), this.suspendedCtx.save()) : this.ctx.save();
              const d = this.current;
              this.stateStack.push(d), this.current = d.clone();
            }
            restore() {
              this.stateStack.length === 0 && this.inSMaskMode && this.endSMaskMode(), this.stateStack.length !== 0 && (this.current = this.stateStack.pop(), this.inSMaskMode ? (this.suspendedCtx.restore(), p(this.suspendedCtx, this.ctx)) : this.ctx.restore(), this.checkSMaskState(), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null);
            }
            transform(d, u, y, B, N, $) {
              this.ctx.transform(d, u, y, B, N, $), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
            }
            constructPath(d, u, y) {
              const B = this.ctx, N = this.current;
              let $ = N.x, K = N.y, st, dt;
              const pt = (0, s.getCurrentTransform)(B), gt = pt[0] === 0 && pt[3] === 0 || pt[1] === 0 && pt[2] === 0, mt = gt ? y.slice(0) : null;
              for (let ut = 0, tt = 0, it = d.length; ut < it; ut++)
                switch (d[ut] | 0) {
                  case e.OPS.rectangle:
                    $ = u[tt++], K = u[tt++];
                    const R = u[tt++], U = u[tt++], J = $ + R, rt = K + U;
                    B.moveTo($, K), R === 0 || U === 0 ? B.lineTo(J, rt) : (B.lineTo(J, K), B.lineTo(J, rt), B.lineTo($, rt)), gt || N.updateRectMinMax(pt, [$, K, J, rt]), B.closePath();
                    break;
                  case e.OPS.moveTo:
                    $ = u[tt++], K = u[tt++], B.moveTo($, K), gt || N.updatePathMinMax(pt, $, K);
                    break;
                  case e.OPS.lineTo:
                    $ = u[tt++], K = u[tt++], B.lineTo($, K), gt || N.updatePathMinMax(pt, $, K);
                    break;
                  case e.OPS.curveTo:
                    st = $, dt = K, $ = u[tt + 4], K = u[tt + 5], B.bezierCurveTo(u[tt], u[tt + 1], u[tt + 2], u[tt + 3], $, K), N.updateCurvePathMinMax(pt, st, dt, u[tt], u[tt + 1], u[tt + 2], u[tt + 3], $, K, mt), tt += 6;
                    break;
                  case e.OPS.curveTo2:
                    st = $, dt = K, B.bezierCurveTo($, K, u[tt], u[tt + 1], u[tt + 2], u[tt + 3]), N.updateCurvePathMinMax(pt, st, dt, $, K, u[tt], u[tt + 1], u[tt + 2], u[tt + 3], mt), $ = u[tt + 2], K = u[tt + 3], tt += 4;
                    break;
                  case e.OPS.curveTo3:
                    st = $, dt = K, $ = u[tt + 2], K = u[tt + 3], B.bezierCurveTo(u[tt], u[tt + 1], $, K, $, K), N.updateCurvePathMinMax(pt, st, dt, u[tt], u[tt + 1], $, K, $, K, mt), tt += 4;
                    break;
                  case e.OPS.closePath:
                    B.closePath();
                    break;
                }
              gt && N.updateScalingPathMinMax(pt, mt), N.setCurrentPoint($, K);
            }
            closePath() {
              this.ctx.closePath();
            }
            stroke(d = !0) {
              const u = this.ctx, y = this.current.strokeColor;
              u.globalAlpha = this.current.strokeAlpha, this.contentVisible && (typeof y == "object" && (y != null && y.getPattern) ? (u.save(), u.strokeStyle = y.getPattern(u, this, (0, s.getCurrentTransformInverse)(u), c.PathType.STROKE), this.rescaleAndStroke(!1), u.restore()) : this.rescaleAndStroke(!0)), d && this.consumePath(this.current.getClippedPathBoundingBox()), u.globalAlpha = this.current.fillAlpha;
            }
            closeStroke() {
              this.closePath(), this.stroke();
            }
            fill(d = !0) {
              const u = this.ctx, y = this.current.fillColor, B = this.current.patternFill;
              let N = !1;
              B && (u.save(), u.fillStyle = y.getPattern(u, this, (0, s.getCurrentTransformInverse)(u), c.PathType.FILL), N = !0);
              const $ = this.current.getClippedPathBoundingBox();
              this.contentVisible && $ !== null && (this.pendingEOFill ? (u.fill("evenodd"), this.pendingEOFill = !1) : u.fill()), N && u.restore(), d && this.consumePath($);
            }
            eoFill() {
              this.pendingEOFill = !0, this.fill();
            }
            fillStroke() {
              this.fill(!1), this.stroke(!1), this.consumePath();
            }
            eoFillStroke() {
              this.pendingEOFill = !0, this.fillStroke();
            }
            closeFillStroke() {
              this.closePath(), this.fillStroke();
            }
            closeEOFillStroke() {
              this.pendingEOFill = !0, this.closePath(), this.fillStroke();
            }
            endPath() {
              this.consumePath();
            }
            clip() {
              this.pendingClip = X;
            }
            eoClip() {
              this.pendingClip = z;
            }
            beginText() {
              this.current.textMatrix = e.IDENTITY_MATRIX, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
            }
            endText() {
              const d = this.pendingTextPaths, u = this.ctx;
              if (d === void 0) {
                u.beginPath();
                return;
              }
              u.save(), u.beginPath();
              for (const y of d)
                u.setTransform(...y.transform), u.translate(y.x, y.y), y.addToPath(u, y.fontSize);
              u.restore(), u.clip(), u.beginPath(), delete this.pendingTextPaths;
            }
            setCharSpacing(d) {
              this.current.charSpacing = d;
            }
            setWordSpacing(d) {
              this.current.wordSpacing = d;
            }
            setHScale(d) {
              this.current.textHScale = d / 100;
            }
            setLeading(d) {
              this.current.leading = -d;
            }
            setFont(d, u) {
              var pt;
              const y = this.commonObjs.get(d), B = this.current;
              if (!y)
                throw new Error(`Can't find font for ${d}`);
              if (B.fontMatrix = y.fontMatrix || e.FONT_IDENTITY_MATRIX, (B.fontMatrix[0] === 0 || B.fontMatrix[3] === 0) && (0, e.warn)("Invalid font matrix for font " + d), u < 0 ? (u = -u, B.fontDirection = -1) : B.fontDirection = 1, this.current.font = y, this.current.fontSize = u, y.isType3Font)
                return;
              const N = y.loadedName || "sans-serif", $ = ((pt = y.systemFontInfo) == null ? void 0 : pt.css) || `"${N}", ${y.fallbackName}`;
              let K = "normal";
              y.black ? K = "900" : y.bold && (K = "bold");
              const st = y.italic ? "italic" : "normal";
              let dt = u;
              u < b ? dt = b : u > o && (dt = o), this.current.fontSizeScale = u / dt, this.ctx.font = `${st} ${K} ${dt}px ${$}`;
            }
            setTextRenderingMode(d) {
              this.current.textRenderingMode = d;
            }
            setTextRise(d) {
              this.current.textRise = d;
            }
            moveText(d, u) {
              this.current.x = this.current.lineX += d, this.current.y = this.current.lineY += u;
            }
            setLeadingMoveText(d, u) {
              this.setLeading(-u), this.moveText(d, u);
            }
            setTextMatrix(d, u, y, B, N, $) {
              this.current.textMatrix = [d, u, y, B, N, $], this.current.textMatrixScale = Math.hypot(d, u), this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
            }
            nextLine() {
              this.moveText(0, this.current.leading);
            }
            paintChar(d, u, y, B) {
              const N = this.ctx, $ = this.current, K = $.font, st = $.textRenderingMode, dt = $.fontSize / $.fontSizeScale, pt = st & e.TextRenderingMode.FILL_STROKE_MASK, gt = !!(st & e.TextRenderingMode.ADD_TO_PATH_FLAG), mt = $.patternFill && !K.missingFile;
              let ut;
              (K.disableFontFace || gt || mt) && (ut = K.getPathGenerator(this.commonObjs, d)), K.disableFontFace || mt ? (N.save(), N.translate(u, y), N.beginPath(), ut(N, dt), B && N.setTransform(...B), (pt === e.TextRenderingMode.FILL || pt === e.TextRenderingMode.FILL_STROKE) && N.fill(), (pt === e.TextRenderingMode.STROKE || pt === e.TextRenderingMode.FILL_STROKE) && N.stroke(), N.restore()) : ((pt === e.TextRenderingMode.FILL || pt === e.TextRenderingMode.FILL_STROKE) && N.fillText(d, u, y), (pt === e.TextRenderingMode.STROKE || pt === e.TextRenderingMode.FILL_STROKE) && N.strokeText(d, u, y)), gt && (this.pendingTextPaths || (this.pendingTextPaths = [])).push({
                transform: (0, s.getCurrentTransform)(N),
                x: u,
                y,
                fontSize: dt,
                addToPath: ut
              });
            }
            get isFontSubpixelAAEnabled() {
              const {
                context: d
              } = this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled", 10, 10);
              d.scale(1.5, 1), d.fillText("I", 0, 10);
              const u = d.getImageData(0, 0, 10, 10).data;
              let y = !1;
              for (let B = 3; B < u.length; B += 4)
                if (u[B] > 0 && u[B] < 255) {
                  y = !0;
                  break;
                }
              return (0, e.shadow)(this, "isFontSubpixelAAEnabled", y);
            }
            showText(d) {
              const u = this.current, y = u.font;
              if (y.isType3Font)
                return this.showType3Text(d);
              const B = u.fontSize;
              if (B === 0)
                return;
              const N = this.ctx, $ = u.fontSizeScale, K = u.charSpacing, st = u.wordSpacing, dt = u.fontDirection, pt = u.textHScale * dt, gt = d.length, mt = y.vertical, ut = mt ? 1 : -1, tt = y.defaultVMetrics, it = B * u.fontMatrix[0], R = u.textRenderingMode === e.TextRenderingMode.FILL && !y.disableFontFace && !u.patternFill;
              N.save(), N.transform(...u.textMatrix), N.translate(u.x, u.y + u.textRise), dt > 0 ? N.scale(pt, -1) : N.scale(pt, 1);
              let U;
              if (u.patternFill) {
                N.save();
                const vt = u.fillColor.getPattern(N, this, (0, s.getCurrentTransformInverse)(N), c.PathType.FILL);
                U = (0, s.getCurrentTransform)(N), N.restore(), N.fillStyle = vt;
              }
              let J = u.lineWidth;
              const rt = u.textMatrixScale;
              if (rt === 0 || J === 0) {
                const vt = u.textRenderingMode & e.TextRenderingMode.FILL_STROKE_MASK;
                (vt === e.TextRenderingMode.STROKE || vt === e.TextRenderingMode.FILL_STROKE) && (J = this.getSinglePixelWidth());
              } else
                J /= rt;
              if ($ !== 1 && (N.scale($, $), J /= $), N.lineWidth = J, y.isInvalidPDFjsFont) {
                const vt = [];
                let nt = 0;
                for (const kt of d)
                  vt.push(kt.unicode), nt += kt.width;
                N.fillText(vt.join(""), 0, 0), u.x += nt * it * pt, N.restore(), this.compose();
                return;
              }
              let _t = 0, wt;
              for (wt = 0; wt < gt; ++wt) {
                const vt = d[wt];
                if (typeof vt == "number") {
                  _t += ut * vt * B / 1e3;
                  continue;
                }
                let nt = !1;
                const kt = (vt.isSpace ? st : 0) + K, Et = vt.fontChar, Ut = vt.accent;
                let Nt, zt, Mt = vt.width;
                if (mt) {
                  const Gt = vt.vmetric || tt, Vt = -(vt.vmetric ? Gt[1] : Mt * 0.5) * it, At = Gt[2] * it;
                  Mt = Gt ? -Gt[0] : Mt, Nt = Vt / $, zt = (_t + At) / $;
                } else
                  Nt = _t / $, zt = 0;
                if (y.remeasure && Mt > 0) {
                  const Gt = N.measureText(Et).width * 1e3 / B * $;
                  if (Mt < Gt && this.isFontSubpixelAAEnabled) {
                    const Vt = Mt / Gt;
                    nt = !0, N.save(), N.scale(Vt, 1), Nt /= Vt;
                  } else Mt !== Gt && (Nt += (Mt - Gt) / 2e3 * B / $);
                }
                if (this.contentVisible && (vt.isInFont || y.missingFile)) {
                  if (R && !Ut)
                    N.fillText(Et, Nt, zt);
                  else if (this.paintChar(Et, Nt, zt, U), Ut) {
                    const Gt = Nt + B * Ut.offset.x / $, Vt = zt - B * Ut.offset.y / $;
                    this.paintChar(Ut.fontChar, Gt, Vt, U);
                  }
                }
                const $t = mt ? Mt * it - kt * dt : Mt * it + kt * dt;
                _t += $t, nt && N.restore();
              }
              mt ? u.y -= _t : u.x += _t * pt, N.restore(), this.compose();
            }
            showType3Text(d) {
              const u = this.ctx, y = this.current, B = y.font, N = y.fontSize, $ = y.fontDirection, K = B.vertical ? 1 : -1, st = y.charSpacing, dt = y.wordSpacing, pt = y.textHScale * $, gt = y.fontMatrix || e.FONT_IDENTITY_MATRIX, mt = d.length, ut = y.textRenderingMode === e.TextRenderingMode.INVISIBLE;
              let tt, it, R, U;
              if (!(ut || N === 0)) {
                for (this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, u.save(), u.transform(...y.textMatrix), u.translate(y.x, y.y), u.scale(pt, $), tt = 0; tt < mt; ++tt) {
                  if (it = d[tt], typeof it == "number") {
                    U = K * it * N / 1e3, this.ctx.translate(U, 0), y.x += U * pt;
                    continue;
                  }
                  const J = (it.isSpace ? dt : 0) + st, rt = B.charProcOperatorList[it.operatorListId];
                  if (!rt) {
                    (0, e.warn)(`Type3 character "${it.operatorListId}" is not available.`);
                    continue;
                  }
                  this.contentVisible && (this.processingType3 = it, this.save(), u.scale(N, N), u.transform(...gt), this.executeOperatorList(rt), this.restore()), R = e.Util.applyTransform([it.width, 0], gt)[0] * N + J, u.translate(R, 0), y.x += R * pt;
                }
                u.restore(), this.processingType3 = null;
              }
            }
            setCharWidth(d, u) {
            }
            setCharWidthAndBounds(d, u, y, B, N, $) {
              this.ctx.rect(y, B, N - y, $ - B), this.ctx.clip(), this.endPath();
            }
            getColorN_Pattern(d) {
              let u;
              if (d[0] === "TilingPattern") {
                const y = d[1], B = this.baseTransform || (0, s.getCurrentTransform)(this.ctx), N = {
                  createCanvasGraphics: ($) => new Q($, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                    optionalContentConfig: this.optionalContentConfig,
                    markedContentStack: this.markedContentStack
                  })
                };
                u = new c.TilingPattern(d, y, this.ctx, N, B);
              } else
                u = this._getPattern(d[1], d[2]);
              return u;
            }
            setStrokeColorN() {
              this.current.strokeColor = this.getColorN_Pattern(arguments);
            }
            setFillColorN() {
              this.current.fillColor = this.getColorN_Pattern(arguments), this.current.patternFill = !0;
            }
            setStrokeRGBColor(d, u, y) {
              const B = e.Util.makeHexColor(d, u, y);
              this.ctx.strokeStyle = B, this.current.strokeColor = B;
            }
            setFillRGBColor(d, u, y) {
              const B = e.Util.makeHexColor(d, u, y);
              this.ctx.fillStyle = B, this.current.fillColor = B, this.current.patternFill = !1;
            }
            _getPattern(d, u = null) {
              let y;
              return this.cachedPatterns.has(d) ? y = this.cachedPatterns.get(d) : (y = (0, c.getShadingPattern)(this.getObject(d)), this.cachedPatterns.set(d, y)), u && (y.matrix = u), y;
            }
            shadingFill(d) {
              if (!this.contentVisible)
                return;
              const u = this.ctx;
              this.save();
              const y = this._getPattern(d);
              u.fillStyle = y.getPattern(u, this, (0, s.getCurrentTransformInverse)(u), c.PathType.SHADING);
              const B = (0, s.getCurrentTransformInverse)(u);
              if (B) {
                const {
                  width: N,
                  height: $
                } = u.canvas, [K, st, dt, pt] = e.Util.getAxialAlignedBoundingBox([0, 0, N, $], B);
                this.ctx.fillRect(K, st, dt - K, pt - st);
              } else
                this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
              this.compose(this.current.getClippedPathBoundingBox()), this.restore();
            }
            beginInlineImage() {
              (0, e.unreachable)("Should not call beginInlineImage");
            }
            beginImageData() {
              (0, e.unreachable)("Should not call beginImageData");
            }
            paintFormXObjectBegin(d, u) {
              if (this.contentVisible && (this.save(), this.baseTransformStack.push(this.baseTransform), Array.isArray(d) && d.length === 6 && this.transform(...d), this.baseTransform = (0, s.getCurrentTransform)(this.ctx), u)) {
                const y = u[2] - u[0], B = u[3] - u[1];
                this.ctx.rect(u[0], u[1], y, B), this.current.updateRectMinMax((0, s.getCurrentTransform)(this.ctx), u), this.clip(), this.endPath();
              }
            }
            paintFormXObjectEnd() {
              this.contentVisible && (this.restore(), this.baseTransform = this.baseTransformStack.pop());
            }
            beginGroup(d) {
              if (!this.contentVisible)
                return;
              this.save(), this.inSMaskMode && (this.endSMaskMode(), this.current.activeSMask = null);
              const u = this.ctx;
              d.isolated || (0, e.info)("TODO: Support non-isolated groups."), d.knockout && (0, e.warn)("Knockout groups not supported.");
              const y = (0, s.getCurrentTransform)(u);
              if (d.matrix && u.transform(...d.matrix), !d.bbox)
                throw new Error("Bounding box is required.");
              let B = e.Util.getAxialAlignedBoundingBox(d.bbox, (0, s.getCurrentTransform)(u));
              const N = [0, 0, u.canvas.width, u.canvas.height];
              B = e.Util.intersect(B, N) || [0, 0, 0, 0];
              const $ = Math.floor(B[0]), K = Math.floor(B[1]);
              let st = Math.max(Math.ceil(B[2]) - $, 1), dt = Math.max(Math.ceil(B[3]) - K, 1), pt = 1, gt = 1;
              st > l && (pt = st / l, st = l), dt > l && (gt = dt / l, dt = l), this.current.startNewPathAndClipBox([0, 0, st, dt]);
              let mt = "groupAt" + this.groupLevel;
              d.smask && (mt += "_smask_" + this.smaskCounter++ % 2);
              const ut = this.cachedCanvases.getCanvas(mt, st, dt), tt = ut.context;
              tt.scale(1 / pt, 1 / gt), tt.translate(-$, -K), tt.transform(...y), d.smask ? this.smaskStack.push({
                canvas: ut.canvas,
                context: tt,
                offsetX: $,
                offsetY: K,
                scaleX: pt,
                scaleY: gt,
                subtype: d.smask.subtype,
                backdrop: d.smask.backdrop,
                transferMap: d.smask.transferMap || null,
                startTransformInverse: null
              }) : (u.setTransform(1, 0, 0, 1, 0, 0), u.translate($, K), u.scale(pt, gt), u.save()), p(u, tt), this.ctx = tt, this.setGState([["BM", "source-over"], ["ca", 1], ["CA", 1]]), this.groupStack.push(u), this.groupLevel++;
            }
            endGroup(d) {
              if (!this.contentVisible)
                return;
              this.groupLevel--;
              const u = this.ctx, y = this.groupStack.pop();
              if (this.ctx = y, this.ctx.imageSmoothingEnabled = !1, d.smask)
                this.tempSMask = this.smaskStack.pop(), this.restore();
              else {
                this.ctx.restore();
                const B = (0, s.getCurrentTransform)(this.ctx);
                this.restore(), this.ctx.save(), this.ctx.setTransform(...B);
                const N = e.Util.getAxialAlignedBoundingBox([0, 0, u.canvas.width, u.canvas.height], B);
                this.ctx.drawImage(u.canvas, 0, 0), this.ctx.restore(), this.compose(N);
              }
            }
            beginAnnotation(d, u, y, B, N) {
              if (Z(this, et, Xe).call(this), _(this.ctx), this.ctx.save(), this.save(), this.baseTransform && this.ctx.setTransform(...this.baseTransform), Array.isArray(u) && u.length === 4) {
                const $ = u[2] - u[0], K = u[3] - u[1];
                if (N && this.annotationCanvasMap) {
                  y = y.slice(), y[4] -= u[0], y[5] -= u[1], u = u.slice(), u[0] = u[1] = 0, u[2] = $, u[3] = K;
                  const [st, dt] = e.Util.singularValueDecompose2dScale((0, s.getCurrentTransform)(this.ctx)), {
                    viewportScale: pt
                  } = this, gt = Math.ceil($ * this.outputScaleX * pt), mt = Math.ceil(K * this.outputScaleY * pt);
                  this.annotationCanvas = this.canvasFactory.create(gt, mt);
                  const {
                    canvas: ut,
                    context: tt
                  } = this.annotationCanvas;
                  this.annotationCanvasMap.set(d, ut), this.annotationCanvas.savedCtx = this.ctx, this.ctx = tt, this.ctx.save(), this.ctx.setTransform(st, 0, 0, -dt, 0, K * dt), _(this.ctx);
                } else
                  _(this.ctx), this.ctx.rect(u[0], u[1], $, K), this.ctx.clip(), this.endPath();
              }
              this.current = new w(this.ctx.canvas.width, this.ctx.canvas.height), this.transform(...y), this.transform(...B);
            }
            endAnnotation() {
              this.annotationCanvas && (this.ctx.restore(), Z(this, et, Ve).call(this), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas);
            }
            paintImageMaskXObject(d) {
              if (!this.contentVisible)
                return;
              const u = d.count;
              d = this.getObject(d.data, d), d.count = u;
              const y = this.ctx, B = this.processingType3;
              if (B && (B.compiled === void 0 && (B.compiled = E(d)), B.compiled)) {
                B.compiled(y);
                return;
              }
              const N = this._createMaskCanvas(d), $ = N.canvas;
              y.save(), y.setTransform(1, 0, 0, 1, 0, 0), y.drawImage($, N.offsetX, N.offsetY), y.restore(), this.compose();
            }
            paintImageMaskXObjectRepeat(d, u, y = 0, B = 0, N, $) {
              if (!this.contentVisible)
                return;
              d = this.getObject(d.data, d);
              const K = this.ctx;
              K.save();
              const st = (0, s.getCurrentTransform)(K);
              K.transform(u, y, B, N, 0, 0);
              const dt = this._createMaskCanvas(d);
              K.setTransform(1, 0, 0, 1, dt.offsetX - st[4], dt.offsetY - st[5]);
              for (let pt = 0, gt = $.length; pt < gt; pt += 2) {
                const mt = e.Util.transform(st, [u, y, B, N, $[pt], $[pt + 1]]), [ut, tt] = e.Util.applyTransform([0, 0], mt);
                K.drawImage(dt.canvas, ut, tt);
              }
              K.restore(), this.compose();
            }
            paintImageMaskXObjectGroup(d) {
              if (!this.contentVisible)
                return;
              const u = this.ctx, y = this.current.fillColor, B = this.current.patternFill;
              for (const N of d) {
                const {
                  data: $,
                  width: K,
                  height: st,
                  transform: dt
                } = N, pt = this.cachedCanvases.getCanvas("maskCanvas", K, st), gt = pt.context;
                gt.save();
                const mt = this.getObject($, N);
                g(gt, mt), gt.globalCompositeOperation = "source-in", gt.fillStyle = B ? y.getPattern(gt, this, (0, s.getCurrentTransformInverse)(u), c.PathType.FILL) : y, gt.fillRect(0, 0, K, st), gt.restore(), u.save(), u.transform(...dt), u.scale(1, -1), S(u, pt.canvas, 0, 0, K, st, 0, -1, 1, 1), u.restore();
              }
              this.compose();
            }
            paintImageXObject(d) {
              if (!this.contentVisible)
                return;
              const u = this.getObject(d);
              if (!u) {
                (0, e.warn)("Dependent image isn't ready yet");
                return;
              }
              this.paintInlineImageXObject(u);
            }
            paintImageXObjectRepeat(d, u, y, B) {
              if (!this.contentVisible)
                return;
              const N = this.getObject(d);
              if (!N) {
                (0, e.warn)("Dependent image isn't ready yet");
                return;
              }
              const $ = N.width, K = N.height, st = [];
              for (let dt = 0, pt = B.length; dt < pt; dt += 2)
                st.push({
                  transform: [u, 0, 0, y, B[dt], B[dt + 1]],
                  x: 0,
                  y: 0,
                  w: $,
                  h: K
                });
              this.paintInlineImageXObjectGroup(N, st);
            }
            applyTransferMapsToCanvas(d) {
              return this.current.transferMaps !== "none" && (d.filter = this.current.transferMaps, d.drawImage(d.canvas, 0, 0), d.filter = "none"), d.canvas;
            }
            applyTransferMapsToBitmap(d) {
              if (this.current.transferMaps === "none")
                return d.bitmap;
              const {
                bitmap: u,
                width: y,
                height: B
              } = d, N = this.cachedCanvases.getCanvas("inlineImage", y, B), $ = N.context;
              return $.filter = this.current.transferMaps, $.drawImage(u, 0, 0), $.filter = "none", N.canvas;
            }
            paintInlineImageXObject(d) {
              if (!this.contentVisible)
                return;
              const u = d.width, y = d.height, B = this.ctx;
              if (this.save(), !e.isNodeJS) {
                const {
                  filter: K
                } = B;
                K !== "none" && K !== "" && (B.filter = "none");
              }
              B.scale(1 / u, -1 / y);
              let N;
              if (d.bitmap)
                N = this.applyTransferMapsToBitmap(d);
              else if (typeof HTMLElement == "function" && d instanceof HTMLElement || !d.data)
                N = d;
              else {
                const st = this.cachedCanvases.getCanvas("inlineImage", u, y).context;
                M(st, d), N = this.applyTransferMapsToCanvas(st);
              }
              const $ = this._scaleImage(N, (0, s.getCurrentTransformInverse)(B));
              B.imageSmoothingEnabled = I((0, s.getCurrentTransform)(B), d.interpolate), S(B, $.img, 0, 0, $.paintWidth, $.paintHeight, 0, -y, u, y), this.compose(), this.restore();
            }
            paintInlineImageXObjectGroup(d, u) {
              if (!this.contentVisible)
                return;
              const y = this.ctx;
              let B;
              if (d.bitmap)
                B = d.bitmap;
              else {
                const N = d.width, $ = d.height, st = this.cachedCanvases.getCanvas("inlineImage", N, $).context;
                M(st, d), B = this.applyTransferMapsToCanvas(st);
              }
              for (const N of u)
                y.save(), y.transform(...N.transform), y.scale(1, -1), S(y, B, N.x, N.y, N.w, N.h, 0, -1, 1, 1), y.restore();
              this.compose();
            }
            paintSolidColorImageMask() {
              this.contentVisible && (this.ctx.fillRect(0, 0, 1, 1), this.compose());
            }
            markPoint(d) {
            }
            markPointProps(d, u) {
            }
            beginMarkedContent(d) {
              this.markedContentStack.push({
                visible: !0
              });
            }
            beginMarkedContentProps(d, u) {
              d === "OC" ? this.markedContentStack.push({
                visible: this.optionalContentConfig.isVisible(u)
              }) : this.markedContentStack.push({
                visible: !0
              }), this.contentVisible = this.isContentVisible();
            }
            endMarkedContent() {
              this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
            }
            beginCompat() {
            }
            endCompat() {
            }
            consumePath(d) {
              const u = this.current.isEmptyClip();
              this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(d);
              const y = this.ctx;
              this.pendingClip && (u || (this.pendingClip === z ? y.clip("evenodd") : y.clip()), this.pendingClip = null), this.current.startNewPathAndClipBox(this.current.clipBox), y.beginPath();
            }
            getSinglePixelWidth() {
              if (!this._cachedGetSinglePixelWidth) {
                const d = (0, s.getCurrentTransform)(this.ctx);
                if (d[1] === 0 && d[2] === 0)
                  this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(d[0]), Math.abs(d[3]));
                else {
                  const u = Math.abs(d[0] * d[3] - d[2] * d[1]), y = Math.hypot(d[0], d[2]), B = Math.hypot(d[1], d[3]);
                  this._cachedGetSinglePixelWidth = Math.max(y, B) / u;
                }
              }
              return this._cachedGetSinglePixelWidth;
            }
            getScaleForStroking() {
              if (this._cachedScaleForStroking[0] === -1) {
                const {
                  lineWidth: d
                } = this.current, {
                  a: u,
                  b: y,
                  c: B,
                  d: N
                } = this.ctx.getTransform();
                let $, K;
                if (y === 0 && B === 0) {
                  const st = Math.abs(u), dt = Math.abs(N);
                  if (st === dt)
                    if (d === 0)
                      $ = K = 1 / st;
                    else {
                      const pt = st * d;
                      $ = K = pt < 1 ? 1 / pt : 1;
                    }
                  else if (d === 0)
                    $ = 1 / st, K = 1 / dt;
                  else {
                    const pt = st * d, gt = dt * d;
                    $ = pt < 1 ? 1 / pt : 1, K = gt < 1 ? 1 / gt : 1;
                  }
                } else {
                  const st = Math.abs(u * N - y * B), dt = Math.hypot(u, y), pt = Math.hypot(B, N);
                  if (d === 0)
                    $ = pt / st, K = dt / st;
                  else {
                    const gt = d * st;
                    $ = pt > gt ? pt / gt : 1, K = dt > gt ? dt / gt : 1;
                  }
                }
                this._cachedScaleForStroking[0] = $, this._cachedScaleForStroking[1] = K;
              }
              return this._cachedScaleForStroking;
            }
            rescaleAndStroke(d) {
              const {
                ctx: u
              } = this, {
                lineWidth: y
              } = this.current, [B, N] = this.getScaleForStroking();
              if (u.lineWidth = y || 1, B === 1 && N === 1) {
                u.stroke();
                return;
              }
              const $ = u.getLineDash();
              if (d && u.save(), u.scale(B, N), $.length > 0) {
                const K = Math.max(B, N);
                u.setLineDash($.map((st) => st / K)), u.lineDashOffset /= K;
              }
              u.stroke(), d && u.restore();
            }
            isContentVisible() {
              for (let d = this.markedContentStack.length - 1; d >= 0; d--)
                if (!this.markedContentStack[d].visible)
                  return !1;
              return !0;
            }
          };
          et = new WeakSet(), Xe = function() {
            for (; this.stateStack.length || this.inSMaskMode; )
              this.restore();
            this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.transparentCanvas = null);
          }, Ve = function() {
            if (this.pageColors) {
              const d = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
              if (d !== "none") {
                const u = this.ctx.filter;
                this.ctx.filter = d, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = u;
              }
            }
          };
          let L = Q;
          t.CanvasGraphics = L;
          for (const F in e.OPS)
            L.prototype[F] !== void 0 && (L.prototype[e.OPS[F]] = L.prototype[F]);
        },
        /* 12 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.TilingPattern = t.PathType = void 0, t.getShadingPattern = v;
          var e = n(1), s = n(6);
          const c = {
            FILL: "Fill",
            STROKE: "Stroke",
            SHADING: "Shading"
          };
          t.PathType = c;
          function h(E, w) {
            if (!w)
              return;
            const M = w[2] - w[0], g = w[3] - w[1], p = new Path2D();
            p.rect(w[0], w[1], M, g), E.clip(p);
          }
          class b {
            constructor() {
              this.constructor === b && (0, e.unreachable)("Cannot initialize BaseShadingPattern.");
            }
            getPattern() {
              (0, e.unreachable)("Abstract method `getPattern` called.");
            }
          }
          class o extends b {
            constructor(w) {
              super(), this._type = w[1], this._bbox = w[2], this._colorStops = w[3], this._p0 = w[4], this._p1 = w[5], this._r0 = w[6], this._r1 = w[7], this.matrix = null;
            }
            _createGradient(w) {
              let M;
              this._type === "axial" ? M = w.createLinearGradient(this._p0[0], this._p0[1], this._p1[0], this._p1[1]) : this._type === "radial" && (M = w.createRadialGradient(this._p0[0], this._p0[1], this._r0, this._p1[0], this._p1[1], this._r1));
              for (const g of this._colorStops)
                M.addColorStop(g[0], g[1]);
              return M;
            }
            getPattern(w, M, g, p) {
              let _;
              if (p === c.STROKE || p === c.FILL) {
                const f = M.current.getClippedPathBoundingBox(p, (0, s.getCurrentTransform)(w)) || [0, 0, 0, 0], A = Math.ceil(f[2] - f[0]) || 1, C = Math.ceil(f[3] - f[1]) || 1, W = M.cachedCanvases.getCanvas("pattern", A, C, !0), m = W.context;
                m.clearRect(0, 0, m.canvas.width, m.canvas.height), m.beginPath(), m.rect(0, 0, m.canvas.width, m.canvas.height), m.translate(-f[0], -f[1]), g = e.Util.transform(g, [1, 0, 0, 1, f[0], f[1]]), m.transform(...M.baseTransform), this.matrix && m.transform(...this.matrix), h(m, this._bbox), m.fillStyle = this._createGradient(m), m.fill(), _ = w.createPattern(W.canvas, "no-repeat");
                const I = new DOMMatrix(g);
                _.setTransform(I);
              } else
                h(w, this._bbox), _ = this._createGradient(w);
              return _;
            }
          }
          function l(E, w, M, g, p, _, f, A) {
            const C = w.coords, W = w.colors, m = E.data, I = E.width * 4;
            let q;
            C[M + 1] > C[g + 1] && (q = M, M = g, g = q, q = _, _ = f, f = q), C[g + 1] > C[p + 1] && (q = g, g = p, p = q, q = f, f = A, A = q), C[M + 1] > C[g + 1] && (q = M, M = g, g = q, q = _, _ = f, f = q);
            const Y = (C[M] + w.offsetX) * w.scaleX, X = (C[M + 1] + w.offsetY) * w.scaleY, z = (C[g] + w.offsetX) * w.scaleX, L = (C[g + 1] + w.offsetY) * w.scaleY, et = (C[p] + w.offsetX) * w.scaleX, D = (C[p + 1] + w.offsetY) * w.scaleY;
            if (X >= D)
              return;
            const G = W[_], Q = W[_ + 1], F = W[_ + 2], d = W[f], u = W[f + 1], y = W[f + 2], B = W[A], N = W[A + 1], $ = W[A + 2], K = Math.round(X), st = Math.round(D);
            let dt, pt, gt, mt, ut, tt, it, R;
            for (let U = K; U <= st; U++) {
              if (U < L) {
                const vt = U < X ? 0 : (X - U) / (X - L);
                dt = Y - (Y - z) * vt, pt = G - (G - d) * vt, gt = Q - (Q - u) * vt, mt = F - (F - y) * vt;
              } else {
                let vt;
                U > D ? vt = 1 : L === D ? vt = 0 : vt = (L - U) / (L - D), dt = z - (z - et) * vt, pt = d - (d - B) * vt, gt = u - (u - N) * vt, mt = y - (y - $) * vt;
              }
              let J;
              U < X ? J = 0 : U > D ? J = 1 : J = (X - U) / (X - D), ut = Y - (Y - et) * J, tt = G - (G - B) * J, it = Q - (Q - N) * J, R = F - (F - $) * J;
              const rt = Math.round(Math.min(dt, ut)), _t = Math.round(Math.max(dt, ut));
              let wt = I * U + rt * 4;
              for (let vt = rt; vt <= _t; vt++)
                J = (dt - vt) / (dt - ut), J < 0 ? J = 0 : J > 1 && (J = 1), m[wt++] = pt - (pt - tt) * J | 0, m[wt++] = gt - (gt - it) * J | 0, m[wt++] = mt - (mt - R) * J | 0, m[wt++] = 255;
            }
          }
          function a(E, w, M) {
            const g = w.coords, p = w.colors;
            let _, f;
            switch (w.type) {
              case "lattice":
                const A = w.verticesPerRow, C = Math.floor(g.length / A) - 1, W = A - 1;
                for (_ = 0; _ < C; _++) {
                  let m = _ * A;
                  for (let I = 0; I < W; I++, m++)
                    l(E, M, g[m], g[m + 1], g[m + A], p[m], p[m + 1], p[m + A]), l(E, M, g[m + A + 1], g[m + 1], g[m + A], p[m + A + 1], p[m + 1], p[m + A]);
                }
                break;
              case "triangles":
                for (_ = 0, f = g.length; _ < f; _ += 3)
                  l(E, M, g[_], g[_ + 1], g[_ + 2], p[_], p[_ + 1], p[_ + 2]);
                break;
              default:
                throw new Error("illegal figure");
            }
          }
          class T extends b {
            constructor(w) {
              super(), this._coords = w[2], this._colors = w[3], this._figures = w[4], this._bounds = w[5], this._bbox = w[7], this._background = w[8], this.matrix = null;
            }
            _createMeshCanvas(w, M, g) {
              const A = Math.floor(this._bounds[0]), C = Math.floor(this._bounds[1]), W = Math.ceil(this._bounds[2]) - A, m = Math.ceil(this._bounds[3]) - C, I = Math.min(Math.ceil(Math.abs(W * w[0] * 1.1)), 3e3), q = Math.min(Math.ceil(Math.abs(m * w[1] * 1.1)), 3e3), Y = W / I, X = m / q, z = {
                coords: this._coords,
                colors: this._colors,
                offsetX: -A,
                offsetY: -C,
                scaleX: 1 / Y,
                scaleY: 1 / X
              }, L = I + 2 * 2, et = q + 2 * 2, D = g.getCanvas("mesh", L, et, !1), G = D.context, Q = G.createImageData(I, q);
              if (M) {
                const d = Q.data;
                for (let u = 0, y = d.length; u < y; u += 4)
                  d[u] = M[0], d[u + 1] = M[1], d[u + 2] = M[2], d[u + 3] = 255;
              }
              for (const d of this._figures)
                a(Q, d, z);
              return G.putImageData(Q, 2, 2), {
                canvas: D.canvas,
                offsetX: A - 2 * Y,
                offsetY: C - 2 * X,
                scaleX: Y,
                scaleY: X
              };
            }
            getPattern(w, M, g, p) {
              h(w, this._bbox);
              let _;
              if (p === c.SHADING)
                _ = e.Util.singularValueDecompose2dScale((0, s.getCurrentTransform)(w));
              else if (_ = e.Util.singularValueDecompose2dScale(M.baseTransform), this.matrix) {
                const A = e.Util.singularValueDecompose2dScale(this.matrix);
                _ = [_[0] * A[0], _[1] * A[1]];
              }
              const f = this._createMeshCanvas(_, p === c.SHADING ? null : this._background, M.cachedCanvases);
              return p !== c.SHADING && (w.setTransform(...M.baseTransform), this.matrix && w.transform(...this.matrix)), w.translate(f.offsetX, f.offsetY), w.scale(f.scaleX, f.scaleY), w.createPattern(f.canvas, "no-repeat");
            }
          }
          class P extends b {
            getPattern() {
              return "hotpink";
            }
          }
          function v(E) {
            switch (E[0]) {
              case "RadialAxial":
                return new o(E);
              case "Mesh":
                return new T(E);
              case "Dummy":
                return new P();
            }
            throw new Error(`Unknown IR type: ${E[0]}`);
          }
          const k = {
            COLORED: 1,
            UNCOLORED: 2
          }, S = class S {
            constructor(w, M, g, p, _) {
              this.operatorList = w[2], this.matrix = w[3] || [1, 0, 0, 1, 0, 0], this.bbox = w[4], this.xstep = w[5], this.ystep = w[6], this.paintType = w[7], this.tilingType = w[8], this.color = M, this.ctx = g, this.canvasGraphicsFactory = p, this.baseTransform = _;
            }
            createPatternCanvas(w) {
              const M = this.operatorList, g = this.bbox, p = this.xstep, _ = this.ystep, f = this.paintType, A = this.tilingType, C = this.color, W = this.canvasGraphicsFactory;
              (0, e.info)("TilingType: " + A);
              const m = g[0], I = g[1], q = g[2], Y = g[3], X = e.Util.singularValueDecompose2dScale(this.matrix), z = e.Util.singularValueDecompose2dScale(this.baseTransform), L = [X[0] * z[0], X[1] * z[1]], et = this.getSizeAndScale(p, this.ctx.canvas.width, L[0]), D = this.getSizeAndScale(_, this.ctx.canvas.height, L[1]), G = w.cachedCanvases.getCanvas("pattern", et.size, D.size, !0), Q = G.context, F = W.createCanvasGraphics(Q);
              F.groupLevel = w.groupLevel, this.setFillAndStrokeStyleToContext(F, f, C);
              let d = m, u = I, y = q, B = Y;
              return m < 0 && (d = 0, y += Math.abs(m)), I < 0 && (u = 0, B += Math.abs(I)), Q.translate(-(et.scale * d), -(D.scale * u)), F.transform(et.scale, 0, 0, D.scale, 0, 0), Q.save(), this.clipBbox(F, d, u, y, B), F.baseTransform = (0, s.getCurrentTransform)(F.ctx), F.executeOperatorList(M), F.endDrawing(), {
                canvas: G.canvas,
                scaleX: et.scale,
                scaleY: D.scale,
                offsetX: d,
                offsetY: u
              };
            }
            getSizeAndScale(w, M, g) {
              w = Math.abs(w);
              const p = Math.max(S.MAX_PATTERN_SIZE, M);
              let _ = Math.ceil(w * g);
              return _ >= p ? _ = p : g = _ / w, {
                scale: g,
                size: _
              };
            }
            clipBbox(w, M, g, p, _) {
              const f = p - M, A = _ - g;
              w.ctx.rect(M, g, f, A), w.current.updateRectMinMax((0, s.getCurrentTransform)(w.ctx), [M, g, p, _]), w.clip(), w.endPath();
            }
            setFillAndStrokeStyleToContext(w, M, g) {
              const p = w.ctx, _ = w.current;
              switch (M) {
                case k.COLORED:
                  const f = this.ctx;
                  p.fillStyle = f.fillStyle, p.strokeStyle = f.strokeStyle, _.fillColor = f.fillStyle, _.strokeColor = f.strokeStyle;
                  break;
                case k.UNCOLORED:
                  const A = e.Util.makeHexColor(g[0], g[1], g[2]);
                  p.fillStyle = A, p.strokeStyle = A, _.fillColor = A, _.strokeColor = A;
                  break;
                default:
                  throw new e.FormatError(`Unsupported paint type: ${M}`);
              }
            }
            getPattern(w, M, g, p) {
              let _ = g;
              p !== c.SHADING && (_ = e.Util.transform(_, M.baseTransform), this.matrix && (_ = e.Util.transform(_, this.matrix)));
              const f = this.createPatternCanvas(M);
              let A = new DOMMatrix(_);
              A = A.translate(f.offsetX, f.offsetY), A = A.scale(1 / f.scaleX, 1 / f.scaleY);
              const C = w.createPattern(f.canvas, "repeat");
              return C.setTransform(A), C;
            }
          };
          Kt(S, "MAX_PATTERN_SIZE", 3e3);
          let x = S;
          t.TilingPattern = x;
        },
        /* 13 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.convertBlackAndWhiteToRGBA = c, t.convertToRGBA = s, t.grayToRGBA = b;
          var e = n(1);
          function s(o) {
            switch (o.kind) {
              case e.ImageKind.GRAYSCALE_1BPP:
                return c(o);
              case e.ImageKind.RGB_24BPP:
                return h(o);
            }
            return null;
          }
          function c({
            src: o,
            srcPos: l = 0,
            dest: a,
            width: T,
            height: P,
            nonBlackColor: v = 4294967295,
            inverseDecode: k = !1
          }) {
            const x = e.FeatureTest.isLittleEndian ? 4278190080 : 255, [S, E] = k ? [v, x] : [x, v], w = T >> 3, M = T & 7, g = o.length;
            a = new Uint32Array(a.buffer);
            let p = 0;
            for (let _ = 0; _ < P; _++) {
              for (const A = l + w; l < A; l++) {
                const C = l < g ? o[l] : 255;
                a[p++] = C & 128 ? E : S, a[p++] = C & 64 ? E : S, a[p++] = C & 32 ? E : S, a[p++] = C & 16 ? E : S, a[p++] = C & 8 ? E : S, a[p++] = C & 4 ? E : S, a[p++] = C & 2 ? E : S, a[p++] = C & 1 ? E : S;
              }
              if (M === 0)
                continue;
              const f = l < g ? o[l++] : 255;
              for (let A = 0; A < M; A++)
                a[p++] = f & 1 << 7 - A ? E : S;
            }
            return {
              srcPos: l,
              destPos: p
            };
          }
          function h({
            src: o,
            srcPos: l = 0,
            dest: a,
            destPos: T = 0,
            width: P,
            height: v
          }) {
            let k = 0;
            const x = o.length >> 2, S = new Uint32Array(o.buffer, l, x);
            if (e.FeatureTest.isLittleEndian) {
              for (; k < x - 2; k += 3, T += 4) {
                const E = S[k], w = S[k + 1], M = S[k + 2];
                a[T] = E | 4278190080, a[T + 1] = E >>> 24 | w << 8 | 4278190080, a[T + 2] = w >>> 16 | M << 16 | 4278190080, a[T + 3] = M >>> 8 | 4278190080;
              }
              for (let E = k * 4, w = o.length; E < w; E += 3)
                a[T++] = o[E] | o[E + 1] << 8 | o[E + 2] << 16 | 4278190080;
            } else {
              for (; k < x - 2; k += 3, T += 4) {
                const E = S[k], w = S[k + 1], M = S[k + 2];
                a[T] = E | 255, a[T + 1] = E << 24 | w >>> 8 | 255, a[T + 2] = w << 16 | M >>> 16 | 255, a[T + 3] = M << 8 | 255;
              }
              for (let E = k * 4, w = o.length; E < w; E += 3)
                a[T++] = o[E] << 24 | o[E + 1] << 16 | o[E + 2] << 8 | 255;
            }
            return {
              srcPos: l,
              destPos: T
            };
          }
          function b(o, l) {
            if (e.FeatureTest.isLittleEndian)
              for (let a = 0, T = o.length; a < T; a++)
                l[a] = o[a] * 65793 | 4278190080;
            else
              for (let a = 0, T = o.length; a < T; a++)
                l[a] = o[a] * 16843008 | 255;
          }
        },
        /* 14 */
        /***/
        (i, t) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.GlobalWorkerOptions = void 0;
          const n = /* @__PURE__ */ Object.create(null);
          t.GlobalWorkerOptions = n, n.workerPort = null, n.workerSrc = "";
        },
        /* 15 */
        /***/
        (i, t, n) => {
          var o, kn, Tn, Se;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.MessageHandler = void 0;
          var e = n(1);
          const s = {
            UNKNOWN: 0,
            DATA: 1,
            ERROR: 2
          }, c = {
            UNKNOWN: 0,
            CANCEL: 1,
            CANCEL_COMPLETE: 2,
            CLOSE: 3,
            ENQUEUE: 4,
            ERROR: 5,
            PULL: 6,
            PULL_COMPLETE: 7,
            START_COMPLETE: 8
          };
          function h(P) {
            switch (P instanceof Error || typeof P == "object" && P !== null || (0, e.unreachable)('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), P.name) {
              case "AbortException":
                return new e.AbortException(P.message);
              case "MissingPDFException":
                return new e.MissingPDFException(P.message);
              case "PasswordException":
                return new e.PasswordException(P.message, P.code);
              case "UnexpectedResponseException":
                return new e.UnexpectedResponseException(P.message, P.status);
              case "UnknownErrorException":
                return new e.UnknownErrorException(P.message, P.details);
              default:
                return new e.UnknownErrorException(P.message, P.toString());
            }
          }
          class b {
            constructor(v, k, x) {
              at(this, o);
              this.sourceName = v, this.targetName = k, this.comObj = x, this.callbackId = 1, this.streamId = 1, this.streamSinks = /* @__PURE__ */ Object.create(null), this.streamControllers = /* @__PURE__ */ Object.create(null), this.callbackCapabilities = /* @__PURE__ */ Object.create(null), this.actionHandler = /* @__PURE__ */ Object.create(null), this._onComObjOnMessage = (S) => {
                const E = S.data;
                if (E.targetName !== this.sourceName)
                  return;
                if (E.stream) {
                  Z(this, o, Tn).call(this, E);
                  return;
                }
                if (E.callback) {
                  const M = E.callbackId, g = this.callbackCapabilities[M];
                  if (!g)
                    throw new Error(`Cannot resolve callback ${M}`);
                  if (delete this.callbackCapabilities[M], E.callback === s.DATA)
                    g.resolve(E.data);
                  else if (E.callback === s.ERROR)
                    g.reject(h(E.reason));
                  else
                    throw new Error("Unexpected callback case");
                  return;
                }
                const w = this.actionHandler[E.action];
                if (!w)
                  throw new Error(`Unknown action from worker: ${E.action}`);
                if (E.callbackId) {
                  const M = this.sourceName, g = E.sourceName;
                  new Promise(function(p) {
                    p(w(E.data));
                  }).then(function(p) {
                    x.postMessage({
                      sourceName: M,
                      targetName: g,
                      callback: s.DATA,
                      callbackId: E.callbackId,
                      data: p
                    });
                  }, function(p) {
                    x.postMessage({
                      sourceName: M,
                      targetName: g,
                      callback: s.ERROR,
                      callbackId: E.callbackId,
                      reason: h(p)
                    });
                  });
                  return;
                }
                if (E.streamId) {
                  Z(this, o, kn).call(this, E);
                  return;
                }
                w(E.data);
              }, x.addEventListener("message", this._onComObjOnMessage);
            }
            on(v, k) {
              const x = this.actionHandler;
              if (x[v])
                throw new Error(`There is already an actionName called "${v}"`);
              x[v] = k;
            }
            send(v, k, x) {
              this.comObj.postMessage({
                sourceName: this.sourceName,
                targetName: this.targetName,
                action: v,
                data: k
              }, x);
            }
            sendWithPromise(v, k, x) {
              const S = this.callbackId++, E = new e.PromiseCapability();
              this.callbackCapabilities[S] = E;
              try {
                this.comObj.postMessage({
                  sourceName: this.sourceName,
                  targetName: this.targetName,
                  action: v,
                  callbackId: S,
                  data: k
                }, x);
              } catch (w) {
                E.reject(w);
              }
              return E.promise;
            }
            sendWithStream(v, k, x, S) {
              const E = this.streamId++, w = this.sourceName, M = this.targetName, g = this.comObj;
              return new ReadableStream({
                start: (p) => {
                  const _ = new e.PromiseCapability();
                  return this.streamControllers[E] = {
                    controller: p,
                    startCall: _,
                    pullCall: null,
                    cancelCall: null,
                    isClosed: !1
                  }, g.postMessage({
                    sourceName: w,
                    targetName: M,
                    action: v,
                    streamId: E,
                    data: k,
                    desiredSize: p.desiredSize
                  }, S), _.promise;
                },
                pull: (p) => {
                  const _ = new e.PromiseCapability();
                  return this.streamControllers[E].pullCall = _, g.postMessage({
                    sourceName: w,
                    targetName: M,
                    stream: c.PULL,
                    streamId: E,
                    desiredSize: p.desiredSize
                  }), _.promise;
                },
                cancel: (p) => {
                  (0, e.assert)(p instanceof Error, "cancel must have a valid reason");
                  const _ = new e.PromiseCapability();
                  return this.streamControllers[E].cancelCall = _, this.streamControllers[E].isClosed = !0, g.postMessage({
                    sourceName: w,
                    targetName: M,
                    stream: c.CANCEL,
                    streamId: E,
                    reason: h(p)
                  }), _.promise;
                }
              }, x);
            }
            destroy() {
              this.comObj.removeEventListener("message", this._onComObjOnMessage);
            }
          }
          o = new WeakSet(), kn = function(v) {
            const k = v.streamId, x = this.sourceName, S = v.sourceName, E = this.comObj, w = this, M = this.actionHandler[v.action], g = {
              enqueue(p, _ = 1, f) {
                if (this.isCancelled)
                  return;
                const A = this.desiredSize;
                this.desiredSize -= _, A > 0 && this.desiredSize <= 0 && (this.sinkCapability = new e.PromiseCapability(), this.ready = this.sinkCapability.promise), E.postMessage({
                  sourceName: x,
                  targetName: S,
                  stream: c.ENQUEUE,
                  streamId: k,
                  chunk: p
                }, f);
              },
              close() {
                this.isCancelled || (this.isCancelled = !0, E.postMessage({
                  sourceName: x,
                  targetName: S,
                  stream: c.CLOSE,
                  streamId: k
                }), delete w.streamSinks[k]);
              },
              error(p) {
                (0, e.assert)(p instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, E.postMessage({
                  sourceName: x,
                  targetName: S,
                  stream: c.ERROR,
                  streamId: k,
                  reason: h(p)
                }));
              },
              sinkCapability: new e.PromiseCapability(),
              onPull: null,
              onCancel: null,
              isCancelled: !1,
              desiredSize: v.desiredSize,
              ready: null
            };
            g.sinkCapability.resolve(), g.ready = g.sinkCapability.promise, this.streamSinks[k] = g, new Promise(function(p) {
              p(M(v.data, g));
            }).then(function() {
              E.postMessage({
                sourceName: x,
                targetName: S,
                stream: c.START_COMPLETE,
                streamId: k,
                success: !0
              });
            }, function(p) {
              E.postMessage({
                sourceName: x,
                targetName: S,
                stream: c.START_COMPLETE,
                streamId: k,
                reason: h(p)
              });
            });
          }, Tn = function(v) {
            const k = v.streamId, x = this.sourceName, S = v.sourceName, E = this.comObj, w = this.streamControllers[k], M = this.streamSinks[k];
            switch (v.stream) {
              case c.START_COMPLETE:
                v.success ? w.startCall.resolve() : w.startCall.reject(h(v.reason));
                break;
              case c.PULL_COMPLETE:
                v.success ? w.pullCall.resolve() : w.pullCall.reject(h(v.reason));
                break;
              case c.PULL:
                if (!M) {
                  E.postMessage({
                    sourceName: x,
                    targetName: S,
                    stream: c.PULL_COMPLETE,
                    streamId: k,
                    success: !0
                  });
                  break;
                }
                M.desiredSize <= 0 && v.desiredSize > 0 && M.sinkCapability.resolve(), M.desiredSize = v.desiredSize, new Promise(function(g) {
                  var p;
                  g((p = M.onPull) == null ? void 0 : p.call(M));
                }).then(function() {
                  E.postMessage({
                    sourceName: x,
                    targetName: S,
                    stream: c.PULL_COMPLETE,
                    streamId: k,
                    success: !0
                  });
                }, function(g) {
                  E.postMessage({
                    sourceName: x,
                    targetName: S,
                    stream: c.PULL_COMPLETE,
                    streamId: k,
                    reason: h(g)
                  });
                });
                break;
              case c.ENQUEUE:
                if ((0, e.assert)(w, "enqueue should have stream controller"), w.isClosed)
                  break;
                w.controller.enqueue(v.chunk);
                break;
              case c.CLOSE:
                if ((0, e.assert)(w, "close should have stream controller"), w.isClosed)
                  break;
                w.isClosed = !0, w.controller.close(), Z(this, o, Se).call(this, w, k);
                break;
              case c.ERROR:
                (0, e.assert)(w, "error should have stream controller"), w.controller.error(h(v.reason)), Z(this, o, Se).call(this, w, k);
                break;
              case c.CANCEL_COMPLETE:
                v.success ? w.cancelCall.resolve() : w.cancelCall.reject(h(v.reason)), Z(this, o, Se).call(this, w, k);
                break;
              case c.CANCEL:
                if (!M)
                  break;
                new Promise(function(g) {
                  var p;
                  g((p = M.onCancel) == null ? void 0 : p.call(M, h(v.reason)));
                }).then(function() {
                  E.postMessage({
                    sourceName: x,
                    targetName: S,
                    stream: c.CANCEL_COMPLETE,
                    streamId: k,
                    success: !0
                  });
                }, function(g) {
                  E.postMessage({
                    sourceName: x,
                    targetName: S,
                    stream: c.CANCEL_COMPLETE,
                    streamId: k,
                    reason: h(g)
                  });
                }), M.sinkCapability.reject(h(v.reason)), M.isCancelled = !0, delete this.streamSinks[k];
                break;
              default:
                throw new Error("Unexpected stream case");
            }
          }, Se = async function(v, k) {
            var x, S, E;
            await Promise.allSettled([(x = v.startCall) == null ? void 0 : x.promise, (S = v.pullCall) == null ? void 0 : S.promise, (E = v.cancelCall) == null ? void 0 : E.promise]), delete this.streamControllers[k];
          }, t.MessageHandler = b;
        },
        /* 16 */
        /***/
        (i, t, n) => {
          var c, h;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.Metadata = void 0;
          var e = n(1);
          class s {
            constructor({
              parsedData: o,
              rawData: l
            }) {
              at(this, c);
              at(this, h);
              lt(this, c, o), lt(this, h, l);
            }
            getRaw() {
              return r(this, h);
            }
            get(o) {
              return r(this, c).get(o) ?? null;
            }
            getAll() {
              return (0, e.objectFromMap)(r(this, c));
            }
            has(o) {
              return r(this, c).has(o);
            }
          }
          c = new WeakMap(), h = new WeakMap(), t.Metadata = s;
        },
        /* 17 */
        /***/
        (i, t, n) => {
          var o, l, a, T, P, v, Ye;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.OptionalContentConfig = void 0;
          var e = n(1), s = n(8);
          const c = Symbol("INTERNAL");
          class h {
            constructor(S, E) {
              at(this, o, !0);
              this.name = S, this.intent = E;
            }
            get visible() {
              return r(this, o);
            }
            _setVisible(S, E) {
              S !== c && (0, e.unreachable)("Internal method `_setVisible` called."), lt(this, o, E);
            }
          }
          o = new WeakMap();
          class b {
            constructor(S) {
              at(this, v);
              at(this, l, null);
              at(this, a, /* @__PURE__ */ new Map());
              at(this, T, null);
              at(this, P, null);
              if (this.name = null, this.creator = null, S !== null) {
                this.name = S.name, this.creator = S.creator, lt(this, P, S.order);
                for (const E of S.groups)
                  r(this, a).set(E.id, new h(E.name, E.intent));
                if (S.baseState === "OFF")
                  for (const E of r(this, a).values())
                    E._setVisible(c, !1);
                for (const E of S.on)
                  r(this, a).get(E)._setVisible(c, !0);
                for (const E of S.off)
                  r(this, a).get(E)._setVisible(c, !1);
                lt(this, T, this.getHash());
              }
            }
            isVisible(S) {
              if (r(this, a).size === 0)
                return !0;
              if (!S)
                return (0, e.warn)("Optional content group not defined."), !0;
              if (S.type === "OCG")
                return r(this, a).has(S.id) ? r(this, a).get(S.id).visible : ((0, e.warn)(`Optional content group not found: ${S.id}`), !0);
              if (S.type === "OCMD") {
                if (S.expression)
                  return Z(this, v, Ye).call(this, S.expression);
                if (!S.policy || S.policy === "AnyOn") {
                  for (const E of S.ids) {
                    if (!r(this, a).has(E))
                      return (0, e.warn)(`Optional content group not found: ${E}`), !0;
                    if (r(this, a).get(E).visible)
                      return !0;
                  }
                  return !1;
                } else if (S.policy === "AllOn") {
                  for (const E of S.ids) {
                    if (!r(this, a).has(E))
                      return (0, e.warn)(`Optional content group not found: ${E}`), !0;
                    if (!r(this, a).get(E).visible)
                      return !1;
                  }
                  return !0;
                } else if (S.policy === "AnyOff") {
                  for (const E of S.ids) {
                    if (!r(this, a).has(E))
                      return (0, e.warn)(`Optional content group not found: ${E}`), !0;
                    if (!r(this, a).get(E).visible)
                      return !0;
                  }
                  return !1;
                } else if (S.policy === "AllOff") {
                  for (const E of S.ids) {
                    if (!r(this, a).has(E))
                      return (0, e.warn)(`Optional content group not found: ${E}`), !0;
                    if (r(this, a).get(E).visible)
                      return !1;
                  }
                  return !0;
                }
                return (0, e.warn)(`Unknown optional content policy ${S.policy}.`), !0;
              }
              return (0, e.warn)(`Unknown group type ${S.type}.`), !0;
            }
            setVisibility(S, E = !0) {
              if (!r(this, a).has(S)) {
                (0, e.warn)(`Optional content group not found: ${S}`);
                return;
              }
              r(this, a).get(S)._setVisible(c, !!E), lt(this, l, null);
            }
            get hasInitialVisibility() {
              return r(this, T) === null || this.getHash() === r(this, T);
            }
            getOrder() {
              return r(this, a).size ? r(this, P) ? r(this, P).slice() : [...r(this, a).keys()] : null;
            }
            getGroups() {
              return r(this, a).size > 0 ? (0, e.objectFromMap)(r(this, a)) : null;
            }
            getGroup(S) {
              return r(this, a).get(S) || null;
            }
            getHash() {
              if (r(this, l) !== null)
                return r(this, l);
              const S = new s.MurmurHash3_64();
              for (const [E, w] of r(this, a))
                S.update(`${E}:${w.visible}`);
              return lt(this, l, S.hexdigest());
            }
          }
          l = new WeakMap(), a = new WeakMap(), T = new WeakMap(), P = new WeakMap(), v = new WeakSet(), Ye = function(S) {
            const E = S.length;
            if (E < 2)
              return !0;
            const w = S[0];
            for (let M = 1; M < E; M++) {
              const g = S[M];
              let p;
              if (Array.isArray(g))
                p = Z(this, v, Ye).call(this, g);
              else if (r(this, a).has(g))
                p = r(this, a).get(g).visible;
              else
                return (0, e.warn)(`Optional content group not found: ${g}`), !0;
              switch (w) {
                case "And":
                  if (!p)
                    return !1;
                  break;
                case "Or":
                  if (p)
                    return !0;
                  break;
                case "Not":
                  return !p;
                default:
                  return !0;
              }
            }
            return w === "And";
          }, t.OptionalContentConfig = b;
        },
        /* 18 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.PDFDataTransportStream = void 0;
          var e = n(1), s = n(6);
          class c {
            constructor({
              length: l,
              initialData: a,
              progressiveDone: T = !1,
              contentDispositionFilename: P = null,
              disableRange: v = !1,
              disableStream: k = !1
            }, x) {
              if ((0, e.assert)(x, 'PDFDataTransportStream - missing required "pdfDataRangeTransport" argument.'), this._queuedChunks = [], this._progressiveDone = T, this._contentDispositionFilename = P, (a == null ? void 0 : a.length) > 0) {
                const S = a instanceof Uint8Array && a.byteLength === a.buffer.byteLength ? a.buffer : new Uint8Array(a).buffer;
                this._queuedChunks.push(S);
              }
              this._pdfDataRangeTransport = x, this._isStreamingSupported = !k, this._isRangeSupported = !v, this._contentLength = l, this._fullRequestReader = null, this._rangeReaders = [], this._pdfDataRangeTransport.addRangeListener((S, E) => {
                this._onReceiveData({
                  begin: S,
                  chunk: E
                });
              }), this._pdfDataRangeTransport.addProgressListener((S, E) => {
                this._onProgress({
                  loaded: S,
                  total: E
                });
              }), this._pdfDataRangeTransport.addProgressiveReadListener((S) => {
                this._onReceiveData({
                  chunk: S
                });
              }), this._pdfDataRangeTransport.addProgressiveDoneListener(() => {
                this._onProgressiveDone();
              }), this._pdfDataRangeTransport.transportReady();
            }
            _onReceiveData({
              begin: l,
              chunk: a
            }) {
              const T = a instanceof Uint8Array && a.byteLength === a.buffer.byteLength ? a.buffer : new Uint8Array(a).buffer;
              if (l === void 0)
                this._fullRequestReader ? this._fullRequestReader._enqueue(T) : this._queuedChunks.push(T);
              else {
                const P = this._rangeReaders.some(function(v) {
                  return v._begin !== l ? !1 : (v._enqueue(T), !0);
                });
                (0, e.assert)(P, "_onReceiveData - no `PDFDataTransportStreamRangeReader` instance found.");
              }
            }
            get _progressiveDataLength() {
              var l;
              return ((l = this._fullRequestReader) == null ? void 0 : l._loaded) ?? 0;
            }
            _onProgress(l) {
              var a, T, P, v;
              l.total === void 0 ? (T = (a = this._rangeReaders[0]) == null ? void 0 : a.onProgress) == null || T.call(a, {
                loaded: l.loaded
              }) : (v = (P = this._fullRequestReader) == null ? void 0 : P.onProgress) == null || v.call(P, {
                loaded: l.loaded,
                total: l.total
              });
            }
            _onProgressiveDone() {
              var l;
              (l = this._fullRequestReader) == null || l.progressiveDone(), this._progressiveDone = !0;
            }
            _removeRangeReader(l) {
              const a = this._rangeReaders.indexOf(l);
              a >= 0 && this._rangeReaders.splice(a, 1);
            }
            getFullReader() {
              (0, e.assert)(!this._fullRequestReader, "PDFDataTransportStream.getFullReader can only be called once.");
              const l = this._queuedChunks;
              return this._queuedChunks = null, new h(this, l, this._progressiveDone, this._contentDispositionFilename);
            }
            getRangeReader(l, a) {
              if (a <= this._progressiveDataLength)
                return null;
              const T = new b(this, l, a);
              return this._pdfDataRangeTransport.requestDataRange(l, a), this._rangeReaders.push(T), T;
            }
            cancelAllRequests(l) {
              var a;
              (a = this._fullRequestReader) == null || a.cancel(l);
              for (const T of this._rangeReaders.slice(0))
                T.cancel(l);
              this._pdfDataRangeTransport.abort();
            }
          }
          t.PDFDataTransportStream = c;
          class h {
            constructor(l, a, T = !1, P = null) {
              this._stream = l, this._done = T || !1, this._filename = (0, s.isPdfFile)(P) ? P : null, this._queuedChunks = a || [], this._loaded = 0;
              for (const v of this._queuedChunks)
                this._loaded += v.byteLength;
              this._requests = [], this._headersReady = Promise.resolve(), l._fullRequestReader = this, this.onProgress = null;
            }
            _enqueue(l) {
              this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
                value: l,
                done: !1
              }) : this._queuedChunks.push(l), this._loaded += l.byteLength);
            }
            get headersReady() {
              return this._headersReady;
            }
            get filename() {
              return this._filename;
            }
            get isRangeSupported() {
              return this._stream._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._stream._isStreamingSupported;
            }
            get contentLength() {
              return this._stream._contentLength;
            }
            async read() {
              if (this._queuedChunks.length > 0)
                return {
                  value: this._queuedChunks.shift(),
                  done: !1
                };
              if (this._done)
                return {
                  value: void 0,
                  done: !0
                };
              const l = new e.PromiseCapability();
              return this._requests.push(l), l.promise;
            }
            cancel(l) {
              this._done = !0;
              for (const a of this._requests)
                a.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0;
            }
            progressiveDone() {
              this._done || (this._done = !0);
            }
          }
          class b {
            constructor(l, a, T) {
              this._stream = l, this._begin = a, this._end = T, this._queuedChunk = null, this._requests = [], this._done = !1, this.onProgress = null;
            }
            _enqueue(l) {
              if (!this._done) {
                if (this._requests.length === 0)
                  this._queuedChunk = l;
                else {
                  this._requests.shift().resolve({
                    value: l,
                    done: !1
                  });
                  for (const T of this._requests)
                    T.resolve({
                      value: void 0,
                      done: !0
                    });
                  this._requests.length = 0;
                }
                this._done = !0, this._stream._removeRangeReader(this);
              }
            }
            get isStreamingSupported() {
              return !1;
            }
            async read() {
              if (this._queuedChunk) {
                const a = this._queuedChunk;
                return this._queuedChunk = null, {
                  value: a,
                  done: !1
                };
              }
              if (this._done)
                return {
                  value: void 0,
                  done: !0
                };
              const l = new e.PromiseCapability();
              return this._requests.push(l), l.promise;
            }
            cancel(l) {
              this._done = !0;
              for (const a of this._requests)
                a.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0, this._stream._removeRangeReader(this);
            }
          }
        },
        /* 19 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.PDFFetchStream = void 0;
          var e = n(1), s = n(20);
          function c(T, P, v) {
            return {
              method: "GET",
              headers: T,
              signal: v.signal,
              mode: "cors",
              credentials: P ? "include" : "same-origin",
              redirect: "follow"
            };
          }
          function h(T) {
            const P = new Headers();
            for (const v in T) {
              const k = T[v];
              k !== void 0 && P.append(v, k);
            }
            return P;
          }
          function b(T) {
            return T instanceof Uint8Array ? T.buffer : T instanceof ArrayBuffer ? T : ((0, e.warn)(`getArrayBuffer - unexpected data format: ${T}`), new Uint8Array(T).buffer);
          }
          class o {
            constructor(P) {
              this.source = P, this.isHttp = /^https?:/i.test(P.url), this.httpHeaders = this.isHttp && P.httpHeaders || {}, this._fullRequestReader = null, this._rangeRequestReaders = [];
            }
            get _progressiveDataLength() {
              var P;
              return ((P = this._fullRequestReader) == null ? void 0 : P._loaded) ?? 0;
            }
            getFullReader() {
              return (0, e.assert)(!this._fullRequestReader, "PDFFetchStream.getFullReader can only be called once."), this._fullRequestReader = new l(this), this._fullRequestReader;
            }
            getRangeReader(P, v) {
              if (v <= this._progressiveDataLength)
                return null;
              const k = new a(this, P, v);
              return this._rangeRequestReaders.push(k), k;
            }
            cancelAllRequests(P) {
              var v;
              (v = this._fullRequestReader) == null || v.cancel(P);
              for (const k of this._rangeRequestReaders.slice(0))
                k.cancel(P);
            }
          }
          t.PDFFetchStream = o;
          class l {
            constructor(P) {
              this._stream = P, this._reader = null, this._loaded = 0, this._filename = null;
              const v = P.source;
              this._withCredentials = v.withCredentials || !1, this._contentLength = v.length, this._headersCapability = new e.PromiseCapability(), this._disableRange = v.disableRange || !1, this._rangeChunkSize = v.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._abortController = new AbortController(), this._isStreamingSupported = !v.disableStream, this._isRangeSupported = !v.disableRange, this._headers = h(this._stream.httpHeaders);
              const k = v.url;
              fetch(k, c(this._headers, this._withCredentials, this._abortController)).then((x) => {
                if (!(0, s.validateResponseStatus)(x.status))
                  throw (0, s.createResponseStatusError)(x.status, k);
                this._reader = x.body.getReader(), this._headersCapability.resolve();
                const S = (M) => x.headers.get(M), {
                  allowRangeRequests: E,
                  suggestedLength: w
                } = (0, s.validateRangeRequestCapabilities)({
                  getResponseHeader: S,
                  isHttp: this._stream.isHttp,
                  rangeChunkSize: this._rangeChunkSize,
                  disableRange: this._disableRange
                });
                this._isRangeSupported = E, this._contentLength = w || this._contentLength, this._filename = (0, s.extractFilenameFromHeader)(S), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new e.AbortException("Streaming is disabled."));
              }).catch(this._headersCapability.reject), this.onProgress = null;
            }
            get headersReady() {
              return this._headersCapability.promise;
            }
            get filename() {
              return this._filename;
            }
            get contentLength() {
              return this._contentLength;
            }
            get isRangeSupported() {
              return this._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              var k;
              await this._headersCapability.promise;
              const {
                value: P,
                done: v
              } = await this._reader.read();
              return v ? {
                value: P,
                done: v
              } : (this._loaded += P.byteLength, (k = this.onProgress) == null || k.call(this, {
                loaded: this._loaded,
                total: this._contentLength
              }), {
                value: b(P),
                done: !1
              });
            }
            cancel(P) {
              var v;
              (v = this._reader) == null || v.cancel(P), this._abortController.abort();
            }
          }
          class a {
            constructor(P, v, k) {
              this._stream = P, this._reader = null, this._loaded = 0;
              const x = P.source;
              this._withCredentials = x.withCredentials || !1, this._readCapability = new e.PromiseCapability(), this._isStreamingSupported = !x.disableStream, this._abortController = new AbortController(), this._headers = h(this._stream.httpHeaders), this._headers.append("Range", `bytes=${v}-${k - 1}`);
              const S = x.url;
              fetch(S, c(this._headers, this._withCredentials, this._abortController)).then((E) => {
                if (!(0, s.validateResponseStatus)(E.status))
                  throw (0, s.createResponseStatusError)(E.status, S);
                this._readCapability.resolve(), this._reader = E.body.getReader();
              }).catch(this._readCapability.reject), this.onProgress = null;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              var k;
              await this._readCapability.promise;
              const {
                value: P,
                done: v
              } = await this._reader.read();
              return v ? {
                value: P,
                done: v
              } : (this._loaded += P.byteLength, (k = this.onProgress) == null || k.call(this, {
                loaded: this._loaded
              }), {
                value: b(P),
                done: !1
              });
            }
            cancel(P) {
              var v;
              (v = this._reader) == null || v.cancel(P), this._abortController.abort();
            }
          }
        },
        /* 20 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.createResponseStatusError = o, t.extractFilenameFromHeader = b, t.validateRangeRequestCapabilities = h, t.validateResponseStatus = l;
          var e = n(1), s = n(21), c = n(6);
          function h({
            getResponseHeader: a,
            isHttp: T,
            rangeChunkSize: P,
            disableRange: v
          }) {
            const k = {
              allowRangeRequests: !1,
              suggestedLength: void 0
            }, x = parseInt(a("Content-Length"), 10);
            return !Number.isInteger(x) || (k.suggestedLength = x, x <= 2 * P) || v || !T || a("Accept-Ranges") !== "bytes" || (a("Content-Encoding") || "identity") !== "identity" || (k.allowRangeRequests = !0), k;
          }
          function b(a) {
            const T = a("Content-Disposition");
            if (T) {
              let P = (0, s.getFilenameFromContentDispositionHeader)(T);
              if (P.includes("%"))
                try {
                  P = decodeURIComponent(P);
                } catch {
                }
              if ((0, c.isPdfFile)(P))
                return P;
            }
            return null;
          }
          function o(a, T) {
            return a === 404 || a === 0 && T.startsWith("file:") ? new e.MissingPDFException('Missing PDF "' + T + '".') : new e.UnexpectedResponseException(`Unexpected server response (${a}) while retrieving PDF "${T}".`, a);
          }
          function l(a) {
            return a === 200 || a === 206;
          }
        },
        /* 21 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.getFilenameFromContentDispositionHeader = s;
          var e = n(1);
          function s(c) {
            let h = !0, b = o("filename\\*", "i").exec(c);
            if (b) {
              b = b[1];
              let x = P(b);
              return x = unescape(x), x = v(x), x = k(x), a(x);
            }
            if (b = T(c), b) {
              const x = k(b);
              return a(x);
            }
            if (b = o("filename", "i").exec(c), b) {
              b = b[1];
              let x = P(b);
              return x = k(x), a(x);
            }
            function o(x, S) {
              return new RegExp("(?:^|;)\\s*" + x + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', S);
            }
            function l(x, S) {
              if (x) {
                if (!/^[\x00-\xFF]+$/.test(S))
                  return S;
                try {
                  const E = new TextDecoder(x, {
                    fatal: !0
                  }), w = (0, e.stringToBytes)(S);
                  S = E.decode(w), h = !1;
                } catch {
                }
              }
              return S;
            }
            function a(x) {
              return h && /[\x80-\xff]/.test(x) && (x = l("utf-8", x), h && (x = l("iso-8859-1", x))), x;
            }
            function T(x) {
              const S = [];
              let E;
              const w = o("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
              for (; (E = w.exec(x)) !== null; ) {
                let [, g, p, _] = E;
                if (g = parseInt(g, 10), g in S) {
                  if (g === 0)
                    break;
                  continue;
                }
                S[g] = [p, _];
              }
              const M = [];
              for (let g = 0; g < S.length && g in S; ++g) {
                let [p, _] = S[g];
                _ = P(_), p && (_ = unescape(_), g === 0 && (_ = v(_))), M.push(_);
              }
              return M.join("");
            }
            function P(x) {
              if (x.startsWith('"')) {
                const S = x.slice(1).split('\\"');
                for (let E = 0; E < S.length; ++E) {
                  const w = S[E].indexOf('"');
                  w !== -1 && (S[E] = S[E].slice(0, w), S.length = E + 1), S[E] = S[E].replaceAll(/\\(.)/g, "$1");
                }
                x = S.join('"');
              }
              return x;
            }
            function v(x) {
              const S = x.indexOf("'");
              if (S === -1)
                return x;
              const E = x.slice(0, S), M = x.slice(S + 1).replace(/^[^']*'/, "");
              return l(E, M);
            }
            function k(x) {
              return !x.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(x) ? x : x.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g, function(S, E, w, M) {
                if (w === "q" || w === "Q")
                  return M = M.replaceAll("_", " "), M = M.replaceAll(/=([0-9a-fA-F]{2})/g, function(g, p) {
                    return String.fromCharCode(parseInt(p, 16));
                  }), l(E, M);
                try {
                  M = atob(M);
                } catch {
                }
                return l(E, M);
              });
            }
            return "";
          }
        },
        /* 22 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.PDFNetworkStream = void 0;
          var e = n(1), s = n(20);
          const c = 200, h = 206;
          function b(P) {
            const v = P.response;
            return typeof v != "string" ? v : (0, e.stringToBytes)(v).buffer;
          }
          class o {
            constructor(v, k = {}) {
              this.url = v, this.isHttp = /^https?:/i.test(v), this.httpHeaders = this.isHttp && k.httpHeaders || /* @__PURE__ */ Object.create(null), this.withCredentials = k.withCredentials || !1, this.currXhrId = 0, this.pendingRequests = /* @__PURE__ */ Object.create(null);
            }
            requestRange(v, k, x) {
              const S = {
                begin: v,
                end: k
              };
              for (const E in x)
                S[E] = x[E];
              return this.request(S);
            }
            requestFull(v) {
              return this.request(v);
            }
            request(v) {
              const k = new XMLHttpRequest(), x = this.currXhrId++, S = this.pendingRequests[x] = {
                xhr: k
              };
              k.open("GET", this.url), k.withCredentials = this.withCredentials;
              for (const E in this.httpHeaders) {
                const w = this.httpHeaders[E];
                w !== void 0 && k.setRequestHeader(E, w);
              }
              return this.isHttp && "begin" in v && "end" in v ? (k.setRequestHeader("Range", `bytes=${v.begin}-${v.end - 1}`), S.expectedStatus = h) : S.expectedStatus = c, k.responseType = "arraybuffer", v.onError && (k.onerror = function(E) {
                v.onError(k.status);
              }), k.onreadystatechange = this.onStateChange.bind(this, x), k.onprogress = this.onProgress.bind(this, x), S.onHeadersReceived = v.onHeadersReceived, S.onDone = v.onDone, S.onError = v.onError, S.onProgress = v.onProgress, k.send(null), x;
            }
            onProgress(v, k) {
              var S;
              const x = this.pendingRequests[v];
              x && ((S = x.onProgress) == null || S.call(x, k));
            }
            onStateChange(v, k) {
              var g, p, _;
              const x = this.pendingRequests[v];
              if (!x)
                return;
              const S = x.xhr;
              if (S.readyState >= 2 && x.onHeadersReceived && (x.onHeadersReceived(), delete x.onHeadersReceived), S.readyState !== 4 || !(v in this.pendingRequests))
                return;
              if (delete this.pendingRequests[v], S.status === 0 && this.isHttp) {
                (g = x.onError) == null || g.call(x, S.status);
                return;
              }
              const E = S.status || c;
              if (!(E === c && x.expectedStatus === h) && E !== x.expectedStatus) {
                (p = x.onError) == null || p.call(x, S.status);
                return;
              }
              const M = b(S);
              if (E === h) {
                const f = S.getResponseHeader("Content-Range"), A = /bytes (\d+)-(\d+)\/(\d+)/.exec(f);
                x.onDone({
                  begin: parseInt(A[1], 10),
                  chunk: M
                });
              } else M ? x.onDone({
                begin: 0,
                chunk: M
              }) : (_ = x.onError) == null || _.call(x, S.status);
            }
            getRequestXhr(v) {
              return this.pendingRequests[v].xhr;
            }
            isPendingRequest(v) {
              return v in this.pendingRequests;
            }
            abortRequest(v) {
              const k = this.pendingRequests[v].xhr;
              delete this.pendingRequests[v], k.abort();
            }
          }
          class l {
            constructor(v) {
              this._source = v, this._manager = new o(v.url, {
                httpHeaders: v.httpHeaders,
                withCredentials: v.withCredentials
              }), this._rangeChunkSize = v.rangeChunkSize, this._fullRequestReader = null, this._rangeRequestReaders = [];
            }
            _onRangeRequestReaderClosed(v) {
              const k = this._rangeRequestReaders.indexOf(v);
              k >= 0 && this._rangeRequestReaders.splice(k, 1);
            }
            getFullReader() {
              return (0, e.assert)(!this._fullRequestReader, "PDFNetworkStream.getFullReader can only be called once."), this._fullRequestReader = new a(this._manager, this._source), this._fullRequestReader;
            }
            getRangeReader(v, k) {
              const x = new T(this._manager, v, k);
              return x.onClosed = this._onRangeRequestReaderClosed.bind(this), this._rangeRequestReaders.push(x), x;
            }
            cancelAllRequests(v) {
              var k;
              (k = this._fullRequestReader) == null || k.cancel(v);
              for (const x of this._rangeRequestReaders.slice(0))
                x.cancel(v);
            }
          }
          t.PDFNetworkStream = l;
          class a {
            constructor(v, k) {
              this._manager = v;
              const x = {
                onHeadersReceived: this._onHeadersReceived.bind(this),
                onDone: this._onDone.bind(this),
                onError: this._onError.bind(this),
                onProgress: this._onProgress.bind(this)
              };
              this._url = k.url, this._fullRequestId = v.requestFull(x), this._headersReceivedCapability = new e.PromiseCapability(), this._disableRange = k.disableRange || !1, this._contentLength = k.length, this._rangeChunkSize = k.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !1, this._isRangeSupported = !1, this._cachedChunks = [], this._requests = [], this._done = !1, this._storedError = void 0, this._filename = null, this.onProgress = null;
            }
            _onHeadersReceived() {
              const v = this._fullRequestId, k = this._manager.getRequestXhr(v), x = (w) => k.getResponseHeader(w), {
                allowRangeRequests: S,
                suggestedLength: E
              } = (0, s.validateRangeRequestCapabilities)({
                getResponseHeader: x,
                isHttp: this._manager.isHttp,
                rangeChunkSize: this._rangeChunkSize,
                disableRange: this._disableRange
              });
              S && (this._isRangeSupported = !0), this._contentLength = E || this._contentLength, this._filename = (0, s.extractFilenameFromHeader)(x), this._isRangeSupported && this._manager.abortRequest(v), this._headersReceivedCapability.resolve();
            }
            _onDone(v) {
              if (v && (this._requests.length > 0 ? this._requests.shift().resolve({
                value: v.chunk,
                done: !1
              }) : this._cachedChunks.push(v.chunk)), this._done = !0, !(this._cachedChunks.length > 0)) {
                for (const k of this._requests)
                  k.resolve({
                    value: void 0,
                    done: !0
                  });
                this._requests.length = 0;
              }
            }
            _onError(v) {
              this._storedError = (0, s.createResponseStatusError)(v, this._url), this._headersReceivedCapability.reject(this._storedError);
              for (const k of this._requests)
                k.reject(this._storedError);
              this._requests.length = 0, this._cachedChunks.length = 0;
            }
            _onProgress(v) {
              var k;
              (k = this.onProgress) == null || k.call(this, {
                loaded: v.loaded,
                total: v.lengthComputable ? v.total : this._contentLength
              });
            }
            get filename() {
              return this._filename;
            }
            get isRangeSupported() {
              return this._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            get contentLength() {
              return this._contentLength;
            }
            get headersReady() {
              return this._headersReceivedCapability.promise;
            }
            async read() {
              if (this._storedError)
                throw this._storedError;
              if (this._cachedChunks.length > 0)
                return {
                  value: this._cachedChunks.shift(),
                  done: !1
                };
              if (this._done)
                return {
                  value: void 0,
                  done: !0
                };
              const v = new e.PromiseCapability();
              return this._requests.push(v), v.promise;
            }
            cancel(v) {
              this._done = !0, this._headersReceivedCapability.reject(v);
              for (const k of this._requests)
                k.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0, this._manager.isPendingRequest(this._fullRequestId) && this._manager.abortRequest(this._fullRequestId), this._fullRequestReader = null;
            }
          }
          class T {
            constructor(v, k, x) {
              this._manager = v;
              const S = {
                onDone: this._onDone.bind(this),
                onError: this._onError.bind(this),
                onProgress: this._onProgress.bind(this)
              };
              this._url = v.url, this._requestId = v.requestRange(k, x, S), this._requests = [], this._queuedChunk = null, this._done = !1, this._storedError = void 0, this.onProgress = null, this.onClosed = null;
            }
            _close() {
              var v;
              (v = this.onClosed) == null || v.call(this, this);
            }
            _onDone(v) {
              const k = v.chunk;
              this._requests.length > 0 ? this._requests.shift().resolve({
                value: k,
                done: !1
              }) : this._queuedChunk = k, this._done = !0;
              for (const x of this._requests)
                x.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0, this._close();
            }
            _onError(v) {
              this._storedError = (0, s.createResponseStatusError)(v, this._url);
              for (const k of this._requests)
                k.reject(this._storedError);
              this._requests.length = 0, this._queuedChunk = null;
            }
            _onProgress(v) {
              var k;
              this.isStreamingSupported || (k = this.onProgress) == null || k.call(this, {
                loaded: v.loaded
              });
            }
            get isStreamingSupported() {
              return !1;
            }
            async read() {
              if (this._storedError)
                throw this._storedError;
              if (this._queuedChunk !== null) {
                const k = this._queuedChunk;
                return this._queuedChunk = null, {
                  value: k,
                  done: !1
                };
              }
              if (this._done)
                return {
                  value: void 0,
                  done: !0
                };
              const v = new e.PromiseCapability();
              return this._requests.push(v), v.promise;
            }
            cancel(v) {
              this._done = !0;
              for (const k of this._requests)
                k.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0, this._manager.isPendingRequest(this._requestId) && this._manager.abortRequest(this._requestId), this._close();
            }
          }
        },
        /* 23 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.PDFNodeStream = void 0;
          var e = n(1), s = n(20);
          const c = /^file:\/\/\/[a-zA-Z]:\//;
          function h(x) {
            const S = require$$5, E = S.parse(x);
            return E.protocol === "file:" || E.host ? E : /^[a-z]:[/\\]/i.test(x) ? S.parse(`file:///${x}`) : (E.host || (E.protocol = "file:"), E);
          }
          class b {
            constructor(S) {
              this.source = S, this.url = h(S.url), this.isHttp = this.url.protocol === "http:" || this.url.protocol === "https:", this.isFsUrl = this.url.protocol === "file:", this.httpHeaders = this.isHttp && S.httpHeaders || {}, this._fullRequestReader = null, this._rangeRequestReaders = [];
            }
            get _progressiveDataLength() {
              var S;
              return ((S = this._fullRequestReader) == null ? void 0 : S._loaded) ?? 0;
            }
            getFullReader() {
              return (0, e.assert)(!this._fullRequestReader, "PDFNodeStream.getFullReader can only be called once."), this._fullRequestReader = this.isFsUrl ? new v(this) : new T(this), this._fullRequestReader;
            }
            getRangeReader(S, E) {
              if (E <= this._progressiveDataLength)
                return null;
              const w = this.isFsUrl ? new k(this, S, E) : new P(this, S, E);
              return this._rangeRequestReaders.push(w), w;
            }
            cancelAllRequests(S) {
              var E;
              (E = this._fullRequestReader) == null || E.cancel(S);
              for (const w of this._rangeRequestReaders.slice(0))
                w.cancel(S);
            }
          }
          t.PDFNodeStream = b;
          class o {
            constructor(S) {
              this._url = S.url, this._done = !1, this._storedError = null, this.onProgress = null;
              const E = S.source;
              this._contentLength = E.length, this._loaded = 0, this._filename = null, this._disableRange = E.disableRange || !1, this._rangeChunkSize = E.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !E.disableStream, this._isRangeSupported = !E.disableRange, this._readableStream = null, this._readCapability = new e.PromiseCapability(), this._headersCapability = new e.PromiseCapability();
            }
            get headersReady() {
              return this._headersCapability.promise;
            }
            get filename() {
              return this._filename;
            }
            get contentLength() {
              return this._contentLength;
            }
            get isRangeSupported() {
              return this._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              var w;
              if (await this._readCapability.promise, this._done)
                return {
                  value: void 0,
                  done: !0
                };
              if (this._storedError)
                throw this._storedError;
              const S = this._readableStream.read();
              return S === null ? (this._readCapability = new e.PromiseCapability(), this.read()) : (this._loaded += S.length, (w = this.onProgress) == null || w.call(this, {
                loaded: this._loaded,
                total: this._contentLength
              }), {
                value: new Uint8Array(S).buffer,
                done: !1
              });
            }
            cancel(S) {
              if (!this._readableStream) {
                this._error(S);
                return;
              }
              this._readableStream.destroy(S);
            }
            _error(S) {
              this._storedError = S, this._readCapability.resolve();
            }
            _setReadableStream(S) {
              this._readableStream = S, S.on("readable", () => {
                this._readCapability.resolve();
              }), S.on("end", () => {
                S.destroy(), this._done = !0, this._readCapability.resolve();
              }), S.on("error", (E) => {
                this._error(E);
              }), !this._isStreamingSupported && this._isRangeSupported && this._error(new e.AbortException("streaming is disabled")), this._storedError && this._readableStream.destroy(this._storedError);
            }
          }
          class l {
            constructor(S) {
              this._url = S.url, this._done = !1, this._storedError = null, this.onProgress = null, this._loaded = 0, this._readableStream = null, this._readCapability = new e.PromiseCapability();
              const E = S.source;
              this._isStreamingSupported = !E.disableStream;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              var w;
              if (await this._readCapability.promise, this._done)
                return {
                  value: void 0,
                  done: !0
                };
              if (this._storedError)
                throw this._storedError;
              const S = this._readableStream.read();
              return S === null ? (this._readCapability = new e.PromiseCapability(), this.read()) : (this._loaded += S.length, (w = this.onProgress) == null || w.call(this, {
                loaded: this._loaded
              }), {
                value: new Uint8Array(S).buffer,
                done: !1
              });
            }
            cancel(S) {
              if (!this._readableStream) {
                this._error(S);
                return;
              }
              this._readableStream.destroy(S);
            }
            _error(S) {
              this._storedError = S, this._readCapability.resolve();
            }
            _setReadableStream(S) {
              this._readableStream = S, S.on("readable", () => {
                this._readCapability.resolve();
              }), S.on("end", () => {
                S.destroy(), this._done = !0, this._readCapability.resolve();
              }), S.on("error", (E) => {
                this._error(E);
              }), this._storedError && this._readableStream.destroy(this._storedError);
            }
          }
          function a(x, S) {
            return {
              protocol: x.protocol,
              auth: x.auth,
              host: x.hostname,
              port: x.port,
              path: x.path,
              method: "GET",
              headers: S
            };
          }
          class T extends o {
            constructor(S) {
              super(S);
              const E = (w) => {
                if (w.statusCode === 404) {
                  const _ = new e.MissingPDFException(`Missing PDF "${this._url}".`);
                  this._storedError = _, this._headersCapability.reject(_);
                  return;
                }
                this._headersCapability.resolve(), this._setReadableStream(w);
                const M = (_) => this._readableStream.headers[_.toLowerCase()], {
                  allowRangeRequests: g,
                  suggestedLength: p
                } = (0, s.validateRangeRequestCapabilities)({
                  getResponseHeader: M,
                  isHttp: S.isHttp,
                  rangeChunkSize: this._rangeChunkSize,
                  disableRange: this._disableRange
                });
                this._isRangeSupported = g, this._contentLength = p || this._contentLength, this._filename = (0, s.extractFilenameFromHeader)(M);
              };
              if (this._request = null, this._url.protocol === "http:") {
                const w = require$$5;
                this._request = w.request(a(this._url, S.httpHeaders), E);
              } else {
                const w = require$$5;
                this._request = w.request(a(this._url, S.httpHeaders), E);
              }
              this._request.on("error", (w) => {
                this._storedError = w, this._headersCapability.reject(w);
              }), this._request.end();
            }
          }
          class P extends l {
            constructor(S, E, w) {
              super(S), this._httpHeaders = {};
              for (const g in S.httpHeaders) {
                const p = S.httpHeaders[g];
                p !== void 0 && (this._httpHeaders[g] = p);
              }
              this._httpHeaders.Range = `bytes=${E}-${w - 1}`;
              const M = (g) => {
                if (g.statusCode === 404) {
                  const p = new e.MissingPDFException(`Missing PDF "${this._url}".`);
                  this._storedError = p;
                  return;
                }
                this._setReadableStream(g);
              };
              if (this._request = null, this._url.protocol === "http:") {
                const g = require$$5;
                this._request = g.request(a(this._url, this._httpHeaders), M);
              } else {
                const g = require$$5;
                this._request = g.request(a(this._url, this._httpHeaders), M);
              }
              this._request.on("error", (g) => {
                this._storedError = g;
              }), this._request.end();
            }
          }
          class v extends o {
            constructor(S) {
              super(S);
              let E = decodeURIComponent(this._url.path);
              c.test(this._url.href) && (E = E.replace(/^\//, ""));
              const w = require$$5;
              w.lstat(E, (M, g) => {
                if (M) {
                  M.code === "ENOENT" && (M = new e.MissingPDFException(`Missing PDF "${E}".`)), this._storedError = M, this._headersCapability.reject(M);
                  return;
                }
                this._contentLength = g.size, this._setReadableStream(w.createReadStream(E)), this._headersCapability.resolve();
              });
            }
          }
          class k extends l {
            constructor(S, E, w) {
              super(S);
              let M = decodeURIComponent(this._url.path);
              c.test(this._url.href) && (M = M.replace(/^\//, ""));
              const g = require$$5;
              this._setReadableStream(g.createReadStream(M, {
                start: E,
                end: w - 1
              }));
            }
          }
        },
        /* 24 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.SVGGraphics = void 0;
          var e = n(6), s = n(1);
          const c = {
            fontStyle: "normal",
            fontWeight: "normal",
            fillColor: "#000000"
          }, h = "http://www.w3.org/XML/1998/namespace", b = "http://www.w3.org/1999/xlink", o = ["butt", "round", "square"], l = ["miter", "round", "bevel"], a = function(g, p = "", _ = !1) {
            if (URL.createObjectURL && typeof Blob < "u" && !_)
              return URL.createObjectURL(new Blob([g], {
                type: p
              }));
            const f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
            let A = `data:${p};base64,`;
            for (let C = 0, W = g.length; C < W; C += 3) {
              const m = g[C] & 255, I = g[C + 1] & 255, q = g[C + 2] & 255, Y = m >> 2, X = (m & 3) << 4 | I >> 4, z = C + 1 < W ? (I & 15) << 2 | q >> 6 : 64, L = C + 2 < W ? q & 63 : 64;
              A += f[Y] + f[X] + f[z] + f[L];
            }
            return A;
          }, T = function() {
            const g = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]), p = 12, _ = new Int32Array(256);
            for (let q = 0; q < 256; q++) {
              let Y = q;
              for (let X = 0; X < 8; X++)
                Y = Y & 1 ? 3988292384 ^ Y >> 1 & 2147483647 : Y >> 1 & 2147483647;
              _[q] = Y;
            }
            function f(q, Y, X) {
              let z = -1;
              for (let L = Y; L < X; L++) {
                const et = (z ^ q[L]) & 255, D = _[et];
                z = z >>> 8 ^ D;
              }
              return z ^ -1;
            }
            function A(q, Y, X, z) {
              let L = z;
              const et = Y.length;
              X[L] = et >> 24 & 255, X[L + 1] = et >> 16 & 255, X[L + 2] = et >> 8 & 255, X[L + 3] = et & 255, L += 4, X[L] = q.charCodeAt(0) & 255, X[L + 1] = q.charCodeAt(1) & 255, X[L + 2] = q.charCodeAt(2) & 255, X[L + 3] = q.charCodeAt(3) & 255, L += 4, X.set(Y, L), L += Y.length;
              const D = f(X, z + 4, L);
              X[L] = D >> 24 & 255, X[L + 1] = D >> 16 & 255, X[L + 2] = D >> 8 & 255, X[L + 3] = D & 255;
            }
            function C(q, Y, X) {
              let z = 1, L = 0;
              for (let et = Y; et < X; ++et)
                z = (z + (q[et] & 255)) % 65521, L = (L + z) % 65521;
              return L << 16 | z;
            }
            function W(q) {
              if (!s.isNodeJS)
                return m(q);
              try {
                const Y = parseInt(process.versions.node) >= 8 ? q : Buffer.from(q), X = require$$5.deflateSync(Y, {
                  level: 9
                });
                return X instanceof Uint8Array ? X : new Uint8Array(X);
              } catch (Y) {
                (0, s.warn)("Not compressing PNG because zlib.deflateSync is unavailable: " + Y);
              }
              return m(q);
            }
            function m(q) {
              let Y = q.length;
              const X = 65535, z = Math.ceil(Y / X), L = new Uint8Array(2 + Y + z * 5 + 4);
              let et = 0;
              L[et++] = 120, L[et++] = 156;
              let D = 0;
              for (; Y > X; )
                L[et++] = 0, L[et++] = 255, L[et++] = 255, L[et++] = 0, L[et++] = 0, L.set(q.subarray(D, D + X), et), et += X, D += X, Y -= X;
              L[et++] = 1, L[et++] = Y & 255, L[et++] = Y >> 8 & 255, L[et++] = ~Y & 65535 & 255, L[et++] = (~Y & 65535) >> 8 & 255, L.set(q.subarray(D), et), et += q.length - D;
              const G = C(q, 0, q.length);
              return L[et++] = G >> 24 & 255, L[et++] = G >> 16 & 255, L[et++] = G >> 8 & 255, L[et++] = G & 255, L;
            }
            function I(q, Y, X, z) {
              const L = q.width, et = q.height;
              let D, G, Q;
              const F = q.data;
              switch (Y) {
                case s.ImageKind.GRAYSCALE_1BPP:
                  G = 0, D = 1, Q = L + 7 >> 3;
                  break;
                case s.ImageKind.RGB_24BPP:
                  G = 2, D = 8, Q = L * 3;
                  break;
                case s.ImageKind.RGBA_32BPP:
                  G = 6, D = 8, Q = L * 4;
                  break;
                default:
                  throw new Error("invalid format");
              }
              const d = new Uint8Array((1 + Q) * et);
              let u = 0, y = 0;
              for (let dt = 0; dt < et; ++dt)
                d[u++] = 0, d.set(F.subarray(y, y + Q), u), y += Q, u += Q;
              if (Y === s.ImageKind.GRAYSCALE_1BPP && z) {
                u = 0;
                for (let dt = 0; dt < et; dt++) {
                  u++;
                  for (let pt = 0; pt < Q; pt++)
                    d[u++] ^= 255;
                }
              }
              const B = new Uint8Array([L >> 24 & 255, L >> 16 & 255, L >> 8 & 255, L & 255, et >> 24 & 255, et >> 16 & 255, et >> 8 & 255, et & 255, D, G, 0, 0, 0]), N = W(d), $ = g.length + p * 3 + B.length + N.length, K = new Uint8Array($);
              let st = 0;
              return K.set(g, st), st += g.length, A("IHDR", B, K, st), st += p + B.length, A("IDATA", N, K, st), st += p + N.length, A("IEND", new Uint8Array(0), K, st), a(K, "image/png", X);
            }
            return function(Y, X, z) {
              const L = Y.kind === void 0 ? s.ImageKind.GRAYSCALE_1BPP : Y.kind;
              return I(Y, L, X, z);
            };
          }();
          class P {
            constructor() {
              this.fontSizeScale = 1, this.fontWeight = c.fontWeight, this.fontSize = 0, this.textMatrix = s.IDENTITY_MATRIX, this.fontMatrix = s.FONT_IDENTITY_MATRIX, this.leading = 0, this.textRenderingMode = s.TextRenderingMode.FILL, this.textMatrixScale = 1, this.x = 0, this.y = 0, this.lineX = 0, this.lineY = 0, this.charSpacing = 0, this.wordSpacing = 0, this.textHScale = 1, this.textRise = 0, this.fillColor = c.fillColor, this.strokeColor = "#000000", this.fillAlpha = 1, this.strokeAlpha = 1, this.lineWidth = 1, this.lineJoin = "", this.lineCap = "", this.miterLimit = 0, this.dashArray = [], this.dashPhase = 0, this.dependencies = [], this.activeClipUrl = null, this.clipGroup = null, this.maskId = "";
            }
            clone() {
              return Object.create(this);
            }
            setCurrentPoint(p, _) {
              this.x = p, this.y = _;
            }
          }
          function v(g) {
            let p = [];
            const _ = [];
            for (const f of g) {
              if (f.fn === "save") {
                p.push({
                  fnId: 92,
                  fn: "group",
                  items: []
                }), _.push(p), p = p.at(-1).items;
                continue;
              }
              f.fn === "restore" ? p = _.pop() : p.push(f);
            }
            return p;
          }
          function k(g) {
            if (Number.isInteger(g))
              return g.toString();
            const p = g.toFixed(10);
            let _ = p.length - 1;
            if (p[_] !== "0")
              return p;
            do
              _--;
            while (p[_] === "0");
            return p.substring(0, p[_] === "." ? _ : _ + 1);
          }
          function x(g) {
            if (g[4] === 0 && g[5] === 0) {
              if (g[1] === 0 && g[2] === 0)
                return g[0] === 1 && g[3] === 1 ? "" : `scale(${k(g[0])} ${k(g[3])})`;
              if (g[0] === g[3] && g[1] === -g[2]) {
                const p = Math.acos(g[0]) * 180 / Math.PI;
                return `rotate(${k(p)})`;
              }
            } else if (g[0] === 1 && g[1] === 0 && g[2] === 0 && g[3] === 1)
              return `translate(${k(g[4])} ${k(g[5])})`;
            return `matrix(${k(g[0])} ${k(g[1])} ${k(g[2])} ${k(g[3])} ${k(g[4])} ${k(g[5])})`;
          }
          let S = 0, E = 0, w = 0;
          class M {
            constructor(p, _, f = !1) {
              (0, e.deprecated)("The SVG back-end is no longer maintained and *may* be removed in the future."), this.svgFactory = new e.DOMSVGFactory(), this.current = new P(), this.transformMatrix = s.IDENTITY_MATRIX, this.transformStack = [], this.extraStack = [], this.commonObjs = p, this.objs = _, this.pendingClip = null, this.pendingEOFill = !1, this.embedFonts = !1, this.embeddedFonts = /* @__PURE__ */ Object.create(null), this.cssStyle = null, this.forceDataSchema = !!f, this._operatorIdMapping = [];
              for (const A in s.OPS)
                this._operatorIdMapping[s.OPS[A]] = A;
            }
            getObject(p, _ = null) {
              return typeof p == "string" ? p.startsWith("g_") ? this.commonObjs.get(p) : this.objs.get(p) : _;
            }
            save() {
              this.transformStack.push(this.transformMatrix);
              const p = this.current;
              this.extraStack.push(p), this.current = p.clone();
            }
            restore() {
              this.transformMatrix = this.transformStack.pop(), this.current = this.extraStack.pop(), this.pendingClip = null, this.tgrp = null;
            }
            group(p) {
              this.save(), this.executeOpTree(p), this.restore();
            }
            loadDependencies(p) {
              const _ = p.fnArray, f = p.argsArray;
              for (let A = 0, C = _.length; A < C; A++)
                if (_[A] === s.OPS.dependency)
                  for (const W of f[A]) {
                    const m = W.startsWith("g_") ? this.commonObjs : this.objs, I = new Promise((q) => {
                      m.get(W, q);
                    });
                    this.current.dependencies.push(I);
                  }
              return Promise.all(this.current.dependencies);
            }
            transform(p, _, f, A, C, W) {
              const m = [p, _, f, A, C, W];
              this.transformMatrix = s.Util.transform(this.transformMatrix, m), this.tgrp = null;
            }
            getSVG(p, _) {
              this.viewport = _;
              const f = this._initialize(_);
              return this.loadDependencies(p).then(() => (this.transformMatrix = s.IDENTITY_MATRIX, this.executeOpTree(this.convertOpList(p)), f));
            }
            convertOpList(p) {
              const _ = this._operatorIdMapping, f = p.argsArray, A = p.fnArray, C = [];
              for (let W = 0, m = A.length; W < m; W++) {
                const I = A[W];
                C.push({
                  fnId: I,
                  fn: _[I],
                  args: f[W]
                });
              }
              return v(C);
            }
            executeOpTree(p) {
              for (const _ of p) {
                const f = _.fn, A = _.fnId, C = _.args;
                switch (A | 0) {
                  case s.OPS.beginText:
                    this.beginText();
                    break;
                  case s.OPS.dependency:
                    break;
                  case s.OPS.setLeading:
                    this.setLeading(C);
                    break;
                  case s.OPS.setLeadingMoveText:
                    this.setLeadingMoveText(C[0], C[1]);
                    break;
                  case s.OPS.setFont:
                    this.setFont(C);
                    break;
                  case s.OPS.showText:
                    this.showText(C[0]);
                    break;
                  case s.OPS.showSpacedText:
                    this.showText(C[0]);
                    break;
                  case s.OPS.endText:
                    this.endText();
                    break;
                  case s.OPS.moveText:
                    this.moveText(C[0], C[1]);
                    break;
                  case s.OPS.setCharSpacing:
                    this.setCharSpacing(C[0]);
                    break;
                  case s.OPS.setWordSpacing:
                    this.setWordSpacing(C[0]);
                    break;
                  case s.OPS.setHScale:
                    this.setHScale(C[0]);
                    break;
                  case s.OPS.setTextMatrix:
                    this.setTextMatrix(C[0], C[1], C[2], C[3], C[4], C[5]);
                    break;
                  case s.OPS.setTextRise:
                    this.setTextRise(C[0]);
                    break;
                  case s.OPS.setTextRenderingMode:
                    this.setTextRenderingMode(C[0]);
                    break;
                  case s.OPS.setLineWidth:
                    this.setLineWidth(C[0]);
                    break;
                  case s.OPS.setLineJoin:
                    this.setLineJoin(C[0]);
                    break;
                  case s.OPS.setLineCap:
                    this.setLineCap(C[0]);
                    break;
                  case s.OPS.setMiterLimit:
                    this.setMiterLimit(C[0]);
                    break;
                  case s.OPS.setFillRGBColor:
                    this.setFillRGBColor(C[0], C[1], C[2]);
                    break;
                  case s.OPS.setStrokeRGBColor:
                    this.setStrokeRGBColor(C[0], C[1], C[2]);
                    break;
                  case s.OPS.setStrokeColorN:
                    this.setStrokeColorN(C);
                    break;
                  case s.OPS.setFillColorN:
                    this.setFillColorN(C);
                    break;
                  case s.OPS.shadingFill:
                    this.shadingFill(C[0]);
                    break;
                  case s.OPS.setDash:
                    this.setDash(C[0], C[1]);
                    break;
                  case s.OPS.setRenderingIntent:
                    this.setRenderingIntent(C[0]);
                    break;
                  case s.OPS.setFlatness:
                    this.setFlatness(C[0]);
                    break;
                  case s.OPS.setGState:
                    this.setGState(C[0]);
                    break;
                  case s.OPS.fill:
                    this.fill();
                    break;
                  case s.OPS.eoFill:
                    this.eoFill();
                    break;
                  case s.OPS.stroke:
                    this.stroke();
                    break;
                  case s.OPS.fillStroke:
                    this.fillStroke();
                    break;
                  case s.OPS.eoFillStroke:
                    this.eoFillStroke();
                    break;
                  case s.OPS.clip:
                    this.clip("nonzero");
                    break;
                  case s.OPS.eoClip:
                    this.clip("evenodd");
                    break;
                  case s.OPS.paintSolidColorImageMask:
                    this.paintSolidColorImageMask();
                    break;
                  case s.OPS.paintImageXObject:
                    this.paintImageXObject(C[0]);
                    break;
                  case s.OPS.paintInlineImageXObject:
                    this.paintInlineImageXObject(C[0]);
                    break;
                  case s.OPS.paintImageMaskXObject:
                    this.paintImageMaskXObject(C[0]);
                    break;
                  case s.OPS.paintFormXObjectBegin:
                    this.paintFormXObjectBegin(C[0], C[1]);
                    break;
                  case s.OPS.paintFormXObjectEnd:
                    this.paintFormXObjectEnd();
                    break;
                  case s.OPS.closePath:
                    this.closePath();
                    break;
                  case s.OPS.closeStroke:
                    this.closeStroke();
                    break;
                  case s.OPS.closeFillStroke:
                    this.closeFillStroke();
                    break;
                  case s.OPS.closeEOFillStroke:
                    this.closeEOFillStroke();
                    break;
                  case s.OPS.nextLine:
                    this.nextLine();
                    break;
                  case s.OPS.transform:
                    this.transform(C[0], C[1], C[2], C[3], C[4], C[5]);
                    break;
                  case s.OPS.constructPath:
                    this.constructPath(C[0], C[1]);
                    break;
                  case s.OPS.endPath:
                    this.endPath();
                    break;
                  case 92:
                    this.group(_.items);
                    break;
                  default:
                    (0, s.warn)(`Unimplemented operator ${f}`);
                    break;
                }
              }
            }
            setWordSpacing(p) {
              this.current.wordSpacing = p;
            }
            setCharSpacing(p) {
              this.current.charSpacing = p;
            }
            nextLine() {
              this.moveText(0, this.current.leading);
            }
            setTextMatrix(p, _, f, A, C, W) {
              const m = this.current;
              m.textMatrix = m.lineMatrix = [p, _, f, A, C, W], m.textMatrixScale = Math.hypot(p, _), m.x = m.lineX = 0, m.y = m.lineY = 0, m.xcoords = [], m.ycoords = [], m.tspan = this.svgFactory.createElement("svg:tspan"), m.tspan.setAttributeNS(null, "font-family", m.fontFamily), m.tspan.setAttributeNS(null, "font-size", `${k(m.fontSize)}px`), m.tspan.setAttributeNS(null, "y", k(-m.y)), m.txtElement = this.svgFactory.createElement("svg:text"), m.txtElement.append(m.tspan);
            }
            beginText() {
              const p = this.current;
              p.x = p.lineX = 0, p.y = p.lineY = 0, p.textMatrix = s.IDENTITY_MATRIX, p.lineMatrix = s.IDENTITY_MATRIX, p.textMatrixScale = 1, p.tspan = this.svgFactory.createElement("svg:tspan"), p.txtElement = this.svgFactory.createElement("svg:text"), p.txtgrp = this.svgFactory.createElement("svg:g"), p.xcoords = [], p.ycoords = [];
            }
            moveText(p, _) {
              const f = this.current;
              f.x = f.lineX += p, f.y = f.lineY += _, f.xcoords = [], f.ycoords = [], f.tspan = this.svgFactory.createElement("svg:tspan"), f.tspan.setAttributeNS(null, "font-family", f.fontFamily), f.tspan.setAttributeNS(null, "font-size", `${k(f.fontSize)}px`), f.tspan.setAttributeNS(null, "y", k(-f.y));
            }
            showText(p) {
              const _ = this.current, f = _.font, A = _.fontSize;
              if (A === 0)
                return;
              const C = _.fontSizeScale, W = _.charSpacing, m = _.wordSpacing, I = _.fontDirection, q = _.textHScale * I, Y = f.vertical, X = Y ? 1 : -1, z = f.defaultVMetrics, L = A * _.fontMatrix[0];
              let et = 0;
              for (const Q of p) {
                if (Q === null) {
                  et += I * m;
                  continue;
                } else if (typeof Q == "number") {
                  et += X * Q * A / 1e3;
                  continue;
                }
                const F = (Q.isSpace ? m : 0) + W, d = Q.fontChar;
                let u, y, B = Q.width;
                if (Y) {
                  let $;
                  const K = Q.vmetric || z;
                  $ = Q.vmetric ? K[1] : B * 0.5, $ = -$ * L;
                  const st = K[2] * L;
                  B = K ? -K[0] : B, u = $ / C, y = (et + st) / C;
                } else
                  u = et / C, y = 0;
                (Q.isInFont || f.missingFile) && (_.xcoords.push(_.x + u), Y && _.ycoords.push(-_.y + y), _.tspan.textContent += d);
                const N = Y ? B * L - F * I : B * L + F * I;
                et += N;
              }
              _.tspan.setAttributeNS(null, "x", _.xcoords.map(k).join(" ")), Y ? _.tspan.setAttributeNS(null, "y", _.ycoords.map(k).join(" ")) : _.tspan.setAttributeNS(null, "y", k(-_.y)), Y ? _.y -= et : _.x += et * q, _.tspan.setAttributeNS(null, "font-family", _.fontFamily), _.tspan.setAttributeNS(null, "font-size", `${k(_.fontSize)}px`), _.fontStyle !== c.fontStyle && _.tspan.setAttributeNS(null, "font-style", _.fontStyle), _.fontWeight !== c.fontWeight && _.tspan.setAttributeNS(null, "font-weight", _.fontWeight);
              const D = _.textRenderingMode & s.TextRenderingMode.FILL_STROKE_MASK;
              if (D === s.TextRenderingMode.FILL || D === s.TextRenderingMode.FILL_STROKE ? (_.fillColor !== c.fillColor && _.tspan.setAttributeNS(null, "fill", _.fillColor), _.fillAlpha < 1 && _.tspan.setAttributeNS(null, "fill-opacity", _.fillAlpha)) : _.textRenderingMode === s.TextRenderingMode.ADD_TO_PATH ? _.tspan.setAttributeNS(null, "fill", "transparent") : _.tspan.setAttributeNS(null, "fill", "none"), D === s.TextRenderingMode.STROKE || D === s.TextRenderingMode.FILL_STROKE) {
                const Q = 1 / (_.textMatrixScale || 1);
                this._setStrokeAttributes(_.tspan, Q);
              }
              let G = _.textMatrix;
              _.textRise !== 0 && (G = G.slice(), G[5] += _.textRise), _.txtElement.setAttributeNS(null, "transform", `${x(G)} scale(${k(q)}, -1)`), _.txtElement.setAttributeNS(h, "xml:space", "preserve"), _.txtElement.append(_.tspan), _.txtgrp.append(_.txtElement), this._ensureTransformGroup().append(_.txtElement);
            }
            setLeadingMoveText(p, _) {
              this.setLeading(-_), this.moveText(p, _);
            }
            addFontStyle(p) {
              if (!p.data)
                throw new Error('addFontStyle: No font data available, ensure that the "fontExtraProperties" API parameter is set.');
              this.cssStyle || (this.cssStyle = this.svgFactory.createElement("svg:style"), this.cssStyle.setAttributeNS(null, "type", "text/css"), this.defs.append(this.cssStyle));
              const _ = a(p.data, p.mimetype, this.forceDataSchema);
              this.cssStyle.textContent += `@font-face { font-family: "${p.loadedName}"; src: url(${_}); }
`;
            }
            setFont(p) {
              const _ = this.current, f = this.commonObjs.get(p[0]);
              let A = p[1];
              _.font = f, this.embedFonts && !f.missingFile && !this.embeddedFonts[f.loadedName] && (this.addFontStyle(f), this.embeddedFonts[f.loadedName] = f), _.fontMatrix = f.fontMatrix || s.FONT_IDENTITY_MATRIX;
              let C = "normal";
              f.black ? C = "900" : f.bold && (C = "bold");
              const W = f.italic ? "italic" : "normal";
              A < 0 ? (A = -A, _.fontDirection = -1) : _.fontDirection = 1, _.fontSize = A, _.fontFamily = f.loadedName, _.fontWeight = C, _.fontStyle = W, _.tspan = this.svgFactory.createElement("svg:tspan"), _.tspan.setAttributeNS(null, "y", k(-_.y)), _.xcoords = [], _.ycoords = [];
            }
            endText() {
              var _;
              const p = this.current;
              p.textRenderingMode & s.TextRenderingMode.ADD_TO_PATH_FLAG && ((_ = p.txtElement) != null && _.hasChildNodes()) && (p.element = p.txtElement, this.clip("nonzero"), this.endPath());
            }
            setLineWidth(p) {
              p > 0 && (this.current.lineWidth = p);
            }
            setLineCap(p) {
              this.current.lineCap = o[p];
            }
            setLineJoin(p) {
              this.current.lineJoin = l[p];
            }
            setMiterLimit(p) {
              this.current.miterLimit = p;
            }
            setStrokeAlpha(p) {
              this.current.strokeAlpha = p;
            }
            setStrokeRGBColor(p, _, f) {
              this.current.strokeColor = s.Util.makeHexColor(p, _, f);
            }
            setFillAlpha(p) {
              this.current.fillAlpha = p;
            }
            setFillRGBColor(p, _, f) {
              this.current.fillColor = s.Util.makeHexColor(p, _, f), this.current.tspan = this.svgFactory.createElement("svg:tspan"), this.current.xcoords = [], this.current.ycoords = [];
            }
            setStrokeColorN(p) {
              this.current.strokeColor = this._makeColorN_Pattern(p);
            }
            setFillColorN(p) {
              this.current.fillColor = this._makeColorN_Pattern(p);
            }
            shadingFill(p) {
              const {
                width: _,
                height: f
              } = this.viewport, A = s.Util.inverseTransform(this.transformMatrix), [C, W, m, I] = s.Util.getAxialAlignedBoundingBox([0, 0, _, f], A), q = this.svgFactory.createElement("svg:rect");
              q.setAttributeNS(null, "x", C), q.setAttributeNS(null, "y", W), q.setAttributeNS(null, "width", m - C), q.setAttributeNS(null, "height", I - W), q.setAttributeNS(null, "fill", this._makeShadingPattern(p)), this.current.fillAlpha < 1 && q.setAttributeNS(null, "fill-opacity", this.current.fillAlpha), this._ensureTransformGroup().append(q);
            }
            _makeColorN_Pattern(p) {
              return p[0] === "TilingPattern" ? this._makeTilingPattern(p) : this._makeShadingPattern(p);
            }
            _makeTilingPattern(p) {
              const _ = p[1], f = p[2], A = p[3] || s.IDENTITY_MATRIX, [C, W, m, I] = p[4], q = p[5], Y = p[6], X = p[7], z = `shading${w++}`, [L, et, D, G] = s.Util.normalizeRect([...s.Util.applyTransform([C, W], A), ...s.Util.applyTransform([m, I], A)]), [Q, F] = s.Util.singularValueDecompose2dScale(A), d = q * Q, u = Y * F, y = this.svgFactory.createElement("svg:pattern");
              y.setAttributeNS(null, "id", z), y.setAttributeNS(null, "patternUnits", "userSpaceOnUse"), y.setAttributeNS(null, "width", d), y.setAttributeNS(null, "height", u), y.setAttributeNS(null, "x", `${L}`), y.setAttributeNS(null, "y", `${et}`);
              const B = this.svg, N = this.transformMatrix, $ = this.current.fillColor, K = this.current.strokeColor, st = this.svgFactory.create(D - L, G - et);
              if (this.svg = st, this.transformMatrix = A, X === 2) {
                const dt = s.Util.makeHexColor(..._);
                this.current.fillColor = dt, this.current.strokeColor = dt;
              }
              return this.executeOpTree(this.convertOpList(f)), this.svg = B, this.transformMatrix = N, this.current.fillColor = $, this.current.strokeColor = K, y.append(st.childNodes[0]), this.defs.append(y), `url(#${z})`;
            }
            _makeShadingPattern(p) {
              switch (typeof p == "string" && (p = this.objs.get(p)), p[0]) {
                case "RadialAxial":
                  const _ = `shading${w++}`, f = p[3];
                  let A;
                  switch (p[1]) {
                    case "axial":
                      const C = p[4], W = p[5];
                      A = this.svgFactory.createElement("svg:linearGradient"), A.setAttributeNS(null, "id", _), A.setAttributeNS(null, "gradientUnits", "userSpaceOnUse"), A.setAttributeNS(null, "x1", C[0]), A.setAttributeNS(null, "y1", C[1]), A.setAttributeNS(null, "x2", W[0]), A.setAttributeNS(null, "y2", W[1]);
                      break;
                    case "radial":
                      const m = p[4], I = p[5], q = p[6], Y = p[7];
                      A = this.svgFactory.createElement("svg:radialGradient"), A.setAttributeNS(null, "id", _), A.setAttributeNS(null, "gradientUnits", "userSpaceOnUse"), A.setAttributeNS(null, "cx", I[0]), A.setAttributeNS(null, "cy", I[1]), A.setAttributeNS(null, "r", Y), A.setAttributeNS(null, "fx", m[0]), A.setAttributeNS(null, "fy", m[1]), A.setAttributeNS(null, "fr", q);
                      break;
                    default:
                      throw new Error(`Unknown RadialAxial type: ${p[1]}`);
                  }
                  for (const C of f) {
                    const W = this.svgFactory.createElement("svg:stop");
                    W.setAttributeNS(null, "offset", C[0]), W.setAttributeNS(null, "stop-color", C[1]), A.append(W);
                  }
                  return this.defs.append(A), `url(#${_})`;
                case "Mesh":
                  return (0, s.warn)("Unimplemented pattern Mesh"), null;
                case "Dummy":
                  return "hotpink";
                default:
                  throw new Error(`Unknown IR type: ${p[0]}`);
              }
            }
            setDash(p, _) {
              this.current.dashArray = p, this.current.dashPhase = _;
            }
            constructPath(p, _) {
              const f = this.current;
              let A = f.x, C = f.y, W = [], m = 0;
              for (const I of p)
                switch (I | 0) {
                  case s.OPS.rectangle:
                    A = _[m++], C = _[m++];
                    const q = _[m++], Y = _[m++], X = A + q, z = C + Y;
                    W.push("M", k(A), k(C), "L", k(X), k(C), "L", k(X), k(z), "L", k(A), k(z), "Z");
                    break;
                  case s.OPS.moveTo:
                    A = _[m++], C = _[m++], W.push("M", k(A), k(C));
                    break;
                  case s.OPS.lineTo:
                    A = _[m++], C = _[m++], W.push("L", k(A), k(C));
                    break;
                  case s.OPS.curveTo:
                    A = _[m + 4], C = _[m + 5], W.push("C", k(_[m]), k(_[m + 1]), k(_[m + 2]), k(_[m + 3]), k(A), k(C)), m += 6;
                    break;
                  case s.OPS.curveTo2:
                    W.push("C", k(A), k(C), k(_[m]), k(_[m + 1]), k(_[m + 2]), k(_[m + 3])), A = _[m + 2], C = _[m + 3], m += 4;
                    break;
                  case s.OPS.curveTo3:
                    A = _[m + 2], C = _[m + 3], W.push("C", k(_[m]), k(_[m + 1]), k(A), k(C), k(A), k(C)), m += 4;
                    break;
                  case s.OPS.closePath:
                    W.push("Z");
                    break;
                }
              W = W.join(" "), f.path && p.length > 0 && p[0] !== s.OPS.rectangle && p[0] !== s.OPS.moveTo ? W = f.path.getAttributeNS(null, "d") + W : (f.path = this.svgFactory.createElement("svg:path"), this._ensureTransformGroup().append(f.path)), f.path.setAttributeNS(null, "d", W), f.path.setAttributeNS(null, "fill", "none"), f.element = f.path, f.setCurrentPoint(A, C);
            }
            endPath() {
              const p = this.current;
              if (p.path = null, !this.pendingClip)
                return;
              if (!p.element) {
                this.pendingClip = null;
                return;
              }
              const _ = `clippath${S++}`, f = this.svgFactory.createElement("svg:clipPath");
              f.setAttributeNS(null, "id", _), f.setAttributeNS(null, "transform", x(this.transformMatrix));
              const A = p.element.cloneNode(!0);
              if (this.pendingClip === "evenodd" ? A.setAttributeNS(null, "clip-rule", "evenodd") : A.setAttributeNS(null, "clip-rule", "nonzero"), this.pendingClip = null, f.append(A), this.defs.append(f), p.activeClipUrl) {
                p.clipGroup = null;
                for (const C of this.extraStack)
                  C.clipGroup = null;
                f.setAttributeNS(null, "clip-path", p.activeClipUrl);
              }
              p.activeClipUrl = `url(#${_})`, this.tgrp = null;
            }
            clip(p) {
              this.pendingClip = p;
            }
            closePath() {
              const p = this.current;
              if (p.path) {
                const _ = `${p.path.getAttributeNS(null, "d")}Z`;
                p.path.setAttributeNS(null, "d", _);
              }
            }
            setLeading(p) {
              this.current.leading = -p;
            }
            setTextRise(p) {
              this.current.textRise = p;
            }
            setTextRenderingMode(p) {
              this.current.textRenderingMode = p;
            }
            setHScale(p) {
              this.current.textHScale = p / 100;
            }
            setRenderingIntent(p) {
            }
            setFlatness(p) {
            }
            setGState(p) {
              for (const [_, f] of p)
                switch (_) {
                  case "LW":
                    this.setLineWidth(f);
                    break;
                  case "LC":
                    this.setLineCap(f);
                    break;
                  case "LJ":
                    this.setLineJoin(f);
                    break;
                  case "ML":
                    this.setMiterLimit(f);
                    break;
                  case "D":
                    this.setDash(f[0], f[1]);
                    break;
                  case "RI":
                    this.setRenderingIntent(f);
                    break;
                  case "FL":
                    this.setFlatness(f);
                    break;
                  case "Font":
                    this.setFont(f);
                    break;
                  case "CA":
                    this.setStrokeAlpha(f);
                    break;
                  case "ca":
                    this.setFillAlpha(f);
                    break;
                  default:
                    (0, s.warn)(`Unimplemented graphic state operator ${_}`);
                    break;
                }
            }
            fill() {
              const p = this.current;
              p.element && (p.element.setAttributeNS(null, "fill", p.fillColor), p.element.setAttributeNS(null, "fill-opacity", p.fillAlpha), this.endPath());
            }
            stroke() {
              const p = this.current;
              p.element && (this._setStrokeAttributes(p.element), p.element.setAttributeNS(null, "fill", "none"), this.endPath());
            }
            _setStrokeAttributes(p, _ = 1) {
              const f = this.current;
              let A = f.dashArray;
              _ !== 1 && A.length > 0 && (A = A.map(function(C) {
                return _ * C;
              })), p.setAttributeNS(null, "stroke", f.strokeColor), p.setAttributeNS(null, "stroke-opacity", f.strokeAlpha), p.setAttributeNS(null, "stroke-miterlimit", k(f.miterLimit)), p.setAttributeNS(null, "stroke-linecap", f.lineCap), p.setAttributeNS(null, "stroke-linejoin", f.lineJoin), p.setAttributeNS(null, "stroke-width", k(_ * f.lineWidth) + "px"), p.setAttributeNS(null, "stroke-dasharray", A.map(k).join(" ")), p.setAttributeNS(null, "stroke-dashoffset", k(_ * f.dashPhase) + "px");
            }
            eoFill() {
              var p;
              (p = this.current.element) == null || p.setAttributeNS(null, "fill-rule", "evenodd"), this.fill();
            }
            fillStroke() {
              this.stroke(), this.fill();
            }
            eoFillStroke() {
              var p;
              (p = this.current.element) == null || p.setAttributeNS(null, "fill-rule", "evenodd"), this.fillStroke();
            }
            closeStroke() {
              this.closePath(), this.stroke();
            }
            closeFillStroke() {
              this.closePath(), this.fillStroke();
            }
            closeEOFillStroke() {
              this.closePath(), this.eoFillStroke();
            }
            paintSolidColorImageMask() {
              const p = this.svgFactory.createElement("svg:rect");
              p.setAttributeNS(null, "x", "0"), p.setAttributeNS(null, "y", "0"), p.setAttributeNS(null, "width", "1px"), p.setAttributeNS(null, "height", "1px"), p.setAttributeNS(null, "fill", this.current.fillColor), this._ensureTransformGroup().append(p);
            }
            paintImageXObject(p) {
              const _ = this.getObject(p);
              if (!_) {
                (0, s.warn)(`Dependent image with object ID ${p} is not ready yet`);
                return;
              }
              this.paintInlineImageXObject(_);
            }
            paintInlineImageXObject(p, _) {
              const f = p.width, A = p.height, C = T(p, this.forceDataSchema, !!_), W = this.svgFactory.createElement("svg:rect");
              W.setAttributeNS(null, "x", "0"), W.setAttributeNS(null, "y", "0"), W.setAttributeNS(null, "width", k(f)), W.setAttributeNS(null, "height", k(A)), this.current.element = W, this.clip("nonzero");
              const m = this.svgFactory.createElement("svg:image");
              m.setAttributeNS(b, "xlink:href", C), m.setAttributeNS(null, "x", "0"), m.setAttributeNS(null, "y", k(-A)), m.setAttributeNS(null, "width", k(f) + "px"), m.setAttributeNS(null, "height", k(A) + "px"), m.setAttributeNS(null, "transform", `scale(${k(1 / f)} ${k(-1 / A)})`), _ ? _.append(m) : this._ensureTransformGroup().append(m);
            }
            paintImageMaskXObject(p) {
              const _ = this.getObject(p.data, p);
              if (_.bitmap) {
                (0, s.warn)("paintImageMaskXObject: ImageBitmap support is not implemented, ensure that the `isOffscreenCanvasSupported` API parameter is disabled.");
                return;
              }
              const f = this.current, A = _.width, C = _.height, W = f.fillColor;
              f.maskId = `mask${E++}`;
              const m = this.svgFactory.createElement("svg:mask");
              m.setAttributeNS(null, "id", f.maskId);
              const I = this.svgFactory.createElement("svg:rect");
              I.setAttributeNS(null, "x", "0"), I.setAttributeNS(null, "y", "0"), I.setAttributeNS(null, "width", k(A)), I.setAttributeNS(null, "height", k(C)), I.setAttributeNS(null, "fill", W), I.setAttributeNS(null, "mask", `url(#${f.maskId})`), this.defs.append(m), this._ensureTransformGroup().append(I), this.paintInlineImageXObject(_, m);
            }
            paintFormXObjectBegin(p, _) {
              if (Array.isArray(p) && p.length === 6 && this.transform(p[0], p[1], p[2], p[3], p[4], p[5]), _) {
                const f = _[2] - _[0], A = _[3] - _[1], C = this.svgFactory.createElement("svg:rect");
                C.setAttributeNS(null, "x", _[0]), C.setAttributeNS(null, "y", _[1]), C.setAttributeNS(null, "width", k(f)), C.setAttributeNS(null, "height", k(A)), this.current.element = C, this.clip("nonzero"), this.endPath();
              }
            }
            paintFormXObjectEnd() {
            }
            _initialize(p) {
              const _ = this.svgFactory.create(p.width, p.height), f = this.svgFactory.createElement("svg:defs");
              _.append(f), this.defs = f;
              const A = this.svgFactory.createElement("svg:g");
              return A.setAttributeNS(null, "transform", x(p.transform)), _.append(A), this.svg = A, _;
            }
            _ensureClipGroup() {
              if (!this.current.clipGroup) {
                const p = this.svgFactory.createElement("svg:g");
                p.setAttributeNS(null, "clip-path", this.current.activeClipUrl), this.svg.append(p), this.current.clipGroup = p;
              }
              return this.current.clipGroup;
            }
            _ensureTransformGroup() {
              return this.tgrp || (this.tgrp = this.svgFactory.createElement("svg:g"), this.tgrp.setAttributeNS(null, "transform", x(this.transformMatrix)), this.current.activeClipUrl ? this._ensureClipGroup().append(this.tgrp) : this.svg.append(this.tgrp)), this.tgrp;
            }
          }
          t.SVGGraphics = M;
        },
        /* 25 */
        /***/
        (i, t) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.XfaText = void 0;
          class n {
            static textContent(s) {
              const c = [], h = {
                items: c,
                styles: /* @__PURE__ */ Object.create(null)
              };
              function b(o) {
                var T;
                if (!o)
                  return;
                let l = null;
                const a = o.name;
                if (a === "#text")
                  l = o.value;
                else if (n.shouldBuildText(a))
                  (T = o == null ? void 0 : o.attributes) != null && T.textContent ? l = o.attributes.textContent : o.value && (l = o.value);
                else return;
                if (l !== null && c.push({
                  str: l
                }), !!o.children)
                  for (const P of o.children)
                    b(P);
              }
              return b(s), h;
            }
            static shouldBuildText(s) {
              return !(s === "textarea" || s === "input" || s === "option" || s === "select");
            }
          }
          t.XfaText = n;
        },
        /* 26 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.TextLayerRenderTask = void 0, t.renderTextLayer = x, t.updateTextLayer = S;
          var e = n(1), s = n(6);
          const c = 1e5, h = 30, b = 0.8, o = /* @__PURE__ */ new Map();
          function l(E, w) {
            let M;
            if (w && e.FeatureTest.isOffscreenCanvasSupported)
              M = new OffscreenCanvas(E, E).getContext("2d", {
                alpha: !1
              });
            else {
              const g = document.createElement("canvas");
              g.width = g.height = E, M = g.getContext("2d", {
                alpha: !1
              });
            }
            return M;
          }
          function a(E, w) {
            const M = o.get(E);
            if (M)
              return M;
            const g = l(h, w);
            g.font = `${h}px ${E}`;
            const p = g.measureText("");
            let _ = p.fontBoundingBoxAscent, f = Math.abs(p.fontBoundingBoxDescent);
            if (_) {
              const C = _ / (_ + f);
              return o.set(E, C), g.canvas.width = g.canvas.height = 0, C;
            }
            g.strokeStyle = "red", g.clearRect(0, 0, h, h), g.strokeText("g", 0, 0);
            let A = g.getImageData(0, 0, h, h).data;
            f = 0;
            for (let C = A.length - 1 - 3; C >= 0; C -= 4)
              if (A[C] > 0) {
                f = Math.ceil(C / 4 / h);
                break;
              }
            g.clearRect(0, 0, h, h), g.strokeText("A", 0, h), A = g.getImageData(0, 0, h, h).data, _ = 0;
            for (let C = 0, W = A.length; C < W; C += 4)
              if (A[C] > 0) {
                _ = h - Math.floor(C / 4 / h);
                break;
              }
            if (g.canvas.width = g.canvas.height = 0, _) {
              const C = _ / (_ + f);
              return o.set(E, C), C;
            }
            return o.set(E, b), b;
          }
          function T(E, w, M) {
            const g = document.createElement("span"), p = {
              angle: 0,
              canvasWidth: 0,
              hasText: w.str !== "",
              hasEOL: w.hasEOL,
              fontSize: 0
            };
            E._textDivs.push(g);
            const _ = e.Util.transform(E._transform, w.transform);
            let f = Math.atan2(_[1], _[0]);
            const A = M[w.fontName];
            A.vertical && (f += Math.PI / 2);
            const C = Math.hypot(_[2], _[3]), W = C * a(A.fontFamily, E._isOffscreenCanvasSupported);
            let m, I;
            f === 0 ? (m = _[4], I = _[5] - W) : (m = _[4] + W * Math.sin(f), I = _[5] - W * Math.cos(f));
            const q = "calc(var(--scale-factor)*", Y = g.style;
            E._container === E._rootContainer ? (Y.left = `${(100 * m / E._pageWidth).toFixed(2)}%`, Y.top = `${(100 * I / E._pageHeight).toFixed(2)}%`) : (Y.left = `${q}${m.toFixed(2)}px)`, Y.top = `${q}${I.toFixed(2)}px)`), Y.fontSize = `${q}${C.toFixed(2)}px)`, Y.fontFamily = A.fontFamily, p.fontSize = C, g.setAttribute("role", "presentation"), g.textContent = w.str, g.dir = w.dir, E._fontInspectorEnabled && (g.dataset.fontName = w.fontName), f !== 0 && (p.angle = f * (180 / Math.PI));
            let X = !1;
            if (w.str.length > 1)
              X = !0;
            else if (w.str !== " " && w.transform[0] !== w.transform[3]) {
              const z = Math.abs(w.transform[0]), L = Math.abs(w.transform[3]);
              z !== L && Math.max(z, L) / Math.min(z, L) > 1.5 && (X = !0);
            }
            X && (p.canvasWidth = A.vertical ? w.height : w.width), E._textDivProperties.set(g, p), E._isReadableStream && E._layoutText(g);
          }
          function P(E) {
            const {
              div: w,
              scale: M,
              properties: g,
              ctx: p,
              prevFontSize: _,
              prevFontFamily: f
            } = E, {
              style: A
            } = w;
            let C = "";
            if (g.canvasWidth !== 0 && g.hasText) {
              const {
                fontFamily: W
              } = A, {
                canvasWidth: m,
                fontSize: I
              } = g;
              (_ !== I || f !== W) && (p.font = `${I * M}px ${W}`, E.prevFontSize = I, E.prevFontFamily = W);
              const {
                width: q
              } = p.measureText(w.textContent);
              q > 0 && (C = `scaleX(${m * M / q})`);
            }
            g.angle !== 0 && (C = `rotate(${g.angle}deg) ${C}`), C.length > 0 && (A.transform = C);
          }
          function v(E) {
            if (E._canceled)
              return;
            const w = E._textDivs, M = E._capability;
            if (w.length > c) {
              M.resolve();
              return;
            }
            if (!E._isReadableStream)
              for (const p of w)
                E._layoutText(p);
            M.resolve();
          }
          class k {
            constructor({
              textContentSource: w,
              container: M,
              viewport: g,
              textDivs: p,
              textDivProperties: _,
              textContentItemsStr: f,
              isOffscreenCanvasSupported: A
            }) {
              var q;
              this._textContentSource = w, this._isReadableStream = w instanceof ReadableStream, this._container = this._rootContainer = M, this._textDivs = p || [], this._textContentItemsStr = f || [], this._isOffscreenCanvasSupported = A, this._fontInspectorEnabled = !!((q = globalThis.FontInspector) != null && q.enabled), this._reader = null, this._textDivProperties = _ || /* @__PURE__ */ new WeakMap(), this._canceled = !1, this._capability = new e.PromiseCapability(), this._layoutTextParams = {
                prevFontSize: null,
                prevFontFamily: null,
                div: null,
                scale: g.scale * (globalThis.devicePixelRatio || 1),
                properties: null,
                ctx: l(0, A)
              };
              const {
                pageWidth: C,
                pageHeight: W,
                pageX: m,
                pageY: I
              } = g.rawDims;
              this._transform = [1, 0, 0, -1, -m, I + W], this._pageWidth = C, this._pageHeight = W, (0, s.setLayerDimensions)(M, g), this._capability.promise.finally(() => {
                this._layoutTextParams = null;
              }).catch(() => {
              });
            }
            get promise() {
              return this._capability.promise;
            }
            cancel() {
              this._canceled = !0, this._reader && (this._reader.cancel(new e.AbortException("TextLayer task cancelled.")).catch(() => {
              }), this._reader = null), this._capability.reject(new e.AbortException("TextLayer task cancelled."));
            }
            _processItems(w, M) {
              for (const g of w) {
                if (g.str === void 0) {
                  if (g.type === "beginMarkedContentProps" || g.type === "beginMarkedContent") {
                    const p = this._container;
                    this._container = document.createElement("span"), this._container.classList.add("markedContent"), g.id !== null && this._container.setAttribute("id", `${g.id}`), p.append(this._container);
                  } else g.type === "endMarkedContent" && (this._container = this._container.parentNode);
                  continue;
                }
                this._textContentItemsStr.push(g.str), T(this, g, M);
              }
            }
            _layoutText(w) {
              const M = this._layoutTextParams.properties = this._textDivProperties.get(w);
              if (this._layoutTextParams.div = w, P(this._layoutTextParams), M.hasText && this._container.append(w), M.hasEOL) {
                const g = document.createElement("br");
                g.setAttribute("role", "presentation"), this._container.append(g);
              }
            }
            _render() {
              const w = new e.PromiseCapability();
              let M = /* @__PURE__ */ Object.create(null);
              if (this._isReadableStream) {
                const g = () => {
                  this._reader.read().then(({
                    value: p,
                    done: _
                  }) => {
                    if (_) {
                      w.resolve();
                      return;
                    }
                    Object.assign(M, p.styles), this._processItems(p.items, M), g();
                  }, w.reject);
                };
                this._reader = this._textContentSource.getReader(), g();
              } else if (this._textContentSource) {
                const {
                  items: g,
                  styles: p
                } = this._textContentSource;
                this._processItems(g, p), w.resolve();
              } else
                throw new Error('No "textContentSource" parameter specified.');
              w.promise.then(() => {
                M = null, v(this);
              }, this._capability.reject);
            }
          }
          t.TextLayerRenderTask = k;
          function x(E) {
            !E.textContentSource && (E.textContent || E.textContentStream) && ((0, s.deprecated)("The TextLayerRender `textContent`/`textContentStream` parameters will be removed in the future, please use `textContentSource` instead."), E.textContentSource = E.textContent || E.textContentStream);
            const {
              container: w,
              viewport: M
            } = E, g = getComputedStyle(w), p = g.getPropertyValue("visibility"), _ = parseFloat(g.getPropertyValue("--scale-factor"));
            p === "visible" && (!_ || Math.abs(_ - M.scale) > 1e-5) && console.error("The `--scale-factor` CSS-variable must be set, to the same value as `viewport.scale`, either on the `container`-element itself or higher up in the DOM.");
            const f = new k(E);
            return f._render(), f;
          }
          function S({
            container: E,
            viewport: w,
            textDivs: M,
            textDivProperties: g,
            isOffscreenCanvasSupported: p,
            mustRotate: _ = !0,
            mustRescale: f = !0
          }) {
            if (_ && (0, s.setLayerDimensions)(E, {
              rotation: w.rotation
            }), f) {
              const A = l(0, p), W = {
                prevFontSize: null,
                prevFontFamily: null,
                div: null,
                scale: w.scale * (globalThis.devicePixelRatio || 1),
                properties: null,
                ctx: A
              };
              for (const m of M)
                W.properties = g.get(m), W.div = m, P(W);
            }
          }
        },
        /* 27 */
        /***/
        (i, t, n) => {
          var a, T, P, v, k, x, S, E, w, M, g, Ke, Ee, Je, Ze;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.AnnotationEditorLayer = void 0;
          var e = n(1), s = n(4), c = n(28), h = n(33), b = n(6), o = n(34);
          const C = class C {
            constructor({
              uiManager: m,
              pageIndex: I,
              div: q,
              accessibilityManager: Y,
              annotationLayer: X,
              viewport: z,
              l10n: L
            }) {
              at(this, g);
              at(this, a);
              at(this, T, !1);
              at(this, P, null);
              at(this, v, this.pointerup.bind(this));
              at(this, k, this.pointerdown.bind(this));
              at(this, x, /* @__PURE__ */ new Map());
              at(this, S, !1);
              at(this, E, !1);
              at(this, w, !1);
              at(this, M);
              const et = [c.FreeTextEditor, h.InkEditor, o.StampEditor];
              if (!C._initialized) {
                C._initialized = !0;
                for (const D of et)
                  D.initialize(L);
              }
              m.registerEditorTypes(et), lt(this, M, m), this.pageIndex = I, this.div = q, lt(this, a, Y), lt(this, P, X), this.viewport = z, r(this, M).addLayer(this);
            }
            get isEmpty() {
              return r(this, x).size === 0;
            }
            updateToolbar(m) {
              r(this, M).updateToolbar(m);
            }
            updateMode(m = r(this, M).getMode()) {
              Z(this, g, Ze).call(this), m === e.AnnotationEditorType.INK ? (this.addInkEditorIfNeeded(!1), this.disableClick()) : this.enableClick(), m !== e.AnnotationEditorType.NONE && (this.div.classList.toggle("freeTextEditing", m === e.AnnotationEditorType.FREETEXT), this.div.classList.toggle("inkEditing", m === e.AnnotationEditorType.INK), this.div.classList.toggle("stampEditing", m === e.AnnotationEditorType.STAMP), this.div.hidden = !1);
            }
            addInkEditorIfNeeded(m) {
              if (!m && r(this, M).getMode() !== e.AnnotationEditorType.INK)
                return;
              if (!m) {
                for (const q of r(this, x).values())
                  if (q.isEmpty()) {
                    q.setInBackground();
                    return;
                  }
              }
              Z(this, g, Ee).call(this, {
                offsetX: 0,
                offsetY: 0
              }, !1).setInBackground();
            }
            setEditingState(m) {
              r(this, M).setEditingState(m);
            }
            addCommands(m) {
              r(this, M).addCommands(m);
            }
            enable() {
              this.div.style.pointerEvents = "auto";
              const m = /* @__PURE__ */ new Set();
              for (const q of r(this, x).values())
                q.enableEditing(), q.annotationElementId && m.add(q.annotationElementId);
              if (!r(this, P))
                return;
              const I = r(this, P).getEditableAnnotations();
              for (const q of I) {
                if (q.hide(), r(this, M).isDeletedAnnotationElement(q.data.id) || m.has(q.data.id))
                  continue;
                const Y = this.deserialize(q);
                Y && (this.addOrRebuild(Y), Y.enableEditing());
              }
            }
            disable() {
              var I;
              lt(this, w, !0), this.div.style.pointerEvents = "none";
              const m = /* @__PURE__ */ new Set();
              for (const q of r(this, x).values()) {
                if (q.disableEditing(), !q.annotationElementId || q.serialize() !== null) {
                  m.add(q.annotationElementId);
                  continue;
                }
                (I = this.getEditableAnnotation(q.annotationElementId)) == null || I.show(), q.remove();
              }
              if (r(this, P)) {
                const q = r(this, P).getEditableAnnotations();
                for (const Y of q) {
                  const {
                    id: X
                  } = Y.data;
                  m.has(X) || r(this, M).isDeletedAnnotationElement(X) || Y.show();
                }
              }
              Z(this, g, Ze).call(this), this.isEmpty && (this.div.hidden = !0), lt(this, w, !1);
            }
            getEditableAnnotation(m) {
              var I;
              return ((I = r(this, P)) == null ? void 0 : I.getEditableAnnotation(m)) || null;
            }
            setActiveEditor(m) {
              r(this, M).getActive() !== m && r(this, M).setActiveEditor(m);
            }
            enableClick() {
              this.div.addEventListener("pointerdown", r(this, k)), this.div.addEventListener("pointerup", r(this, v));
            }
            disableClick() {
              this.div.removeEventListener("pointerdown", r(this, k)), this.div.removeEventListener("pointerup", r(this, v));
            }
            attach(m) {
              r(this, x).set(m.id, m);
              const {
                annotationElementId: I
              } = m;
              I && r(this, M).isDeletedAnnotationElement(I) && r(this, M).removeDeletedAnnotationElement(m);
            }
            detach(m) {
              var I;
              r(this, x).delete(m.id), (I = r(this, a)) == null || I.removePointerInTextLayer(m.contentDiv), !r(this, w) && m.annotationElementId && r(this, M).addDeletedAnnotationElement(m);
            }
            remove(m) {
              this.detach(m), r(this, M).removeEditor(m), m.div.contains(document.activeElement) && setTimeout(() => {
                r(this, M).focusMainContainer();
              }, 0), m.div.remove(), m.isAttachedToDOM = !1, r(this, E) || this.addInkEditorIfNeeded(!1);
            }
            changeParent(m) {
              var I;
              m.parent !== this && (m.annotationElementId && (r(this, M).addDeletedAnnotationElement(m.annotationElementId), s.AnnotationEditor.deleteAnnotationElement(m), m.annotationElementId = null), this.attach(m), (I = m.parent) == null || I.detach(m), m.setParent(this), m.div && m.isAttachedToDOM && (m.div.remove(), this.div.append(m.div)));
            }
            add(m) {
              if (this.changeParent(m), r(this, M).addEditor(m), this.attach(m), !m.isAttachedToDOM) {
                const I = m.render();
                this.div.append(I), m.isAttachedToDOM = !0;
              }
              m.fixAndSetPosition(), m.onceAdded(), r(this, M).addToAnnotationStorage(m);
            }
            moveEditorInDOM(m) {
              var q;
              if (!m.isAttachedToDOM)
                return;
              const {
                activeElement: I
              } = document;
              m.div.contains(I) && (m._focusEventsAllowed = !1, setTimeout(() => {
                m.div.contains(document.activeElement) ? m._focusEventsAllowed = !0 : (m.div.addEventListener("focusin", () => {
                  m._focusEventsAllowed = !0;
                }, {
                  once: !0
                }), I.focus());
              }, 0)), m._structTreeParentId = (q = r(this, a)) == null ? void 0 : q.moveElementInDOM(this.div, m.div, m.contentDiv, !0);
            }
            addOrRebuild(m) {
              m.needsToBeRebuilt() ? m.rebuild() : this.add(m);
            }
            addUndoableEditor(m) {
              const I = () => m._uiManager.rebuild(m), q = () => {
                m.remove();
              };
              this.addCommands({
                cmd: I,
                undo: q,
                mustExec: !1
              });
            }
            getNextId() {
              return r(this, M).getId();
            }
            pasteEditor(m, I) {
              r(this, M).updateToolbar(m), r(this, M).updateMode(m);
              const {
                offsetX: q,
                offsetY: Y
              } = Z(this, g, Je).call(this), X = this.getNextId(), z = Z(this, g, Ke).call(this, {
                parent: this,
                id: X,
                x: q,
                y: Y,
                uiManager: r(this, M),
                isCentered: !0,
                ...I
              });
              z && this.add(z);
            }
            deserialize(m) {
              switch (m.annotationType ?? m.annotationEditorType) {
                case e.AnnotationEditorType.FREETEXT:
                  return c.FreeTextEditor.deserialize(m, this, r(this, M));
                case e.AnnotationEditorType.INK:
                  return h.InkEditor.deserialize(m, this, r(this, M));
                case e.AnnotationEditorType.STAMP:
                  return o.StampEditor.deserialize(m, this, r(this, M));
              }
              return null;
            }
            addNewEditor() {
              Z(this, g, Ee).call(this, Z(this, g, Je).call(this), !0);
            }
            setSelected(m) {
              r(this, M).setSelected(m);
            }
            toggleSelected(m) {
              r(this, M).toggleSelected(m);
            }
            isSelected(m) {
              return r(this, M).isSelected(m);
            }
            unselect(m) {
              r(this, M).unselect(m);
            }
            pointerup(m) {
              const {
                isMac: I
              } = e.FeatureTest.platform;
              if (!(m.button !== 0 || m.ctrlKey && I) && m.target === this.div && r(this, S)) {
                if (lt(this, S, !1), !r(this, T)) {
                  lt(this, T, !0);
                  return;
                }
                if (r(this, M).getMode() === e.AnnotationEditorType.STAMP) {
                  r(this, M).unselectAll();
                  return;
                }
                Z(this, g, Ee).call(this, m, !1);
              }
            }
            pointerdown(m) {
              if (r(this, S)) {
                lt(this, S, !1);
                return;
              }
              const {
                isMac: I
              } = e.FeatureTest.platform;
              if (m.button !== 0 || m.ctrlKey && I || m.target !== this.div)
                return;
              lt(this, S, !0);
              const q = r(this, M).getActive();
              lt(this, T, !q || q.isEmpty());
            }
            findNewParent(m, I, q) {
              const Y = r(this, M).findParent(I, q);
              return Y === null || Y === this ? !1 : (Y.changeParent(m), !0);
            }
            destroy() {
              var m, I;
              ((m = r(this, M).getActive()) == null ? void 0 : m.parent) === this && (r(this, M).commitOrRemove(), r(this, M).setActiveEditor(null));
              for (const q of r(this, x).values())
                (I = r(this, a)) == null || I.removePointerInTextLayer(q.contentDiv), q.setParent(null), q.isAttachedToDOM = !1, q.div.remove();
              this.div = null, r(this, x).clear(), r(this, M).removeLayer(this);
            }
            render({
              viewport: m
            }) {
              this.viewport = m, (0, b.setLayerDimensions)(this.div, m);
              for (const I of r(this, M).getEditors(this.pageIndex))
                this.add(I);
              this.updateMode();
            }
            update({
              viewport: m
            }) {
              r(this, M).commitOrRemove(), this.viewport = m, (0, b.setLayerDimensions)(this.div, {
                rotation: m.rotation
              }), this.updateMode();
            }
            get pageDimensions() {
              const {
                pageWidth: m,
                pageHeight: I
              } = this.viewport.rawDims;
              return [m, I];
            }
          };
          a = new WeakMap(), T = new WeakMap(), P = new WeakMap(), v = new WeakMap(), k = new WeakMap(), x = new WeakMap(), S = new WeakMap(), E = new WeakMap(), w = new WeakMap(), M = new WeakMap(), g = new WeakSet(), Ke = function(m) {
            switch (r(this, M).getMode()) {
              case e.AnnotationEditorType.FREETEXT:
                return new c.FreeTextEditor(m);
              case e.AnnotationEditorType.INK:
                return new h.InkEditor(m);
              case e.AnnotationEditorType.STAMP:
                return new o.StampEditor(m);
            }
            return null;
          }, Ee = function(m, I) {
            const q = this.getNextId(), Y = Z(this, g, Ke).call(this, {
              parent: this,
              id: q,
              x: m.offsetX,
              y: m.offsetY,
              uiManager: r(this, M),
              isCentered: I
            });
            return Y && this.add(Y), Y;
          }, Je = function() {
            const {
              x: m,
              y: I,
              width: q,
              height: Y
            } = this.div.getBoundingClientRect(), X = Math.max(0, m), z = Math.max(0, I), L = Math.min(window.innerWidth, m + q), et = Math.min(window.innerHeight, I + Y), D = (X + L) / 2 - m, G = (z + et) / 2 - I, [Q, F] = this.viewport.rotation % 180 === 0 ? [D, G] : [G, D];
            return {
              offsetX: Q,
              offsetY: F
            };
          }, Ze = function() {
            lt(this, E, !0);
            for (const m of r(this, x).values())
              m.isEmpty() && m.remove();
            lt(this, E, !1);
          }, Kt(C, "_initialized", !1);
          let l = C;
          t.AnnotationEditorLayer = l;
        },
        /* 28 */
        /***/
        (i, t, n) => {
          var o, l, a, T, P, v, k, x, S, E, Pn, Fn, Mn, ge, Qe, Rn, tn;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.FreeTextEditor = void 0;
          var e = n(1), s = n(5), c = n(4), h = n(29);
          const C = class C extends c.AnnotationEditor {
            constructor(I) {
              super({
                ...I,
                name: "freeTextEditor"
              });
              at(this, E);
              at(this, o, this.editorDivBlur.bind(this));
              at(this, l, this.editorDivFocus.bind(this));
              at(this, a, this.editorDivInput.bind(this));
              at(this, T, this.editorDivKeydown.bind(this));
              at(this, P);
              at(this, v, "");
              at(this, k, `${this.id}-editor`);
              at(this, x);
              at(this, S, null);
              lt(this, P, I.color || C._defaultColor || c.AnnotationEditor._defaultLineColor), lt(this, x, I.fontSize || C._defaultFontSize);
            }
            static get _keyboardManager() {
              const I = C.prototype, q = (z) => z.isEmpty(), Y = s.AnnotationEditorUIManager.TRANSLATE_SMALL, X = s.AnnotationEditorUIManager.TRANSLATE_BIG;
              return (0, e.shadow)(this, "_keyboardManager", new s.KeyboardManager([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], I.commitOrRemove, {
                bubbles: !0
              }], [["ctrl+Enter", "mac+meta+Enter", "Escape", "mac+Escape"], I.commitOrRemove], [["ArrowLeft", "mac+ArrowLeft"], I._translateEmpty, {
                args: [-Y, 0],
                checker: q
              }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], I._translateEmpty, {
                args: [-X, 0],
                checker: q
              }], [["ArrowRight", "mac+ArrowRight"], I._translateEmpty, {
                args: [Y, 0],
                checker: q
              }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], I._translateEmpty, {
                args: [X, 0],
                checker: q
              }], [["ArrowUp", "mac+ArrowUp"], I._translateEmpty, {
                args: [0, -Y],
                checker: q
              }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], I._translateEmpty, {
                args: [0, -X],
                checker: q
              }], [["ArrowDown", "mac+ArrowDown"], I._translateEmpty, {
                args: [0, Y],
                checker: q
              }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], I._translateEmpty, {
                args: [0, X],
                checker: q
              }]]));
            }
            static initialize(I) {
              c.AnnotationEditor.initialize(I, {
                strings: ["free_text2_default_content", "editor_free_text2_aria_label"]
              });
              const q = getComputedStyle(document.documentElement);
              this._internalPadding = parseFloat(q.getPropertyValue("--freetext-padding"));
            }
            static updateDefaultParams(I, q) {
              switch (I) {
                case e.AnnotationEditorParamsType.FREETEXT_SIZE:
                  C._defaultFontSize = q;
                  break;
                case e.AnnotationEditorParamsType.FREETEXT_COLOR:
                  C._defaultColor = q;
                  break;
              }
            }
            updateParams(I, q) {
              switch (I) {
                case e.AnnotationEditorParamsType.FREETEXT_SIZE:
                  Z(this, E, Pn).call(this, q);
                  break;
                case e.AnnotationEditorParamsType.FREETEXT_COLOR:
                  Z(this, E, Fn).call(this, q);
                  break;
              }
            }
            static get defaultPropertiesToUpdate() {
              return [[e.AnnotationEditorParamsType.FREETEXT_SIZE, C._defaultFontSize], [e.AnnotationEditorParamsType.FREETEXT_COLOR, C._defaultColor || c.AnnotationEditor._defaultLineColor]];
            }
            get propertiesToUpdate() {
              return [[e.AnnotationEditorParamsType.FREETEXT_SIZE, r(this, x)], [e.AnnotationEditorParamsType.FREETEXT_COLOR, r(this, P)]];
            }
            _translateEmpty(I, q) {
              this._uiManager.translateSelectedEditors(I, q, !0);
            }
            getInitialTranslation() {
              const I = this.parentScale;
              return [-C._internalPadding * I, -(C._internalPadding + r(this, x)) * I];
            }
            rebuild() {
              this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
            }
            enableEditMode() {
              this.isInEditMode() || (this.parent.setEditingState(!1), this.parent.updateToolbar(e.AnnotationEditorType.FREETEXT), super.enableEditMode(), this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), this.editorDiv.addEventListener("keydown", r(this, T)), this.editorDiv.addEventListener("focus", r(this, l)), this.editorDiv.addEventListener("blur", r(this, o)), this.editorDiv.addEventListener("input", r(this, a)));
            }
            disableEditMode() {
              this.isInEditMode() && (this.parent.setEditingState(!0), super.disableEditMode(), this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", r(this, k)), this._isDraggable = !0, this.editorDiv.removeEventListener("keydown", r(this, T)), this.editorDiv.removeEventListener("focus", r(this, l)), this.editorDiv.removeEventListener("blur", r(this, o)), this.editorDiv.removeEventListener("input", r(this, a)), this.div.focus({
                preventScroll: !0
              }), this.isEditing = !1, this.parent.div.classList.add("freeTextEditing"));
            }
            focusin(I) {
              this._focusEventsAllowed && (super.focusin(I), I.target !== this.editorDiv && this.editorDiv.focus());
            }
            onceAdded() {
              var I;
              if (this.width) {
                Z(this, E, tn).call(this);
                return;
              }
              this.enableEditMode(), this.editorDiv.focus(), (I = this._initialOptions) != null && I.isCentered && this.center(), this._initialOptions = null;
            }
            isEmpty() {
              return !this.editorDiv || this.editorDiv.innerText.trim() === "";
            }
            remove() {
              this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freeTextEditing")), super.remove();
            }
            commit() {
              if (!this.isInEditMode())
                return;
              super.commit(), this.disableEditMode();
              const I = r(this, v), q = lt(this, v, Z(this, E, Mn).call(this).trimEnd());
              if (I === q)
                return;
              const Y = (X) => {
                if (lt(this, v, X), !X) {
                  this.remove();
                  return;
                }
                Z(this, E, Qe).call(this), this._uiManager.rebuild(this), Z(this, E, ge).call(this);
              };
              this.addCommands({
                cmd: () => {
                  Y(q);
                },
                undo: () => {
                  Y(I);
                },
                mustExec: !1
              }), Z(this, E, ge).call(this);
            }
            shouldGetKeyboardEvents() {
              return this.isInEditMode();
            }
            enterInEditMode() {
              this.enableEditMode(), this.editorDiv.focus();
            }
            dblclick(I) {
              this.enterInEditMode();
            }
            keydown(I) {
              I.target === this.div && I.key === "Enter" && (this.enterInEditMode(), I.preventDefault());
            }
            editorDivKeydown(I) {
              C._keyboardManager.exec(this, I);
            }
            editorDivFocus(I) {
              this.isEditing = !0;
            }
            editorDivBlur(I) {
              this.isEditing = !1;
            }
            editorDivInput(I) {
              this.parent.div.classList.toggle("freeTextEditing", this.isEmpty());
            }
            disableEditing() {
              this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
            }
            enableEditing() {
              this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
            }
            render() {
              if (this.div)
                return this.div;
              let I, q;
              this.width && (I = this.x, q = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", r(this, k)), this.enableEditing(), c.AnnotationEditor._l10nPromise.get("editor_free_text2_aria_label").then((X) => {
                var z;
                return (z = this.editorDiv) == null ? void 0 : z.setAttribute("aria-label", X);
              }), c.AnnotationEditor._l10nPromise.get("free_text2_default_content").then((X) => {
                var z;
                return (z = this.editorDiv) == null ? void 0 : z.setAttribute("default-content", X);
              }), this.editorDiv.contentEditable = !0;
              const {
                style: Y
              } = this.editorDiv;
              if (Y.fontSize = `calc(${r(this, x)}px * var(--scale-factor))`, Y.color = r(this, P), this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), (0, s.bindEvents)(this, this.div, ["dblclick", "keydown"]), this.width) {
                const [X, z] = this.parentDimensions;
                if (this.annotationElementId) {
                  const {
                    position: L
                  } = r(this, S);
                  let [et, D] = this.getInitialTranslation();
                  [et, D] = this.pageTranslationToScreen(et, D);
                  const [G, Q] = this.pageDimensions, [F, d] = this.pageTranslation;
                  let u, y;
                  switch (this.rotation) {
                    case 0:
                      u = I + (L[0] - F) / G, y = q + this.height - (L[1] - d) / Q;
                      break;
                    case 90:
                      u = I + (L[0] - F) / G, y = q - (L[1] - d) / Q, [et, D] = [D, -et];
                      break;
                    case 180:
                      u = I - this.width + (L[0] - F) / G, y = q - (L[1] - d) / Q, [et, D] = [-et, -D];
                      break;
                    case 270:
                      u = I + (L[0] - F - this.height * Q) / G, y = q + (L[1] - d - this.width * G) / Q, [et, D] = [-D, et];
                      break;
                  }
                  this.setAt(u * X, y * z, et, D);
                } else
                  this.setAt(I * X, q * z, this.width * X, this.height * z);
                Z(this, E, Qe).call(this), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
              } else
                this._isDraggable = !1, this.editorDiv.contentEditable = !0;
              return this.div;
            }
            get contentDiv() {
              return this.editorDiv;
            }
            static deserialize(I, q, Y) {
              let X = null;
              if (I instanceof h.FreeTextAnnotationElement) {
                const {
                  data: {
                    defaultAppearanceData: {
                      fontSize: L,
                      fontColor: et
                    },
                    rect: D,
                    rotation: G,
                    id: Q
                  },
                  textContent: F,
                  textPosition: d,
                  parent: {
                    page: {
                      pageNumber: u
                    }
                  }
                } = I;
                if (!F || F.length === 0)
                  return null;
                X = I = {
                  annotationType: e.AnnotationEditorType.FREETEXT,
                  color: Array.from(et),
                  fontSize: L,
                  value: F.join(`
`),
                  position: d,
                  pageIndex: u - 1,
                  rect: D,
                  rotation: G,
                  id: Q,
                  deleted: !1
                };
              }
              const z = super.deserialize(I, q, Y);
              return lt(z, x, I.fontSize), lt(z, P, e.Util.makeHexColor(...I.color)), lt(z, v, I.value), z.annotationElementId = I.id || null, lt(z, S, X), z;
            }
            serialize(I = !1) {
              if (this.isEmpty())
                return null;
              if (this.deleted)
                return {
                  pageIndex: this.pageIndex,
                  id: this.annotationElementId,
                  deleted: !0
                };
              const q = C._internalPadding * this.parentScale, Y = this.getRect(q, q), X = c.AnnotationEditor._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : r(this, P)), z = {
                annotationType: e.AnnotationEditorType.FREETEXT,
                color: X,
                fontSize: r(this, x),
                value: r(this, v),
                pageIndex: this.pageIndex,
                rect: Y,
                rotation: this.rotation,
                structTreeParentId: this._structTreeParentId
              };
              return I ? z : this.annotationElementId && !Z(this, E, Rn).call(this, z) ? null : (z.id = this.annotationElementId, z);
            }
          };
          o = new WeakMap(), l = new WeakMap(), a = new WeakMap(), T = new WeakMap(), P = new WeakMap(), v = new WeakMap(), k = new WeakMap(), x = new WeakMap(), S = new WeakMap(), E = new WeakSet(), Pn = function(I) {
            const q = (X) => {
              this.editorDiv.style.fontSize = `calc(${X}px * var(--scale-factor))`, this.translate(0, -(X - r(this, x)) * this.parentScale), lt(this, x, X), Z(this, E, ge).call(this);
            }, Y = r(this, x);
            this.addCommands({
              cmd: () => {
                q(I);
              },
              undo: () => {
                q(Y);
              },
              mustExec: !0,
              type: e.AnnotationEditorParamsType.FREETEXT_SIZE,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, Fn = function(I) {
            const q = r(this, P);
            this.addCommands({
              cmd: () => {
                lt(this, P, this.editorDiv.style.color = I);
              },
              undo: () => {
                lt(this, P, this.editorDiv.style.color = q);
              },
              mustExec: !0,
              type: e.AnnotationEditorParamsType.FREETEXT_COLOR,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, Mn = function() {
            const I = this.editorDiv.getElementsByTagName("div");
            if (I.length === 0)
              return this.editorDiv.innerText;
            const q = [];
            for (const Y of I)
              q.push(Y.innerText.replace(/\r\n?|\n/, ""));
            return q.join(`
`);
          }, ge = function() {
            const [I, q] = this.parentDimensions;
            let Y;
            if (this.isAttachedToDOM)
              Y = this.div.getBoundingClientRect();
            else {
              const {
                currentLayer: X,
                div: z
              } = this, L = z.style.display;
              z.style.display = "hidden", X.div.append(this.div), Y = z.getBoundingClientRect(), z.remove(), z.style.display = L;
            }
            this.rotation % 180 === this.parentRotation % 180 ? (this.width = Y.width / I, this.height = Y.height / q) : (this.width = Y.height / I, this.height = Y.width / q), this.fixAndSetPosition();
          }, Qe = function() {
            if (this.editorDiv.replaceChildren(), !!r(this, v))
              for (const I of r(this, v).split(`
`)) {
                const q = document.createElement("div");
                q.append(I ? document.createTextNode(I) : document.createElement("br")), this.editorDiv.append(q);
              }
          }, Rn = function(I) {
            const {
              value: q,
              fontSize: Y,
              color: X,
              rect: z,
              pageIndex: L
            } = r(this, S);
            return I.value !== q || I.fontSize !== Y || I.rect.some((et, D) => Math.abs(et - z[D]) >= 1) || I.color.some((et, D) => et !== X[D]) || I.pageIndex !== L;
          }, tn = function(I = !1) {
            if (!this.annotationElementId)
              return;
            if (Z(this, E, ge).call(this), !I && (this.width === 0 || this.height === 0)) {
              setTimeout(() => Z(this, E, tn).call(this, !0), 0);
              return;
            }
            const q = C._internalPadding * this.parentScale;
            r(this, S).rect = this.getRect(q, q);
          }, Kt(C, "_freeTextDefaultContent", ""), Kt(C, "_internalPadding", 0), Kt(C, "_defaultColor", null), Kt(C, "_defaultFontSize", 10), Kt(C, "_type", "freetext");
          let b = C;
          t.FreeTextEditor = b;
        },
        /* 29 */
        /***/
        (i, t, n) => {
          var y, N, se, xn, st, dt, pt, gt, mt, ut, tt, it, R, U, J, rt, _t, wt, vt, nt, kt, Et, Dn, Ce, en, nn, $t, Gt, Vt, At, ot, ct, Ft, sn, Wt, H, bt, Ct, In, rn;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.StampAnnotationElement = t.InkAnnotationElement = t.FreeTextAnnotationElement = t.AnnotationLayer = void 0;
          var e = n(1), s = n(6), c = n(3), h = n(30), b = n(31), o = n(32);
          const l = 1e3, a = 9, T = /* @__PURE__ */ new WeakSet();
          function P(Pt) {
            return {
              width: Pt[2] - Pt[0],
              height: Pt[3] - Pt[1]
            };
          }
          class v {
            static create(j) {
              switch (j.data.annotationType) {
                case e.AnnotationType.LINK:
                  return new x(j);
                case e.AnnotationType.TEXT:
                  return new S(j);
                case e.AnnotationType.WIDGET:
                  switch (j.data.fieldType) {
                    case "Tx":
                      return new w(j);
                    case "Btn":
                      return j.data.radioButton ? new p(j) : j.data.checkBox ? new g(j) : new _(j);
                    case "Ch":
                      return new f(j);
                    case "Sig":
                      return new M(j);
                  }
                  return new E(j);
                case e.AnnotationType.POPUP:
                  return new A(j);
                case e.AnnotationType.FREETEXT:
                  return new W(j);
                case e.AnnotationType.LINE:
                  return new m(j);
                case e.AnnotationType.SQUARE:
                  return new I(j);
                case e.AnnotationType.CIRCLE:
                  return new q(j);
                case e.AnnotationType.POLYLINE:
                  return new Y(j);
                case e.AnnotationType.CARET:
                  return new z(j);
                case e.AnnotationType.INK:
                  return new L(j);
                case e.AnnotationType.POLYGON:
                  return new X(j);
                case e.AnnotationType.HIGHLIGHT:
                  return new et(j);
                case e.AnnotationType.UNDERLINE:
                  return new D(j);
                case e.AnnotationType.SQUIGGLY:
                  return new G(j);
                case e.AnnotationType.STRIKEOUT:
                  return new Q(j);
                case e.AnnotationType.STAMP:
                  return new F(j);
                case e.AnnotationType.FILEATTACHMENT:
                  return new d(j);
                default:
                  return new k(j);
              }
            }
          }
          const B = class B {
            constructor(j, {
              isRenderable: O = !1,
              ignoreBorder: V = !1,
              createQuadrilaterals: ht = !1
            } = {}) {
              at(this, y, !1);
              this.isRenderable = O, this.data = j.data, this.layer = j.layer, this.linkService = j.linkService, this.downloadManager = j.downloadManager, this.imageResourcesPath = j.imageResourcesPath, this.renderForms = j.renderForms, this.svgFactory = j.svgFactory, this.annotationStorage = j.annotationStorage, this.enableScripting = j.enableScripting, this.hasJSActions = j.hasJSActions, this._fieldObjects = j.fieldObjects, this.parent = j.parent, O && (this.container = this._createContainer(V)), ht && this._createQuadrilaterals();
            }
            static _hasPopupData({
              titleObj: j,
              contentsObj: O,
              richText: V
            }) {
              return !!(j != null && j.str || O != null && O.str || V != null && V.str);
            }
            get hasPopupData() {
              return B._hasPopupData(this.data);
            }
            _createContainer(j) {
              const {
                data: O,
                parent: {
                  page: V,
                  viewport: ht
                }
              } = this, ft = document.createElement("section");
              ft.setAttribute("data-annotation-id", O.id), this instanceof E || (ft.tabIndex = l), ft.style.zIndex = this.parent.zIndex++, this.data.popupRef && ft.setAttribute("aria-haspopup", "dialog"), O.noRotate && ft.classList.add("norotate");
              const {
                pageWidth: yt,
                pageHeight: St,
                pageX: It,
                pageY: Rt
              } = ht.rawDims;
              if (!O.rect || this instanceof A) {
                const {
                  rotation: Bt
                } = O;
                return !O.hasOwnCanvas && Bt !== 0 && this.setRotation(Bt, ft), ft;
              }
              const {
                width: Tt,
                height: jt
              } = P(O.rect), xt = e.Util.normalizeRect([O.rect[0], V.view[3] - O.rect[1] + V.view[1], O.rect[2], V.view[3] - O.rect[3] + V.view[1]]);
              if (!j && O.borderStyle.width > 0) {
                ft.style.borderWidth = `${O.borderStyle.width}px`;
                const Bt = O.borderStyle.horizontalCornerRadius, qt = O.borderStyle.verticalCornerRadius;
                if (Bt > 0 || qt > 0) {
                  const Yt = `calc(${Bt}px * var(--scale-factor)) / calc(${qt}px * var(--scale-factor))`;
                  ft.style.borderRadius = Yt;
                } else if (this instanceof p) {
                  const Yt = `calc(${Tt}px * var(--scale-factor)) / calc(${jt}px * var(--scale-factor))`;
                  ft.style.borderRadius = Yt;
                }
                switch (O.borderStyle.style) {
                  case e.AnnotationBorderStyleType.SOLID:
                    ft.style.borderStyle = "solid";
                    break;
                  case e.AnnotationBorderStyleType.DASHED:
                    ft.style.borderStyle = "dashed";
                    break;
                  case e.AnnotationBorderStyleType.BEVELED:
                    (0, e.warn)("Unimplemented border style: beveled");
                    break;
                  case e.AnnotationBorderStyleType.INSET:
                    (0, e.warn)("Unimplemented border style: inset");
                    break;
                  case e.AnnotationBorderStyleType.UNDERLINE:
                    ft.style.borderBottomStyle = "solid";
                    break;
                }
                const Xt = O.borderColor || null;
                Xt ? (lt(this, y, !0), ft.style.borderColor = e.Util.makeHexColor(Xt[0] | 0, Xt[1] | 0, Xt[2] | 0)) : ft.style.borderWidth = 0;
              }
              ft.style.left = `${100 * (xt[0] - It) / yt}%`, ft.style.top = `${100 * (xt[1] - Rt) / St}%`;
              const {
                rotation: Lt
              } = O;
              return O.hasOwnCanvas || Lt === 0 ? (ft.style.width = `${100 * Tt / yt}%`, ft.style.height = `${100 * jt / St}%`) : this.setRotation(Lt, ft), ft;
            }
            setRotation(j, O = this.container) {
              if (!this.data.rect)
                return;
              const {
                pageWidth: V,
                pageHeight: ht
              } = this.parent.viewport.rawDims, {
                width: ft,
                height: yt
              } = P(this.data.rect);
              let St, It;
              j % 180 === 0 ? (St = 100 * ft / V, It = 100 * yt / ht) : (St = 100 * yt / V, It = 100 * ft / ht), O.style.width = `${St}%`, O.style.height = `${It}%`, O.setAttribute("data-main-rotation", (360 - j) % 360);
            }
            get _commonActions() {
              const j = (O, V, ht) => {
                const ft = ht.detail[O], yt = ft[0], St = ft.slice(1);
                ht.target.style[V] = h.ColorConverters[`${yt}_HTML`](St), this.annotationStorage.setValue(this.data.id, {
                  [V]: h.ColorConverters[`${yt}_rgb`](St)
                });
              };
              return (0, e.shadow)(this, "_commonActions", {
                display: (O) => {
                  const {
                    display: V
                  } = O.detail, ht = V % 2 === 1;
                  this.container.style.visibility = ht ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                    noView: ht,
                    noPrint: V === 1 || V === 2
                  });
                },
                print: (O) => {
                  this.annotationStorage.setValue(this.data.id, {
                    noPrint: !O.detail.print
                  });
                },
                hidden: (O) => {
                  const {
                    hidden: V
                  } = O.detail;
                  this.container.style.visibility = V ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                    noPrint: V,
                    noView: V
                  });
                },
                focus: (O) => {
                  setTimeout(() => O.target.focus({
                    preventScroll: !1
                  }), 0);
                },
                userName: (O) => {
                  O.target.title = O.detail.userName;
                },
                readonly: (O) => {
                  O.target.disabled = O.detail.readonly;
                },
                required: (O) => {
                  this._setRequired(O.target, O.detail.required);
                },
                bgColor: (O) => {
                  j("bgColor", "backgroundColor", O);
                },
                fillColor: (O) => {
                  j("fillColor", "backgroundColor", O);
                },
                fgColor: (O) => {
                  j("fgColor", "color", O);
                },
                textColor: (O) => {
                  j("textColor", "color", O);
                },
                borderColor: (O) => {
                  j("borderColor", "borderColor", O);
                },
                strokeColor: (O) => {
                  j("strokeColor", "borderColor", O);
                },
                rotation: (O) => {
                  const V = O.detail.rotation;
                  this.setRotation(V), this.annotationStorage.setValue(this.data.id, {
                    rotation: V
                  });
                }
              });
            }
            _dispatchEventFromSandbox(j, O) {
              const V = this._commonActions;
              for (const ht of Object.keys(O.detail)) {
                const ft = j[ht] || V[ht];
                ft == null || ft(O);
              }
            }
            _setDefaultPropertiesFromJS(j) {
              if (!this.enableScripting)
                return;
              const O = this.annotationStorage.getRawValue(this.data.id);
              if (!O)
                return;
              const V = this._commonActions;
              for (const [ht, ft] of Object.entries(O)) {
                const yt = V[ht];
                if (yt) {
                  const St = {
                    detail: {
                      [ht]: ft
                    },
                    target: j
                  };
                  yt(St), delete O[ht];
                }
              }
            }
            _createQuadrilaterals() {
              if (!this.container)
                return;
              const {
                quadPoints: j
              } = this.data;
              if (!j)
                return;
              const [O, V, ht, ft] = this.data.rect;
              if (j.length === 1) {
                const [, {
                  x: qt,
                  y: Xt
                }, {
                  x: Yt,
                  y: Zt
                }] = j[0];
                if (ht === qt && ft === Xt && O === Yt && V === Zt)
                  return;
              }
              const {
                style: yt
              } = this.container;
              let St;
              if (r(this, y)) {
                const {
                  borderColor: qt,
                  borderWidth: Xt
                } = yt;
                yt.borderWidth = 0, St = ["url('data:image/svg+xml;utf8,", '<svg xmlns="http://www.w3.org/2000/svg"', ' preserveAspectRatio="none" viewBox="0 0 1 1">', `<g fill="transparent" stroke="${qt}" stroke-width="${Xt}">`], this.container.classList.add("hasBorder");
              }
              const It = ht - O, Rt = ft - V, {
                svgFactory: Tt
              } = this, jt = Tt.createElement("svg");
              jt.classList.add("quadrilateralsContainer"), jt.setAttribute("width", 0), jt.setAttribute("height", 0);
              const xt = Tt.createElement("defs");
              jt.append(xt);
              const Lt = Tt.createElement("clipPath"), Bt = `clippath_${this.data.id}`;
              Lt.setAttribute("id", Bt), Lt.setAttribute("clipPathUnits", "objectBoundingBox"), xt.append(Lt);
              for (const [, {
                x: qt,
                y: Xt
              }, {
                x: Yt,
                y: Zt
              }] of j) {
                const Jt = Tt.createElement("rect"), te = (Yt - O) / It, ne = (ft - Xt) / Rt, ie = (qt - Yt) / It, gn = (Xt - Zt) / Rt;
                Jt.setAttribute("x", te), Jt.setAttribute("y", ne), Jt.setAttribute("width", ie), Jt.setAttribute("height", gn), Lt.append(Jt), St == null || St.push(`<rect vector-effect="non-scaling-stroke" x="${te}" y="${ne}" width="${ie}" height="${gn}"/>`);
              }
              r(this, y) && (St.push("</g></svg>')"), yt.backgroundImage = St.join("")), this.container.append(jt), this.container.style.clipPath = `url(#${Bt})`;
            }
            _createPopup() {
              const {
                container: j,
                data: O
              } = this;
              j.setAttribute("aria-haspopup", "dialog");
              const V = new A({
                data: {
                  color: O.color,
                  titleObj: O.titleObj,
                  modificationDate: O.modificationDate,
                  contentsObj: O.contentsObj,
                  richText: O.richText,
                  parentRect: O.rect,
                  borderStyle: 0,
                  id: `popup_${O.id}`,
                  rotation: O.rotation
                },
                parent: this.parent,
                elements: [this]
              });
              this.parent.div.append(V.render());
            }
            render() {
              (0, e.unreachable)("Abstract method `AnnotationElement.render` called");
            }
            _getElementsByName(j, O = null) {
              const V = [];
              if (this._fieldObjects) {
                const ht = this._fieldObjects[j];
                if (ht)
                  for (const {
                    page: ft,
                    id: yt,
                    exportValues: St
                  } of ht) {
                    if (ft === -1 || yt === O)
                      continue;
                    const It = typeof St == "string" ? St : null, Rt = document.querySelector(`[data-element-id="${yt}"]`);
                    if (Rt && !T.has(Rt)) {
                      (0, e.warn)(`_getElementsByName - element not allowed: ${yt}`);
                      continue;
                    }
                    V.push({
                      id: yt,
                      exportValue: It,
                      domElement: Rt
                    });
                  }
                return V;
              }
              for (const ht of document.getElementsByName(j)) {
                const {
                  exportValue: ft
                } = ht, yt = ht.getAttribute("data-element-id");
                yt !== O && T.has(ht) && V.push({
                  id: yt,
                  exportValue: ft,
                  domElement: ht
                });
              }
              return V;
            }
            show() {
              var j;
              this.container && (this.container.hidden = !1), (j = this.popup) == null || j.maybeShow();
            }
            hide() {
              var j;
              this.container && (this.container.hidden = !0), (j = this.popup) == null || j.forceHide();
            }
            getElementsToTriggerPopup() {
              return this.container;
            }
            addHighlightArea() {
              const j = this.getElementsToTriggerPopup();
              if (Array.isArray(j))
                for (const O of j)
                  O.classList.add("highlightArea");
              else
                j.classList.add("highlightArea");
            }
            _editOnDoubleClick() {
              const {
                annotationEditorType: j,
                data: {
                  id: O
                }
              } = this;
              this.container.addEventListener("dblclick", () => {
                var V;
                (V = this.linkService.eventBus) == null || V.dispatch("switchannotationeditormode", {
                  source: this,
                  mode: j,
                  editId: O
                });
              });
            }
          };
          y = new WeakMap();
          let k = B;
          class x extends k {
            constructor(O, V = null) {
              super(O, {
                isRenderable: !0,
                ignoreBorder: !!(V != null && V.ignoreBorder),
                createQuadrilaterals: !0
              });
              at(this, N);
              this.isTooltipOnly = O.data.isTooltipOnly;
            }
            render() {
              const {
                data: O,
                linkService: V
              } = this, ht = document.createElement("a");
              ht.setAttribute("data-element-id", O.id);
              let ft = !1;
              return O.url ? (V.addLinkAttributes(ht, O.url, O.newWindow), ft = !0) : O.action ? (this._bindNamedAction(ht, O.action), ft = !0) : O.attachment ? (this._bindAttachment(ht, O.attachment), ft = !0) : O.setOCGState ? (Z(this, N, xn).call(this, ht, O.setOCGState), ft = !0) : O.dest ? (this._bindLink(ht, O.dest), ft = !0) : (O.actions && (O.actions.Action || O.actions["Mouse Up"] || O.actions["Mouse Down"]) && this.enableScripting && this.hasJSActions && (this._bindJSAction(ht, O), ft = !0), O.resetForm ? (this._bindResetFormAction(ht, O.resetForm), ft = !0) : this.isTooltipOnly && !ft && (this._bindLink(ht, ""), ft = !0)), this.container.classList.add("linkAnnotation"), ft && this.container.append(ht), this.container;
            }
            _bindLink(O, V) {
              O.href = this.linkService.getDestinationHash(V), O.onclick = () => (V && this.linkService.goToDestination(V), !1), (V || V === "") && Z(this, N, se).call(this);
            }
            _bindNamedAction(O, V) {
              O.href = this.linkService.getAnchorUrl(""), O.onclick = () => (this.linkService.executeNamedAction(V), !1), Z(this, N, se).call(this);
            }
            _bindAttachment(O, V) {
              O.href = this.linkService.getAnchorUrl(""), O.onclick = () => {
                var ht;
                return (ht = this.downloadManager) == null || ht.openOrDownloadData(this.container, V.content, V.filename), !1;
              }, Z(this, N, se).call(this);
            }
            _bindJSAction(O, V) {
              O.href = this.linkService.getAnchorUrl("");
              const ht = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
              for (const ft of Object.keys(V.actions)) {
                const yt = ht.get(ft);
                yt && (O[yt] = () => {
                  var St;
                  return (St = this.linkService.eventBus) == null || St.dispatch("dispatcheventinsandbox", {
                    source: this,
                    detail: {
                      id: V.id,
                      name: ft
                    }
                  }), !1;
                });
              }
              O.onclick || (O.onclick = () => !1), Z(this, N, se).call(this);
            }
            _bindResetFormAction(O, V) {
              const ht = O.onclick;
              if (ht || (O.href = this.linkService.getAnchorUrl("")), Z(this, N, se).call(this), !this._fieldObjects) {
                (0, e.warn)('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), ht || (O.onclick = () => !1);
                return;
              }
              O.onclick = () => {
                var jt;
                ht == null || ht();
                const {
                  fields: ft,
                  refs: yt,
                  include: St
                } = V, It = [];
                if (ft.length !== 0 || yt.length !== 0) {
                  const xt = new Set(yt);
                  for (const Lt of ft) {
                    const Bt = this._fieldObjects[Lt] || [];
                    for (const {
                      id: qt
                    } of Bt)
                      xt.add(qt);
                  }
                  for (const Lt of Object.values(this._fieldObjects))
                    for (const Bt of Lt)
                      xt.has(Bt.id) === St && It.push(Bt);
                } else
                  for (const xt of Object.values(this._fieldObjects))
                    It.push(...xt);
                const Rt = this.annotationStorage, Tt = [];
                for (const xt of It) {
                  const {
                    id: Lt
                  } = xt;
                  switch (Tt.push(Lt), xt.type) {
                    case "text": {
                      const qt = xt.defaultValue || "";
                      Rt.setValue(Lt, {
                        value: qt
                      });
                      break;
                    }
                    case "checkbox":
                    case "radiobutton": {
                      const qt = xt.defaultValue === xt.exportValues;
                      Rt.setValue(Lt, {
                        value: qt
                      });
                      break;
                    }
                    case "combobox":
                    case "listbox": {
                      const qt = xt.defaultValue || "";
                      Rt.setValue(Lt, {
                        value: qt
                      });
                      break;
                    }
                    default:
                      continue;
                  }
                  const Bt = document.querySelector(`[data-element-id="${Lt}"]`);
                  if (Bt) {
                    if (!T.has(Bt)) {
                      (0, e.warn)(`_bindResetFormAction - element not allowed: ${Lt}`);
                      continue;
                    }
                  } else continue;
                  Bt.dispatchEvent(new Event("resetform"));
                }
                return this.enableScripting && ((jt = this.linkService.eventBus) == null || jt.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: "app",
                    ids: Tt,
                    name: "ResetForm"
                  }
                })), !1;
              };
            }
          }
          N = new WeakSet(), se = function() {
            this.container.setAttribute("data-internal-link", "");
          }, xn = function(O, V) {
            O.href = this.linkService.getAnchorUrl(""), O.onclick = () => (this.linkService.executeSetOCGState(V), !1), Z(this, N, se).call(this);
          };
          class S extends k {
            constructor(j) {
              super(j, {
                isRenderable: !0
              });
            }
            render() {
              this.container.classList.add("textAnnotation");
              const j = document.createElement("img");
              return j.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", j.alt = "[{{type}} Annotation]", j.dataset.l10nId = "text_annotation_type", j.dataset.l10nArgs = JSON.stringify({
                type: this.data.name
              }), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.append(j), this.container;
            }
          }
          class E extends k {
            render() {
              return this.data.alternativeText && (this.container.title = this.data.alternativeText), this.container;
            }
            showElementAndHideCanvas(j) {
              var O;
              this.data.hasOwnCanvas && (((O = j.previousSibling) == null ? void 0 : O.nodeName) === "CANVAS" && (j.previousSibling.hidden = !0), j.hidden = !1);
            }
            _getKeyModifier(j) {
              const {
                isWin: O,
                isMac: V
              } = e.FeatureTest.platform;
              return O && j.ctrlKey || V && j.metaKey;
            }
            _setEventListener(j, O, V, ht, ft) {
              V.includes("mouse") ? j.addEventListener(V, (yt) => {
                var St;
                (St = this.linkService.eventBus) == null || St.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: this.data.id,
                    name: ht,
                    value: ft(yt),
                    shift: yt.shiftKey,
                    modifier: this._getKeyModifier(yt)
                  }
                });
              }) : j.addEventListener(V, (yt) => {
                var St;
                if (V === "blur") {
                  if (!O.focused || !yt.relatedTarget)
                    return;
                  O.focused = !1;
                } else if (V === "focus") {
                  if (O.focused)
                    return;
                  O.focused = !0;
                }
                ft && ((St = this.linkService.eventBus) == null || St.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: this.data.id,
                    name: ht,
                    value: ft(yt)
                  }
                }));
              });
            }
            _setEventListeners(j, O, V, ht) {
              var ft, yt, St;
              for (const [It, Rt] of V)
                (Rt === "Action" || (ft = this.data.actions) != null && ft[Rt]) && ((Rt === "Focus" || Rt === "Blur") && (O || (O = {
                  focused: !1
                })), this._setEventListener(j, O, It, Rt, ht), Rt === "Focus" && !((yt = this.data.actions) != null && yt.Blur) ? this._setEventListener(j, O, "blur", "Blur", null) : Rt === "Blur" && !((St = this.data.actions) != null && St.Focus) && this._setEventListener(j, O, "focus", "Focus", null));
            }
            _setBackgroundColor(j) {
              const O = this.data.backgroundColor || null;
              j.style.backgroundColor = O === null ? "transparent" : e.Util.makeHexColor(O[0], O[1], O[2]);
            }
            _setTextStyle(j) {
              const O = ["left", "center", "right"], {
                fontColor: V
              } = this.data.defaultAppearanceData, ht = this.data.defaultAppearanceData.fontSize || a, ft = j.style;
              let yt;
              const St = 2, It = (Rt) => Math.round(10 * Rt) / 10;
              if (this.data.multiLine) {
                const Rt = Math.abs(this.data.rect[3] - this.data.rect[1] - St), Tt = Math.round(Rt / (e.LINE_FACTOR * ht)) || 1, jt = Rt / Tt;
                yt = Math.min(ht, It(jt / e.LINE_FACTOR));
              } else {
                const Rt = Math.abs(this.data.rect[3] - this.data.rect[1] - St);
                yt = Math.min(ht, It(Rt / e.LINE_FACTOR));
              }
              ft.fontSize = `calc(${yt}px * var(--scale-factor))`, ft.color = e.Util.makeHexColor(V[0], V[1], V[2]), this.data.textAlignment !== null && (ft.textAlign = O[this.data.textAlignment]);
            }
            _setRequired(j, O) {
              O ? j.setAttribute("required", !0) : j.removeAttribute("required"), j.setAttribute("aria-required", O);
            }
          }
          class w extends E {
            constructor(j) {
              const O = j.renderForms || !j.data.hasAppearance && !!j.data.fieldValue;
              super(j, {
                isRenderable: O
              });
            }
            setPropertyOnSiblings(j, O, V, ht) {
              const ft = this.annotationStorage;
              for (const yt of this._getElementsByName(j.name, j.id))
                yt.domElement && (yt.domElement[O] = V), ft.setValue(yt.id, {
                  [ht]: V
                });
            }
            render() {
              var ht, ft;
              const j = this.annotationStorage, O = this.data.id;
              this.container.classList.add("textWidgetAnnotation");
              let V = null;
              if (this.renderForms) {
                const yt = j.getValue(O, {
                  value: this.data.fieldValue
                });
                let St = yt.value || "";
                const It = j.getValue(O, {
                  charLimit: this.data.maxLen
                }).charLimit;
                It && St.length > It && (St = St.slice(0, It));
                let Rt = yt.formattedValue || ((ht = this.data.textContent) == null ? void 0 : ht.join(`
`)) || null;
                Rt && this.data.comb && (Rt = Rt.replaceAll(/\s+/g, ""));
                const Tt = {
                  userValue: St,
                  formattedValue: Rt,
                  lastCommittedValue: null,
                  commitKey: 1,
                  focused: !1
                };
                this.data.multiLine ? (V = document.createElement("textarea"), V.textContent = Rt ?? St, this.data.doNotScroll && (V.style.overflowY = "hidden")) : (V = document.createElement("input"), V.type = "text", V.setAttribute("value", Rt ?? St), this.data.doNotScroll && (V.style.overflowX = "hidden")), this.data.hasOwnCanvas && (V.hidden = !0), T.add(V), V.setAttribute("data-element-id", O), V.disabled = this.data.readOnly, V.name = this.data.fieldName, V.tabIndex = l, this._setRequired(V, this.data.required), It && (V.maxLength = It), V.addEventListener("input", (xt) => {
                  j.setValue(O, {
                    value: xt.target.value
                  }), this.setPropertyOnSiblings(V, "value", xt.target.value, "value"), Tt.formattedValue = null;
                }), V.addEventListener("resetform", (xt) => {
                  const Lt = this.data.defaultFieldValue ?? "";
                  V.value = Tt.userValue = Lt, Tt.formattedValue = null;
                });
                let jt = (xt) => {
                  const {
                    formattedValue: Lt
                  } = Tt;
                  Lt != null && (xt.target.value = Lt), xt.target.scrollLeft = 0;
                };
                if (this.enableScripting && this.hasJSActions) {
                  V.addEventListener("focus", (Lt) => {
                    if (Tt.focused)
                      return;
                    const {
                      target: Bt
                    } = Lt;
                    Tt.userValue && (Bt.value = Tt.userValue), Tt.lastCommittedValue = Bt.value, Tt.commitKey = 1, Tt.focused = !0;
                  }), V.addEventListener("updatefromsandbox", (Lt) => {
                    this.showElementAndHideCanvas(Lt.target);
                    const Bt = {
                      value(qt) {
                        Tt.userValue = qt.detail.value ?? "", j.setValue(O, {
                          value: Tt.userValue.toString()
                        }), qt.target.value = Tt.userValue;
                      },
                      formattedValue(qt) {
                        const {
                          formattedValue: Xt
                        } = qt.detail;
                        Tt.formattedValue = Xt, Xt != null && qt.target !== document.activeElement && (qt.target.value = Xt), j.setValue(O, {
                          formattedValue: Xt
                        });
                      },
                      selRange(qt) {
                        qt.target.setSelectionRange(...qt.detail.selRange);
                      },
                      charLimit: (qt) => {
                        var Jt;
                        const {
                          charLimit: Xt
                        } = qt.detail, {
                          target: Yt
                        } = qt;
                        if (Xt === 0) {
                          Yt.removeAttribute("maxLength");
                          return;
                        }
                        Yt.setAttribute("maxLength", Xt);
                        let Zt = Tt.userValue;
                        !Zt || Zt.length <= Xt || (Zt = Zt.slice(0, Xt), Yt.value = Tt.userValue = Zt, j.setValue(O, {
                          value: Zt
                        }), (Jt = this.linkService.eventBus) == null || Jt.dispatch("dispatcheventinsandbox", {
                          source: this,
                          detail: {
                            id: O,
                            name: "Keystroke",
                            value: Zt,
                            willCommit: !0,
                            commitKey: 1,
                            selStart: Yt.selectionStart,
                            selEnd: Yt.selectionEnd
                          }
                        }));
                      }
                    };
                    this._dispatchEventFromSandbox(Bt, Lt);
                  }), V.addEventListener("keydown", (Lt) => {
                    var Xt;
                    Tt.commitKey = 1;
                    let Bt = -1;
                    if (Lt.key === "Escape" ? Bt = 0 : Lt.key === "Enter" && !this.data.multiLine ? Bt = 2 : Lt.key === "Tab" && (Tt.commitKey = 3), Bt === -1)
                      return;
                    const {
                      value: qt
                    } = Lt.target;
                    Tt.lastCommittedValue !== qt && (Tt.lastCommittedValue = qt, Tt.userValue = qt, (Xt = this.linkService.eventBus) == null || Xt.dispatch("dispatcheventinsandbox", {
                      source: this,
                      detail: {
                        id: O,
                        name: "Keystroke",
                        value: qt,
                        willCommit: !0,
                        commitKey: Bt,
                        selStart: Lt.target.selectionStart,
                        selEnd: Lt.target.selectionEnd
                      }
                    }));
                  });
                  const xt = jt;
                  jt = null, V.addEventListener("blur", (Lt) => {
                    var qt;
                    if (!Tt.focused || !Lt.relatedTarget)
                      return;
                    Tt.focused = !1;
                    const {
                      value: Bt
                    } = Lt.target;
                    Tt.userValue = Bt, Tt.lastCommittedValue !== Bt && ((qt = this.linkService.eventBus) == null || qt.dispatch("dispatcheventinsandbox", {
                      source: this,
                      detail: {
                        id: O,
                        name: "Keystroke",
                        value: Bt,
                        willCommit: !0,
                        commitKey: Tt.commitKey,
                        selStart: Lt.target.selectionStart,
                        selEnd: Lt.target.selectionEnd
                      }
                    })), xt(Lt);
                  }), (ft = this.data.actions) != null && ft.Keystroke && V.addEventListener("beforeinput", (Lt) => {
                    var ne;
                    Tt.lastCommittedValue = null;
                    const {
                      data: Bt,
                      target: qt
                    } = Lt, {
                      value: Xt,
                      selectionStart: Yt,
                      selectionEnd: Zt
                    } = qt;
                    let Jt = Yt, te = Zt;
                    switch (Lt.inputType) {
                      case "deleteWordBackward": {
                        const ie = Xt.substring(0, Yt).match(/\w*[^\w]*$/);
                        ie && (Jt -= ie[0].length);
                        break;
                      }
                      case "deleteWordForward": {
                        const ie = Xt.substring(Yt).match(/^[^\w]*\w*/);
                        ie && (te += ie[0].length);
                        break;
                      }
                      case "deleteContentBackward":
                        Yt === Zt && (Jt -= 1);
                        break;
                      case "deleteContentForward":
                        Yt === Zt && (te += 1);
                        break;
                    }
                    Lt.preventDefault(), (ne = this.linkService.eventBus) == null || ne.dispatch("dispatcheventinsandbox", {
                      source: this,
                      detail: {
                        id: O,
                        name: "Keystroke",
                        value: Xt,
                        change: Bt || "",
                        willCommit: !1,
                        selStart: Jt,
                        selEnd: te
                      }
                    });
                  }), this._setEventListeners(V, Tt, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (Lt) => Lt.target.value);
                }
                if (jt && V.addEventListener("blur", jt), this.data.comb) {
                  const Lt = (this.data.rect[2] - this.data.rect[0]) / It;
                  V.classList.add("comb"), V.style.letterSpacing = `calc(${Lt}px * var(--scale-factor) - 1ch)`;
                }
              } else
                V = document.createElement("div"), V.textContent = this.data.fieldValue, V.style.verticalAlign = "middle", V.style.display = "table-cell";
              return this._setTextStyle(V), this._setBackgroundColor(V), this._setDefaultPropertiesFromJS(V), this.container.append(V), this.container;
            }
          }
          class M extends E {
            constructor(j) {
              super(j, {
                isRenderable: !!j.data.hasOwnCanvas
              });
            }
          }
          class g extends E {
            constructor(j) {
              super(j, {
                isRenderable: j.renderForms
              });
            }
            render() {
              const j = this.annotationStorage, O = this.data, V = O.id;
              let ht = j.getValue(V, {
                value: O.exportValue === O.fieldValue
              }).value;
              typeof ht == "string" && (ht = ht !== "Off", j.setValue(V, {
                value: ht
              })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
              const ft = document.createElement("input");
              return T.add(ft), ft.setAttribute("data-element-id", V), ft.disabled = O.readOnly, this._setRequired(ft, this.data.required), ft.type = "checkbox", ft.name = O.fieldName, ht && ft.setAttribute("checked", !0), ft.setAttribute("exportValue", O.exportValue), ft.tabIndex = l, ft.addEventListener("change", (yt) => {
                const {
                  name: St,
                  checked: It
                } = yt.target;
                for (const Rt of this._getElementsByName(St, V)) {
                  const Tt = It && Rt.exportValue === O.exportValue;
                  Rt.domElement && (Rt.domElement.checked = Tt), j.setValue(Rt.id, {
                    value: Tt
                  });
                }
                j.setValue(V, {
                  value: It
                });
              }), ft.addEventListener("resetform", (yt) => {
                const St = O.defaultFieldValue || "Off";
                yt.target.checked = St === O.exportValue;
              }), this.enableScripting && this.hasJSActions && (ft.addEventListener("updatefromsandbox", (yt) => {
                const St = {
                  value(It) {
                    It.target.checked = It.detail.value !== "Off", j.setValue(V, {
                      value: It.target.checked
                    });
                  }
                };
                this._dispatchEventFromSandbox(St, yt);
              }), this._setEventListeners(ft, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (yt) => yt.target.checked)), this._setBackgroundColor(ft), this._setDefaultPropertiesFromJS(ft), this.container.append(ft), this.container;
            }
          }
          class p extends E {
            constructor(j) {
              super(j, {
                isRenderable: j.renderForms
              });
            }
            render() {
              this.container.classList.add("buttonWidgetAnnotation", "radioButton");
              const j = this.annotationStorage, O = this.data, V = O.id;
              let ht = j.getValue(V, {
                value: O.fieldValue === O.buttonValue
              }).value;
              typeof ht == "string" && (ht = ht !== O.buttonValue, j.setValue(V, {
                value: ht
              }));
              const ft = document.createElement("input");
              if (T.add(ft), ft.setAttribute("data-element-id", V), ft.disabled = O.readOnly, this._setRequired(ft, this.data.required), ft.type = "radio", ft.name = O.fieldName, ht && ft.setAttribute("checked", !0), ft.tabIndex = l, ft.addEventListener("change", (yt) => {
                const {
                  name: St,
                  checked: It
                } = yt.target;
                for (const Rt of this._getElementsByName(St, V))
                  j.setValue(Rt.id, {
                    value: !1
                  });
                j.setValue(V, {
                  value: It
                });
              }), ft.addEventListener("resetform", (yt) => {
                const St = O.defaultFieldValue;
                yt.target.checked = St != null && St === O.buttonValue;
              }), this.enableScripting && this.hasJSActions) {
                const yt = O.buttonValue;
                ft.addEventListener("updatefromsandbox", (St) => {
                  const It = {
                    value: (Rt) => {
                      const Tt = yt === Rt.detail.value;
                      for (const jt of this._getElementsByName(Rt.target.name)) {
                        const xt = Tt && jt.id === V;
                        jt.domElement && (jt.domElement.checked = xt), j.setValue(jt.id, {
                          value: xt
                        });
                      }
                    }
                  };
                  this._dispatchEventFromSandbox(It, St);
                }), this._setEventListeners(ft, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (St) => St.target.checked);
              }
              return this._setBackgroundColor(ft), this._setDefaultPropertiesFromJS(ft), this.container.append(ft), this.container;
            }
          }
          class _ extends x {
            constructor(j) {
              super(j, {
                ignoreBorder: j.data.hasAppearance
              });
            }
            render() {
              const j = super.render();
              j.classList.add("buttonWidgetAnnotation", "pushButton"), this.data.alternativeText && (j.title = this.data.alternativeText);
              const O = j.lastChild;
              return this.enableScripting && this.hasJSActions && O && (this._setDefaultPropertiesFromJS(O), O.addEventListener("updatefromsandbox", (V) => {
                this._dispatchEventFromSandbox({}, V);
              })), j;
            }
          }
          class f extends E {
            constructor(j) {
              super(j, {
                isRenderable: j.renderForms
              });
            }
            render() {
              this.container.classList.add("choiceWidgetAnnotation");
              const j = this.annotationStorage, O = this.data.id, V = j.getValue(O, {
                value: this.data.fieldValue
              }), ht = document.createElement("select");
              T.add(ht), ht.setAttribute("data-element-id", O), ht.disabled = this.data.readOnly, this._setRequired(ht, this.data.required), ht.name = this.data.fieldName, ht.tabIndex = l;
              let ft = this.data.combo && this.data.options.length > 0;
              this.data.combo || (ht.size = this.data.options.length, this.data.multiSelect && (ht.multiple = !0)), ht.addEventListener("resetform", (Tt) => {
                const jt = this.data.defaultFieldValue;
                for (const xt of ht.options)
                  xt.selected = xt.value === jt;
              });
              for (const Tt of this.data.options) {
                const jt = document.createElement("option");
                jt.textContent = Tt.displayValue, jt.value = Tt.exportValue, V.value.includes(Tt.exportValue) && (jt.setAttribute("selected", !0), ft = !1), ht.append(jt);
              }
              let yt = null;
              if (ft) {
                const Tt = document.createElement("option");
                Tt.value = " ", Tt.setAttribute("hidden", !0), Tt.setAttribute("selected", !0), ht.prepend(Tt), yt = () => {
                  Tt.remove(), ht.removeEventListener("input", yt), yt = null;
                }, ht.addEventListener("input", yt);
              }
              const St = (Tt) => {
                const jt = Tt ? "value" : "textContent", {
                  options: xt,
                  multiple: Lt
                } = ht;
                return Lt ? Array.prototype.filter.call(xt, (Bt) => Bt.selected).map((Bt) => Bt[jt]) : xt.selectedIndex === -1 ? null : xt[xt.selectedIndex][jt];
              };
              let It = St(!1);
              const Rt = (Tt) => {
                const jt = Tt.target.options;
                return Array.prototype.map.call(jt, (xt) => ({
                  displayValue: xt.textContent,
                  exportValue: xt.value
                }));
              };
              return this.enableScripting && this.hasJSActions ? (ht.addEventListener("updatefromsandbox", (Tt) => {
                const jt = {
                  value(xt) {
                    yt == null || yt();
                    const Lt = xt.detail.value, Bt = new Set(Array.isArray(Lt) ? Lt : [Lt]);
                    for (const qt of ht.options)
                      qt.selected = Bt.has(qt.value);
                    j.setValue(O, {
                      value: St(!0)
                    }), It = St(!1);
                  },
                  multipleSelection(xt) {
                    ht.multiple = !0;
                  },
                  remove(xt) {
                    const Lt = ht.options, Bt = xt.detail.remove;
                    Lt[Bt].selected = !1, ht.remove(Bt), Lt.length > 0 && Array.prototype.findIndex.call(Lt, (Xt) => Xt.selected) === -1 && (Lt[0].selected = !0), j.setValue(O, {
                      value: St(!0),
                      items: Rt(xt)
                    }), It = St(!1);
                  },
                  clear(xt) {
                    for (; ht.length !== 0; )
                      ht.remove(0);
                    j.setValue(O, {
                      value: null,
                      items: []
                    }), It = St(!1);
                  },
                  insert(xt) {
                    const {
                      index: Lt,
                      displayValue: Bt,
                      exportValue: qt
                    } = xt.detail.insert, Xt = ht.children[Lt], Yt = document.createElement("option");
                    Yt.textContent = Bt, Yt.value = qt, Xt ? Xt.before(Yt) : ht.append(Yt), j.setValue(O, {
                      value: St(!0),
                      items: Rt(xt)
                    }), It = St(!1);
                  },
                  items(xt) {
                    const {
                      items: Lt
                    } = xt.detail;
                    for (; ht.length !== 0; )
                      ht.remove(0);
                    for (const Bt of Lt) {
                      const {
                        displayValue: qt,
                        exportValue: Xt
                      } = Bt, Yt = document.createElement("option");
                      Yt.textContent = qt, Yt.value = Xt, ht.append(Yt);
                    }
                    ht.options.length > 0 && (ht.options[0].selected = !0), j.setValue(O, {
                      value: St(!0),
                      items: Rt(xt)
                    }), It = St(!1);
                  },
                  indices(xt) {
                    const Lt = new Set(xt.detail.indices);
                    for (const Bt of xt.target.options)
                      Bt.selected = Lt.has(Bt.index);
                    j.setValue(O, {
                      value: St(!0)
                    }), It = St(!1);
                  },
                  editable(xt) {
                    xt.target.disabled = !xt.detail.editable;
                  }
                };
                this._dispatchEventFromSandbox(jt, Tt);
              }), ht.addEventListener("input", (Tt) => {
                var xt;
                const jt = St(!0);
                j.setValue(O, {
                  value: jt
                }), Tt.preventDefault(), (xt = this.linkService.eventBus) == null || xt.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: O,
                    name: "Keystroke",
                    value: It,
                    changeEx: jt,
                    willCommit: !1,
                    commitKey: 1,
                    keyDown: !1
                  }
                });
              }), this._setEventListeners(ht, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (Tt) => Tt.target.value)) : ht.addEventListener("input", function(Tt) {
                j.setValue(O, {
                  value: St(!0)
                });
              }), this.data.combo && this._setTextStyle(ht), this._setBackgroundColor(ht), this._setDefaultPropertiesFromJS(ht), this.container.append(ht), this.container;
            }
          }
          class A extends k {
            constructor(j) {
              const {
                data: O,
                elements: V
              } = j;
              super(j, {
                isRenderable: k._hasPopupData(O)
              }), this.elements = V;
            }
            render() {
              this.container.classList.add("popupAnnotation");
              const j = new C({
                container: this.container,
                color: this.data.color,
                titleObj: this.data.titleObj,
                modificationDate: this.data.modificationDate,
                contentsObj: this.data.contentsObj,
                richText: this.data.richText,
                rect: this.data.rect,
                parentRect: this.data.parentRect || null,
                parent: this.parent,
                elements: this.elements,
                open: this.data.open
              }), O = [];
              for (const V of this.elements)
                V.popup = j, O.push(V.data.id), V.addHighlightArea();
              return this.container.setAttribute("aria-controls", O.map((V) => `${e.AnnotationPrefix}${V}`).join(",")), this.container;
            }
          }
          class C {
            constructor({
              container: j,
              color: O,
              elements: V,
              titleObj: ht,
              modificationDate: ft,
              contentsObj: yt,
              richText: St,
              parent: It,
              rect: Rt,
              parentRect: Tt,
              open: jt
            }) {
              at(this, Et);
              at(this, st, null);
              at(this, dt, Z(this, Et, Dn).bind(this));
              at(this, pt, Z(this, Et, nn).bind(this));
              at(this, gt, Z(this, Et, en).bind(this));
              at(this, mt, Z(this, Et, Ce).bind(this));
              at(this, ut, null);
              at(this, tt, null);
              at(this, it, null);
              at(this, R, null);
              at(this, U, null);
              at(this, J, null);
              at(this, rt, !1);
              at(this, _t, null);
              at(this, wt, null);
              at(this, vt, null);
              at(this, nt, null);
              at(this, kt, !1);
              var Lt;
              lt(this, tt, j), lt(this, nt, ht), lt(this, it, yt), lt(this, vt, St), lt(this, U, It), lt(this, ut, O), lt(this, wt, Rt), lt(this, J, Tt), lt(this, R, V);
              const xt = s.PDFDateString.toDateObject(ft);
              xt && lt(this, st, It.l10n.get("annotation_date_string", {
                date: xt.toLocaleDateString(),
                time: xt.toLocaleTimeString()
              })), this.trigger = V.flatMap((Bt) => Bt.getElementsToTriggerPopup());
              for (const Bt of this.trigger)
                Bt.addEventListener("click", r(this, mt)), Bt.addEventListener("mouseenter", r(this, gt)), Bt.addEventListener("mouseleave", r(this, pt)), Bt.classList.add("popupTriggerArea");
              for (const Bt of V)
                (Lt = Bt.container) == null || Lt.addEventListener("keydown", r(this, dt));
              r(this, tt).hidden = !0, jt && Z(this, Et, Ce).call(this);
            }
            render() {
              if (r(this, _t))
                return;
              const {
                page: {
                  view: j
                },
                viewport: {
                  rawDims: {
                    pageWidth: O,
                    pageHeight: V,
                    pageX: ht,
                    pageY: ft
                  }
                }
              } = r(this, U), yt = lt(this, _t, document.createElement("div"));
              if (yt.className = "popup", r(this, ut)) {
                const Jt = yt.style.outlineColor = e.Util.makeHexColor(...r(this, ut));
                CSS.supports("background-color", "color-mix(in srgb, red 30%, white)") ? yt.style.backgroundColor = `color-mix(in srgb, ${Jt} 30%, white)` : yt.style.backgroundColor = e.Util.makeHexColor(...r(this, ut).map((ne) => Math.floor(0.7 * (255 - ne) + ne)));
              }
              const St = document.createElement("span");
              St.className = "header";
              const It = document.createElement("h1");
              if (St.append(It), {
                dir: It.dir,
                str: It.textContent
              } = r(this, nt), yt.append(St), r(this, st)) {
                const Jt = document.createElement("span");
                Jt.classList.add("popupDate"), r(this, st).then((te) => {
                  Jt.textContent = te;
                }), St.append(Jt);
              }
              const Rt = r(this, it), Tt = r(this, vt);
              if (Tt != null && Tt.str && (!(Rt != null && Rt.str) || Rt.str === Tt.str))
                o.XfaLayer.render({
                  xfaHtml: Tt.html,
                  intent: "richText",
                  div: yt
                }), yt.lastChild.classList.add("richText", "popupContent");
              else {
                const Jt = this._formatContents(Rt);
                yt.append(Jt);
              }
              let jt = !!r(this, J), xt = jt ? r(this, J) : r(this, wt);
              for (const Jt of r(this, R))
                if (!xt || e.Util.intersect(Jt.data.rect, xt) !== null) {
                  xt = Jt.data.rect, jt = !0;
                  break;
                }
              const Lt = e.Util.normalizeRect([xt[0], j[3] - xt[1] + j[1], xt[2], j[3] - xt[3] + j[1]]), qt = jt ? xt[2] - xt[0] + 5 : 0, Xt = Lt[0] + qt, Yt = Lt[1], {
                style: Zt
              } = r(this, tt);
              Zt.left = `${100 * (Xt - ht) / O}%`, Zt.top = `${100 * (Yt - ft) / V}%`, r(this, tt).append(yt);
            }
            _formatContents({
              str: j,
              dir: O
            }) {
              const V = document.createElement("p");
              V.classList.add("popupContent"), V.dir = O;
              const ht = j.split(/(?:\r\n?|\n)/);
              for (let ft = 0, yt = ht.length; ft < yt; ++ft) {
                const St = ht[ft];
                V.append(document.createTextNode(St)), ft < yt - 1 && V.append(document.createElement("br"));
              }
              return V;
            }
            forceHide() {
              lt(this, kt, this.isVisible), r(this, kt) && (r(this, tt).hidden = !0);
            }
            maybeShow() {
              r(this, kt) && (lt(this, kt, !1), r(this, tt).hidden = !1);
            }
            get isVisible() {
              return r(this, tt).hidden === !1;
            }
          }
          st = new WeakMap(), dt = new WeakMap(), pt = new WeakMap(), gt = new WeakMap(), mt = new WeakMap(), ut = new WeakMap(), tt = new WeakMap(), it = new WeakMap(), R = new WeakMap(), U = new WeakMap(), J = new WeakMap(), rt = new WeakMap(), _t = new WeakMap(), wt = new WeakMap(), vt = new WeakMap(), nt = new WeakMap(), kt = new WeakMap(), Et = new WeakSet(), Dn = function(j) {
            j.altKey || j.shiftKey || j.ctrlKey || j.metaKey || (j.key === "Enter" || j.key === "Escape" && r(this, rt)) && Z(this, Et, Ce).call(this);
          }, Ce = function() {
            lt(this, rt, !r(this, rt)), r(this, rt) ? (Z(this, Et, en).call(this), r(this, tt).addEventListener("click", r(this, mt)), r(this, tt).addEventListener("keydown", r(this, dt))) : (Z(this, Et, nn).call(this), r(this, tt).removeEventListener("click", r(this, mt)), r(this, tt).removeEventListener("keydown", r(this, dt)));
          }, en = function() {
            r(this, _t) || this.render(), this.isVisible ? r(this, rt) && r(this, tt).classList.add("focused") : (r(this, tt).hidden = !1, r(this, tt).style.zIndex = parseInt(r(this, tt).style.zIndex) + 1e3);
          }, nn = function() {
            r(this, tt).classList.remove("focused"), !(r(this, rt) || !this.isVisible) && (r(this, tt).hidden = !0, r(this, tt).style.zIndex = parseInt(r(this, tt).style.zIndex) - 1e3);
          };
          class W extends k {
            constructor(j) {
              super(j, {
                isRenderable: !0,
                ignoreBorder: !0
              }), this.textContent = j.data.textContent, this.textPosition = j.data.textPosition, this.annotationEditorType = e.AnnotationEditorType.FREETEXT;
            }
            render() {
              if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
                const j = document.createElement("div");
                j.classList.add("annotationTextContent"), j.setAttribute("role", "comment");
                for (const O of this.textContent) {
                  const V = document.createElement("span");
                  V.textContent = O, j.append(V);
                }
                this.container.append(j);
              }
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
            }
          }
          t.FreeTextAnnotationElement = W;
          class m extends k {
            constructor(O) {
              super(O, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              at(this, $t, null);
            }
            render() {
              this.container.classList.add("lineAnnotation");
              const O = this.data, {
                width: V,
                height: ht
              } = P(O.rect), ft = this.svgFactory.create(V, ht, !0), yt = lt(this, $t, this.svgFactory.createElement("svg:line"));
              return yt.setAttribute("x1", O.rect[2] - O.lineCoordinates[0]), yt.setAttribute("y1", O.rect[3] - O.lineCoordinates[1]), yt.setAttribute("x2", O.rect[2] - O.lineCoordinates[2]), yt.setAttribute("y2", O.rect[3] - O.lineCoordinates[3]), yt.setAttribute("stroke-width", O.borderStyle.width || 1), yt.setAttribute("stroke", "transparent"), yt.setAttribute("fill", "transparent"), ft.append(yt), this.container.append(ft), !O.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
            getElementsToTriggerPopup() {
              return r(this, $t);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          $t = new WeakMap();
          class I extends k {
            constructor(O) {
              super(O, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              at(this, Gt, null);
            }
            render() {
              this.container.classList.add("squareAnnotation");
              const O = this.data, {
                width: V,
                height: ht
              } = P(O.rect), ft = this.svgFactory.create(V, ht, !0), yt = O.borderStyle.width, St = lt(this, Gt, this.svgFactory.createElement("svg:rect"));
              return St.setAttribute("x", yt / 2), St.setAttribute("y", yt / 2), St.setAttribute("width", V - yt), St.setAttribute("height", ht - yt), St.setAttribute("stroke-width", yt || 1), St.setAttribute("stroke", "transparent"), St.setAttribute("fill", "transparent"), ft.append(St), this.container.append(ft), !O.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
            getElementsToTriggerPopup() {
              return r(this, Gt);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          Gt = new WeakMap();
          class q extends k {
            constructor(O) {
              super(O, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              at(this, Vt, null);
            }
            render() {
              this.container.classList.add("circleAnnotation");
              const O = this.data, {
                width: V,
                height: ht
              } = P(O.rect), ft = this.svgFactory.create(V, ht, !0), yt = O.borderStyle.width, St = lt(this, Vt, this.svgFactory.createElement("svg:ellipse"));
              return St.setAttribute("cx", V / 2), St.setAttribute("cy", ht / 2), St.setAttribute("rx", V / 2 - yt / 2), St.setAttribute("ry", ht / 2 - yt / 2), St.setAttribute("stroke-width", yt || 1), St.setAttribute("stroke", "transparent"), St.setAttribute("fill", "transparent"), ft.append(St), this.container.append(ft), !O.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
            getElementsToTriggerPopup() {
              return r(this, Vt);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          Vt = new WeakMap();
          class Y extends k {
            constructor(O) {
              super(O, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              at(this, At, null);
              this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
            }
            render() {
              this.container.classList.add(this.containerClassName);
              const O = this.data, {
                width: V,
                height: ht
              } = P(O.rect), ft = this.svgFactory.create(V, ht, !0);
              let yt = [];
              for (const It of O.vertices) {
                const Rt = It.x - O.rect[0], Tt = O.rect[3] - It.y;
                yt.push(Rt + "," + Tt);
              }
              yt = yt.join(" ");
              const St = lt(this, At, this.svgFactory.createElement(this.svgElementName));
              return St.setAttribute("points", yt), St.setAttribute("stroke-width", O.borderStyle.width || 1), St.setAttribute("stroke", "transparent"), St.setAttribute("fill", "transparent"), ft.append(St), this.container.append(ft), !O.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
            getElementsToTriggerPopup() {
              return r(this, At);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          At = new WeakMap();
          class X extends Y {
            constructor(j) {
              super(j), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
            }
          }
          class z extends k {
            constructor(j) {
              super(j, {
                isRenderable: !0,
                ignoreBorder: !0
              });
            }
            render() {
              return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
          }
          class L extends k {
            constructor(O) {
              super(O, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              at(this, ot, []);
              this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = e.AnnotationEditorType.INK;
            }
            render() {
              this.container.classList.add(this.containerClassName);
              const O = this.data, {
                width: V,
                height: ht
              } = P(O.rect), ft = this.svgFactory.create(V, ht, !0);
              for (const yt of O.inkLists) {
                let St = [];
                for (const Rt of yt) {
                  const Tt = Rt.x - O.rect[0], jt = O.rect[3] - Rt.y;
                  St.push(`${Tt},${jt}`);
                }
                St = St.join(" ");
                const It = this.svgFactory.createElement(this.svgElementName);
                r(this, ot).push(It), It.setAttribute("points", St), It.setAttribute("stroke-width", O.borderStyle.width || 1), It.setAttribute("stroke", "transparent"), It.setAttribute("fill", "transparent"), !O.popupRef && this.hasPopupData && this._createPopup(), ft.append(It);
              }
              return this.container.append(ft), this.container;
            }
            getElementsToTriggerPopup() {
              return r(this, ot);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          ot = new WeakMap(), t.InkAnnotationElement = L;
          class et extends k {
            constructor(j) {
              super(j, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
              });
            }
            render() {
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("highlightAnnotation"), this.container;
            }
          }
          class D extends k {
            constructor(j) {
              super(j, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
              });
            }
            render() {
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("underlineAnnotation"), this.container;
            }
          }
          class G extends k {
            constructor(j) {
              super(j, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
              });
            }
            render() {
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("squigglyAnnotation"), this.container;
            }
          }
          class Q extends k {
            constructor(j) {
              super(j, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
              });
            }
            render() {
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("strikeoutAnnotation"), this.container;
            }
          }
          class F extends k {
            constructor(j) {
              super(j, {
                isRenderable: !0,
                ignoreBorder: !0
              });
            }
            render() {
              return this.container.classList.add("stampAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
          }
          t.StampAnnotationElement = F;
          class d extends k {
            constructor(O) {
              var ft;
              super(O, {
                isRenderable: !0
              });
              at(this, Ft);
              at(this, ct, null);
              const {
                filename: V,
                content: ht
              } = this.data.file;
              this.filename = (0, s.getFilenameFromUrl)(V, !0), this.content = ht, (ft = this.linkService.eventBus) == null || ft.dispatch("fileattachmentannotation", {
                source: this,
                filename: V,
                content: ht
              });
            }
            render() {
              this.container.classList.add("fileAttachmentAnnotation");
              const {
                container: O,
                data: V
              } = this;
              let ht;
              V.hasAppearance || V.fillAlpha === 0 ? ht = document.createElement("div") : (ht = document.createElement("img"), ht.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(V.name) ? "paperclip" : "pushpin"}.svg`, V.fillAlpha && V.fillAlpha < 1 && (ht.style = `filter: opacity(${Math.round(V.fillAlpha * 100)}%);`)), ht.addEventListener("dblclick", Z(this, Ft, sn).bind(this)), lt(this, ct, ht);
              const {
                isMac: ft
              } = e.FeatureTest.platform;
              return O.addEventListener("keydown", (yt) => {
                yt.key === "Enter" && (ft ? yt.metaKey : yt.ctrlKey) && Z(this, Ft, sn).call(this);
              }), !V.popupRef && this.hasPopupData ? this._createPopup() : ht.classList.add("popupTriggerArea"), O.append(ht), O;
            }
            getElementsToTriggerPopup() {
              return r(this, ct);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          ct = new WeakMap(), Ft = new WeakSet(), sn = function() {
            var O;
            (O = this.downloadManager) == null || O.openOrDownloadData(this.container, this.content, this.filename);
          };
          class u {
            constructor({
              div: j,
              accessibilityManager: O,
              annotationCanvasMap: V,
              l10n: ht,
              page: ft,
              viewport: yt
            }) {
              at(this, Ct);
              at(this, Wt, null);
              at(this, H, null);
              at(this, bt, /* @__PURE__ */ new Map());
              this.div = j, lt(this, Wt, O), lt(this, H, V), this.l10n = ht, this.page = ft, this.viewport = yt, this.zIndex = 0, this.l10n || (this.l10n = b.NullL10n);
            }
            async render(j) {
              const {
                annotations: O
              } = j, V = this.div;
              (0, s.setLayerDimensions)(V, this.viewport);
              const ht = /* @__PURE__ */ new Map(), ft = {
                data: null,
                layer: V,
                linkService: j.linkService,
                downloadManager: j.downloadManager,
                imageResourcesPath: j.imageResourcesPath || "",
                renderForms: j.renderForms !== !1,
                svgFactory: new s.DOMSVGFactory(),
                annotationStorage: j.annotationStorage || new c.AnnotationStorage(),
                enableScripting: j.enableScripting === !0,
                hasJSActions: j.hasJSActions,
                fieldObjects: j.fieldObjects,
                parent: this,
                elements: null
              };
              for (const yt of O) {
                if (yt.noHTML)
                  continue;
                const St = yt.annotationType === e.AnnotationType.POPUP;
                if (St) {
                  const Tt = ht.get(yt.id);
                  if (!Tt)
                    continue;
                  ft.elements = Tt;
                } else {
                  const {
                    width: Tt,
                    height: jt
                  } = P(yt.rect);
                  if (Tt <= 0 || jt <= 0)
                    continue;
                }
                ft.data = yt;
                const It = v.create(ft);
                if (!It.isRenderable)
                  continue;
                if (!St && yt.popupRef) {
                  const Tt = ht.get(yt.popupRef);
                  Tt ? Tt.push(It) : ht.set(yt.popupRef, [It]);
                }
                It.annotationEditorType > 0 && r(this, bt).set(It.data.id, It);
                const Rt = It.render();
                yt.hidden && (Rt.style.visibility = "hidden"), Z(this, Ct, In).call(this, Rt, yt.id);
              }
              Z(this, Ct, rn).call(this), await this.l10n.translate(V);
            }
            update({
              viewport: j
            }) {
              const O = this.div;
              this.viewport = j, (0, s.setLayerDimensions)(O, {
                rotation: j.rotation
              }), Z(this, Ct, rn).call(this), O.hidden = !1;
            }
            getEditableAnnotations() {
              return Array.from(r(this, bt).values());
            }
            getEditableAnnotation(j) {
              return r(this, bt).get(j);
            }
          }
          Wt = new WeakMap(), H = new WeakMap(), bt = new WeakMap(), Ct = new WeakSet(), In = function(j, O) {
            var ht;
            const V = j.firstChild || j;
            V.id = `${e.AnnotationPrefix}${O}`, this.div.append(j), (ht = r(this, Wt)) == null || ht.moveElementInDOM(this.div, j, V, !1);
          }, rn = function() {
            if (!r(this, H))
              return;
            const j = this.div;
            for (const [O, V] of r(this, H)) {
              const ht = j.querySelector(`[data-annotation-id="${O}"]`);
              if (!ht)
                continue;
              const {
                firstChild: ft
              } = ht;
              ft ? ft.nodeName === "CANVAS" ? ft.replaceWith(V) : ft.before(V) : ht.append(V);
            }
            r(this, H).clear();
          }, t.AnnotationLayer = u;
        },
        /* 30 */
        /***/
        (i, t) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.ColorConverters = void 0;
          function n(c) {
            return Math.floor(Math.max(0, Math.min(1, c)) * 255).toString(16).padStart(2, "0");
          }
          function e(c) {
            return Math.max(0, Math.min(255, 255 * c));
          }
          class s {
            static CMYK_G([h, b, o, l]) {
              return ["G", 1 - Math.min(1, 0.3 * h + 0.59 * o + 0.11 * b + l)];
            }
            static G_CMYK([h]) {
              return ["CMYK", 0, 0, 0, 1 - h];
            }
            static G_RGB([h]) {
              return ["RGB", h, h, h];
            }
            static G_rgb([h]) {
              return h = e(h), [h, h, h];
            }
            static G_HTML([h]) {
              const b = n(h);
              return `#${b}${b}${b}`;
            }
            static RGB_G([h, b, o]) {
              return ["G", 0.3 * h + 0.59 * b + 0.11 * o];
            }
            static RGB_rgb(h) {
              return h.map(e);
            }
            static RGB_HTML(h) {
              return `#${h.map(n).join("")}`;
            }
            static T_HTML() {
              return "#00000000";
            }
            static T_rgb() {
              return [null];
            }
            static CMYK_RGB([h, b, o, l]) {
              return ["RGB", 1 - Math.min(1, h + l), 1 - Math.min(1, o + l), 1 - Math.min(1, b + l)];
            }
            static CMYK_rgb([h, b, o, l]) {
              return [e(1 - Math.min(1, h + l)), e(1 - Math.min(1, o + l)), e(1 - Math.min(1, b + l))];
            }
            static CMYK_HTML(h) {
              const b = this.CMYK_RGB(h).slice(1);
              return this.RGB_HTML(b);
            }
            static RGB_CMYK([h, b, o]) {
              const l = 1 - h, a = 1 - b, T = 1 - o, P = Math.min(l, a, T);
              return ["CMYK", l, a, T, P];
            }
          }
          t.ColorConverters = s;
        },
        /* 31 */
        /***/
        (i, t) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.NullL10n = void 0, t.getL10nFallback = e;
          const n = {
            of_pages: "of {{pagesCount}}",
            page_of_pages: "({{pageNumber}} of {{pagesCount}})",
            document_properties_kb: "{{size_kb}} KB ({{size_b}} bytes)",
            document_properties_mb: "{{size_mb}} MB ({{size_b}} bytes)",
            document_properties_date_string: "{{date}}, {{time}}",
            document_properties_page_size_unit_inches: "in",
            document_properties_page_size_unit_millimeters: "mm",
            document_properties_page_size_orientation_portrait: "portrait",
            document_properties_page_size_orientation_landscape: "landscape",
            document_properties_page_size_name_a3: "A3",
            document_properties_page_size_name_a4: "A4",
            document_properties_page_size_name_letter: "Letter",
            document_properties_page_size_name_legal: "Legal",
            document_properties_page_size_dimension_string: "{{width}} × {{height}} {{unit}} ({{orientation}})",
            document_properties_page_size_dimension_name_string: "{{width}} × {{height}} {{unit}} ({{name}}, {{orientation}})",
            document_properties_linearized_yes: "Yes",
            document_properties_linearized_no: "No",
            additional_layers: "Additional Layers",
            page_landmark: "Page {{page}}",
            thumb_page_title: "Page {{page}}",
            thumb_page_canvas: "Thumbnail of Page {{page}}",
            find_reached_top: "Reached top of document, continued from bottom",
            find_reached_bottom: "Reached end of document, continued from top",
            "find_match_count[one]": "{{current}} of {{total}} match",
            "find_match_count[other]": "{{current}} of {{total}} matches",
            "find_match_count_limit[one]": "More than {{limit}} match",
            "find_match_count_limit[other]": "More than {{limit}} matches",
            find_not_found: "Phrase not found",
            page_scale_width: "Page Width",
            page_scale_fit: "Page Fit",
            page_scale_auto: "Automatic Zoom",
            page_scale_actual: "Actual Size",
            page_scale_percent: "{{scale}}%",
            loading_error: "An error occurred while loading the PDF.",
            invalid_file_error: "Invalid or corrupted PDF file.",
            missing_file_error: "Missing PDF file.",
            unexpected_response_error: "Unexpected server response.",
            rendering_error: "An error occurred while rendering the page.",
            annotation_date_string: "{{date}}, {{time}}",
            printing_not_supported: "Warning: Printing is not fully supported by this browser.",
            printing_not_ready: "Warning: The PDF is not fully loaded for printing.",
            web_fonts_disabled: "Web fonts are disabled: unable to use embedded PDF fonts.",
            free_text2_default_content: "Start typing…",
            editor_free_text2_aria_label: "Text Editor",
            editor_ink2_aria_label: "Draw Editor",
            editor_ink_canvas_aria_label: "User-created image",
            editor_alt_text_button_label: "Alt text",
            editor_alt_text_edit_button_label: "Edit alt text",
            editor_alt_text_decorative_tooltip: "Marked as decorative"
          };
          n.print_progress_percent = "{{progress}}%";
          function e(h, b) {
            switch (h) {
              case "find_match_count":
                h = `find_match_count[${b.total === 1 ? "one" : "other"}]`;
                break;
              case "find_match_count_limit":
                h = `find_match_count_limit[${b.limit === 1 ? "one" : "other"}]`;
                break;
            }
            return n[h] || "";
          }
          function s(h, b) {
            return b ? h.replaceAll(/\{\{\s*(\w+)\s*\}\}/g, (o, l) => l in b ? b[l] : "{{" + l + "}}") : h;
          }
          const c = {
            async getLanguage() {
              return "en-us";
            },
            async getDirection() {
              return "ltr";
            },
            async get(h, b = null, o = e(h, b)) {
              return s(o, b);
            },
            async translate(h) {
            }
          };
          t.NullL10n = c;
        },
        /* 32 */
        /***/
        (i, t, n) => {
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.XfaLayer = void 0;
          var e = n(25);
          class s {
            static setupStorage(h, b, o, l, a) {
              const T = l.getValue(b, {
                value: null
              });
              switch (o.name) {
                case "textarea":
                  if (T.value !== null && (h.textContent = T.value), a === "print")
                    break;
                  h.addEventListener("input", (P) => {
                    l.setValue(b, {
                      value: P.target.value
                    });
                  });
                  break;
                case "input":
                  if (o.attributes.type === "radio" || o.attributes.type === "checkbox") {
                    if (T.value === o.attributes.xfaOn ? h.setAttribute("checked", !0) : T.value === o.attributes.xfaOff && h.removeAttribute("checked"), a === "print")
                      break;
                    h.addEventListener("change", (P) => {
                      l.setValue(b, {
                        value: P.target.checked ? P.target.getAttribute("xfaOn") : P.target.getAttribute("xfaOff")
                      });
                    });
                  } else {
                    if (T.value !== null && h.setAttribute("value", T.value), a === "print")
                      break;
                    h.addEventListener("input", (P) => {
                      l.setValue(b, {
                        value: P.target.value
                      });
                    });
                  }
                  break;
                case "select":
                  if (T.value !== null) {
                    h.setAttribute("value", T.value);
                    for (const P of o.children)
                      P.attributes.value === T.value ? P.attributes.selected = !0 : P.attributes.hasOwnProperty("selected") && delete P.attributes.selected;
                  }
                  h.addEventListener("input", (P) => {
                    const v = P.target.options, k = v.selectedIndex === -1 ? "" : v[v.selectedIndex].value;
                    l.setValue(b, {
                      value: k
                    });
                  });
                  break;
              }
            }
            static setAttributes({
              html: h,
              element: b,
              storage: o = null,
              intent: l,
              linkService: a
            }) {
              const {
                attributes: T
              } = b, P = h instanceof HTMLAnchorElement;
              T.type === "radio" && (T.name = `${T.name}-${l}`);
              for (const [v, k] of Object.entries(T))
                if (k != null)
                  switch (v) {
                    case "class":
                      k.length && h.setAttribute(v, k.join(" "));
                      break;
                    case "dataId":
                      break;
                    case "id":
                      h.setAttribute("data-element-id", k);
                      break;
                    case "style":
                      Object.assign(h.style, k);
                      break;
                    case "textContent":
                      h.textContent = k;
                      break;
                    default:
                      (!P || v !== "href" && v !== "newWindow") && h.setAttribute(v, k);
                  }
              P && a.addLinkAttributes(h, T.href, T.newWindow), o && T.dataId && this.setupStorage(h, T.dataId, b, o);
            }
            static render(h) {
              var x;
              const b = h.annotationStorage, o = h.linkService, l = h.xfaHtml, a = h.intent || "display", T = document.createElement(l.name);
              l.attributes && this.setAttributes({
                html: T,
                element: l,
                intent: a,
                linkService: o
              });
              const P = [[l, -1, T]], v = h.div;
              if (v.append(T), h.viewport) {
                const S = `matrix(${h.viewport.transform.join(",")})`;
                v.style.transform = S;
              }
              a !== "richText" && v.setAttribute("class", "xfaLayer xfaFont");
              const k = [];
              for (; P.length > 0; ) {
                const [S, E, w] = P.at(-1);
                if (E + 1 === S.children.length) {
                  P.pop();
                  continue;
                }
                const M = S.children[++P.at(-1)[1]];
                if (M === null)
                  continue;
                const {
                  name: g
                } = M;
                if (g === "#text") {
                  const _ = document.createTextNode(M.value);
                  k.push(_), w.append(_);
                  continue;
                }
                const p = (x = M == null ? void 0 : M.attributes) != null && x.xmlns ? document.createElementNS(M.attributes.xmlns, g) : document.createElement(g);
                if (w.append(p), M.attributes && this.setAttributes({
                  html: p,
                  element: M,
                  storage: b,
                  intent: a,
                  linkService: o
                }), M.children && M.children.length > 0)
                  P.push([M, -1, p]);
                else if (M.value) {
                  const _ = document.createTextNode(M.value);
                  e.XfaText.shouldBuildText(g) && k.push(_), p.append(_);
                }
              }
              for (const S of v.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
                S.setAttribute("readOnly", !0);
              return {
                textDivs: k
              };
            }
            static update(h) {
              const b = `matrix(${h.viewport.transform.join(",")})`;
              h.div.style.transform = b, h.div.hidden = !1;
            }
          }
          t.XfaLayer = s;
        },
        /* 33 */
        /***/
        (i, t, n) => {
          var l, a, T, P, v, k, x, S, E, w, M, g, p, _, f, Ln, On, $n, Nn, an, Bn, on, Un, jn, qn, Wn, Hn, ee, ln, ke, Te, le, cn, Pe, N, zn, hn, Gn, Xn, dn, Fe, ce;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.InkEditor = void 0;
          var e = n(1), s = n(4), c = n(29), h = n(6), b = n(5);
          const ut = class ut extends s.AnnotationEditor {
            constructor(R) {
              super({
                ...R,
                name: "inkEditor"
              });
              at(this, f);
              at(this, l, 0);
              at(this, a, 0);
              at(this, T, this.canvasPointermove.bind(this));
              at(this, P, this.canvasPointerleave.bind(this));
              at(this, v, this.canvasPointerup.bind(this));
              at(this, k, this.canvasPointerdown.bind(this));
              at(this, x, new Path2D());
              at(this, S, !1);
              at(this, E, !1);
              at(this, w, !1);
              at(this, M, null);
              at(this, g, 0);
              at(this, p, 0);
              at(this, _, null);
              this.color = R.color || null, this.thickness = R.thickness || null, this.opacity = R.opacity || null, this.paths = [], this.bezierPath2D = [], this.allRawPaths = [], this.currentPath = [], this.scaleFactor = 1, this.translationX = this.translationY = 0, this.x = 0, this.y = 0, this._willKeepAspectRatio = !0;
            }
            static initialize(R) {
              s.AnnotationEditor.initialize(R, {
                strings: ["editor_ink_canvas_aria_label", "editor_ink2_aria_label"]
              });
            }
            static updateDefaultParams(R, U) {
              switch (R) {
                case e.AnnotationEditorParamsType.INK_THICKNESS:
                  ut._defaultThickness = U;
                  break;
                case e.AnnotationEditorParamsType.INK_COLOR:
                  ut._defaultColor = U;
                  break;
                case e.AnnotationEditorParamsType.INK_OPACITY:
                  ut._defaultOpacity = U / 100;
                  break;
              }
            }
            updateParams(R, U) {
              switch (R) {
                case e.AnnotationEditorParamsType.INK_THICKNESS:
                  Z(this, f, Ln).call(this, U);
                  break;
                case e.AnnotationEditorParamsType.INK_COLOR:
                  Z(this, f, On).call(this, U);
                  break;
                case e.AnnotationEditorParamsType.INK_OPACITY:
                  Z(this, f, $n).call(this, U);
                  break;
              }
            }
            static get defaultPropertiesToUpdate() {
              return [[e.AnnotationEditorParamsType.INK_THICKNESS, ut._defaultThickness], [e.AnnotationEditorParamsType.INK_COLOR, ut._defaultColor || s.AnnotationEditor._defaultLineColor], [e.AnnotationEditorParamsType.INK_OPACITY, Math.round(ut._defaultOpacity * 100)]];
            }
            get propertiesToUpdate() {
              return [[e.AnnotationEditorParamsType.INK_THICKNESS, this.thickness || ut._defaultThickness], [e.AnnotationEditorParamsType.INK_COLOR, this.color || ut._defaultColor || s.AnnotationEditor._defaultLineColor], [e.AnnotationEditorParamsType.INK_OPACITY, Math.round(100 * (this.opacity ?? ut._defaultOpacity))]];
            }
            rebuild() {
              this.parent && (super.rebuild(), this.div !== null && (this.canvas || (Z(this, f, ke).call(this), Z(this, f, Te).call(this)), this.isAttachedToDOM || (this.parent.add(this), Z(this, f, le).call(this)), Z(this, f, ce).call(this)));
            }
            remove() {
              this.canvas !== null && (this.isEmpty() || this.commit(), this.canvas.width = this.canvas.height = 0, this.canvas.remove(), this.canvas = null, r(this, M).disconnect(), lt(this, M, null), super.remove());
            }
            setParent(R) {
              !this.parent && R ? this._uiManager.removeShouldRescale(this) : this.parent && R === null && this._uiManager.addShouldRescale(this), super.setParent(R);
            }
            onScaleChanging() {
              const [R, U] = this.parentDimensions, J = this.width * R, rt = this.height * U;
              this.setDimensions(J, rt);
            }
            enableEditMode() {
              r(this, S) || this.canvas === null || (super.enableEditMode(), this._isDraggable = !1, this.canvas.addEventListener("pointerdown", r(this, k)));
            }
            disableEditMode() {
              !this.isInEditMode() || this.canvas === null || (super.disableEditMode(), this._isDraggable = !this.isEmpty(), this.div.classList.remove("editing"), this.canvas.removeEventListener("pointerdown", r(this, k)));
            }
            onceAdded() {
              this._isDraggable = !this.isEmpty();
            }
            isEmpty() {
              return this.paths.length === 0 || this.paths.length === 1 && this.paths[0].length === 0;
            }
            commit() {
              r(this, S) || (super.commit(), this.isEditing = !1, this.disableEditMode(), this.setInForeground(), lt(this, S, !0), this.div.classList.add("disabled"), Z(this, f, ce).call(this, !0), this.makeResizable(), this.parent.addInkEditorIfNeeded(!0), this.moveInDOM(), this.div.focus({
                preventScroll: !0
              }));
            }
            focusin(R) {
              this._focusEventsAllowed && (super.focusin(R), this.enableEditMode());
            }
            canvasPointerdown(R) {
              R.button !== 0 || !this.isInEditMode() || r(this, S) || (this.setInForeground(), R.preventDefault(), R.type !== "mouse" && this.div.focus(), Z(this, f, Bn).call(this, R.offsetX, R.offsetY));
            }
            canvasPointermove(R) {
              R.preventDefault(), Z(this, f, on).call(this, R.offsetX, R.offsetY);
            }
            canvasPointerup(R) {
              R.preventDefault(), Z(this, f, ln).call(this, R);
            }
            canvasPointerleave(R) {
              Z(this, f, ln).call(this, R);
            }
            get isResizable() {
              return !this.isEmpty() && r(this, S);
            }
            render() {
              if (this.div)
                return this.div;
              let R, U;
              this.width && (R = this.x, U = this.y), super.render(), s.AnnotationEditor._l10nPromise.get("editor_ink2_aria_label").then((vt) => {
                var nt;
                return (nt = this.div) == null ? void 0 : nt.setAttribute("aria-label", vt);
              });
              const [J, rt, _t, wt] = Z(this, f, Nn).call(this);
              if (this.setAt(J, rt, 0, 0), this.setDims(_t, wt), Z(this, f, ke).call(this), this.width) {
                const [vt, nt] = this.parentDimensions;
                this.setAspectRatio(this.width * vt, this.height * nt), this.setAt(R * vt, U * nt, this.width * vt, this.height * nt), lt(this, w, !0), Z(this, f, le).call(this), this.setDims(this.width * vt, this.height * nt), Z(this, f, ee).call(this), this.div.classList.add("disabled");
              } else
                this.div.classList.add("editing"), this.enableEditMode();
              return Z(this, f, Te).call(this), this.div;
            }
            setDimensions(R, U) {
              const J = Math.round(R), rt = Math.round(U);
              if (r(this, g) === J && r(this, p) === rt)
                return;
              lt(this, g, J), lt(this, p, rt), this.canvas.style.visibility = "hidden";
              const [_t, wt] = this.parentDimensions;
              this.width = R / _t, this.height = U / wt, this.fixAndSetPosition(), r(this, S) && Z(this, f, cn).call(this, R, U), Z(this, f, le).call(this), Z(this, f, ee).call(this), this.canvas.style.visibility = "visible", this.fixDims();
            }
            static deserialize(R, U, J) {
              var $t, Gt, Vt;
              if (R instanceof c.InkAnnotationElement)
                return null;
              const rt = super.deserialize(R, U, J);
              rt.thickness = R.thickness, rt.color = e.Util.makeHexColor(...R.color), rt.opacity = R.opacity;
              const [_t, wt] = rt.pageDimensions, vt = rt.width * _t, nt = rt.height * wt, kt = rt.parentScale, Et = R.thickness / 2;
              lt(rt, S, !0), lt(rt, g, Math.round(vt)), lt(rt, p, Math.round(nt));
              const {
                paths: Ut,
                rect: Nt,
                rotation: zt
              } = R;
              for (let {
                bezier: At
              } of Ut) {
                At = Z($t = ut, N, Gn).call($t, At, Nt, zt);
                const ot = [];
                rt.paths.push(ot);
                let ct = kt * (At[0] - Et), Ft = kt * (At[1] - Et);
                for (let Wt = 2, H = At.length; Wt < H; Wt += 6) {
                  const bt = kt * (At[Wt] - Et), Ct = kt * (At[Wt + 1] - Et), Dt = kt * (At[Wt + 2] - Et), Ot = kt * (At[Wt + 3] - Et), Pt = kt * (At[Wt + 4] - Et), j = kt * (At[Wt + 5] - Et);
                  ot.push([[ct, Ft], [bt, Ct], [Dt, Ot], [Pt, j]]), ct = Pt, Ft = j;
                }
                const Ht = Z(this, N, zn).call(this, ot);
                rt.bezierPath2D.push(Ht);
              }
              const Mt = Z(Gt = rt, f, dn).call(Gt);
              return lt(rt, a, Math.max(s.AnnotationEditor.MIN_SIZE, Mt[2] - Mt[0])), lt(rt, l, Math.max(s.AnnotationEditor.MIN_SIZE, Mt[3] - Mt[1])), Z(Vt = rt, f, cn).call(Vt, vt, nt), rt;
            }
            serialize() {
              if (this.isEmpty())
                return null;
              const R = this.getRect(0, 0), U = s.AnnotationEditor._colorManager.convert(this.ctx.strokeStyle);
              return {
                annotationType: e.AnnotationEditorType.INK,
                color: U,
                thickness: this.thickness,
                opacity: this.opacity,
                paths: Z(this, f, Xn).call(this, this.scaleFactor / this.parentScale, this.translationX, this.translationY, R),
                pageIndex: this.pageIndex,
                rect: R,
                rotation: this.rotation,
                structTreeParentId: this._structTreeParentId
              };
            }
          };
          l = new WeakMap(), a = new WeakMap(), T = new WeakMap(), P = new WeakMap(), v = new WeakMap(), k = new WeakMap(), x = new WeakMap(), S = new WeakMap(), E = new WeakMap(), w = new WeakMap(), M = new WeakMap(), g = new WeakMap(), p = new WeakMap(), _ = new WeakMap(), f = new WeakSet(), Ln = function(R) {
            const U = this.thickness;
            this.addCommands({
              cmd: () => {
                this.thickness = R, Z(this, f, ce).call(this);
              },
              undo: () => {
                this.thickness = U, Z(this, f, ce).call(this);
              },
              mustExec: !0,
              type: e.AnnotationEditorParamsType.INK_THICKNESS,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, On = function(R) {
            const U = this.color;
            this.addCommands({
              cmd: () => {
                this.color = R, Z(this, f, ee).call(this);
              },
              undo: () => {
                this.color = U, Z(this, f, ee).call(this);
              },
              mustExec: !0,
              type: e.AnnotationEditorParamsType.INK_COLOR,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, $n = function(R) {
            R /= 100;
            const U = this.opacity;
            this.addCommands({
              cmd: () => {
                this.opacity = R, Z(this, f, ee).call(this);
              },
              undo: () => {
                this.opacity = U, Z(this, f, ee).call(this);
              },
              mustExec: !0,
              type: e.AnnotationEditorParamsType.INK_OPACITY,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, Nn = function() {
            const {
              parentRotation: R,
              parentDimensions: [U, J]
            } = this;
            switch (R) {
              case 90:
                return [0, J, J, U];
              case 180:
                return [U, J, U, J];
              case 270:
                return [U, 0, J, U];
              default:
                return [0, 0, U, J];
            }
          }, an = function() {
            const {
              ctx: R,
              color: U,
              opacity: J,
              thickness: rt,
              parentScale: _t,
              scaleFactor: wt
            } = this;
            R.lineWidth = rt * _t / wt, R.lineCap = "round", R.lineJoin = "round", R.miterLimit = 10, R.strokeStyle = `${U}${(0, b.opacityToHex)(J)}`;
          }, Bn = function(R, U) {
            this.canvas.addEventListener("contextmenu", h.noContextMenu), this.canvas.addEventListener("pointerleave", r(this, P)), this.canvas.addEventListener("pointermove", r(this, T)), this.canvas.addEventListener("pointerup", r(this, v)), this.canvas.removeEventListener("pointerdown", r(this, k)), this.isEditing = !0, r(this, w) || (lt(this, w, !0), Z(this, f, le).call(this), this.thickness || (this.thickness = ut._defaultThickness), this.color || (this.color = ut._defaultColor || s.AnnotationEditor._defaultLineColor), this.opacity ?? (this.opacity = ut._defaultOpacity)), this.currentPath.push([R, U]), lt(this, E, !1), Z(this, f, an).call(this), lt(this, _, () => {
              Z(this, f, qn).call(this), r(this, _) && window.requestAnimationFrame(r(this, _));
            }), window.requestAnimationFrame(r(this, _));
          }, on = function(R, U) {
            const [J, rt] = this.currentPath.at(-1);
            if (this.currentPath.length > 1 && R === J && U === rt)
              return;
            const _t = this.currentPath;
            let wt = r(this, x);
            if (_t.push([R, U]), lt(this, E, !0), _t.length <= 2) {
              wt.moveTo(..._t[0]), wt.lineTo(R, U);
              return;
            }
            _t.length === 3 && (lt(this, x, wt = new Path2D()), wt.moveTo(..._t[0])), Z(this, f, Wn).call(this, wt, ..._t.at(-3), ..._t.at(-2), R, U);
          }, Un = function() {
            if (this.currentPath.length === 0)
              return;
            const R = this.currentPath.at(-1);
            r(this, x).lineTo(...R);
          }, jn = function(R, U) {
            lt(this, _, null), R = Math.min(Math.max(R, 0), this.canvas.width), U = Math.min(Math.max(U, 0), this.canvas.height), Z(this, f, on).call(this, R, U), Z(this, f, Un).call(this);
            let J;
            if (this.currentPath.length !== 1)
              J = Z(this, f, Hn).call(this);
            else {
              const nt = [R, U];
              J = [[nt, nt.slice(), nt.slice(), nt]];
            }
            const rt = r(this, x), _t = this.currentPath;
            this.currentPath = [], lt(this, x, new Path2D());
            const wt = () => {
              this.allRawPaths.push(_t), this.paths.push(J), this.bezierPath2D.push(rt), this.rebuild();
            }, vt = () => {
              this.allRawPaths.pop(), this.paths.pop(), this.bezierPath2D.pop(), this.paths.length === 0 ? this.remove() : (this.canvas || (Z(this, f, ke).call(this), Z(this, f, Te).call(this)), Z(this, f, ce).call(this));
            };
            this.addCommands({
              cmd: wt,
              undo: vt,
              mustExec: !0
            });
          }, qn = function() {
            if (!r(this, E))
              return;
            lt(this, E, !1);
            const R = Math.ceil(this.thickness * this.parentScale), U = this.currentPath.slice(-3), J = U.map((wt) => wt[0]), rt = U.map((wt) => wt[1]);
            Math.min(...J) - R, Math.max(...J) + R, Math.min(...rt) - R, Math.max(...rt) + R;
            const {
              ctx: _t
            } = this;
            _t.save(), _t.clearRect(0, 0, this.canvas.width, this.canvas.height);
            for (const wt of this.bezierPath2D)
              _t.stroke(wt);
            _t.stroke(r(this, x)), _t.restore();
          }, Wn = function(R, U, J, rt, _t, wt, vt) {
            const nt = (U + rt) / 2, kt = (J + _t) / 2, Et = (rt + wt) / 2, Ut = (_t + vt) / 2;
            R.bezierCurveTo(nt + 2 * (rt - nt) / 3, kt + 2 * (_t - kt) / 3, Et + 2 * (rt - Et) / 3, Ut + 2 * (_t - Ut) / 3, Et, Ut);
          }, Hn = function() {
            const R = this.currentPath;
            if (R.length <= 2)
              return [[R[0], R[0], R.at(-1), R.at(-1)]];
            const U = [];
            let J, [rt, _t] = R[0];
            for (J = 1; J < R.length - 2; J++) {
              const [Nt, zt] = R[J], [Mt, $t] = R[J + 1], Gt = (Nt + Mt) / 2, Vt = (zt + $t) / 2, At = [rt + 2 * (Nt - rt) / 3, _t + 2 * (zt - _t) / 3], ot = [Gt + 2 * (Nt - Gt) / 3, Vt + 2 * (zt - Vt) / 3];
              U.push([[rt, _t], At, ot, [Gt, Vt]]), [rt, _t] = [Gt, Vt];
            }
            const [wt, vt] = R[J], [nt, kt] = R[J + 1], Et = [rt + 2 * (wt - rt) / 3, _t + 2 * (vt - _t) / 3], Ut = [nt + 2 * (wt - nt) / 3, kt + 2 * (vt - kt) / 3];
            return U.push([[rt, _t], Et, Ut, [nt, kt]]), U;
          }, ee = function() {
            if (this.isEmpty()) {
              Z(this, f, Pe).call(this);
              return;
            }
            Z(this, f, an).call(this);
            const {
              canvas: R,
              ctx: U
            } = this;
            U.setTransform(1, 0, 0, 1, 0, 0), U.clearRect(0, 0, R.width, R.height), Z(this, f, Pe).call(this);
            for (const J of this.bezierPath2D)
              U.stroke(J);
          }, ln = function(R) {
            this.canvas.removeEventListener("pointerleave", r(this, P)), this.canvas.removeEventListener("pointermove", r(this, T)), this.canvas.removeEventListener("pointerup", r(this, v)), this.canvas.addEventListener("pointerdown", r(this, k)), setTimeout(() => {
              this.canvas.removeEventListener("contextmenu", h.noContextMenu);
            }, 10), Z(this, f, jn).call(this, R.offsetX, R.offsetY), this.addToAnnotationStorage(), this.setInBackground();
          }, ke = function() {
            this.canvas = document.createElement("canvas"), this.canvas.width = this.canvas.height = 0, this.canvas.className = "inkEditorCanvas", s.AnnotationEditor._l10nPromise.get("editor_ink_canvas_aria_label").then((R) => {
              var U;
              return (U = this.canvas) == null ? void 0 : U.setAttribute("aria-label", R);
            }), this.div.append(this.canvas), this.ctx = this.canvas.getContext("2d");
          }, Te = function() {
            lt(this, M, new ResizeObserver((R) => {
              const U = R[0].contentRect;
              U.width && U.height && this.setDimensions(U.width, U.height);
            })), r(this, M).observe(this.div);
          }, le = function() {
            if (!r(this, w))
              return;
            const [R, U] = this.parentDimensions;
            this.canvas.width = Math.ceil(this.width * R), this.canvas.height = Math.ceil(this.height * U), Z(this, f, Pe).call(this);
          }, cn = function(R, U) {
            const J = Z(this, f, Fe).call(this), rt = (R - J) / r(this, a), _t = (U - J) / r(this, l);
            this.scaleFactor = Math.min(rt, _t);
          }, Pe = function() {
            const R = Z(this, f, Fe).call(this) / 2;
            this.ctx.setTransform(this.scaleFactor, 0, 0, this.scaleFactor, this.translationX * this.scaleFactor + R, this.translationY * this.scaleFactor + R);
          }, N = new WeakSet(), zn = function(R) {
            const U = new Path2D();
            for (let J = 0, rt = R.length; J < rt; J++) {
              const [_t, wt, vt, nt] = R[J];
              J === 0 && U.moveTo(..._t), U.bezierCurveTo(wt[0], wt[1], vt[0], vt[1], nt[0], nt[1]);
            }
            return U;
          }, hn = function(R, U, J) {
            const [rt, _t, wt, vt] = U;
            switch (J) {
              case 0:
                for (let nt = 0, kt = R.length; nt < kt; nt += 2)
                  R[nt] += rt, R[nt + 1] = vt - R[nt + 1];
                break;
              case 90:
                for (let nt = 0, kt = R.length; nt < kt; nt += 2) {
                  const Et = R[nt];
                  R[nt] = R[nt + 1] + rt, R[nt + 1] = Et + _t;
                }
                break;
              case 180:
                for (let nt = 0, kt = R.length; nt < kt; nt += 2)
                  R[nt] = wt - R[nt], R[nt + 1] += _t;
                break;
              case 270:
                for (let nt = 0, kt = R.length; nt < kt; nt += 2) {
                  const Et = R[nt];
                  R[nt] = wt - R[nt + 1], R[nt + 1] = vt - Et;
                }
                break;
              default:
                throw new Error("Invalid rotation");
            }
            return R;
          }, Gn = function(R, U, J) {
            const [rt, _t, wt, vt] = U;
            switch (J) {
              case 0:
                for (let nt = 0, kt = R.length; nt < kt; nt += 2)
                  R[nt] -= rt, R[nt + 1] = vt - R[nt + 1];
                break;
              case 90:
                for (let nt = 0, kt = R.length; nt < kt; nt += 2) {
                  const Et = R[nt];
                  R[nt] = R[nt + 1] - _t, R[nt + 1] = Et - rt;
                }
                break;
              case 180:
                for (let nt = 0, kt = R.length; nt < kt; nt += 2)
                  R[nt] = wt - R[nt], R[nt + 1] -= _t;
                break;
              case 270:
                for (let nt = 0, kt = R.length; nt < kt; nt += 2) {
                  const Et = R[nt];
                  R[nt] = vt - R[nt + 1], R[nt + 1] = wt - Et;
                }
                break;
              default:
                throw new Error("Invalid rotation");
            }
            return R;
          }, Xn = function(R, U, J, rt) {
            var kt, Et;
            const _t = [], wt = this.thickness / 2, vt = R * U + wt, nt = R * J + wt;
            for (const Ut of this.paths) {
              const Nt = [], zt = [];
              for (let Mt = 0, $t = Ut.length; Mt < $t; Mt++) {
                const [Gt, Vt, At, ot] = Ut[Mt], ct = R * Gt[0] + vt, Ft = R * Gt[1] + nt, Ht = R * Vt[0] + vt, Wt = R * Vt[1] + nt, H = R * At[0] + vt, bt = R * At[1] + nt, Ct = R * ot[0] + vt, Dt = R * ot[1] + nt;
                Mt === 0 && (Nt.push(ct, Ft), zt.push(ct, Ft)), Nt.push(Ht, Wt, H, bt, Ct, Dt), zt.push(Ht, Wt), Mt === $t - 1 && zt.push(Ct, Dt);
              }
              _t.push({
                bezier: Z(kt = ut, N, hn).call(kt, Nt, rt, this.rotation),
                points: Z(Et = ut, N, hn).call(Et, zt, rt, this.rotation)
              });
            }
            return _t;
          }, dn = function() {
            let R = 1 / 0, U = -1 / 0, J = 1 / 0, rt = -1 / 0;
            for (const _t of this.paths)
              for (const [wt, vt, nt, kt] of _t) {
                const Et = e.Util.bezierBoundingBox(...wt, ...vt, ...nt, ...kt);
                R = Math.min(R, Et[0]), J = Math.min(J, Et[1]), U = Math.max(U, Et[2]), rt = Math.max(rt, Et[3]);
              }
            return [R, J, U, rt];
          }, Fe = function() {
            return r(this, S) ? Math.ceil(this.thickness * this.parentScale) : 0;
          }, ce = function(R = !1) {
            if (this.isEmpty())
              return;
            if (!r(this, S)) {
              Z(this, f, ee).call(this);
              return;
            }
            const U = Z(this, f, dn).call(this), J = Z(this, f, Fe).call(this);
            lt(this, a, Math.max(s.AnnotationEditor.MIN_SIZE, U[2] - U[0])), lt(this, l, Math.max(s.AnnotationEditor.MIN_SIZE, U[3] - U[1]));
            const rt = Math.ceil(J + r(this, a) * this.scaleFactor), _t = Math.ceil(J + r(this, l) * this.scaleFactor), [wt, vt] = this.parentDimensions;
            this.width = rt / wt, this.height = _t / vt, this.setAspectRatio(rt, _t);
            const nt = this.translationX, kt = this.translationY;
            this.translationX = -U[0], this.translationY = -U[1], Z(this, f, le).call(this), Z(this, f, ee).call(this), lt(this, g, rt), lt(this, p, _t), this.setDims(rt, _t);
            const Et = R ? J / this.scaleFactor / 2 : 0;
            this.translate(nt - this.translationX - Et, kt - this.translationY - Et);
          }, at(ut, N), Kt(ut, "_defaultColor", null), Kt(ut, "_defaultOpacity", 1), Kt(ut, "_defaultThickness", 1), Kt(ut, "_type", "ink");
          let o = ut;
          t.InkEditor = o;
        },
        /* 34 */
        /***/
        (i, t, n) => {
          var o, l, a, T, P, v, k, x, S, E, w, _e, me, Me, un, Vn, Yn, pn, Re, Kn;
          Object.defineProperty(t, "__esModule", {
            value: !0
          }), t.StampEditor = void 0;
          var e = n(1), s = n(4), c = n(6), h = n(29);
          const I = class I extends s.AnnotationEditor {
            constructor(X) {
              super({
                ...X,
                name: "stampEditor"
              });
              at(this, w);
              at(this, o, null);
              at(this, l, null);
              at(this, a, null);
              at(this, T, null);
              at(this, P, null);
              at(this, v, null);
              at(this, k, null);
              at(this, x, null);
              at(this, S, !1);
              at(this, E, !1);
              lt(this, T, X.bitmapUrl), lt(this, P, X.bitmapFile);
            }
            static initialize(X) {
              s.AnnotationEditor.initialize(X);
            }
            static get supportedTypes() {
              const X = ["apng", "avif", "bmp", "gif", "jpeg", "png", "svg+xml", "webp", "x-icon"];
              return (0, e.shadow)(this, "supportedTypes", X.map((z) => `image/${z}`));
            }
            static get supportedTypesStr() {
              return (0, e.shadow)(this, "supportedTypesStr", this.supportedTypes.join(","));
            }
            static isHandlingMimeForPasting(X) {
              return this.supportedTypes.includes(X);
            }
            static paste(X, z) {
              z.pasteEditor(e.AnnotationEditorType.STAMP, {
                bitmapFile: X.getAsFile()
              });
            }
            remove() {
              var X, z;
              r(this, l) && (lt(this, o, null), this._uiManager.imageManager.deleteId(r(this, l)), (X = r(this, v)) == null || X.remove(), lt(this, v, null), (z = r(this, k)) == null || z.disconnect(), lt(this, k, null)), super.remove();
            }
            rebuild() {
              if (!this.parent) {
                r(this, l) && Z(this, w, Me).call(this);
                return;
              }
              super.rebuild(), this.div !== null && (r(this, l) && Z(this, w, Me).call(this), this.isAttachedToDOM || this.parent.add(this));
            }
            onceAdded() {
              this._isDraggable = !0, this.div.focus();
            }
            isEmpty() {
              return !(r(this, a) || r(this, o) || r(this, T) || r(this, P));
            }
            get isResizable() {
              return !0;
            }
            render() {
              if (this.div)
                return this.div;
              let X, z;
              if (this.width && (X = this.x, z = this.y), super.render(), this.div.hidden = !0, r(this, o) ? Z(this, w, un).call(this) : Z(this, w, Me).call(this), this.width) {
                const [L, et] = this.parentDimensions;
                this.setAt(X * L, z * et, this.width * L, this.height * et);
              }
              return this.div;
            }
            static deserialize(X, z, L) {
              if (X instanceof h.StampAnnotationElement)
                return null;
              const et = super.deserialize(X, z, L), {
                rect: D,
                bitmapUrl: G,
                bitmapId: Q,
                isSvg: F,
                accessibilityData: d
              } = X;
              Q && L.imageManager.isValidId(Q) ? lt(et, l, Q) : lt(et, T, G), lt(et, S, F);
              const [u, y] = et.pageDimensions;
              return et.width = (D[2] - D[0]) / u, et.height = (D[3] - D[1]) / y, d && (et.altTextData = d), et;
            }
            serialize(X = !1, z = null) {
              if (this.isEmpty())
                return null;
              const L = {
                annotationType: e.AnnotationEditorType.STAMP,
                bitmapId: r(this, l),
                pageIndex: this.pageIndex,
                rect: this.getRect(0, 0),
                rotation: this.rotation,
                isSvg: r(this, S),
                structTreeParentId: this._structTreeParentId
              };
              if (X)
                return L.bitmapUrl = Z(this, w, Re).call(this, !0), L.accessibilityData = this.altTextData, L;
              const {
                decorative: et,
                altText: D
              } = this.altTextData;
              if (!et && D && (L.accessibilityData = {
                type: "Figure",
                alt: D
              }), z === null)
                return L;
              z.stamps || (z.stamps = /* @__PURE__ */ new Map());
              const G = r(this, S) ? (L.rect[2] - L.rect[0]) * (L.rect[3] - L.rect[1]) : null;
              if (!z.stamps.has(r(this, l)))
                z.stamps.set(r(this, l), {
                  area: G,
                  serialized: L
                }), L.bitmap = Z(this, w, Re).call(this, !1);
              else if (r(this, S)) {
                const Q = z.stamps.get(r(this, l));
                G > Q.area && (Q.area = G, Q.serialized.bitmap.close(), Q.serialized.bitmap = Z(this, w, Re).call(this, !1));
              }
              return L;
            }
          };
          o = new WeakMap(), l = new WeakMap(), a = new WeakMap(), T = new WeakMap(), P = new WeakMap(), v = new WeakMap(), k = new WeakMap(), x = new WeakMap(), S = new WeakMap(), E = new WeakMap(), w = new WeakSet(), _e = function(X, z = !1) {
            if (!X) {
              this.remove();
              return;
            }
            lt(this, o, X.bitmap), z || (lt(this, l, X.id), lt(this, S, X.isSvg)), Z(this, w, un).call(this);
          }, me = function() {
            lt(this, a, null), this._uiManager.enableWaiting(!1), r(this, v) && this.div.focus();
          }, Me = function() {
            if (r(this, l)) {
              this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(r(this, l)).then((z) => Z(this, w, _e).call(this, z, !0)).finally(() => Z(this, w, me).call(this));
              return;
            }
            if (r(this, T)) {
              const z = r(this, T);
              lt(this, T, null), this._uiManager.enableWaiting(!0), lt(this, a, this._uiManager.imageManager.getFromUrl(z).then((L) => Z(this, w, _e).call(this, L)).finally(() => Z(this, w, me).call(this)));
              return;
            }
            if (r(this, P)) {
              const z = r(this, P);
              lt(this, P, null), this._uiManager.enableWaiting(!0), lt(this, a, this._uiManager.imageManager.getFromFile(z).then((L) => Z(this, w, _e).call(this, L)).finally(() => Z(this, w, me).call(this)));
              return;
            }
            const X = document.createElement("input");
            X.type = "file", X.accept = I.supportedTypesStr, lt(this, a, new Promise((z) => {
              X.addEventListener("change", async () => {
                if (!X.files || X.files.length === 0)
                  this.remove();
                else {
                  this._uiManager.enableWaiting(!0);
                  const L = await this._uiManager.imageManager.getFromFile(X.files[0]);
                  Z(this, w, _e).call(this, L);
                }
                z();
              }), X.addEventListener("cancel", () => {
                this.remove(), z();
              });
            }).finally(() => Z(this, w, me).call(this))), X.click();
          }, un = function() {
            const {
              div: X
            } = this;
            let {
              width: z,
              height: L
            } = r(this, o);
            const [et, D] = this.pageDimensions, G = 0.75;
            if (this.width)
              z = this.width * et, L = this.height * D;
            else if (z > G * et || L > G * D) {
              const u = Math.min(G * et / z, G * D / L);
              z *= u, L *= u;
            }
            const [Q, F] = this.parentDimensions;
            this.setDims(z * Q / et, L * F / D), this._uiManager.enableWaiting(!1);
            const d = lt(this, v, document.createElement("canvas"));
            X.append(d), X.hidden = !1, Z(this, w, pn).call(this, z, L), Z(this, w, Kn).call(this), r(this, E) || (this.parent.addUndoableEditor(this), lt(this, E, !0)), this._uiManager._eventBus.dispatch("reporttelemetry", {
              source: this,
              details: {
                type: "editing",
                subtype: this.editorType,
                data: {
                  action: "inserted_image"
                }
              }
            }), this.addAltTextButton();
          }, Vn = function(X, z) {
            var G;
            const [L, et] = this.parentDimensions;
            this.width = X / L, this.height = z / et, this.setDims(X, z), (G = this._initialOptions) != null && G.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, r(this, x) !== null && clearTimeout(r(this, x)), lt(this, x, setTimeout(() => {
              lt(this, x, null), Z(this, w, pn).call(this, X, z);
            }, 200));
          }, Yn = function(X, z) {
            const {
              width: L,
              height: et
            } = r(this, o);
            let D = L, G = et, Q = r(this, o);
            for (; D > 2 * X || G > 2 * z; ) {
              const F = D, d = G;
              D > 2 * X && (D = D >= 16384 ? Math.floor(D / 2) - 1 : Math.ceil(D / 2)), G > 2 * z && (G = G >= 16384 ? Math.floor(G / 2) - 1 : Math.ceil(G / 2));
              const u = new OffscreenCanvas(D, G);
              u.getContext("2d").drawImage(Q, 0, 0, F, d, 0, 0, D, G), Q = u.transferToImageBitmap();
            }
            return Q;
          }, pn = function(X, z) {
            X = Math.ceil(X), z = Math.ceil(z);
            const L = r(this, v);
            if (!L || L.width === X && L.height === z)
              return;
            L.width = X, L.height = z;
            const et = r(this, S) ? r(this, o) : Z(this, w, Yn).call(this, X, z), D = L.getContext("2d");
            D.filter = this._uiManager.hcmFilter, D.drawImage(et, 0, 0, et.width, et.height, 0, 0, X, z);
          }, Re = function(X) {
            if (X) {
              if (r(this, S)) {
                const et = this._uiManager.imageManager.getSvgUrl(r(this, l));
                if (et)
                  return et;
              }
              const z = document.createElement("canvas");
              return {
                width: z.width,
                height: z.height
              } = r(this, o), z.getContext("2d").drawImage(r(this, o), 0, 0), z.toDataURL();
            }
            if (r(this, S)) {
              const [z, L] = this.pageDimensions, et = Math.round(this.width * z * c.PixelsPerInch.PDF_TO_CSS_UNITS), D = Math.round(this.height * L * c.PixelsPerInch.PDF_TO_CSS_UNITS), G = new OffscreenCanvas(et, D);
              return G.getContext("2d").drawImage(r(this, o), 0, 0, r(this, o).width, r(this, o).height, 0, 0, et, D), G.transferToImageBitmap();
            }
            return structuredClone(r(this, o));
          }, Kn = function() {
            lt(this, k, new ResizeObserver((X) => {
              const z = X[0].contentRect;
              z.width && z.height && Z(this, w, Vn).call(this, z.width, z.height);
            })), r(this, k).observe(this.div);
          }, Kt(I, "_type", "stamp");
          let b = I;
          t.StampEditor = b;
        }
        /******/
      ], __webpack_module_cache__ = {};
      function __w_pdfjs_require__(i) {
        var t = __webpack_module_cache__[i];
        if (t !== void 0)
          return t.exports;
        var n = __webpack_module_cache__[i] = {
          /******/
          // no module.id needed
          /******/
          // no module.loaded needed
          /******/
          exports: {}
          /******/
        };
        return __webpack_modules__[i](n, n.exports, __w_pdfjs_require__), n.exports;
      }
      var __webpack_exports__ = {};
      return (() => {
        var i = __webpack_exports__;
        Object.defineProperty(i, "__esModule", {
          value: !0
        }), Object.defineProperty(i, "AbortException", {
          enumerable: !0,
          get: function() {
            return t.AbortException;
          }
        }), Object.defineProperty(i, "AnnotationEditorLayer", {
          enumerable: !0,
          get: function() {
            return c.AnnotationEditorLayer;
          }
        }), Object.defineProperty(i, "AnnotationEditorParamsType", {
          enumerable: !0,
          get: function() {
            return t.AnnotationEditorParamsType;
          }
        }), Object.defineProperty(i, "AnnotationEditorType", {
          enumerable: !0,
          get: function() {
            return t.AnnotationEditorType;
          }
        }), Object.defineProperty(i, "AnnotationEditorUIManager", {
          enumerable: !0,
          get: function() {
            return h.AnnotationEditorUIManager;
          }
        }), Object.defineProperty(i, "AnnotationLayer", {
          enumerable: !0,
          get: function() {
            return b.AnnotationLayer;
          }
        }), Object.defineProperty(i, "AnnotationMode", {
          enumerable: !0,
          get: function() {
            return t.AnnotationMode;
          }
        }), Object.defineProperty(i, "CMapCompressionType", {
          enumerable: !0,
          get: function() {
            return t.CMapCompressionType;
          }
        }), Object.defineProperty(i, "DOMSVGFactory", {
          enumerable: !0,
          get: function() {
            return e.DOMSVGFactory;
          }
        }), Object.defineProperty(i, "FeatureTest", {
          enumerable: !0,
          get: function() {
            return t.FeatureTest;
          }
        }), Object.defineProperty(i, "GlobalWorkerOptions", {
          enumerable: !0,
          get: function() {
            return o.GlobalWorkerOptions;
          }
        }), Object.defineProperty(i, "ImageKind", {
          enumerable: !0,
          get: function() {
            return t.ImageKind;
          }
        }), Object.defineProperty(i, "InvalidPDFException", {
          enumerable: !0,
          get: function() {
            return t.InvalidPDFException;
          }
        }), Object.defineProperty(i, "MissingPDFException", {
          enumerable: !0,
          get: function() {
            return t.MissingPDFException;
          }
        }), Object.defineProperty(i, "OPS", {
          enumerable: !0,
          get: function() {
            return t.OPS;
          }
        }), Object.defineProperty(i, "PDFDataRangeTransport", {
          enumerable: !0,
          get: function() {
            return n.PDFDataRangeTransport;
          }
        }), Object.defineProperty(i, "PDFDateString", {
          enumerable: !0,
          get: function() {
            return e.PDFDateString;
          }
        }), Object.defineProperty(i, "PDFWorker", {
          enumerable: !0,
          get: function() {
            return n.PDFWorker;
          }
        }), Object.defineProperty(i, "PasswordResponses", {
          enumerable: !0,
          get: function() {
            return t.PasswordResponses;
          }
        }), Object.defineProperty(i, "PermissionFlag", {
          enumerable: !0,
          get: function() {
            return t.PermissionFlag;
          }
        }), Object.defineProperty(i, "PixelsPerInch", {
          enumerable: !0,
          get: function() {
            return e.PixelsPerInch;
          }
        }), Object.defineProperty(i, "PromiseCapability", {
          enumerable: !0,
          get: function() {
            return t.PromiseCapability;
          }
        }), Object.defineProperty(i, "RenderingCancelledException", {
          enumerable: !0,
          get: function() {
            return e.RenderingCancelledException;
          }
        }), Object.defineProperty(i, "SVGGraphics", {
          enumerable: !0,
          get: function() {
            return n.SVGGraphics;
          }
        }), Object.defineProperty(i, "UnexpectedResponseException", {
          enumerable: !0,
          get: function() {
            return t.UnexpectedResponseException;
          }
        }), Object.defineProperty(i, "Util", {
          enumerable: !0,
          get: function() {
            return t.Util;
          }
        }), Object.defineProperty(i, "VerbosityLevel", {
          enumerable: !0,
          get: function() {
            return t.VerbosityLevel;
          }
        }), Object.defineProperty(i, "XfaLayer", {
          enumerable: !0,
          get: function() {
            return l.XfaLayer;
          }
        }), Object.defineProperty(i, "build", {
          enumerable: !0,
          get: function() {
            return n.build;
          }
        }), Object.defineProperty(i, "createValidAbsoluteUrl", {
          enumerable: !0,
          get: function() {
            return t.createValidAbsoluteUrl;
          }
        }), Object.defineProperty(i, "getDocument", {
          enumerable: !0,
          get: function() {
            return n.getDocument;
          }
        }), Object.defineProperty(i, "getFilenameFromUrl", {
          enumerable: !0,
          get: function() {
            return e.getFilenameFromUrl;
          }
        }), Object.defineProperty(i, "getPdfFilenameFromUrl", {
          enumerable: !0,
          get: function() {
            return e.getPdfFilenameFromUrl;
          }
        }), Object.defineProperty(i, "getXfaPageViewport", {
          enumerable: !0,
          get: function() {
            return e.getXfaPageViewport;
          }
        }), Object.defineProperty(i, "isDataScheme", {
          enumerable: !0,
          get: function() {
            return e.isDataScheme;
          }
        }), Object.defineProperty(i, "isPdfFile", {
          enumerable: !0,
          get: function() {
            return e.isPdfFile;
          }
        }), Object.defineProperty(i, "loadScript", {
          enumerable: !0,
          get: function() {
            return e.loadScript;
          }
        }), Object.defineProperty(i, "noContextMenu", {
          enumerable: !0,
          get: function() {
            return e.noContextMenu;
          }
        }), Object.defineProperty(i, "normalizeUnicode", {
          enumerable: !0,
          get: function() {
            return t.normalizeUnicode;
          }
        }), Object.defineProperty(i, "renderTextLayer", {
          enumerable: !0,
          get: function() {
            return s.renderTextLayer;
          }
        }), Object.defineProperty(i, "setLayerDimensions", {
          enumerable: !0,
          get: function() {
            return e.setLayerDimensions;
          }
        }), Object.defineProperty(i, "shadow", {
          enumerable: !0,
          get: function() {
            return t.shadow;
          }
        }), Object.defineProperty(i, "updateTextLayer", {
          enumerable: !0,
          get: function() {
            return s.updateTextLayer;
          }
        }), Object.defineProperty(i, "version", {
          enumerable: !0,
          get: function() {
            return n.version;
          }
        });
        var t = __w_pdfjs_require__(1), n = __w_pdfjs_require__(2), e = __w_pdfjs_require__(6), s = __w_pdfjs_require__(26), c = __w_pdfjs_require__(27), h = __w_pdfjs_require__(5), b = __w_pdfjs_require__(29), o = __w_pdfjs_require__(14), l = __w_pdfjs_require__(32);
      })(), __webpack_exports__;
    })()
  ));
})(pdf);
var pdfExports = pdf.exports;
const {
  SvelteComponent,
  append,
  assign,
  attr,
  binding_callbacks,
  check_outros,
  create_component,
  destroy_component,
  detach,
  element,
  empty,
  get_spread_object,
  get_spread_update,
  group_outros,
  init,
  insert,
  mount_component,
  safe_not_equal,
  set_data,
  set_style,
  space,
  text,
  transition_in,
  transition_out
} = window.__gradio__svelte__internal, { tick } = window.__gradio__svelte__internal;
function create_if_block_1(i) {
  let t, n;
  const e = [
    {
      autoscroll: (
        /*gradio*/
        i[11].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      i[11].i18n
    ) },
    /*loading_status*/
    i[10]
  ];
  let s = {};
  for (let c = 0; c < e.length; c += 1)
    s = assign(s, e[c]);
  return t = new Static({ props: s }), {
    c() {
      create_component(t.$$.fragment);
    },
    m(c, h) {
      mount_component(t, c, h), n = !0;
    },
    p(c, h) {
      const b = h[0] & /*gradio, loading_status*/
      3072 ? get_spread_update(e, [
        h[0] & /*gradio*/
        2048 && {
          autoscroll: (
            /*gradio*/
            c[11].autoscroll
          )
        },
        h[0] & /*gradio*/
        2048 && { i18n: (
          /*gradio*/
          c[11].i18n
        ) },
        h[0] & /*loading_status*/
        1024 && get_spread_object(
          /*loading_status*/
          c[10]
        )
      ]) : {};
      t.$set(b);
    },
    i(c) {
      n || (transition_in(t.$$.fragment, c), n = !0);
    },
    o(c) {
      transition_out(t.$$.fragment, c), n = !1;
    },
    d(c) {
      destroy_component(t, c);
    }
  };
}
function create_else_block(i) {
  let t, n;
  return t = new Upload({
    props: {
      filetype: "application/pdf",
      file_count: "single",
      root: (
        /*root*/
        i[7]
      ),
      $$slots: { default: [create_default_slot_5] },
      $$scope: { ctx: i }
    }
  }), t.$on(
    "load",
    /*handle_upload*/
    i[17]
  ), {
    c() {
      create_component(t.$$.fragment);
    },
    m(e, s) {
      mount_component(t, e, s), n = !0;
    },
    p(e, s) {
      const c = {};
      s[0] & /*root*/
      128 && (c.root = /*root*/
      e[7]), s[1] & /*$$scope*/
      1 && (c.$$scope = { dirty: s, ctx: e }), t.$set(c);
    },
    i(e) {
      n || (transition_in(t.$$.fragment, e), n = !0);
    },
    o(e) {
      transition_out(t.$$.fragment, e), n = !1;
    },
    d(e) {
      destroy_component(t, e);
    }
  };
}
function create_if_block(i) {
  let t, n, e, s, c, h, b, o, l, a, T, P, v, k, x, S, E, w, M;
  return t = new ModifyUpload({
    props: {
      i18n: (
        /*gradio*/
        i[11].i18n
      ),
      absolute: !0
    }
  }), t.$on(
    "clear",
    /*handle_clear*/
    i[16]
  ), b = new Button({
    props: {
      $$slots: { default: [create_default_slot_4] },
      $$scope: { ctx: i }
    }
  }), b.$on(
    "click",
    /*prev_page*/
    i[19]
  ), k = new Button({
    props: {
      $$slots: { default: [create_default_slot_3] },
      $$scope: { ctx: i }
    }
  }), k.$on(
    "click",
    /*next_page*/
    i[18]
  ), S = new Button({
    props: {
      $$slots: { default: [create_default_slot_2] },
      $$scope: { ctx: i }
    }
  }), S.$on(
    "click",
    /*enlarge*/
    i[20]
  ), w = new Button({
    props: {
      $$slots: { default: [create_default_slot_1] },
      $$scope: { ctx: i }
    }
  }), w.$on(
    "click",
    /*letting*/
    i[21]
  ), {
    c() {
      create_component(t.$$.fragment), n = space(), e = element("div"), s = element("canvas"), c = space(), h = element("div"), create_component(b.$$.fragment), o = space(), l = element("span"), a = text(
        /*currentPage*/
        i[15]
      ), T = text(" / "), P = text(
        /*numPages*/
        i[13]
      ), v = space(), create_component(k.$$.fragment), x = space(), create_component(S.$$.fragment), E = space(), create_component(w.$$.fragment), attr(e, "class", "pdf-canvas svelte-qxsbof"), set_style(
        e,
        "height",
        /*height*/
        i[1] + "px"
      ), attr(l, "class", "page-count svelte-qxsbof"), attr(h, "class", "button-row svelte-qxsbof");
    },
    m(g, p) {
      mount_component(t, g, p), insert(g, n, p), insert(g, e, p), append(e, s), i[25](s), insert(g, c, p), insert(g, h, p), mount_component(b, h, null), append(h, o), append(h, l), append(l, a), append(l, T), append(l, P), append(h, v), mount_component(k, h, null), append(h, x), mount_component(S, h, null), append(h, E), mount_component(w, h, null), M = !0;
    },
    p(g, p) {
      const _ = {};
      p[0] & /*gradio*/
      2048 && (_.i18n = /*gradio*/
      g[11].i18n), t.$set(_), (!M || p[0] & /*height*/
      2) && set_style(
        e,
        "height",
        /*height*/
        g[1] + "px"
      );
      const f = {};
      p[1] & /*$$scope*/
      1 && (f.$$scope = { dirty: p, ctx: g }), b.$set(f), (!M || p[0] & /*currentPage*/
      32768) && set_data(
        a,
        /*currentPage*/
        g[15]
      ), (!M || p[0] & /*numPages*/
      8192) && set_data(
        P,
        /*numPages*/
        g[13]
      );
      const A = {};
      p[1] & /*$$scope*/
      1 && (A.$$scope = { dirty: p, ctx: g }), k.$set(A);
      const C = {};
      p[1] & /*$$scope*/
      1 && (C.$$scope = { dirty: p, ctx: g }), S.$set(C);
      const W = {};
      p[1] & /*$$scope*/
      1 && (W.$$scope = { dirty: p, ctx: g }), w.$set(W);
    },
    i(g) {
      M || (transition_in(t.$$.fragment, g), transition_in(b.$$.fragment, g), transition_in(k.$$.fragment, g), transition_in(S.$$.fragment, g), transition_in(w.$$.fragment, g), M = !0);
    },
    o(g) {
      transition_out(t.$$.fragment, g), transition_out(b.$$.fragment, g), transition_out(k.$$.fragment, g), transition_out(S.$$.fragment, g), transition_out(w.$$.fragment, g), M = !1;
    },
    d(g) {
      g && (detach(n), detach(e), detach(c), detach(h)), destroy_component(t, g), i[25](null), destroy_component(b), destroy_component(k), destroy_component(S), destroy_component(w);
    }
  };
}
function create_default_slot_5(i) {
  let t, n;
  return t = new PdfUploadText({}), {
    c() {
      create_component(t.$$.fragment);
    },
    m(e, s) {
      mount_component(t, e, s), n = !0;
    },
    i(e) {
      n || (transition_in(t.$$.fragment, e), n = !0);
    },
    o(e) {
      transition_out(t.$$.fragment, e), n = !1;
    },
    d(e) {
      destroy_component(t, e);
    }
  };
}
function create_default_slot_4(i) {
  let t;
  return {
    c() {
      t = text("⬅️");
    },
    m(n, e) {
      insert(n, t, e);
    },
    d(n) {
      n && detach(t);
    }
  };
}
function create_default_slot_3(i) {
  let t;
  return {
    c() {
      t = text("➡️");
    },
    m(n, e) {
      insert(n, t, e);
    },
    d(n) {
      n && detach(t);
    }
  };
}
function create_default_slot_2(i) {
  let t;
  return {
    c() {
      t = text("+");
    },
    m(n, e) {
      insert(n, t, e);
    },
    d(n) {
      n && detach(t);
    }
  };
}
function create_default_slot_1(i) {
  let t;
  return {
    c() {
      t = text("-");
    },
    m(n, e) {
      insert(n, t, e);
    },
    d(n) {
      n && detach(t);
    }
  };
}
function create_default_slot(i) {
  let t, n, e, s, c, h, b, o = (
    /*loading_status*/
    i[10] && create_if_block_1(i)
  );
  n = new BlockLabel({
    props: {
      show_label: (
        /*label*/
        i[8] !== null
      ),
      Icon: File$1,
      float: (
        /*value*/
        i[0] === null
      ),
      label: (
        /*label*/
        i[8] || "File"
      )
    }
  });
  const l = [create_if_block, create_else_block], a = [];
  function T(P, v) {
    return (
      /*_value*/
      P[12] ? 0 : 1
    );
  }
  return s = T(i), c = a[s] = l[s](i), {
    c() {
      o && o.c(), t = space(), create_component(n.$$.fragment), e = space(), c.c(), h = empty();
    },
    m(P, v) {
      o && o.m(P, v), insert(P, t, v), mount_component(n, P, v), insert(P, e, v), a[s].m(P, v), insert(P, h, v), b = !0;
    },
    p(P, v) {
      /*loading_status*/
      P[10] ? o ? (o.p(P, v), v[0] & /*loading_status*/
      1024 && transition_in(o, 1)) : (o = create_if_block_1(P), o.c(), transition_in(o, 1), o.m(t.parentNode, t)) : o && (group_outros(), transition_out(o, 1, 1, () => {
        o = null;
      }), check_outros());
      const k = {};
      v[0] & /*label*/
      256 && (k.show_label = /*label*/
      P[8] !== null), v[0] & /*value*/
      1 && (k.float = /*value*/
      P[0] === null), v[0] & /*label*/
      256 && (k.label = /*label*/
      P[8] || "File"), n.$set(k);
      let x = s;
      s = T(P), s === x ? a[s].p(P, v) : (group_outros(), transition_out(a[x], 1, 1, () => {
        a[x] = null;
      }), check_outros(), c = a[s], c ? c.p(P, v) : (c = a[s] = l[s](P), c.c()), transition_in(c, 1), c.m(h.parentNode, h));
    },
    i(P) {
      b || (transition_in(o), transition_in(n.$$.fragment, P), transition_in(c), b = !0);
    },
    o(P) {
      transition_out(o), transition_out(n.$$.fragment, P), transition_out(c), b = !1;
    },
    d(P) {
      P && (detach(t), detach(e), detach(h)), o && o.d(P), destroy_component(n, P), a[s].d(P);
    }
  };
}
function create_fragment(i) {
  let t, n;
  return t = new Block({
    props: {
      visible: (
        /*visible*/
        i[5]
      ),
      elem_id: (
        /*elem_id*/
        i[3]
      ),
      elem_classes: (
        /*elem_classes*/
        i[4]
      ),
      container: (
        /*container*/
        i[6]
      ),
      scale: (
        /*scale*/
        i[2]
      ),
      min_width: (
        /*min_width*/
        i[9]
      ),
      $$slots: { default: [create_default_slot] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      create_component(t.$$.fragment);
    },
    m(e, s) {
      mount_component(t, e, s), n = !0;
    },
    p(e, s) {
      const c = {};
      s[0] & /*visible*/
      32 && (c.visible = /*visible*/
      e[5]), s[0] & /*elem_id*/
      8 && (c.elem_id = /*elem_id*/
      e[3]), s[0] & /*elem_classes*/
      16 && (c.elem_classes = /*elem_classes*/
      e[4]), s[0] & /*container*/
      64 && (c.container = /*container*/
      e[6]), s[0] & /*scale*/
      4 && (c.scale = /*scale*/
      e[2]), s[0] & /*min_width*/
      512 && (c.min_width = /*min_width*/
      e[9]), s[0] & /*numPages, currentPage, height, canvasRef, gradio, _value, root, label, value, loading_status*/
      64899 | s[1] & /*$$scope*/
      1 && (c.$$scope = { dirty: s, ctx: e }), t.$set(c);
    },
    i(e) {
      n || (transition_in(t.$$.fragment, e), n = !0);
    },
    o(e) {
      transition_out(t.$$.fragment, e), n = !1;
    },
    d(e) {
      destroy_component(t, e);
    }
  };
}
function normalise_file(i, t, n) {
  return i;
}
function instance(i, t, n) {
  let e;
  var s = this && this.__awaiter || function(L, et, D, G) {
    function Q(F) {
      return F instanceof D ? F : new D(function(d) {
        d(F);
      });
    }
    return new (D || (D = Promise))(function(F, d) {
      function u(N) {
        try {
          B(G.next(N));
        } catch ($) {
          d($);
        }
      }
      function y(N) {
        try {
          B(G.throw(N));
        } catch ($) {
          d($);
        }
      }
      function B(N) {
        N.done ? F(N.value) : Q(N.value).then(u, y);
      }
      B((G = G.apply(L, et || [])).next());
    });
  };
  let { elem_id: c = "" } = t, { elem_classes: h = [] } = t, { visible: b = !0 } = t, { value: o = null } = t, { container: l = !0 } = t, { scale: a = 1 } = t, { root: T } = t, { height: P = 1e3 } = t, { starting_page: v } = t, { label: k } = t, { proxy_url: x } = t, { min_width: S = void 0 } = t, { loading_status: E } = t, { gradio: w } = t;
  pdfExports.GlobalWorkerOptions.workerSrc = "https://cdn.bootcss.com/pdf.js/3.11.174/pdf.worker.js";
  let M = o, g = M, p, _ = 1, f;
  function A() {
    return s(this, void 0, void 0, function* () {
      n(12, M = null), yield tick(), w.dispatch("change");
    });
  }
  function C(L) {
    return s(this, arguments, void 0, function* ({ detail: et }) {
      n(0, o = et), yield tick(), w.dispatch("change"), w.dispatch("upload");
    });
  }
  function W(L) {
    return s(this, void 0, void 0, function* () {
      p = yield pdfExports.getDocument(L.url).promise, n(13, _ = p.numPages), m(e);
    });
  }
  function m(L) {
    p.getPage(L).then((et) => {
      const D = f.getContext("2d");
      let G = window.devicePixelRatio || 1, Q = D.webkitBackingStorePixelRatio || D.mozBackingStorePixelRatio || D.msBackingStorePixelRatio || D.oBackingStorePixelRatio || D.backingStorePixelRatio || 1, F = G / Q, d = et.getViewport({ scale: a });
      var u = et.getViewport({
        scale: screen.availWidth / d.width
      });
      u = d, u = d, n(14, f.width = u.width * F, f), n(14, f.height = u.height * F, f), n(14, f.style.width = u.width + "px", f), n(14, f.style.height = u.height + "px", f), D.setTransform(F, 0, 0, F, 0, 0);
      var y = {
        canvasContext: D,
        viewport: d
      };
      et.render(y);
    });
  }
  function I() {
    e >= _ || (n(15, e++, e), m(e));
  }
  function q() {
    e != 1 && (n(15, e--, e), m(e));
  }
  function Y() {
    n(2, a += 0.1), m(e);
  }
  function X() {
    n(2, a -= 0.1), m(e);
  }
  function z(L) {
    binding_callbacks[L ? "unshift" : "push"](() => {
      f = L, n(14, f);
    });
  }
  return i.$$set = (L) => {
    "elem_id" in L && n(3, c = L.elem_id), "elem_classes" in L && n(4, h = L.elem_classes), "visible" in L && n(5, b = L.visible), "value" in L && n(0, o = L.value), "container" in L && n(6, l = L.container), "scale" in L && n(2, a = L.scale), "root" in L && n(7, T = L.root), "height" in L && n(1, P = L.height), "starting_page" in L && n(22, v = L.starting_page), "label" in L && n(8, k = L.label), "proxy_url" in L && n(23, x = L.proxy_url), "min_width" in L && n(9, S = L.min_width), "loading_status" in L && n(10, E = L.loading_status), "gradio" in L && n(11, w = L.gradio);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*value*/
    1 && console.log("Current height:", o), i.$$.dirty[0] & /*height*/
    2 && n(1, P = P || 500), i.$$.dirty[0] & /*value, root, proxy_url*/
    8388737 && n(12, M = normalise_file(o)), i.$$.dirty[0] & /*old_value, _value, gradio*/
    16783360 && JSON.stringify(g) != JSON.stringify(M) && (M && W(M), n(24, g = M), w.dispatch("change"));
  }, n(15, e = 1), [
    o,
    P,
    a,
    c,
    h,
    b,
    l,
    T,
    k,
    S,
    E,
    w,
    M,
    _,
    f,
    e,
    A,
    C,
    I,
    q,
    Y,
    X,
    v,
    x,
    g,
    z
  ];
}
class Index extends SvelteComponent {
  constructor(t) {
    super(), init(
      this,
      t,
      instance,
      create_fragment,
      safe_not_equal,
      {
        elem_id: 3,
        elem_classes: 4,
        visible: 5,
        value: 0,
        container: 6,
        scale: 2,
        root: 7,
        height: 1,
        starting_page: 22,
        label: 8,
        proxy_url: 23,
        min_width: 9,
        loading_status: 10,
        gradio: 11
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Index as I,
  require$$5$1 as r
};
