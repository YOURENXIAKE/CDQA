var Yi = Object.defineProperty;
var pi = (pt) => {
  throw TypeError(pt);
};
var Ki = (pt, h, rt) => h in pt ? Yi(pt, h, { enumerable: !0, configurable: !0, writable: !0, value: rt }) : pt[h] = rt;
var Kt = (pt, h, rt) => Ki(pt, typeof h != "symbol" ? h + "" : h, rt), Re = (pt, h, rt) => h.has(pt) || pi("Cannot " + rt);
var t = (pt, h, rt) => (Re(pt, h, "read from private field"), rt ? rt.call(pt) : h.get(pt)), Q = (pt, h, rt) => h.has(pt) ? pi("Cannot add the same private member more than once") : h instanceof WeakSet ? h.add(pt) : h.set(pt, rt), et = (pt, h, rt, o) => (Re(pt, h, "write to private field"), o ? o.call(pt, rt) : h.set(pt, rt), rt), z = (pt, h, rt) => (Re(pt, h, "access private method"), rt);
var he = (pt, h, rt, o) => ({
  set _(T) {
    et(pt, h, T, rt);
  },
  get _() {
    return t(pt, h, o);
  }
});
function getDefaultExportFromCjs(pt) {
  return pt && pt.__esModule && Object.prototype.hasOwnProperty.call(pt, "default") ? pt.default : pt;
}
function getAugmentedNamespace(pt) {
  if (pt.__esModule) return pt;
  var h = pt.default;
  if (typeof h == "function") {
    var rt = function o() {
      return this instanceof o ? Reflect.construct(h, arguments, this.constructor) : h.apply(this, arguments);
    };
    rt.prototype = h.prototype;
  } else rt = {};
  return Object.defineProperty(rt, "__esModule", { value: !0 }), Object.keys(pt).forEach(function(o) {
    var T = Object.getOwnPropertyDescriptor(pt, o);
    Object.defineProperty(rt, o, T.get ? T : {
      enumerable: !0,
      get: function() {
        return pt[o];
      }
    });
  }), rt;
}
function commonjsRequire(pt) {
  throw new Error('Could not dynamically require "' + pt + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var pdf = { exports: {} };
const __viteBrowserExternal = {}, __viteBrowserExternal$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: __viteBrowserExternal
}, Symbol.toStringTag, { value: "Module" })), require$$5 = /* @__PURE__ */ getAugmentedNamespace(__viteBrowserExternal$1);
(function(module, exports) {
  (function(h, rt) {
    module.exports = h.pdfjsLib = rt();
  })(globalThis, () => (
    /******/
    (() => {
      var __webpack_modules__ = [
        ,
        /* 1 */
        /***/
        (pt, h) => {
          var $t;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.VerbosityLevel = h.Util = h.UnknownErrorException = h.UnexpectedResponseException = h.TextRenderingMode = h.RenderingIntentFlag = h.PromiseCapability = h.PermissionFlag = h.PasswordResponses = h.PasswordException = h.PageActionEventType = h.OPS = h.MissingPDFException = h.MAX_IMAGE_SIZE_TO_CACHE = h.LINE_FACTOR = h.LINE_DESCENT_FACTOR = h.InvalidPDFException = h.ImageKind = h.IDENTITY_MATRIX = h.FormatError = h.FeatureTest = h.FONT_IDENTITY_MATRIX = h.DocumentActionEventType = h.CMapCompressionType = h.BaseException = h.BASELINE_FACTOR = h.AnnotationType = h.AnnotationReplyType = h.AnnotationPrefix = h.AnnotationMode = h.AnnotationFlag = h.AnnotationFieldFlag = h.AnnotationEditorType = h.AnnotationEditorPrefix = h.AnnotationEditorParamsType = h.AnnotationBorderStyleType = h.AnnotationActionEventType = h.AbortException = void 0, h.assert = C, h.bytesToString = ht, h.createValidAbsoluteUrl = Y, h.getModificationDate = wt, h.getUuid = Nt, h.getVerbosityLevel = W, h.info = $, h.isArrayBuffer = V, h.isArrayEqual = Tt, h.isNodeJS = void 0, h.normalizeUnicode = Ft, h.objectFromMap = vt, h.objectSize = At, h.setVerbosityLevel = nt, h.shadow = S, h.string32 = mt, h.stringToBytes = dt, h.stringToPDFString = ut, h.stringToUTF8String = St, h.unreachable = at, h.utf8StringToString = yt, h.warn = j;
          const rt = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser");
          h.isNodeJS = rt;
          const o = [1, 0, 0, 1, 0, 0];
          h.IDENTITY_MATRIX = o;
          const T = [1e-3, 0, 0, 1e-3, 0, 0];
          h.FONT_IDENTITY_MATRIX = T;
          const ct = 1e7;
          h.MAX_IMAGE_SIZE_TO_CACHE = ct;
          const q = 1.35;
          h.LINE_FACTOR = q;
          const gt = 0.35;
          h.LINE_DESCENT_FACTOR = gt;
          const B = gt / q;
          h.BASELINE_FACTOR = B;
          const M = {
            ANY: 1,
            DISPLAY: 2,
            PRINT: 4,
            SAVE: 8,
            ANNOTATIONS_FORMS: 16,
            ANNOTATIONS_STORAGE: 32,
            ANNOTATIONS_DISABLE: 64,
            OPLIST: 256
          };
          h.RenderingIntentFlag = M;
          const m = {
            DISABLE: 0,
            ENABLE: 1,
            ENABLE_FORMS: 2,
            ENABLE_STORAGE: 3
          };
          h.AnnotationMode = m;
          const N = "pdfjs_internal_editor_";
          h.AnnotationEditorPrefix = N;
          const I = {
            DISABLE: -1,
            NONE: 0,
            FREETEXT: 3,
            STAMP: 13,
            INK: 15
          };
          h.AnnotationEditorType = I;
          const _ = {
            RESIZE: 1,
            CREATE: 2,
            FREETEXT_SIZE: 11,
            FREETEXT_COLOR: 12,
            FREETEXT_OPACITY: 13,
            INK_COLOR: 21,
            INK_THICKNESS: 22,
            INK_OPACITY: 23
          };
          h.AnnotationEditorParamsType = _;
          const b = {
            PRINT: 4,
            MODIFY_CONTENTS: 8,
            COPY: 16,
            MODIFY_ANNOTATIONS: 32,
            FILL_INTERACTIVE_FORMS: 256,
            COPY_FOR_ACCESSIBILITY: 512,
            ASSEMBLE: 1024,
            PRINT_HIGH_QUALITY: 2048
          };
          h.PermissionFlag = b;
          const E = {
            FILL: 0,
            STROKE: 1,
            FILL_STROKE: 2,
            INVISIBLE: 3,
            FILL_ADD_TO_PATH: 4,
            STROKE_ADD_TO_PATH: 5,
            FILL_STROKE_ADD_TO_PATH: 6,
            ADD_TO_PATH: 7,
            FILL_STROKE_MASK: 3,
            ADD_TO_PATH_FLAG: 4
          };
          h.TextRenderingMode = E;
          const f = {
            GRAYSCALE_1BPP: 1,
            RGB_24BPP: 2,
            RGBA_32BPP: 3
          };
          h.ImageKind = f;
          const d = {
            TEXT: 1,
            LINK: 2,
            FREETEXT: 3,
            LINE: 4,
            SQUARE: 5,
            CIRCLE: 6,
            POLYGON: 7,
            POLYLINE: 8,
            HIGHLIGHT: 9,
            UNDERLINE: 10,
            SQUIGGLY: 11,
            STRIKEOUT: 12,
            STAMP: 13,
            CARET: 14,
            INK: 15,
            POPUP: 16,
            FILEATTACHMENT: 17,
            SOUND: 18,
            MOVIE: 19,
            WIDGET: 20,
            SCREEN: 21,
            PRINTERMARK: 22,
            TRAPNET: 23,
            WATERMARK: 24,
            THREED: 25,
            REDACT: 26
          };
          h.AnnotationType = d;
          const p = {
            GROUP: "Group",
            REPLY: "R"
          };
          h.AnnotationReplyType = p;
          const D = {
            INVISIBLE: 1,
            HIDDEN: 2,
            PRINT: 4,
            NOZOOM: 8,
            NOROTATE: 16,
            NOVIEW: 32,
            READONLY: 64,
            LOCKED: 128,
            TOGGLENOVIEW: 256,
            LOCKEDCONTENTS: 512
          };
          h.AnnotationFlag = D;
          const y = {
            READONLY: 1,
            REQUIRED: 2,
            NOEXPORT: 4,
            MULTILINE: 4096,
            PASSWORD: 8192,
            NOTOGGLETOOFF: 16384,
            RADIO: 32768,
            PUSHBUTTON: 65536,
            COMBO: 131072,
            EDIT: 262144,
            SORT: 524288,
            FILESELECT: 1048576,
            MULTISELECT: 2097152,
            DONOTSPELLCHECK: 4194304,
            DONOTSCROLL: 8388608,
            COMB: 16777216,
            RICHTEXT: 33554432,
            RADIOSINUNISON: 33554432,
            COMMITONSELCHANGE: 67108864
          };
          h.AnnotationFieldFlag = y;
          const n = {
            SOLID: 1,
            DASHED: 2,
            BEVELED: 3,
            INSET: 4,
            UNDERLINE: 5
          };
          h.AnnotationBorderStyleType = n;
          const l = {
            E: "Mouse Enter",
            X: "Mouse Exit",
            D: "Mouse Down",
            U: "Mouse Up",
            Fo: "Focus",
            Bl: "Blur",
            PO: "PageOpen",
            PC: "PageClose",
            PV: "PageVisible",
            PI: "PageInvisible",
            K: "Keystroke",
            F: "Format",
            V: "Validate",
            C: "Calculate"
          };
          h.AnnotationActionEventType = l;
          const s = {
            WC: "WillClose",
            WS: "WillSave",
            DS: "DidSave",
            WP: "WillPrint",
            DP: "DidPrint"
          };
          h.DocumentActionEventType = s;
          const a = {
            O: "PageOpen",
            C: "PageClose"
          };
          h.PageActionEventType = a;
          const c = {
            ERRORS: 0,
            WARNINGS: 1,
            INFOS: 5
          };
          h.VerbosityLevel = c;
          const O = {
            NONE: 0,
            BINARY: 1
          };
          h.CMapCompressionType = O;
          const r = {
            dependency: 1,
            setLineWidth: 2,
            setLineCap: 3,
            setLineJoin: 4,
            setMiterLimit: 5,
            setDash: 6,
            setRenderingIntent: 7,
            setFlatness: 8,
            setGState: 9,
            save: 10,
            restore: 11,
            transform: 12,
            moveTo: 13,
            lineTo: 14,
            curveTo: 15,
            curveTo2: 16,
            curveTo3: 17,
            closePath: 18,
            rectangle: 19,
            stroke: 20,
            closeStroke: 21,
            fill: 22,
            eoFill: 23,
            fillStroke: 24,
            eoFillStroke: 25,
            closeFillStroke: 26,
            closeEOFillStroke: 27,
            endPath: 28,
            clip: 29,
            eoClip: 30,
            beginText: 31,
            endText: 32,
            setCharSpacing: 33,
            setWordSpacing: 34,
            setHScale: 35,
            setLeading: 36,
            setFont: 37,
            setTextRenderingMode: 38,
            setTextRise: 39,
            moveText: 40,
            setLeadingMoveText: 41,
            setTextMatrix: 42,
            nextLine: 43,
            showText: 44,
            showSpacedText: 45,
            nextLineShowText: 46,
            nextLineSetSpacingShowText: 47,
            setCharWidth: 48,
            setCharWidthAndBounds: 49,
            setStrokeColorSpace: 50,
            setFillColorSpace: 51,
            setStrokeColor: 52,
            setStrokeColorN: 53,
            setFillColor: 54,
            setFillColorN: 55,
            setStrokeGray: 56,
            setFillGray: 57,
            setStrokeRGBColor: 58,
            setFillRGBColor: 59,
            setStrokeCMYKColor: 60,
            setFillCMYKColor: 61,
            shadingFill: 62,
            beginInlineImage: 63,
            beginImageData: 64,
            endInlineImage: 65,
            paintXObject: 66,
            markPoint: 67,
            markPointProps: 68,
            beginMarkedContent: 69,
            beginMarkedContentProps: 70,
            endMarkedContent: 71,
            beginCompat: 72,
            endCompat: 73,
            paintFormXObjectBegin: 74,
            paintFormXObjectEnd: 75,
            beginGroup: 76,
            endGroup: 77,
            beginAnnotation: 80,
            endAnnotation: 81,
            paintImageMaskXObject: 83,
            paintImageMaskXObjectGroup: 84,
            paintImageXObject: 85,
            paintInlineImageXObject: 86,
            paintInlineImageXObjectGroup: 87,
            paintImageXObjectRepeat: 88,
            paintImageMaskXObjectRepeat: 89,
            paintSolidColorImageMask: 90,
            constructPath: 91
          };
          h.OPS = r;
          const A = {
            NEED_PASSWORD: 1,
            INCORRECT_PASSWORD: 2
          };
          h.PasswordResponses = A;
          let F = c.WARNINGS;
          function nt(_t) {
            Number.isInteger(_t) && (F = _t);
          }
          function W() {
            return F;
          }
          function $(_t) {
            F >= c.INFOS && console.log(`Info: ${_t}`);
          }
          function j(_t) {
            F >= c.WARNINGS && console.log(`Warning: ${_t}`);
          }
          function at(_t) {
            throw new Error(_t);
          }
          function C(_t, tt) {
            _t || at(tt);
          }
          function U(_t) {
            switch (_t == null ? void 0 : _t.protocol) {
              case "http:":
              case "https:":
              case "ftp:":
              case "mailto:":
              case "tel:":
                return !0;
              default:
                return !1;
            }
          }
          function Y(_t, tt = null, st = null) {
            if (!_t)
              return null;
            try {
              if (st && typeof _t == "string") {
                if (st.addDefaultProtocol && _t.startsWith("www.")) {
                  const zt = _t.match(/\./g);
                  (zt == null ? void 0 : zt.length) >= 2 && (_t = `http://${_t}`);
                }
                if (st.tryConvertEncoding)
                  try {
                    _t = St(_t);
                  } catch {
                  }
              }
              const kt = tt ? new URL(_t, tt) : new URL(_t);
              if (U(kt))
                return kt;
            } catch {
            }
            return null;
          }
          function S(_t, tt, st, kt = !1) {
            return Object.defineProperty(_t, tt, {
              value: st,
              enumerable: !kt,
              configurable: !0,
              writable: !1
            }), st;
          }
          const e = function() {
            function tt(st, kt) {
              this.constructor === tt && at("Cannot initialize BaseException."), this.message = st, this.name = kt;
            }
            return tt.prototype = new Error(), tt.constructor = tt, tt;
          }();
          h.BaseException = e;
          class i extends e {
            constructor(tt, st) {
              super(tt, "PasswordException"), this.code = st;
            }
          }
          h.PasswordException = i;
          class u extends e {
            constructor(tt, st) {
              super(tt, "UnknownErrorException"), this.details = st;
            }
          }
          h.UnknownErrorException = u;
          class x extends e {
            constructor(tt) {
              super(tt, "InvalidPDFException");
            }
          }
          h.InvalidPDFException = x;
          class P extends e {
            constructor(tt) {
              super(tt, "MissingPDFException");
            }
          }
          h.MissingPDFException = P;
          class k extends e {
            constructor(tt, st) {
              super(tt, "UnexpectedResponseException"), this.status = st;
            }
          }
          h.UnexpectedResponseException = k;
          class G extends e {
            constructor(tt) {
              super(tt, "FormatError");
            }
          }
          h.FormatError = G;
          class it extends e {
            constructor(tt) {
              super(tt, "AbortException");
            }
          }
          h.AbortException = it;
          function ht(_t) {
            (typeof _t != "object" || (_t == null ? void 0 : _t.length) === void 0) && at("Invalid argument for bytesToString");
            const tt = _t.length, st = 8192;
            if (tt < st)
              return String.fromCharCode.apply(null, _t);
            const kt = [];
            for (let zt = 0; zt < tt; zt += st) {
              const Gt = Math.min(zt + st, tt), L = _t.subarray(zt, Gt);
              kt.push(String.fromCharCode.apply(null, L));
            }
            return kt.join("");
          }
          function dt(_t) {
            typeof _t != "string" && at("Invalid argument for stringToBytes");
            const tt = _t.length, st = new Uint8Array(tt);
            for (let kt = 0; kt < tt; ++kt)
              st[kt] = _t.charCodeAt(kt) & 255;
            return st;
          }
          function mt(_t) {
            return String.fromCharCode(_t >> 24 & 255, _t >> 16 & 255, _t >> 8 & 255, _t & 255);
          }
          function At(_t) {
            return Object.keys(_t).length;
          }
          function vt(_t) {
            const tt = /* @__PURE__ */ Object.create(null);
            for (const [st, kt] of _t)
              tt[st] = kt;
            return tt;
          }
          function K() {
            const _t = new Uint8Array(4);
            return _t[0] = 1, new Uint32Array(_t.buffer, 0, 1)[0] === 1;
          }
          function Z() {
            try {
              return new Function(""), !0;
            } catch {
              return !1;
            }
          }
          class g {
            static get isLittleEndian() {
              return S(this, "isLittleEndian", K());
            }
            static get isEvalSupported() {
              return S(this, "isEvalSupported", Z());
            }
            static get isOffscreenCanvasSupported() {
              return S(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
            }
            static get platform() {
              return typeof navigator > "u" ? S(this, "platform", {
                isWin: !1,
                isMac: !1
              }) : S(this, "platform", {
                isWin: navigator.platform.includes("Win"),
                isMac: navigator.platform.includes("Mac")
              });
            }
            static get isCSSRoundSupported() {
              var tt, st;
              return S(this, "isCSSRoundSupported", (st = (tt = globalThis.CSS) == null ? void 0 : tt.supports) == null ? void 0 : st.call(tt, "width: round(1.5px, 1px)"));
            }
          }
          h.FeatureTest = g;
          const R = [...Array(256).keys()].map((_t) => _t.toString(16).padStart(2, "0"));
          class X {
            static makeHexColor(tt, st, kt) {
              return `#${R[tt]}${R[st]}${R[kt]}`;
            }
            static scaleMinMax(tt, st) {
              let kt;
              tt[0] ? (tt[0] < 0 && (kt = st[0], st[0] = st[1], st[1] = kt), st[0] *= tt[0], st[1] *= tt[0], tt[3] < 0 && (kt = st[2], st[2] = st[3], st[3] = kt), st[2] *= tt[3], st[3] *= tt[3]) : (kt = st[0], st[0] = st[2], st[2] = kt, kt = st[1], st[1] = st[3], st[3] = kt, tt[1] < 0 && (kt = st[2], st[2] = st[3], st[3] = kt), st[2] *= tt[1], st[3] *= tt[1], tt[2] < 0 && (kt = st[0], st[0] = st[1], st[1] = kt), st[0] *= tt[2], st[1] *= tt[2]), st[0] += tt[4], st[1] += tt[4], st[2] += tt[5], st[3] += tt[5];
            }
            static transform(tt, st) {
              return [tt[0] * st[0] + tt[2] * st[1], tt[1] * st[0] + tt[3] * st[1], tt[0] * st[2] + tt[2] * st[3], tt[1] * st[2] + tt[3] * st[3], tt[0] * st[4] + tt[2] * st[5] + tt[4], tt[1] * st[4] + tt[3] * st[5] + tt[5]];
            }
            static applyTransform(tt, st) {
              const kt = tt[0] * st[0] + tt[1] * st[2] + st[4], zt = tt[0] * st[1] + tt[1] * st[3] + st[5];
              return [kt, zt];
            }
            static applyInverseTransform(tt, st) {
              const kt = st[0] * st[3] - st[1] * st[2], zt = (tt[0] * st[3] - tt[1] * st[2] + st[2] * st[5] - st[4] * st[3]) / kt, Gt = (-tt[0] * st[1] + tt[1] * st[0] + st[4] * st[1] - st[5] * st[0]) / kt;
              return [zt, Gt];
            }
            static getAxialAlignedBoundingBox(tt, st) {
              const kt = this.applyTransform(tt, st), zt = this.applyTransform(tt.slice(2, 4), st), Gt = this.applyTransform([tt[0], tt[3]], st), L = this.applyTransform([tt[2], tt[1]], st);
              return [Math.min(kt[0], zt[0], Gt[0], L[0]), Math.min(kt[1], zt[1], Gt[1], L[1]), Math.max(kt[0], zt[0], Gt[0], L[0]), Math.max(kt[1], zt[1], Gt[1], L[1])];
            }
            static inverseTransform(tt) {
              const st = tt[0] * tt[3] - tt[1] * tt[2];
              return [tt[3] / st, -tt[1] / st, -tt[2] / st, tt[0] / st, (tt[2] * tt[5] - tt[4] * tt[3]) / st, (tt[4] * tt[1] - tt[5] * tt[0]) / st];
            }
            static singularValueDecompose2dScale(tt) {
              const st = [tt[0], tt[2], tt[1], tt[3]], kt = tt[0] * st[0] + tt[1] * st[2], zt = tt[0] * st[1] + tt[1] * st[3], Gt = tt[2] * st[0] + tt[3] * st[2], L = tt[2] * st[1] + tt[3] * st[3], ft = (kt + L) / 2, Ct = Math.sqrt((kt + L) ** 2 - 4 * (kt * L - Gt * zt)) / 2, Dt = ft + Ct || 1, Ot = ft - Ct || 1;
              return [Math.sqrt(Dt), Math.sqrt(Ot)];
            }
            static normalizeRect(tt) {
              const st = tt.slice(0);
              return tt[0] > tt[2] && (st[0] = tt[2], st[2] = tt[0]), tt[1] > tt[3] && (st[1] = tt[3], st[3] = tt[1]), st;
            }
            static intersect(tt, st) {
              const kt = Math.max(Math.min(tt[0], tt[2]), Math.min(st[0], st[2])), zt = Math.min(Math.max(tt[0], tt[2]), Math.max(st[0], st[2]));
              if (kt > zt)
                return null;
              const Gt = Math.max(Math.min(tt[1], tt[3]), Math.min(st[1], st[3])), L = Math.min(Math.max(tt[1], tt[3]), Math.max(st[1], st[3]));
              return Gt > L ? null : [kt, Gt, zt, L];
            }
            static bezierBoundingBox(tt, st, kt, zt, Gt, L, ft, Ct) {
              const Dt = [], Ot = [[], []];
              let Pt, w, v, H, ot, lt, bt, Et;
              for (let Ht = 0; Ht < 2; ++Ht) {
                if (Ht === 0 ? (w = 6 * tt - 12 * kt + 6 * Gt, Pt = -3 * tt + 9 * kt - 9 * Gt + 3 * ft, v = 3 * kt - 3 * tt) : (w = 6 * st - 12 * zt + 6 * L, Pt = -3 * st + 9 * zt - 9 * L + 3 * Ct, v = 3 * zt - 3 * st), Math.abs(Pt) < 1e-12) {
                  if (Math.abs(w) < 1e-12)
                    continue;
                  H = -v / w, 0 < H && H < 1 && Dt.push(H);
                  continue;
                }
                bt = w * w - 4 * v * Pt, Et = Math.sqrt(bt), !(bt < 0) && (ot = (-w + Et) / (2 * Pt), 0 < ot && ot < 1 && Dt.push(ot), lt = (-w - Et) / (2 * Pt), 0 < lt && lt < 1 && Dt.push(lt));
              }
              let It = Dt.length, Mt;
              const xt = It;
              for (; It--; )
                H = Dt[It], Mt = 1 - H, Ot[0][It] = Mt * Mt * Mt * tt + 3 * Mt * Mt * H * kt + 3 * Mt * H * H * Gt + H * H * H * ft, Ot[1][It] = Mt * Mt * Mt * st + 3 * Mt * Mt * H * zt + 3 * Mt * H * H * L + H * H * H * Ct;
              return Ot[0][xt] = tt, Ot[1][xt] = st, Ot[0][xt + 1] = ft, Ot[1][xt + 1] = Ct, Ot[0].length = Ot[1].length = xt + 2, [Math.min(...Ot[0]), Math.min(...Ot[1]), Math.max(...Ot[0]), Math.max(...Ot[1])];
            }
          }
          h.Util = X;
          const J = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 728, 711, 710, 729, 733, 731, 730, 732, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8226, 8224, 8225, 8230, 8212, 8211, 402, 8260, 8249, 8250, 8722, 8240, 8222, 8220, 8221, 8216, 8217, 8218, 8482, 64257, 64258, 321, 338, 352, 376, 381, 305, 322, 339, 353, 382, 0, 8364];
          function ut(_t) {
            if (_t[0] >= "ï") {
              let st;
              if (_t[0] === "þ" && _t[1] === "ÿ" ? st = "utf-16be" : _t[0] === "ÿ" && _t[1] === "þ" ? st = "utf-16le" : _t[0] === "ï" && _t[1] === "»" && _t[2] === "¿" && (st = "utf-8"), st)
                try {
                  const kt = new TextDecoder(st, {
                    fatal: !0
                  }), zt = dt(_t);
                  return kt.decode(zt);
                } catch (kt) {
                  j(`stringToPDFString: "${kt}".`);
                }
            }
            const tt = [];
            for (let st = 0, kt = _t.length; st < kt; st++) {
              const zt = J[_t.charCodeAt(st)];
              tt.push(zt ? String.fromCharCode(zt) : _t.charAt(st));
            }
            return tt.join("");
          }
          function St(_t) {
            return decodeURIComponent(escape(_t));
          }
          function yt(_t) {
            return unescape(encodeURIComponent(_t));
          }
          function V(_t) {
            return typeof _t == "object" && (_t == null ? void 0 : _t.byteLength) !== void 0;
          }
          function Tt(_t, tt) {
            if (_t.length !== tt.length)
              return !1;
            for (let st = 0, kt = _t.length; st < kt; st++)
              if (_t[st] !== tt[st])
                return !1;
            return !0;
          }
          function wt(_t = /* @__PURE__ */ new Date()) {
            return [_t.getUTCFullYear().toString(), (_t.getUTCMonth() + 1).toString().padStart(2, "0"), _t.getUTCDate().toString().padStart(2, "0"), _t.getUTCHours().toString().padStart(2, "0"), _t.getUTCMinutes().toString().padStart(2, "0"), _t.getUTCSeconds().toString().padStart(2, "0")].join("");
          }
          class jt {
            constructor() {
              Q(this, $t, !1);
              this.promise = new Promise((tt, st) => {
                this.resolve = (kt) => {
                  et(this, $t, !0), tt(kt);
                }, this.reject = (kt) => {
                  et(this, $t, !0), st(kt);
                };
              });
            }
            get settled() {
              return t(this, $t);
            }
          }
          $t = new WeakMap(), h.PromiseCapability = jt;
          let Bt = null, Xt = null;
          function Ft(_t) {
            return Bt || (Bt = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, Xt = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), _t.replaceAll(Bt, (tt, st, kt) => st ? st.normalize("NFKC") : Xt.get(kt));
          }
          function Nt() {
            if (typeof crypto < "u" && typeof (crypto == null ? void 0 : crypto.randomUUID) == "function")
              return crypto.randomUUID();
            const _t = new Uint8Array(32);
            if (typeof crypto < "u" && typeof (crypto == null ? void 0 : crypto.getRandomValues) == "function")
              crypto.getRandomValues(_t);
            else
              for (let tt = 0; tt < 32; tt++)
                _t[tt] = Math.floor(Math.random() * 255);
            return ht(_t);
          }
          const Vt = "pdfjs_internal_id_";
          h.AnnotationPrefix = Vt;
        },
        /* 2 */
        /***/
        (__unused_webpack_module, exports, __w_pdfjs_require__) => {
          var pt, rt, o, T, re, _e, gt, B, M, m, N, I, _, b, E, Ae, d, p, De, y, n;
          Object.defineProperty(exports, "__esModule", {
            value: !0
          }), exports.RenderTask = exports.PDFWorkerUtil = exports.PDFWorker = exports.PDFPageProxy = exports.PDFDocumentProxy = exports.PDFDocumentLoadingTask = exports.PDFDataRangeTransport = exports.LoopbackPort = exports.DefaultStandardFontDataFactory = exports.DefaultFilterFactory = exports.DefaultCanvasFactory = exports.DefaultCMapReaderFactory = void 0, Object.defineProperty(exports, "SVGGraphics", {
            enumerable: !0,
            get: function() {
              return _displaySvg.SVGGraphics;
            }
          }), exports.build = void 0, exports.getDocument = getDocument, exports.version = void 0;
          var _util = __w_pdfjs_require__(1), _annotation_storage = __w_pdfjs_require__(3), _display_utils = __w_pdfjs_require__(6), _font_loader = __w_pdfjs_require__(9), _displayNode_utils = __w_pdfjs_require__(10), _canvas = __w_pdfjs_require__(11), _worker_options = __w_pdfjs_require__(14), _message_handler = __w_pdfjs_require__(15), _metadata = __w_pdfjs_require__(16), _optional_content_config = __w_pdfjs_require__(17), _transport_stream = __w_pdfjs_require__(18), _displayFetch_stream = __w_pdfjs_require__(19), _displayNetwork = __w_pdfjs_require__(22), _displayNode_stream = __w_pdfjs_require__(23), _displaySvg = __w_pdfjs_require__(24), _xfa_text = __w_pdfjs_require__(25);
          const DEFAULT_RANGE_CHUNK_SIZE = 65536, RENDERING_CANCELLED_TIMEOUT = 100, DELAYED_CLEANUP_TIMEOUT = 5e3, DefaultCanvasFactory = _util.isNodeJS ? _displayNode_utils.NodeCanvasFactory : _display_utils.DOMCanvasFactory;
          exports.DefaultCanvasFactory = DefaultCanvasFactory;
          const DefaultCMapReaderFactory = _util.isNodeJS ? _displayNode_utils.NodeCMapReaderFactory : _display_utils.DOMCMapReaderFactory;
          exports.DefaultCMapReaderFactory = DefaultCMapReaderFactory;
          const DefaultFilterFactory = _util.isNodeJS ? _displayNode_utils.NodeFilterFactory : _display_utils.DOMFilterFactory;
          exports.DefaultFilterFactory = DefaultFilterFactory;
          const DefaultStandardFontDataFactory = _util.isNodeJS ? _displayNode_utils.NodeStandardFontDataFactory : _display_utils.DOMStandardFontDataFactory;
          exports.DefaultStandardFontDataFactory = DefaultStandardFontDataFactory;
          function getDocument(s) {
            if (typeof s == "string" || s instanceof URL ? s = {
              url: s
            } : (0, _util.isArrayBuffer)(s) && (s = {
              data: s
            }), typeof s != "object")
              throw new Error("Invalid parameter in getDocument, need parameter object.");
            if (!s.url && !s.data && !s.range)
              throw new Error("Invalid parameter object: need either .data, .range or .url");
            const a = new PDFDocumentLoadingTask(), {
              docId: c
            } = a, O = s.url ? getUrlProp(s.url) : null, r = s.data ? getDataProp(s.data) : null, A = s.httpHeaders || null, F = s.withCredentials === !0, nt = s.password ?? null, W = s.range instanceof PDFDataRangeTransport ? s.range : null, $ = Number.isInteger(s.rangeChunkSize) && s.rangeChunkSize > 0 ? s.rangeChunkSize : DEFAULT_RANGE_CHUNK_SIZE;
            let j = s.worker instanceof PDFWorker ? s.worker : null;
            const at = s.verbosity, C = typeof s.docBaseUrl == "string" && !(0, _display_utils.isDataScheme)(s.docBaseUrl) ? s.docBaseUrl : null, U = typeof s.cMapUrl == "string" ? s.cMapUrl : null, Y = s.cMapPacked !== !1, S = s.CMapReaderFactory || DefaultCMapReaderFactory, e = typeof s.standardFontDataUrl == "string" ? s.standardFontDataUrl : null, i = s.StandardFontDataFactory || DefaultStandardFontDataFactory, u = s.stopAtErrors !== !0, x = Number.isInteger(s.maxImageSize) && s.maxImageSize > -1 ? s.maxImageSize : -1, P = s.isEvalSupported !== !1, k = typeof s.isOffscreenCanvasSupported == "boolean" ? s.isOffscreenCanvasSupported : !_util.isNodeJS, G = Number.isInteger(s.canvasMaxAreaInBytes) ? s.canvasMaxAreaInBytes : -1, it = typeof s.disableFontFace == "boolean" ? s.disableFontFace : _util.isNodeJS, ht = s.fontExtraProperties === !0, dt = s.enableXfa === !0, mt = s.ownerDocument || globalThis.document, At = s.disableRange === !0, vt = s.disableStream === !0, K = s.disableAutoFetch === !0, Z = s.pdfBug === !0, g = W ? W.length : s.length ?? NaN, R = typeof s.useSystemFonts == "boolean" ? s.useSystemFonts : !_util.isNodeJS && !it, X = typeof s.useWorkerFetch == "boolean" ? s.useWorkerFetch : S === _display_utils.DOMCMapReaderFactory && i === _display_utils.DOMStandardFontDataFactory && U && e && (0, _display_utils.isValidFetchUrl)(U, document.baseURI) && (0, _display_utils.isValidFetchUrl)(e, document.baseURI), J = s.canvasFactory || new DefaultCanvasFactory({
              ownerDocument: mt
            }), ut = s.filterFactory || new DefaultFilterFactory({
              docId: c,
              ownerDocument: mt
            }), St = null;
            (0, _util.setVerbosityLevel)(at);
            const yt = {
              canvasFactory: J,
              filterFactory: ut
            };
            if (X || (yt.cMapReaderFactory = new S({
              baseUrl: U,
              isCompressed: Y
            }), yt.standardFontDataFactory = new i({
              baseUrl: e
            })), !j) {
              const wt = {
                verbosity: at,
                port: _worker_options.GlobalWorkerOptions.workerPort
              };
              j = wt.port ? PDFWorker.fromPort(wt) : new PDFWorker(wt), a._worker = j;
            }
            const V = {
              docId: c,
              apiVersion: "3.11.174",
              data: r,
              password: nt,
              disableAutoFetch: K,
              rangeChunkSize: $,
              length: g,
              docBaseUrl: C,
              enableXfa: dt,
              evaluatorOptions: {
                maxImageSize: x,
                disableFontFace: it,
                ignoreErrors: u,
                isEvalSupported: P,
                isOffscreenCanvasSupported: k,
                canvasMaxAreaInBytes: G,
                fontExtraProperties: ht,
                useSystemFonts: R,
                cMapUrl: X ? U : null,
                standardFontDataUrl: X ? e : null
              }
            }, Tt = {
              ignoreErrors: u,
              isEvalSupported: P,
              disableFontFace: it,
              fontExtraProperties: ht,
              enableXfa: dt,
              ownerDocument: mt,
              disableAutoFetch: K,
              pdfBug: Z,
              styleElement: St
            };
            return j.promise.then(function() {
              if (a.destroyed)
                throw new Error("Loading aborted");
              const wt = _fetchDocument(j, V), jt = new Promise(function(Bt) {
                let Xt;
                W ? Xt = new _transport_stream.PDFDataTransportStream({
                  length: g,
                  initialData: W.initialData,
                  progressiveDone: W.progressiveDone,
                  contentDispositionFilename: W.contentDispositionFilename,
                  disableRange: At,
                  disableStream: vt
                }, W) : r || (Xt = ((Nt) => _util.isNodeJS ? new _displayNode_stream.PDFNodeStream(Nt) : (0, _display_utils.isValidFetchUrl)(Nt.url) ? new _displayFetch_stream.PDFFetchStream(Nt) : new _displayNetwork.PDFNetworkStream(Nt))({
                  url: O,
                  length: g,
                  httpHeaders: A,
                  withCredentials: F,
                  rangeChunkSize: $,
                  disableRange: At,
                  disableStream: vt
                })), Bt(Xt);
              });
              return Promise.all([wt, jt]).then(function([Bt, Xt]) {
                if (a.destroyed)
                  throw new Error("Loading aborted");
                const Ft = new _message_handler.MessageHandler(c, Bt, j.port), Nt = new WorkerTransport(Ft, a, Xt, Tt, yt);
                a._transport = Nt, Ft.send("Ready", null);
              });
            }).catch(a._capability.reject), a;
          }
          async function _fetchDocument(s, a) {
            if (s.destroyed)
              throw new Error("Worker was destroyed");
            const c = await s.messageHandler.sendWithPromise("GetDocRequest", a, a.data ? [a.data.buffer] : null);
            if (s.destroyed)
              throw new Error("Worker was destroyed");
            return c;
          }
          function getUrlProp(s) {
            if (s instanceof URL)
              return s.href;
            try {
              return new URL(s, window.location).href;
            } catch {
              if (_util.isNodeJS && typeof s == "string")
                return s;
            }
            throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
          }
          function getDataProp(s) {
            if (_util.isNodeJS && typeof Buffer < "u" && s instanceof Buffer)
              throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
            if (s instanceof Uint8Array && s.byteLength === s.buffer.byteLength)
              return s;
            if (typeof s == "string")
              return (0, _util.stringToBytes)(s);
            if (typeof s == "object" && !isNaN(s == null ? void 0 : s.length) || (0, _util.isArrayBuffer)(s))
              return new Uint8Array(s);
            throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
          }
          const h = class h {
            constructor() {
              this._capability = new _util.PromiseCapability(), this._transport = null, this._worker = null, this.docId = `d${he(h, pt)._++}`, this.destroyed = !1, this.onPassword = null, this.onProgress = null;
            }
            get promise() {
              return this._capability.promise;
            }
            async destroy() {
              var a, c, O;
              this.destroyed = !0;
              try {
                (a = this._worker) != null && a.port && (this._worker._pendingDestroy = !0), await ((c = this._transport) == null ? void 0 : c.destroy());
              } catch (r) {
                throw (O = this._worker) != null && O.port && delete this._worker._pendingDestroy, r;
              }
              this._transport = null, this._worker && (this._worker.destroy(), this._worker = null);
            }
          };
          pt = new WeakMap(), Q(h, pt, 0);
          let PDFDocumentLoadingTask = h;
          exports.PDFDocumentLoadingTask = PDFDocumentLoadingTask;
          class PDFDataRangeTransport {
            constructor(a, c, O = !1, r = null) {
              this.length = a, this.initialData = c, this.progressiveDone = O, this.contentDispositionFilename = r, this._rangeListeners = [], this._progressListeners = [], this._progressiveReadListeners = [], this._progressiveDoneListeners = [], this._readyCapability = new _util.PromiseCapability();
            }
            addRangeListener(a) {
              this._rangeListeners.push(a);
            }
            addProgressListener(a) {
              this._progressListeners.push(a);
            }
            addProgressiveReadListener(a) {
              this._progressiveReadListeners.push(a);
            }
            addProgressiveDoneListener(a) {
              this._progressiveDoneListeners.push(a);
            }
            onDataRange(a, c) {
              for (const O of this._rangeListeners)
                O(a, c);
            }
            onDataProgress(a, c) {
              this._readyCapability.promise.then(() => {
                for (const O of this._progressListeners)
                  O(a, c);
              });
            }
            onDataProgressiveRead(a) {
              this._readyCapability.promise.then(() => {
                for (const c of this._progressiveReadListeners)
                  c(a);
              });
            }
            onDataProgressiveDone() {
              this._readyCapability.promise.then(() => {
                for (const a of this._progressiveDoneListeners)
                  a();
              });
            }
            transportReady() {
              this._readyCapability.resolve();
            }
            requestDataRange(a, c) {
              (0, _util.unreachable)("Abstract method PDFDataRangeTransport.requestDataRange");
            }
            abort() {
            }
          }
          exports.PDFDataRangeTransport = PDFDataRangeTransport;
          class PDFDocumentProxy {
            constructor(a, c) {
              this._pdfInfo = a, this._transport = c, Object.defineProperty(this, "getJavaScript", {
                value: () => ((0, _display_utils.deprecated)("`PDFDocumentProxy.getJavaScript`, please use `PDFDocumentProxy.getJSActions` instead."), this.getJSActions().then((O) => {
                  if (!O)
                    return O;
                  const r = [];
                  for (const A in O)
                    r.push(...O[A]);
                  return r;
                }))
              });
            }
            get annotationStorage() {
              return this._transport.annotationStorage;
            }
            get filterFactory() {
              return this._transport.filterFactory;
            }
            get numPages() {
              return this._pdfInfo.numPages;
            }
            get fingerprints() {
              return this._pdfInfo.fingerprints;
            }
            get isPureXfa() {
              return (0, _util.shadow)(this, "isPureXfa", !!this._transport._htmlForXfa);
            }
            get allXfaHtml() {
              return this._transport._htmlForXfa;
            }
            getPage(a) {
              return this._transport.getPage(a);
            }
            getPageIndex(a) {
              return this._transport.getPageIndex(a);
            }
            getDestinations() {
              return this._transport.getDestinations();
            }
            getDestination(a) {
              return this._transport.getDestination(a);
            }
            getPageLabels() {
              return this._transport.getPageLabels();
            }
            getPageLayout() {
              return this._transport.getPageLayout();
            }
            getPageMode() {
              return this._transport.getPageMode();
            }
            getViewerPreferences() {
              return this._transport.getViewerPreferences();
            }
            getOpenAction() {
              return this._transport.getOpenAction();
            }
            getAttachments() {
              return this._transport.getAttachments();
            }
            getJSActions() {
              return this._transport.getDocJSActions();
            }
            getOutline() {
              return this._transport.getOutline();
            }
            getOptionalContentConfig() {
              return this._transport.getOptionalContentConfig();
            }
            getPermissions() {
              return this._transport.getPermissions();
            }
            getMetadata() {
              return this._transport.getMetadata();
            }
            getMarkInfo() {
              return this._transport.getMarkInfo();
            }
            getData() {
              return this._transport.getData();
            }
            saveDocument() {
              return this._transport.saveDocument();
            }
            getDownloadInfo() {
              return this._transport.downloadInfoCapability.promise;
            }
            cleanup(a = !1) {
              return this._transport.startCleanup(a || this.isPureXfa);
            }
            destroy() {
              return this.loadingTask.destroy();
            }
            get loadingParams() {
              return this._transport.loadingParams;
            }
            get loadingTask() {
              return this._transport.loadingTask;
            }
            getFieldObjects() {
              return this._transport.getFieldObjects();
            }
            hasJSActions() {
              return this._transport.hasJSActions();
            }
            getCalculationOrderIds() {
              return this._transport.getCalculationOrderIds();
            }
          }
          exports.PDFDocumentProxy = PDFDocumentProxy;
          class PDFPageProxy {
            constructor(a, c, O, r = !1) {
              Q(this, T);
              Q(this, rt, null);
              Q(this, o, !1);
              this._pageIndex = a, this._pageInfo = c, this._transport = O, this._stats = r ? new _display_utils.StatTimer() : null, this._pdfBug = r, this.commonObjs = O.commonObjs, this.objs = new PDFObjects(), this._maybeCleanupAfterRender = !1, this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1;
            }
            get pageNumber() {
              return this._pageIndex + 1;
            }
            get rotate() {
              return this._pageInfo.rotate;
            }
            get ref() {
              return this._pageInfo.ref;
            }
            get userUnit() {
              return this._pageInfo.userUnit;
            }
            get view() {
              return this._pageInfo.view;
            }
            getViewport({
              scale: a,
              rotation: c = this.rotate,
              offsetX: O = 0,
              offsetY: r = 0,
              dontFlip: A = !1
            } = {}) {
              return new _display_utils.PageViewport({
                viewBox: this.view,
                scale: a,
                rotation: c,
                offsetX: O,
                offsetY: r,
                dontFlip: A
              });
            }
            getAnnotations({
              intent: a = "display"
            } = {}) {
              const c = this._transport.getRenderingIntent(a);
              return this._transport.getAnnotations(this._pageIndex, c.renderingIntent);
            }
            getJSActions() {
              return this._transport.getPageJSActions(this._pageIndex);
            }
            get filterFactory() {
              return this._transport.filterFactory;
            }
            get isPureXfa() {
              return (0, _util.shadow)(this, "isPureXfa", !!this._transport._htmlForXfa);
            }
            async getXfa() {
              var a;
              return ((a = this._transport._htmlForXfa) == null ? void 0 : a.children[this._pageIndex]) || null;
            }
            render({
              canvasContext: a,
              viewport: c,
              intent: O = "display",
              annotationMode: r = _util.AnnotationMode.ENABLE,
              transform: A = null,
              background: F = null,
              optionalContentConfigPromise: nt = null,
              annotationCanvasMap: W = null,
              pageColors: $ = null,
              printAnnotationStorage: j = null
            }) {
              var i, u;
              (i = this._stats) == null || i.time("Overall");
              const at = this._transport.getRenderingIntent(O, r, j);
              et(this, o, !1), z(this, T, _e).call(this), nt || (nt = this._transport.getOptionalContentConfig());
              let C = this._intentStates.get(at.cacheKey);
              C || (C = /* @__PURE__ */ Object.create(null), this._intentStates.set(at.cacheKey, C)), C.streamReaderCancelTimeout && (clearTimeout(C.streamReaderCancelTimeout), C.streamReaderCancelTimeout = null);
              const U = !!(at.renderingIntent & _util.RenderingIntentFlag.PRINT);
              C.displayReadyCapability || (C.displayReadyCapability = new _util.PromiseCapability(), C.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
              }, (u = this._stats) == null || u.time("Page Request"), this._pumpOperatorList(at));
              const Y = (x) => {
                var P, k;
                C.renderTasks.delete(S), (this._maybeCleanupAfterRender || U) && et(this, o, !0), z(this, T, re).call(this, !U), x ? (S.capability.reject(x), this._abortOperatorList({
                  intentState: C,
                  reason: x instanceof Error ? x : new Error(x)
                })) : S.capability.resolve(), (P = this._stats) == null || P.timeEnd("Rendering"), (k = this._stats) == null || k.timeEnd("Overall");
              }, S = new InternalRenderTask({
                callback: Y,
                params: {
                  canvasContext: a,
                  viewport: c,
                  transform: A,
                  background: F
                },
                objs: this.objs,
                commonObjs: this.commonObjs,
                annotationCanvasMap: W,
                operatorList: C.operatorList,
                pageIndex: this._pageIndex,
                canvasFactory: this._transport.canvasFactory,
                filterFactory: this._transport.filterFactory,
                useRequestAnimationFrame: !U,
                pdfBug: this._pdfBug,
                pageColors: $
              });
              (C.renderTasks || (C.renderTasks = /* @__PURE__ */ new Set())).add(S);
              const e = S.task;
              return Promise.all([C.displayReadyCapability.promise, nt]).then(([x, P]) => {
                var k;
                if (this.destroyed) {
                  Y();
                  return;
                }
                (k = this._stats) == null || k.time("Rendering"), S.initializeGraphics({
                  transparency: x,
                  optionalContentConfig: P
                }), S.operatorListChanged();
              }).catch(Y), e;
            }
            getOperatorList({
              intent: a = "display",
              annotationMode: c = _util.AnnotationMode.ENABLE,
              printAnnotationStorage: O = null
            } = {}) {
              var W;
              function r() {
                F.operatorList.lastChunk && (F.opListReadCapability.resolve(F.operatorList), F.renderTasks.delete(nt));
              }
              const A = this._transport.getRenderingIntent(a, c, O, !0);
              let F = this._intentStates.get(A.cacheKey);
              F || (F = /* @__PURE__ */ Object.create(null), this._intentStates.set(A.cacheKey, F));
              let nt;
              return F.opListReadCapability || (nt = /* @__PURE__ */ Object.create(null), nt.operatorListChanged = r, F.opListReadCapability = new _util.PromiseCapability(), (F.renderTasks || (F.renderTasks = /* @__PURE__ */ new Set())).add(nt), F.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
              }, (W = this._stats) == null || W.time("Page Request"), this._pumpOperatorList(A)), F.opListReadCapability.promise;
            }
            streamTextContent({
              includeMarkedContent: a = !1,
              disableNormalization: c = !1
            } = {}) {
              return this._transport.messageHandler.sendWithStream("GetTextContent", {
                pageIndex: this._pageIndex,
                includeMarkedContent: a === !0,
                disableNormalization: c === !0
              }, {
                highWaterMark: 100,
                size(r) {
                  return r.items.length;
                }
              });
            }
            getTextContent(a = {}) {
              if (this._transport._htmlForXfa)
                return this.getXfa().then((O) => _xfa_text.XfaText.textContent(O));
              const c = this.streamTextContent(a);
              return new Promise(function(O, r) {
                function A() {
                  F.read().then(function({
                    value: W,
                    done: $
                  }) {
                    if ($) {
                      O(nt);
                      return;
                    }
                    Object.assign(nt.styles, W.styles), nt.items.push(...W.items), A();
                  }, r);
                }
                const F = c.getReader(), nt = {
                  items: [],
                  styles: /* @__PURE__ */ Object.create(null)
                };
                A();
              });
            }
            getStructTree() {
              return this._transport.getStructTree(this._pageIndex);
            }
            _destroy() {
              this.destroyed = !0;
              const a = [];
              for (const c of this._intentStates.values())
                if (this._abortOperatorList({
                  intentState: c,
                  reason: new Error("Page was destroyed."),
                  force: !0
                }), !c.opListReadCapability)
                  for (const O of c.renderTasks)
                    a.push(O.completed), O.cancel();
              return this.objs.clear(), et(this, o, !1), z(this, T, _e).call(this), Promise.all(a);
            }
            cleanup(a = !1) {
              et(this, o, !0);
              const c = z(this, T, re).call(this, !1);
              return a && c && this._stats && (this._stats = new _display_utils.StatTimer()), c;
            }
            _startRenderPage(a, c) {
              var r, A;
              const O = this._intentStates.get(c);
              O && ((r = this._stats) == null || r.timeEnd("Page Request"), (A = O.displayReadyCapability) == null || A.resolve(a));
            }
            _renderPageChunk(a, c) {
              for (let O = 0, r = a.length; O < r; O++)
                c.operatorList.fnArray.push(a.fnArray[O]), c.operatorList.argsArray.push(a.argsArray[O]);
              c.operatorList.lastChunk = a.lastChunk, c.operatorList.separateAnnots = a.separateAnnots;
              for (const O of c.renderTasks)
                O.operatorListChanged();
              a.lastChunk && z(this, T, re).call(this, !0);
            }
            _pumpOperatorList({
              renderingIntent: a,
              cacheKey: c,
              annotationStorageSerializable: O
            }) {
              const {
                map: r,
                transfers: A
              } = O, nt = this._transport.messageHandler.sendWithStream("GetOperatorList", {
                pageIndex: this._pageIndex,
                intent: a,
                cacheKey: c,
                annotationStorage: r
              }, A).getReader(), W = this._intentStates.get(c);
              W.streamReader = nt;
              const $ = () => {
                nt.read().then(({
                  value: j,
                  done: at
                }) => {
                  if (at) {
                    W.streamReader = null;
                    return;
                  }
                  this._transport.destroyed || (this._renderPageChunk(j, W), $());
                }, (j) => {
                  if (W.streamReader = null, !this._transport.destroyed) {
                    if (W.operatorList) {
                      W.operatorList.lastChunk = !0;
                      for (const at of W.renderTasks)
                        at.operatorListChanged();
                      z(this, T, re).call(this, !0);
                    }
                    if (W.displayReadyCapability)
                      W.displayReadyCapability.reject(j);
                    else if (W.opListReadCapability)
                      W.opListReadCapability.reject(j);
                    else
                      throw j;
                  }
                });
              };
              $();
            }
            _abortOperatorList({
              intentState: a,
              reason: c,
              force: O = !1
            }) {
              if (a.streamReader) {
                if (a.streamReaderCancelTimeout && (clearTimeout(a.streamReaderCancelTimeout), a.streamReaderCancelTimeout = null), !O) {
                  if (a.renderTasks.size > 0)
                    return;
                  if (c instanceof _display_utils.RenderingCancelledException) {
                    let r = RENDERING_CANCELLED_TIMEOUT;
                    c.extraDelay > 0 && c.extraDelay < 1e3 && (r += c.extraDelay), a.streamReaderCancelTimeout = setTimeout(() => {
                      a.streamReaderCancelTimeout = null, this._abortOperatorList({
                        intentState: a,
                        reason: c,
                        force: !0
                      });
                    }, r);
                    return;
                  }
                }
                if (a.streamReader.cancel(new _util.AbortException(c.message)).catch(() => {
                }), a.streamReader = null, !this._transport.destroyed) {
                  for (const [r, A] of this._intentStates)
                    if (A === a) {
                      this._intentStates.delete(r);
                      break;
                    }
                  this.cleanup();
                }
              }
            }
            get stats() {
              return this._stats;
            }
          }
          rt = new WeakMap(), o = new WeakMap(), T = new WeakSet(), re = function(a = !1) {
            if (z(this, T, _e).call(this), !t(this, o) || this.destroyed)
              return !1;
            if (a)
              return et(this, rt, setTimeout(() => {
                et(this, rt, null), z(this, T, re).call(this, !1);
              }, DELAYED_CLEANUP_TIMEOUT)), !1;
            for (const {
              renderTasks: c,
              operatorList: O
            } of this._intentStates.values())
              if (c.size > 0 || !O.lastChunk)
                return !1;
            return this._intentStates.clear(), this.objs.clear(), et(this, o, !1), !0;
          }, _e = function() {
            t(this, rt) && (clearTimeout(t(this, rt)), et(this, rt, null));
          }, exports.PDFPageProxy = PDFPageProxy;
          class LoopbackPort {
            constructor() {
              Q(this, gt, /* @__PURE__ */ new Set());
              Q(this, B, Promise.resolve());
            }
            postMessage(a, c) {
              const O = {
                data: structuredClone(a, c ? {
                  transfer: c
                } : null)
              };
              t(this, B).then(() => {
                for (const r of t(this, gt))
                  r.call(this, O);
              });
            }
            addEventListener(a, c) {
              t(this, gt).add(c);
            }
            removeEventListener(a, c) {
              t(this, gt).delete(c);
            }
            terminate() {
              t(this, gt).clear();
            }
          }
          gt = new WeakMap(), B = new WeakMap(), exports.LoopbackPort = LoopbackPort;
          const PDFWorkerUtil = {
            isWorkerDisabled: !1,
            fallbackWorkerSrc: null,
            fakeWorkerId: 0
          };
          exports.PDFWorkerUtil = PDFWorkerUtil;
          {
            if (_util.isNodeJS && typeof commonjsRequire == "function")
              PDFWorkerUtil.isWorkerDisabled = !0, PDFWorkerUtil.fallbackWorkerSrc = "./pdf.worker.js";
            else if (typeof document == "object") {
              const s = (M = document == null ? void 0 : document.currentScript) == null ? void 0 : M.src;
              s && (PDFWorkerUtil.fallbackWorkerSrc = s.replace(/(\.(?:min\.)?js)(\?.*)?$/i, ".worker$1$2"));
            }
            PDFWorkerUtil.isSameOrigin = function(s, a) {
              let c;
              try {
                if (c = new URL(s), !c.origin || c.origin === "null")
                  return !1;
              } catch {
                return !1;
              }
              const O = new URL(a, c);
              return c.origin === O.origin;
            }, PDFWorkerUtil.createCDNWrapper = function(s) {
              const a = `importScripts("${s}");`;
              return URL.createObjectURL(new Blob([a]));
            };
          }
          const _PDFWorker = class _PDFWorker {
            constructor({
              name: s = null,
              port: a = null,
              verbosity: c = (0, _util.getVerbosityLevel)()
            } = {}) {
              var O;
              if (this.name = s, this.destroyed = !1, this.verbosity = c, this._readyCapability = new _util.PromiseCapability(), this._port = null, this._webWorker = null, this._messageHandler = null, a) {
                if ((O = t(_PDFWorker, m)) != null && O.has(a))
                  throw new Error("Cannot use more than one PDFWorker per port.");
                (t(_PDFWorker, m) || et(_PDFWorker, m, /* @__PURE__ */ new WeakMap())).set(a, this), this._initializeFromPort(a);
                return;
              }
              this._initialize();
            }
            get promise() {
              return this._readyCapability.promise;
            }
            get port() {
              return this._port;
            }
            get messageHandler() {
              return this._messageHandler;
            }
            _initializeFromPort(s) {
              this._port = s, this._messageHandler = new _message_handler.MessageHandler("main", "worker", s), this._messageHandler.on("ready", function() {
              }), this._readyCapability.resolve(), this._messageHandler.send("configure", {
                verbosity: this.verbosity
              });
            }
            _initialize() {
              if (!PDFWorkerUtil.isWorkerDisabled && !_PDFWorker._mainThreadWorkerMessageHandler) {
                let {
                  workerSrc: s
                } = _PDFWorker;
                try {
                  PDFWorkerUtil.isSameOrigin(window.location.href, s) || (s = PDFWorkerUtil.createCDNWrapper(new URL(s, window.location).href));
                  const a = new Worker(s), c = new _message_handler.MessageHandler("main", "worker", a), O = () => {
                    a.removeEventListener("error", r), c.destroy(), a.terminate(), this.destroyed ? this._readyCapability.reject(new Error("Worker was destroyed")) : this._setupFakeWorker();
                  }, r = () => {
                    this._webWorker || O();
                  };
                  a.addEventListener("error", r), c.on("test", (F) => {
                    if (a.removeEventListener("error", r), this.destroyed) {
                      O();
                      return;
                    }
                    F ? (this._messageHandler = c, this._port = a, this._webWorker = a, this._readyCapability.resolve(), c.send("configure", {
                      verbosity: this.verbosity
                    })) : (this._setupFakeWorker(), c.destroy(), a.terminate());
                  }), c.on("ready", (F) => {
                    if (a.removeEventListener("error", r), this.destroyed) {
                      O();
                      return;
                    }
                    try {
                      A();
                    } catch {
                      this._setupFakeWorker();
                    }
                  });
                  const A = () => {
                    const F = new Uint8Array();
                    c.send("test", F, [F.buffer]);
                  };
                  A();
                  return;
                } catch {
                  (0, _util.info)("The worker has been disabled.");
                }
              }
              this._setupFakeWorker();
            }
            _setupFakeWorker() {
              PDFWorkerUtil.isWorkerDisabled || ((0, _util.warn)("Setting up fake worker."), PDFWorkerUtil.isWorkerDisabled = !0), _PDFWorker._setupFakeWorkerGlobal.then((s) => {
                if (this.destroyed) {
                  this._readyCapability.reject(new Error("Worker was destroyed"));
                  return;
                }
                const a = new LoopbackPort();
                this._port = a;
                const c = `fake${PDFWorkerUtil.fakeWorkerId++}`, O = new _message_handler.MessageHandler(c + "_worker", c, a);
                s.setup(O, a);
                const r = new _message_handler.MessageHandler(c, c + "_worker", a);
                this._messageHandler = r, this._readyCapability.resolve(), r.send("configure", {
                  verbosity: this.verbosity
                });
              }).catch((s) => {
                this._readyCapability.reject(new Error(`Setting up fake worker failed: "${s.message}".`));
              });
            }
            destroy() {
              var s;
              this.destroyed = !0, this._webWorker && (this._webWorker.terminate(), this._webWorker = null), (s = t(_PDFWorker, m)) == null || s.delete(this._port), this._port = null, this._messageHandler && (this._messageHandler.destroy(), this._messageHandler = null);
            }
            static fromPort(s) {
              var c;
              if (!(s != null && s.port))
                throw new Error("PDFWorker.fromPort - invalid method signature.");
              const a = (c = t(this, m)) == null ? void 0 : c.get(s.port);
              if (a) {
                if (a._pendingDestroy)
                  throw new Error("PDFWorker.fromPort - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
                return a;
              }
              return new _PDFWorker(s);
            }
            static get workerSrc() {
              if (_worker_options.GlobalWorkerOptions.workerSrc)
                return _worker_options.GlobalWorkerOptions.workerSrc;
              if (PDFWorkerUtil.fallbackWorkerSrc !== null)
                return _util.isNodeJS || (0, _display_utils.deprecated)('No "GlobalWorkerOptions.workerSrc" specified.'), PDFWorkerUtil.fallbackWorkerSrc;
              throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
            }
            static get _mainThreadWorkerMessageHandler() {
              var s;
              try {
                return ((s = globalThis.pdfjsWorker) == null ? void 0 : s.WorkerMessageHandler) || null;
              } catch {
                return null;
              }
            }
            static get _setupFakeWorkerGlobal() {
              const loader = async () => {
                const mainWorkerMessageHandler = this._mainThreadWorkerMessageHandler;
                if (mainWorkerMessageHandler)
                  return mainWorkerMessageHandler;
                if (_util.isNodeJS && typeof commonjsRequire == "function") {
                  const worker = eval("require")(this.workerSrc);
                  return worker.WorkerMessageHandler;
                }
                return await (0, _display_utils.loadScript)(this.workerSrc), window.pdfjsWorker.WorkerMessageHandler;
              };
              return (0, _util.shadow)(this, "_setupFakeWorkerGlobal", loader());
            }
          };
          m = new WeakMap(), Q(_PDFWorker, m);
          let PDFWorker = _PDFWorker;
          exports.PDFWorker = PDFWorker;
          class WorkerTransport {
            constructor(a, c, O, r, A) {
              Q(this, E);
              Q(this, N, /* @__PURE__ */ new Map());
              Q(this, I, /* @__PURE__ */ new Map());
              Q(this, _, /* @__PURE__ */ new Map());
              Q(this, b, null);
              this.messageHandler = a, this.loadingTask = c, this.commonObjs = new PDFObjects(), this.fontLoader = new _font_loader.FontLoader({
                ownerDocument: r.ownerDocument,
                styleElement: r.styleElement
              }), this._params = r, this.canvasFactory = A.canvasFactory, this.filterFactory = A.filterFactory, this.cMapReaderFactory = A.cMapReaderFactory, this.standardFontDataFactory = A.standardFontDataFactory, this.destroyed = !1, this.destroyCapability = null, this._networkStream = O, this._fullReader = null, this._lastProgress = null, this.downloadInfoCapability = new _util.PromiseCapability(), this.setupMessageHandler();
            }
            get annotationStorage() {
              return (0, _util.shadow)(this, "annotationStorage", new _annotation_storage.AnnotationStorage());
            }
            getRenderingIntent(a, c = _util.AnnotationMode.ENABLE, O = null, r = !1) {
              let A = _util.RenderingIntentFlag.DISPLAY, F = _annotation_storage.SerializableEmpty;
              switch (a) {
                case "any":
                  A = _util.RenderingIntentFlag.ANY;
                  break;
                case "display":
                  break;
                case "print":
                  A = _util.RenderingIntentFlag.PRINT;
                  break;
                default:
                  (0, _util.warn)(`getRenderingIntent - invalid intent: ${a}`);
              }
              switch (c) {
                case _util.AnnotationMode.DISABLE:
                  A += _util.RenderingIntentFlag.ANNOTATIONS_DISABLE;
                  break;
                case _util.AnnotationMode.ENABLE:
                  break;
                case _util.AnnotationMode.ENABLE_FORMS:
                  A += _util.RenderingIntentFlag.ANNOTATIONS_FORMS;
                  break;
                case _util.AnnotationMode.ENABLE_STORAGE:
                  A += _util.RenderingIntentFlag.ANNOTATIONS_STORAGE, F = (A & _util.RenderingIntentFlag.PRINT && O instanceof _annotation_storage.PrintAnnotationStorage ? O : this.annotationStorage).serializable;
                  break;
                default:
                  (0, _util.warn)(`getRenderingIntent - invalid annotationMode: ${c}`);
              }
              return r && (A += _util.RenderingIntentFlag.OPLIST), {
                renderingIntent: A,
                cacheKey: `${A}_${F.hash}`,
                annotationStorageSerializable: F
              };
            }
            destroy() {
              var O;
              if (this.destroyCapability)
                return this.destroyCapability.promise;
              this.destroyed = !0, this.destroyCapability = new _util.PromiseCapability(), (O = t(this, b)) == null || O.reject(new Error("Worker was destroyed during onPassword callback"));
              const a = [];
              for (const r of t(this, I).values())
                a.push(r._destroy());
              t(this, I).clear(), t(this, _).clear(), this.hasOwnProperty("annotationStorage") && this.annotationStorage.resetModified();
              const c = this.messageHandler.sendWithPromise("Terminate", null);
              return a.push(c), Promise.all(a).then(() => {
                var r;
                this.commonObjs.clear(), this.fontLoader.clear(), t(this, N).clear(), this.filterFactory.destroy(), (r = this._networkStream) == null || r.cancelAllRequests(new _util.AbortException("Worker was terminated.")), this.messageHandler && (this.messageHandler.destroy(), this.messageHandler = null), this.destroyCapability.resolve();
              }, this.destroyCapability.reject), this.destroyCapability.promise;
            }
            setupMessageHandler() {
              const {
                messageHandler: a,
                loadingTask: c
              } = this;
              a.on("GetReader", (O, r) => {
                (0, _util.assert)(this._networkStream, "GetReader - no `IPDFStream` instance available."), this._fullReader = this._networkStream.getFullReader(), this._fullReader.onProgress = (A) => {
                  this._lastProgress = {
                    loaded: A.loaded,
                    total: A.total
                  };
                }, r.onPull = () => {
                  this._fullReader.read().then(function({
                    value: A,
                    done: F
                  }) {
                    if (F) {
                      r.close();
                      return;
                    }
                    (0, _util.assert)(A instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), r.enqueue(new Uint8Array(A), 1, [A]);
                  }).catch((A) => {
                    r.error(A);
                  });
                }, r.onCancel = (A) => {
                  this._fullReader.cancel(A), r.ready.catch((F) => {
                    if (!this.destroyed)
                      throw F;
                  });
                };
              }), a.on("ReaderHeadersReady", (O) => {
                const r = new _util.PromiseCapability(), A = this._fullReader;
                return A.headersReady.then(() => {
                  var F;
                  (!A.isStreamingSupported || !A.isRangeSupported) && (this._lastProgress && ((F = c.onProgress) == null || F.call(c, this._lastProgress)), A.onProgress = (nt) => {
                    var W;
                    (W = c.onProgress) == null || W.call(c, {
                      loaded: nt.loaded,
                      total: nt.total
                    });
                  }), r.resolve({
                    isStreamingSupported: A.isStreamingSupported,
                    isRangeSupported: A.isRangeSupported,
                    contentLength: A.contentLength
                  });
                }, r.reject), r.promise;
              }), a.on("GetRangeReader", (O, r) => {
                (0, _util.assert)(this._networkStream, "GetRangeReader - no `IPDFStream` instance available.");
                const A = this._networkStream.getRangeReader(O.begin, O.end);
                if (!A) {
                  r.close();
                  return;
                }
                r.onPull = () => {
                  A.read().then(function({
                    value: F,
                    done: nt
                  }) {
                    if (nt) {
                      r.close();
                      return;
                    }
                    (0, _util.assert)(F instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), r.enqueue(new Uint8Array(F), 1, [F]);
                  }).catch((F) => {
                    r.error(F);
                  });
                }, r.onCancel = (F) => {
                  A.cancel(F), r.ready.catch((nt) => {
                    if (!this.destroyed)
                      throw nt;
                  });
                };
              }), a.on("GetDoc", ({
                pdfInfo: O
              }) => {
                this._numPages = O.numPages, this._htmlForXfa = O.htmlForXfa, delete O.htmlForXfa, c._capability.resolve(new PDFDocumentProxy(O, this));
              }), a.on("DocException", function(O) {
                let r;
                switch (O.name) {
                  case "PasswordException":
                    r = new _util.PasswordException(O.message, O.code);
                    break;
                  case "InvalidPDFException":
                    r = new _util.InvalidPDFException(O.message);
                    break;
                  case "MissingPDFException":
                    r = new _util.MissingPDFException(O.message);
                    break;
                  case "UnexpectedResponseException":
                    r = new _util.UnexpectedResponseException(O.message, O.status);
                    break;
                  case "UnknownErrorException":
                    r = new _util.UnknownErrorException(O.message, O.details);
                    break;
                  default:
                    (0, _util.unreachable)("DocException - expected a valid Error.");
                }
                c._capability.reject(r);
              }), a.on("PasswordRequest", (O) => {
                if (et(this, b, new _util.PromiseCapability()), c.onPassword) {
                  const r = (A) => {
                    A instanceof Error ? t(this, b).reject(A) : t(this, b).resolve({
                      password: A
                    });
                  };
                  try {
                    c.onPassword(r, O.code);
                  } catch (A) {
                    t(this, b).reject(A);
                  }
                } else
                  t(this, b).reject(new _util.PasswordException(O.message, O.code));
                return t(this, b).promise;
              }), a.on("DataLoaded", (O) => {
                var r;
                (r = c.onProgress) == null || r.call(c, {
                  loaded: O.length,
                  total: O.length
                }), this.downloadInfoCapability.resolve(O);
              }), a.on("StartRenderPage", (O) => {
                if (this.destroyed)
                  return;
                t(this, I).get(O.pageIndex)._startRenderPage(O.transparency, O.cacheKey);
              }), a.on("commonobj", ([O, r, A]) => {
                var F;
                if (!this.destroyed && !this.commonObjs.has(O))
                  switch (r) {
                    case "Font":
                      const nt = this._params;
                      if ("error" in A) {
                        const j = A.error;
                        (0, _util.warn)(`Error during font loading: ${j}`), this.commonObjs.resolve(O, j);
                        break;
                      }
                      const W = nt.pdfBug && ((F = globalThis.FontInspector) != null && F.enabled) ? (j, at) => globalThis.FontInspector.fontAdded(j, at) : null, $ = new _font_loader.FontFaceObject(A, {
                        isEvalSupported: nt.isEvalSupported,
                        disableFontFace: nt.disableFontFace,
                        ignoreErrors: nt.ignoreErrors,
                        inspectFont: W
                      });
                      this.fontLoader.bind($).catch((j) => a.sendWithPromise("FontFallback", {
                        id: O
                      })).finally(() => {
                        !nt.fontExtraProperties && $.data && ($.data = null), this.commonObjs.resolve(O, $);
                      });
                      break;
                    case "FontPath":
                    case "Image":
                    case "Pattern":
                      this.commonObjs.resolve(O, A);
                      break;
                    default:
                      throw new Error(`Got unknown common object type ${r}`);
                  }
              }), a.on("obj", ([O, r, A, F]) => {
                var W;
                if (this.destroyed)
                  return;
                const nt = t(this, I).get(r);
                if (!nt.objs.has(O))
                  switch (A) {
                    case "Image":
                      if (nt.objs.resolve(O, F), F) {
                        let $;
                        if (F.bitmap) {
                          const {
                            width: j,
                            height: at
                          } = F;
                          $ = j * at * 4;
                        } else
                          $ = ((W = F.data) == null ? void 0 : W.length) || 0;
                        $ > _util.MAX_IMAGE_SIZE_TO_CACHE && (nt._maybeCleanupAfterRender = !0);
                      }
                      break;
                    case "Pattern":
                      nt.objs.resolve(O, F);
                      break;
                    default:
                      throw new Error(`Got unknown object type ${A}`);
                  }
              }), a.on("DocProgress", (O) => {
                var r;
                this.destroyed || (r = c.onProgress) == null || r.call(c, {
                  loaded: O.loaded,
                  total: O.total
                });
              }), a.on("FetchBuiltInCMap", (O) => this.destroyed ? Promise.reject(new Error("Worker was destroyed.")) : this.cMapReaderFactory ? this.cMapReaderFactory.fetch(O) : Promise.reject(new Error("CMapReaderFactory not initialized, see the `useWorkerFetch` parameter."))), a.on("FetchStandardFontData", (O) => this.destroyed ? Promise.reject(new Error("Worker was destroyed.")) : this.standardFontDataFactory ? this.standardFontDataFactory.fetch(O) : Promise.reject(new Error("StandardFontDataFactory not initialized, see the `useWorkerFetch` parameter.")));
            }
            getData() {
              return this.messageHandler.sendWithPromise("GetData", null);
            }
            saveDocument() {
              var O;
              this.annotationStorage.size <= 0 && (0, _util.warn)("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
              const {
                map: a,
                transfers: c
              } = this.annotationStorage.serializable;
              return this.messageHandler.sendWithPromise("SaveDocument", {
                isPureXfa: !!this._htmlForXfa,
                numPages: this._numPages,
                annotationStorage: a,
                filename: ((O = this._fullReader) == null ? void 0 : O.filename) ?? null
              }, c).finally(() => {
                this.annotationStorage.resetModified();
              });
            }
            getPage(a) {
              if (!Number.isInteger(a) || a <= 0 || a > this._numPages)
                return Promise.reject(new Error("Invalid page request."));
              const c = a - 1, O = t(this, _).get(c);
              if (O)
                return O;
              const r = this.messageHandler.sendWithPromise("GetPage", {
                pageIndex: c
              }).then((A) => {
                if (this.destroyed)
                  throw new Error("Transport destroyed");
                const F = new PDFPageProxy(c, A, this, this._params.pdfBug);
                return t(this, I).set(c, F), F;
              });
              return t(this, _).set(c, r), r;
            }
            getPageIndex(a) {
              return typeof a != "object" || a === null || !Number.isInteger(a.num) || a.num < 0 || !Number.isInteger(a.gen) || a.gen < 0 ? Promise.reject(new Error("Invalid pageIndex request.")) : this.messageHandler.sendWithPromise("GetPageIndex", {
                num: a.num,
                gen: a.gen
              });
            }
            getAnnotations(a, c) {
              return this.messageHandler.sendWithPromise("GetAnnotations", {
                pageIndex: a,
                intent: c
              });
            }
            getFieldObjects() {
              return z(this, E, Ae).call(this, "GetFieldObjects");
            }
            hasJSActions() {
              return z(this, E, Ae).call(this, "HasJSActions");
            }
            getCalculationOrderIds() {
              return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
            }
            getDestinations() {
              return this.messageHandler.sendWithPromise("GetDestinations", null);
            }
            getDestination(a) {
              return typeof a != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
                id: a
              });
            }
            getPageLabels() {
              return this.messageHandler.sendWithPromise("GetPageLabels", null);
            }
            getPageLayout() {
              return this.messageHandler.sendWithPromise("GetPageLayout", null);
            }
            getPageMode() {
              return this.messageHandler.sendWithPromise("GetPageMode", null);
            }
            getViewerPreferences() {
              return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
            }
            getOpenAction() {
              return this.messageHandler.sendWithPromise("GetOpenAction", null);
            }
            getAttachments() {
              return this.messageHandler.sendWithPromise("GetAttachments", null);
            }
            getDocJSActions() {
              return z(this, E, Ae).call(this, "GetDocJSActions");
            }
            getPageJSActions(a) {
              return this.messageHandler.sendWithPromise("GetPageJSActions", {
                pageIndex: a
              });
            }
            getStructTree(a) {
              return this.messageHandler.sendWithPromise("GetStructTree", {
                pageIndex: a
              });
            }
            getOutline() {
              return this.messageHandler.sendWithPromise("GetOutline", null);
            }
            getOptionalContentConfig() {
              return this.messageHandler.sendWithPromise("GetOptionalContentConfig", null).then((a) => new _optional_content_config.OptionalContentConfig(a));
            }
            getPermissions() {
              return this.messageHandler.sendWithPromise("GetPermissions", null);
            }
            getMetadata() {
              const a = "GetMetadata", c = t(this, N).get(a);
              if (c)
                return c;
              const O = this.messageHandler.sendWithPromise(a, null).then((r) => {
                var A, F;
                return {
                  info: r[0],
                  metadata: r[1] ? new _metadata.Metadata(r[1]) : null,
                  contentDispositionFilename: ((A = this._fullReader) == null ? void 0 : A.filename) ?? null,
                  contentLength: ((F = this._fullReader) == null ? void 0 : F.contentLength) ?? null
                };
              });
              return t(this, N).set(a, O), O;
            }
            getMarkInfo() {
              return this.messageHandler.sendWithPromise("GetMarkInfo", null);
            }
            async startCleanup(a = !1) {
              if (!this.destroyed) {
                await this.messageHandler.sendWithPromise("Cleanup", null);
                for (const c of t(this, I).values())
                  if (!c.cleanup())
                    throw new Error(`startCleanup: Page ${c.pageNumber} is currently rendering.`);
                this.commonObjs.clear(), a || this.fontLoader.clear(), t(this, N).clear(), this.filterFactory.destroy(!0);
              }
            }
            get loadingParams() {
              const {
                disableAutoFetch: a,
                enableXfa: c
              } = this._params;
              return (0, _util.shadow)(this, "loadingParams", {
                disableAutoFetch: a,
                enableXfa: c
              });
            }
          }
          N = new WeakMap(), I = new WeakMap(), _ = new WeakMap(), b = new WeakMap(), E = new WeakSet(), Ae = function(a, c = null) {
            const O = t(this, N).get(a);
            if (O)
              return O;
            const r = this.messageHandler.sendWithPromise(a, c);
            return t(this, N).set(a, r), r;
          };
          class PDFObjects {
            constructor() {
              Q(this, p);
              Q(this, d, /* @__PURE__ */ Object.create(null));
            }
            get(a, c = null) {
              if (c) {
                const r = z(this, p, De).call(this, a);
                return r.capability.promise.then(() => c(r.data)), null;
              }
              const O = t(this, d)[a];
              if (!(O != null && O.capability.settled))
                throw new Error(`Requesting object that isn't resolved yet ${a}.`);
              return O.data;
            }
            has(a) {
              const c = t(this, d)[a];
              return (c == null ? void 0 : c.capability.settled) || !1;
            }
            resolve(a, c = null) {
              const O = z(this, p, De).call(this, a);
              O.data = c, O.capability.resolve();
            }
            clear() {
              var a;
              for (const c in t(this, d)) {
                const {
                  data: O
                } = t(this, d)[c];
                (a = O == null ? void 0 : O.bitmap) == null || a.close();
              }
              et(this, d, /* @__PURE__ */ Object.create(null));
            }
          }
          d = new WeakMap(), p = new WeakSet(), De = function(a) {
            var c;
            return (c = t(this, d))[a] || (c[a] = {
              capability: new _util.PromiseCapability(),
              data: null
            });
          };
          class RenderTask {
            constructor(a) {
              Q(this, y, null);
              et(this, y, a), this.onContinue = null;
            }
            get promise() {
              return t(this, y).capability.promise;
            }
            cancel(a = 0) {
              t(this, y).cancel(null, a);
            }
            get separateAnnots() {
              const {
                separateAnnots: a
              } = t(this, y).operatorList;
              if (!a)
                return !1;
              const {
                annotationCanvasMap: c
              } = t(this, y);
              return a.form || a.canvas && (c == null ? void 0 : c.size) > 0;
            }
          }
          y = new WeakMap(), exports.RenderTask = RenderTask;
          const l = class l {
            constructor({
              callback: a,
              params: c,
              objs: O,
              commonObjs: r,
              annotationCanvasMap: A,
              operatorList: F,
              pageIndex: nt,
              canvasFactory: W,
              filterFactory: $,
              useRequestAnimationFrame: j = !1,
              pdfBug: at = !1,
              pageColors: C = null
            }) {
              this.callback = a, this.params = c, this.objs = O, this.commonObjs = r, this.annotationCanvasMap = A, this.operatorListIdx = null, this.operatorList = F, this._pageIndex = nt, this.canvasFactory = W, this.filterFactory = $, this._pdfBug = at, this.pageColors = C, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = j === !0 && typeof window < "u", this.cancelled = !1, this.capability = new _util.PromiseCapability(), this.task = new RenderTask(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = c.canvasContext.canvas;
            }
            get completed() {
              return this.capability.promise.catch(function() {
              });
            }
            initializeGraphics({
              transparency: a = !1,
              optionalContentConfig: c
            }) {
              var nt, W;
              if (this.cancelled)
                return;
              if (this._canvas) {
                if (t(l, n).has(this._canvas))
                  throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
                t(l, n).add(this._canvas);
              }
              this._pdfBug && ((nt = globalThis.StepperManager) != null && nt.enabled) && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
              const {
                canvasContext: O,
                viewport: r,
                transform: A,
                background: F
              } = this.params;
              this.gfx = new _canvas.CanvasGraphics(O, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                optionalContentConfig: c
              }, this.annotationCanvasMap, this.pageColors), this.gfx.beginDrawing({
                transform: A,
                viewport: r,
                transparency: a,
                background: F
              }), this.operatorListIdx = 0, this.graphicsReady = !0, (W = this.graphicsReadyCallback) == null || W.call(this);
            }
            cancel(a = null, c = 0) {
              var O;
              this.running = !1, this.cancelled = !0, (O = this.gfx) == null || O.endDrawing(), t(l, n).delete(this._canvas), this.callback(a || new _display_utils.RenderingCancelledException(`Rendering cancelled, page ${this._pageIndex + 1}`, c));
            }
            operatorListChanged() {
              var a;
              if (!this.graphicsReady) {
                this.graphicsReadyCallback || (this.graphicsReadyCallback = this._continueBound);
                return;
              }
              (a = this.stepper) == null || a.updateOperatorList(this.operatorList), !this.running && this._continue();
            }
            _continue() {
              this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
            }
            _scheduleNext() {
              this._useRequestAnimationFrame ? window.requestAnimationFrame(() => {
                this._nextBound().catch(this._cancelBound);
              }) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
            }
            async _next() {
              this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), t(l, n).delete(this._canvas), this.callback())));
            }
          };
          n = new WeakMap(), Q(l, n, /* @__PURE__ */ new WeakSet());
          let InternalRenderTask = l;
          const version = "3.11.174";
          exports.version = version;
          const build = "ce8716743";
          exports.build = build;
        },
        /* 3 */
        /***/
        (pt, h, rt) => {
          var M, m, N, gi, _;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.SerializableEmpty = h.PrintAnnotationStorage = h.AnnotationStorage = void 0;
          var o = rt(1), T = rt(4), ct = rt(8);
          const q = Object.freeze({
            map: null,
            hash: "",
            transfers: void 0
          });
          h.SerializableEmpty = q;
          class gt {
            constructor() {
              Q(this, N);
              Q(this, M, !1);
              Q(this, m, /* @__PURE__ */ new Map());
              this.onSetModified = null, this.onResetModified = null, this.onAnnotationEditor = null;
            }
            getValue(E, f) {
              const d = t(this, m).get(E);
              return d === void 0 ? f : Object.assign(f, d);
            }
            getRawValue(E) {
              return t(this, m).get(E);
            }
            remove(E) {
              if (t(this, m).delete(E), t(this, m).size === 0 && this.resetModified(), typeof this.onAnnotationEditor == "function") {
                for (const f of t(this, m).values())
                  if (f instanceof T.AnnotationEditor)
                    return;
                this.onAnnotationEditor(null);
              }
            }
            setValue(E, f) {
              const d = t(this, m).get(E);
              let p = !1;
              if (d !== void 0)
                for (const [D, y] of Object.entries(f))
                  d[D] !== y && (p = !0, d[D] = y);
              else
                p = !0, t(this, m).set(E, f);
              p && z(this, N, gi).call(this), f instanceof T.AnnotationEditor && typeof this.onAnnotationEditor == "function" && this.onAnnotationEditor(f.constructor._type);
            }
            has(E) {
              return t(this, m).has(E);
            }
            getAll() {
              return t(this, m).size > 0 ? (0, o.objectFromMap)(t(this, m)) : null;
            }
            setAll(E) {
              for (const [f, d] of Object.entries(E))
                this.setValue(f, d);
            }
            get size() {
              return t(this, m).size;
            }
            resetModified() {
              t(this, M) && (et(this, M, !1), typeof this.onResetModified == "function" && this.onResetModified());
            }
            get print() {
              return new B(this);
            }
            get serializable() {
              if (t(this, m).size === 0)
                return q;
              const E = /* @__PURE__ */ new Map(), f = new ct.MurmurHash3_64(), d = [], p = /* @__PURE__ */ Object.create(null);
              let D = !1;
              for (const [y, n] of t(this, m)) {
                const l = n instanceof T.AnnotationEditor ? n.serialize(!1, p) : n;
                l && (E.set(y, l), f.update(`${y}:${JSON.stringify(l)}`), D || (D = !!l.bitmap));
              }
              if (D)
                for (const y of E.values())
                  y.bitmap && d.push(y.bitmap);
              return E.size > 0 ? {
                map: E,
                hash: f.hexdigest(),
                transfers: d
              } : q;
            }
          }
          M = new WeakMap(), m = new WeakMap(), N = new WeakSet(), gi = function() {
            t(this, M) || (et(this, M, !0), typeof this.onSetModified == "function" && this.onSetModified());
          }, h.AnnotationStorage = gt;
          class B extends gt {
            constructor(f) {
              super();
              Q(this, _);
              const {
                map: d,
                hash: p,
                transfers: D
              } = f.serializable, y = structuredClone(d, D ? {
                transfer: D
              } : null);
              et(this, _, {
                map: y,
                hash: p,
                transfers: D
              });
            }
            get print() {
              (0, o.unreachable)("Should not call PrintAnnotationStorage.print");
            }
            get serializable() {
              return t(this, _);
            }
          }
          _ = new WeakMap(), h.PrintAnnotationStorage = B;
        },
        /* 4 */
        /***/
        (pt, h, rt) => {
          var B, M, m, N, I, _, b, E, f, d, p, D, y, n, l, Ie, Le, c, Oe, Ne, mi, bi, _i, Be, Ai;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.AnnotationEditor = void 0;
          var o = rt(5), T = rt(1), ct = rt(6);
          const j = class j {
            constructor(C) {
              Q(this, l);
              Q(this, B, "");
              Q(this, M, !1);
              Q(this, m, null);
              Q(this, N, null);
              Q(this, I, null);
              Q(this, _, !1);
              Q(this, b, null);
              Q(this, E, this.focusin.bind(this));
              Q(this, f, this.focusout.bind(this));
              Q(this, d, !1);
              Q(this, p, !1);
              Q(this, D, !1);
              Kt(this, "_initialOptions", /* @__PURE__ */ Object.create(null));
              Kt(this, "_uiManager", null);
              Kt(this, "_focusEventsAllowed", !0);
              Kt(this, "_l10nPromise", null);
              Q(this, y, !1);
              Q(this, n, j._zIndex++);
              this.constructor === j && (0, T.unreachable)("Cannot initialize AnnotationEditor."), this.parent = C.parent, this.id = C.id, this.width = this.height = null, this.pageIndex = C.parent.pageIndex, this.name = C.name, this.div = null, this._uiManager = C.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = C.isCentered, this._structTreeParentId = null;
              const {
                rotation: U,
                rawDims: {
                  pageWidth: Y,
                  pageHeight: S,
                  pageX: e,
                  pageY: i
                }
              } = this.parent.viewport;
              this.rotation = U, this.pageRotation = (360 + U - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [Y, S], this.pageTranslation = [e, i];
              const [u, x] = this.parentDimensions;
              this.x = C.x / u, this.y = C.y / x, this.isAttachedToDOM = !1, this.deleted = !1;
            }
            get editorType() {
              return Object.getPrototypeOf(this).constructor._type;
            }
            static get _defaultLineColor() {
              return (0, T.shadow)(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
            }
            static deleteAnnotationElement(C) {
              const U = new gt({
                id: C.parent.getNextId(),
                parent: C.parent,
                uiManager: C._uiManager
              });
              U.annotationElementId = C.annotationElementId, U.deleted = !0, U._uiManager.addToAnnotationStorage(U);
            }
            static initialize(C, U = null) {
              if (j._l10nPromise || (j._l10nPromise = new Map(["editor_alt_text_button_label", "editor_alt_text_edit_button_label", "editor_alt_text_decorative_tooltip"].map((S) => [S, C.get(S)]))), U != null && U.strings)
                for (const S of U.strings)
                  j._l10nPromise.set(S, C.get(S));
              if (j._borderLineWidth !== -1)
                return;
              const Y = getComputedStyle(document.documentElement);
              j._borderLineWidth = parseFloat(Y.getPropertyValue("--outline-width")) || 0;
            }
            static updateDefaultParams(C, U) {
            }
            static get defaultPropertiesToUpdate() {
              return [];
            }
            static isHandlingMimeForPasting(C) {
              return !1;
            }
            static paste(C, U) {
              (0, T.unreachable)("Not implemented");
            }
            get propertiesToUpdate() {
              return [];
            }
            get _isDraggable() {
              return t(this, y);
            }
            set _isDraggable(C) {
              var U;
              et(this, y, C), (U = this.div) == null || U.classList.toggle("draggable", C);
            }
            center() {
              const [C, U] = this.pageDimensions;
              switch (this.parentRotation) {
                case 90:
                  this.x -= this.height * U / (C * 2), this.y += this.width * C / (U * 2);
                  break;
                case 180:
                  this.x += this.width / 2, this.y += this.height / 2;
                  break;
                case 270:
                  this.x += this.height * U / (C * 2), this.y -= this.width * C / (U * 2);
                  break;
                default:
                  this.x -= this.width / 2, this.y -= this.height / 2;
                  break;
              }
              this.fixAndSetPosition();
            }
            addCommands(C) {
              this._uiManager.addCommands(C);
            }
            get currentLayer() {
              return this._uiManager.currentLayer;
            }
            setInBackground() {
              this.div.style.zIndex = 0;
            }
            setInForeground() {
              this.div.style.zIndex = t(this, n);
            }
            setParent(C) {
              C !== null && (this.pageIndex = C.pageIndex, this.pageDimensions = C.pageDimensions), this.parent = C;
            }
            focusin(C) {
              this._focusEventsAllowed && (t(this, d) ? et(this, d, !1) : this.parent.setSelected(this));
            }
            focusout(C) {
              var Y;
              if (!this._focusEventsAllowed || !this.isAttachedToDOM)
                return;
              const U = C.relatedTarget;
              U != null && U.closest(`#${this.id}`) || (C.preventDefault(), (Y = this.parent) != null && Y.isMultipleSelection || this.commitOrRemove());
            }
            commitOrRemove() {
              this.isEmpty() ? this.remove() : this.commit();
            }
            commit() {
              this.addToAnnotationStorage();
            }
            addToAnnotationStorage() {
              this._uiManager.addToAnnotationStorage(this);
            }
            setAt(C, U, Y, S) {
              const [e, i] = this.parentDimensions;
              [Y, S] = this.screenToPageTranslation(Y, S), this.x = (C + Y) / e, this.y = (U + S) / i, this.fixAndSetPosition();
            }
            translate(C, U) {
              z(this, l, Ie).call(this, this.parentDimensions, C, U);
            }
            translateInPage(C, U) {
              z(this, l, Ie).call(this, this.pageDimensions, C, U), this.div.scrollIntoView({
                block: "nearest"
              });
            }
            drag(C, U) {
              const [Y, S] = this.parentDimensions;
              if (this.x += C / Y, this.y += U / S, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
                const {
                  x: P,
                  y: k
                } = this.div.getBoundingClientRect();
                this.parent.findNewParent(this, P, k) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
              }
              let {
                x: e,
                y: i
              } = this;
              const [u, x] = z(this, l, Le).call(this);
              e += u, i += x, this.div.style.left = `${(100 * e).toFixed(2)}%`, this.div.style.top = `${(100 * i).toFixed(2)}%`, this.div.scrollIntoView({
                block: "nearest"
              });
            }
            fixAndSetPosition() {
              const [C, U] = this.pageDimensions;
              let {
                x: Y,
                y: S,
                width: e,
                height: i
              } = this;
              switch (e *= C, i *= U, Y *= C, S *= U, this.rotation) {
                case 0:
                  Y = Math.max(0, Math.min(C - e, Y)), S = Math.max(0, Math.min(U - i, S));
                  break;
                case 90:
                  Y = Math.max(0, Math.min(C - i, Y)), S = Math.min(U, Math.max(e, S));
                  break;
                case 180:
                  Y = Math.min(C, Math.max(e, Y)), S = Math.min(U, Math.max(i, S));
                  break;
                case 270:
                  Y = Math.min(C, Math.max(i, Y)), S = Math.max(0, Math.min(U - e, S));
                  break;
              }
              this.x = Y /= C, this.y = S /= U;
              const [u, x] = z(this, l, Le).call(this);
              Y += u, S += x;
              const {
                style: P
              } = this.div;
              P.left = `${(100 * Y).toFixed(2)}%`, P.top = `${(100 * S).toFixed(2)}%`, this.moveInDOM();
            }
            screenToPageTranslation(C, U) {
              var Y;
              return z(Y = j, c, Oe).call(Y, C, U, this.parentRotation);
            }
            pageTranslationToScreen(C, U) {
              var Y;
              return z(Y = j, c, Oe).call(Y, C, U, 360 - this.parentRotation);
            }
            get parentScale() {
              return this._uiManager.viewParameters.realScale;
            }
            get parentRotation() {
              return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
            }
            get parentDimensions() {
              const {
                parentScale: C,
                pageDimensions: [U, Y]
              } = this, S = U * C, e = Y * C;
              return T.FeatureTest.isCSSRoundSupported ? [Math.round(S), Math.round(e)] : [S, e];
            }
            setDims(C, U) {
              var e;
              const [Y, S] = this.parentDimensions;
              this.div.style.width = `${(100 * C / Y).toFixed(2)}%`, t(this, _) || (this.div.style.height = `${(100 * U / S).toFixed(2)}%`), (e = t(this, m)) == null || e.classList.toggle("small", C < j.SMALL_EDITOR_SIZE || U < j.SMALL_EDITOR_SIZE);
            }
            fixDims() {
              const {
                style: C
              } = this.div, {
                height: U,
                width: Y
              } = C, S = Y.endsWith("%"), e = !t(this, _) && U.endsWith("%");
              if (S && e)
                return;
              const [i, u] = this.parentDimensions;
              S || (C.width = `${(100 * parseFloat(Y) / i).toFixed(2)}%`), !t(this, _) && !e && (C.height = `${(100 * parseFloat(U) / u).toFixed(2)}%`);
            }
            getInitialTranslation() {
              return [0, 0];
            }
            async addAltTextButton() {
              if (t(this, m))
                return;
              const C = et(this, m, document.createElement("button"));
              C.className = "altText";
              const U = await j._l10nPromise.get("editor_alt_text_button_label");
              C.textContent = U, C.setAttribute("aria-label", U), C.tabIndex = "0", C.addEventListener("contextmenu", ct.noContextMenu), C.addEventListener("pointerdown", (Y) => Y.stopPropagation()), C.addEventListener("click", (Y) => {
                Y.preventDefault(), this._uiManager.editAltText(this);
              }, {
                capture: !0
              }), C.addEventListener("keydown", (Y) => {
                Y.target === C && Y.key === "Enter" && (Y.preventDefault(), this._uiManager.editAltText(this));
              }), z(this, l, Be).call(this), this.div.append(C), j.SMALL_EDITOR_SIZE || (j.SMALL_EDITOR_SIZE = Math.min(128, Math.round(C.getBoundingClientRect().width * 1.4)));
            }
            getClientDimensions() {
              return this.div.getBoundingClientRect();
            }
            get altTextData() {
              return {
                altText: t(this, B),
                decorative: t(this, M)
              };
            }
            set altTextData({
              altText: C,
              decorative: U
            }) {
              t(this, B) === C && t(this, M) === U || (et(this, B, C), et(this, M, U), z(this, l, Be).call(this));
            }
            render() {
              this.div = document.createElement("div"), this.div.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), this.div.className = this.name, this.div.setAttribute("id", this.id), this.div.setAttribute("tabIndex", 0), this.setInForeground(), this.div.addEventListener("focusin", t(this, E)), this.div.addEventListener("focusout", t(this, f));
              const [C, U] = this.parentDimensions;
              this.parentRotation % 180 !== 0 && (this.div.style.maxWidth = `${(100 * U / C).toFixed(2)}%`, this.div.style.maxHeight = `${(100 * C / U).toFixed(2)}%`);
              const [Y, S] = this.getInitialTranslation();
              return this.translate(Y, S), (0, o.bindEvents)(this, this.div, ["pointerdown"]), this.div;
            }
            pointerdown(C) {
              const {
                isMac: U
              } = T.FeatureTest.platform;
              if (C.button !== 0 || C.ctrlKey && U) {
                C.preventDefault();
                return;
              }
              et(this, d, !0), z(this, l, Ai).call(this, C);
            }
            moveInDOM() {
              var C;
              (C = this.parent) == null || C.moveEditorInDOM(this);
            }
            _setParentAndPosition(C, U, Y) {
              C.changeParent(this), this.x = U, this.y = Y, this.fixAndSetPosition();
            }
            getRect(C, U) {
              const Y = this.parentScale, [S, e] = this.pageDimensions, [i, u] = this.pageTranslation, x = C / Y, P = U / Y, k = this.x * S, G = this.y * e, it = this.width * S, ht = this.height * e;
              switch (this.rotation) {
                case 0:
                  return [k + x + i, e - G - P - ht + u, k + x + it + i, e - G - P + u];
                case 90:
                  return [k + P + i, e - G + x + u, k + P + ht + i, e - G + x + it + u];
                case 180:
                  return [k - x - it + i, e - G + P + u, k - x + i, e - G + P + ht + u];
                case 270:
                  return [k - P - ht + i, e - G - x - it + u, k - P + i, e - G - x + u];
                default:
                  throw new Error("Invalid rotation");
              }
            }
            getRectInCurrentCoords(C, U) {
              const [Y, S, e, i] = C, u = e - Y, x = i - S;
              switch (this.rotation) {
                case 0:
                  return [Y, U - i, u, x];
                case 90:
                  return [Y, U - S, x, u];
                case 180:
                  return [e, U - S, u, x];
                case 270:
                  return [e, U - i, x, u];
                default:
                  throw new Error("Invalid rotation");
              }
            }
            onceAdded() {
            }
            isEmpty() {
              return !1;
            }
            enableEditMode() {
              et(this, D, !0);
            }
            disableEditMode() {
              et(this, D, !1);
            }
            isInEditMode() {
              return t(this, D);
            }
            shouldGetKeyboardEvents() {
              return !1;
            }
            needsToBeRebuilt() {
              return this.div && !this.isAttachedToDOM;
            }
            rebuild() {
              var C, U;
              (C = this.div) == null || C.addEventListener("focusin", t(this, E)), (U = this.div) == null || U.addEventListener("focusout", t(this, f));
            }
            serialize(C = !1, U = null) {
              (0, T.unreachable)("An editor must be serializable");
            }
            static deserialize(C, U, Y) {
              const S = new this.prototype.constructor({
                parent: U,
                id: U.getNextId(),
                uiManager: Y
              });
              S.rotation = C.rotation;
              const [e, i] = S.pageDimensions, [u, x, P, k] = S.getRectInCurrentCoords(C.rect, i);
              return S.x = u / e, S.y = x / i, S.width = P / e, S.height = k / i, S;
            }
            remove() {
              var C;
              this.div.removeEventListener("focusin", t(this, E)), this.div.removeEventListener("focusout", t(this, f)), this.isEmpty() || this.commit(), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), (C = t(this, m)) == null || C.remove(), et(this, m, null), et(this, N, null);
            }
            get isResizable() {
              return !1;
            }
            makeResizable() {
              this.isResizable && (z(this, l, mi).call(this), t(this, b).classList.remove("hidden"));
            }
            select() {
              var C;
              this.makeResizable(), (C = this.div) == null || C.classList.add("selectedEditor");
            }
            unselect() {
              var C, U, Y;
              (C = t(this, b)) == null || C.classList.add("hidden"), (U = this.div) == null || U.classList.remove("selectedEditor"), (Y = this.div) != null && Y.contains(document.activeElement) && this._uiManager.currentLayer.div.focus();
            }
            updateParams(C, U) {
            }
            disableEditing() {
              t(this, m) && (t(this, m).hidden = !0);
            }
            enableEditing() {
              t(this, m) && (t(this, m).hidden = !1);
            }
            enterInEditMode() {
            }
            get contentDiv() {
              return this.div;
            }
            get isEditing() {
              return t(this, p);
            }
            set isEditing(C) {
              et(this, p, C), this.parent && (C ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
            }
            setAspectRatio(C, U) {
              et(this, _, !0);
              const Y = C / U, {
                style: S
              } = this.div;
              S.aspectRatio = Y, S.height = "auto";
            }
            static get MIN_SIZE() {
              return 16;
            }
          };
          B = new WeakMap(), M = new WeakMap(), m = new WeakMap(), N = new WeakMap(), I = new WeakMap(), _ = new WeakMap(), b = new WeakMap(), E = new WeakMap(), f = new WeakMap(), d = new WeakMap(), p = new WeakMap(), D = new WeakMap(), y = new WeakMap(), n = new WeakMap(), l = new WeakSet(), Ie = function([C, U], Y, S) {
            [Y, S] = this.screenToPageTranslation(Y, S), this.x += Y / C, this.y += S / U, this.fixAndSetPosition();
          }, Le = function() {
            const [C, U] = this.parentDimensions, {
              _borderLineWidth: Y
            } = j, S = Y / C, e = Y / U;
            switch (this.rotation) {
              case 90:
                return [-S, e];
              case 180:
                return [S, e];
              case 270:
                return [S, -e];
              default:
                return [-S, -e];
            }
          }, c = new WeakSet(), Oe = function(C, U, Y) {
            switch (Y) {
              case 90:
                return [U, -C];
              case 180:
                return [-C, -U];
              case 270:
                return [-U, C];
              default:
                return [C, U];
            }
          }, Ne = function(C) {
            switch (C) {
              case 90: {
                const [U, Y] = this.pageDimensions;
                return [0, -U / Y, Y / U, 0];
              }
              case 180:
                return [-1, 0, 0, -1];
              case 270: {
                const [U, Y] = this.pageDimensions;
                return [0, U / Y, -Y / U, 0];
              }
              default:
                return [1, 0, 0, 1];
            }
          }, mi = function() {
            if (t(this, b))
              return;
            et(this, b, document.createElement("div")), t(this, b).classList.add("resizers");
            const C = ["topLeft", "topRight", "bottomRight", "bottomLeft"];
            this._willKeepAspectRatio || C.push("topMiddle", "middleRight", "bottomMiddle", "middleLeft");
            for (const U of C) {
              const Y = document.createElement("div");
              t(this, b).append(Y), Y.classList.add("resizer", U), Y.addEventListener("pointerdown", z(this, l, bi).bind(this, U)), Y.addEventListener("contextmenu", ct.noContextMenu);
            }
            this.div.prepend(t(this, b));
          }, bi = function(C, U) {
            U.preventDefault();
            const {
              isMac: Y
            } = T.FeatureTest.platform;
            if (U.button !== 0 || U.ctrlKey && Y)
              return;
            const S = z(this, l, _i).bind(this, C), e = this._isDraggable;
            this._isDraggable = !1;
            const i = {
              passive: !0,
              capture: !0
            };
            window.addEventListener("pointermove", S, i);
            const u = this.x, x = this.y, P = this.width, k = this.height, G = this.parent.div.style.cursor, it = this.div.style.cursor;
            this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(U.target).cursor;
            const ht = () => {
              this._isDraggable = e, window.removeEventListener("pointerup", ht), window.removeEventListener("blur", ht), window.removeEventListener("pointermove", S, i), this.parent.div.style.cursor = G, this.div.style.cursor = it;
              const dt = this.x, mt = this.y, At = this.width, vt = this.height;
              dt === u && mt === x && At === P && vt === k || this.addCommands({
                cmd: () => {
                  this.width = At, this.height = vt, this.x = dt, this.y = mt;
                  const [K, Z] = this.parentDimensions;
                  this.setDims(K * At, Z * vt), this.fixAndSetPosition();
                },
                undo: () => {
                  this.width = P, this.height = k, this.x = u, this.y = x;
                  const [K, Z] = this.parentDimensions;
                  this.setDims(K * P, Z * k), this.fixAndSetPosition();
                },
                mustExec: !0
              });
            };
            window.addEventListener("pointerup", ht), window.addEventListener("blur", ht);
          }, _i = function(C, U) {
            const [Y, S] = this.parentDimensions, e = this.x, i = this.y, u = this.width, x = this.height, P = j.MIN_SIZE / Y, k = j.MIN_SIZE / S, G = (Ft) => Math.round(Ft * 1e4) / 1e4, it = z(this, l, Ne).call(this, this.rotation), ht = (Ft, Nt) => [it[0] * Ft + it[2] * Nt, it[1] * Ft + it[3] * Nt], dt = z(this, l, Ne).call(this, 360 - this.rotation), mt = (Ft, Nt) => [dt[0] * Ft + dt[2] * Nt, dt[1] * Ft + dt[3] * Nt];
            let At, vt, K = !1, Z = !1;
            switch (C) {
              case "topLeft":
                K = !0, At = (Ft, Nt) => [0, 0], vt = (Ft, Nt) => [Ft, Nt];
                break;
              case "topMiddle":
                At = (Ft, Nt) => [Ft / 2, 0], vt = (Ft, Nt) => [Ft / 2, Nt];
                break;
              case "topRight":
                K = !0, At = (Ft, Nt) => [Ft, 0], vt = (Ft, Nt) => [0, Nt];
                break;
              case "middleRight":
                Z = !0, At = (Ft, Nt) => [Ft, Nt / 2], vt = (Ft, Nt) => [0, Nt / 2];
                break;
              case "bottomRight":
                K = !0, At = (Ft, Nt) => [Ft, Nt], vt = (Ft, Nt) => [0, 0];
                break;
              case "bottomMiddle":
                At = (Ft, Nt) => [Ft / 2, Nt], vt = (Ft, Nt) => [Ft / 2, 0];
                break;
              case "bottomLeft":
                K = !0, At = (Ft, Nt) => [0, Nt], vt = (Ft, Nt) => [Ft, 0];
                break;
              case "middleLeft":
                Z = !0, At = (Ft, Nt) => [0, Nt / 2], vt = (Ft, Nt) => [Ft, Nt / 2];
                break;
            }
            const g = At(u, x), R = vt(u, x);
            let X = ht(...R);
            const J = G(e + X[0]), ut = G(i + X[1]);
            let St = 1, yt = 1, [V, Tt] = this.screenToPageTranslation(U.movementX, U.movementY);
            if ([V, Tt] = mt(V / Y, Tt / S), K) {
              const Ft = Math.hypot(u, x);
              St = yt = Math.max(Math.min(Math.hypot(R[0] - g[0] - V, R[1] - g[1] - Tt) / Ft, 1 / u, 1 / x), P / u, k / x);
            } else Z ? St = Math.max(P, Math.min(1, Math.abs(R[0] - g[0] - V))) / u : yt = Math.max(k, Math.min(1, Math.abs(R[1] - g[1] - Tt))) / x;
            const wt = G(u * St), jt = G(x * yt);
            X = ht(...vt(wt, jt));
            const Bt = J - X[0], Xt = ut - X[1];
            this.width = wt, this.height = jt, this.x = Bt, this.y = Xt, this.setDims(Y * wt, S * jt), this.fixAndSetPosition();
          }, Be = async function() {
            var Y;
            const C = t(this, m);
            if (!C)
              return;
            if (!t(this, B) && !t(this, M)) {
              C.classList.remove("done"), (Y = t(this, N)) == null || Y.remove();
              return;
            }
            j._l10nPromise.get("editor_alt_text_edit_button_label").then((S) => {
              C.setAttribute("aria-label", S);
            });
            let U = t(this, N);
            if (!U) {
              et(this, N, U = document.createElement("span")), U.className = "tooltip", U.setAttribute("role", "tooltip");
              const S = U.id = `alt-text-tooltip-${this.id}`;
              C.setAttribute("aria-describedby", S);
              const e = 100;
              C.addEventListener("mouseenter", () => {
                et(this, I, setTimeout(() => {
                  et(this, I, null), t(this, N).classList.add("show"), this._uiManager._eventBus.dispatch("reporttelemetry", {
                    source: this,
                    details: {
                      type: "editing",
                      subtype: this.editorType,
                      data: {
                        action: "alt_text_tooltip"
                      }
                    }
                  });
                }, e));
              }), C.addEventListener("mouseleave", () => {
                var i;
                clearTimeout(t(this, I)), et(this, I, null), (i = t(this, N)) == null || i.classList.remove("show");
              });
            }
            C.classList.add("done"), U.innerText = t(this, M) ? await j._l10nPromise.get("editor_alt_text_decorative_tooltip") : t(this, B), U.parentNode || C.append(U);
          }, Ai = function(C) {
            if (!this._isDraggable)
              return;
            const U = this._uiManager.isSelected(this);
            this._uiManager.setUpDragSession();
            let Y, S;
            U && (Y = {
              passive: !0,
              capture: !0
            }, S = (i) => {
              const [u, x] = this.screenToPageTranslation(i.movementX, i.movementY);
              this._uiManager.dragSelectedEditors(u, x);
            }, window.addEventListener("pointermove", S, Y));
            const e = () => {
              if (window.removeEventListener("pointerup", e), window.removeEventListener("blur", e), U && window.removeEventListener("pointermove", S, Y), et(this, d, !1), !this._uiManager.endDragSession()) {
                const {
                  isMac: i
                } = T.FeatureTest.platform;
                C.ctrlKey && !i || C.shiftKey || C.metaKey && i ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
              }
            };
            window.addEventListener("pointerup", e), window.addEventListener("blur", e);
          }, Q(j, c), Kt(j, "_borderLineWidth", -1), Kt(j, "_colorManager", new o.ColorManager()), Kt(j, "_zIndex", 1), Kt(j, "SMALL_EDITOR_SIZE", 0);
          let q = j;
          h.AnnotationEditor = q;
          class gt extends q {
            constructor(C) {
              super(C), this.annotationElementId = C.annotationElementId, this.deleted = !0;
            }
            serialize() {
              return {
                id: this.annotationElementId,
                deleted: !0,
                pageIndex: this.pageIndex
              };
            }
          }
        },
        /* 5 */
        /***/
        (pt, h, rt) => {
          var _, b, E, f, d, Ue, y, n, l, s, a, yi, r, A, F, nt, W, $, j, at, C, U, Y, S, e, i, u, x, P, k, G, it, ht, dt, mt, At, vt, K, Z, g, R, X, J, ut, St, yt, V, vi, je, He, ye, We, Ge, Zt, de, Si, Ei, ze, ue, Xe;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.KeyboardManager = h.CommandManager = h.ColorManager = h.AnnotationEditorUIManager = void 0, h.bindEvents = ct, h.opacityToHex = q;
          var o = rt(1), T = rt(6);
          function ct(Gt, L, ft) {
            for (const Ct of ft)
              L.addEventListener(Ct, Gt[Ct].bind(Gt));
          }
          function q(Gt) {
            return Math.round(Math.min(255, Math.max(1, 255 * Gt))).toString(16).padStart(2, "0");
          }
          class gt {
            constructor() {
              Q(this, _, 0);
            }
            getId() {
              return `${o.AnnotationEditorPrefix}${he(this, _)._++}`;
            }
          }
          _ = new WeakMap();
          const D = class D {
            constructor() {
              Q(this, d);
              Q(this, b, (0, o.getUuid)());
              Q(this, E, 0);
              Q(this, f, null);
            }
            static get _isSVGFittingCanvas() {
              const L = 'data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>', Ct = new OffscreenCanvas(1, 3).getContext("2d"), Dt = new Image();
              Dt.src = L;
              const Ot = Dt.decode().then(() => (Ct.drawImage(Dt, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(Ct.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
              return (0, o.shadow)(this, "_isSVGFittingCanvas", Ot);
            }
            async getFromFile(L) {
              const {
                lastModified: ft,
                name: Ct,
                size: Dt,
                type: Ot
              } = L;
              return z(this, d, Ue).call(this, `${ft}_${Ct}_${Dt}_${Ot}`, L);
            }
            async getFromUrl(L) {
              return z(this, d, Ue).call(this, L, L);
            }
            async getFromId(L) {
              t(this, f) || et(this, f, /* @__PURE__ */ new Map());
              const ft = t(this, f).get(L);
              return ft ? ft.bitmap ? (ft.refCounter += 1, ft) : ft.file ? this.getFromFile(ft.file) : this.getFromUrl(ft.url) : null;
            }
            getSvgUrl(L) {
              const ft = t(this, f).get(L);
              return ft != null && ft.isSvg ? ft.svgUrl : null;
            }
            deleteId(L) {
              t(this, f) || et(this, f, /* @__PURE__ */ new Map());
              const ft = t(this, f).get(L);
              ft && (ft.refCounter -= 1, ft.refCounter === 0 && (ft.bitmap = null));
            }
            isValidId(L) {
              return L.startsWith(`image_${t(this, b)}_`);
            }
          };
          b = new WeakMap(), E = new WeakMap(), f = new WeakMap(), d = new WeakSet(), Ue = async function(L, ft) {
            t(this, f) || et(this, f, /* @__PURE__ */ new Map());
            let Ct = t(this, f).get(L);
            if (Ct === null)
              return null;
            if (Ct != null && Ct.bitmap)
              return Ct.refCounter += 1, Ct;
            try {
              Ct || (Ct = {
                bitmap: null,
                id: `image_${t(this, b)}_${he(this, E)._++}`,
                refCounter: 0,
                isSvg: !1
              });
              let Dt;
              if (typeof ft == "string") {
                Ct.url = ft;
                const Ot = await fetch(ft);
                if (!Ot.ok)
                  throw new Error(Ot.statusText);
                Dt = await Ot.blob();
              } else
                Dt = Ct.file = ft;
              if (Dt.type === "image/svg+xml") {
                const Ot = D._isSVGFittingCanvas, Pt = new FileReader(), w = new Image(), v = new Promise((H, ot) => {
                  w.onload = () => {
                    Ct.bitmap = w, Ct.isSvg = !0, H();
                  }, Pt.onload = async () => {
                    const lt = Ct.svgUrl = Pt.result;
                    w.src = await Ot ? `${lt}#svgView(preserveAspectRatio(none))` : lt;
                  }, w.onerror = Pt.onerror = ot;
                });
                Pt.readAsDataURL(Dt), await v;
              } else
                Ct.bitmap = await createImageBitmap(Dt);
              Ct.refCounter = 1;
            } catch (Dt) {
              console.error(Dt), Ct = null;
            }
            return t(this, f).set(L, Ct), Ct && t(this, f).set(Ct.id, Ct), Ct;
          };
          let B = D;
          class M {
            constructor(L = 128) {
              Q(this, y, []);
              Q(this, n, !1);
              Q(this, l);
              Q(this, s, -1);
              et(this, l, L);
            }
            add({
              cmd: L,
              undo: ft,
              mustExec: Ct,
              type: Dt = NaN,
              overwriteIfSameType: Ot = !1,
              keepUndo: Pt = !1
            }) {
              if (Ct && L(), t(this, n))
                return;
              const w = {
                cmd: L,
                undo: ft,
                type: Dt
              };
              if (t(this, s) === -1) {
                t(this, y).length > 0 && (t(this, y).length = 0), et(this, s, 0), t(this, y).push(w);
                return;
              }
              if (Ot && t(this, y)[t(this, s)].type === Dt) {
                Pt && (w.undo = t(this, y)[t(this, s)].undo), t(this, y)[t(this, s)] = w;
                return;
              }
              const v = t(this, s) + 1;
              v === t(this, l) ? t(this, y).splice(0, 1) : (et(this, s, v), v < t(this, y).length && t(this, y).splice(v)), t(this, y).push(w);
            }
            undo() {
              t(this, s) !== -1 && (et(this, n, !0), t(this, y)[t(this, s)].undo(), et(this, n, !1), et(this, s, t(this, s) - 1));
            }
            redo() {
              t(this, s) < t(this, y).length - 1 && (et(this, s, t(this, s) + 1), et(this, n, !0), t(this, y)[t(this, s)].cmd(), et(this, n, !1));
            }
            hasSomethingToUndo() {
              return t(this, s) !== -1;
            }
            hasSomethingToRedo() {
              return t(this, s) < t(this, y).length - 1;
            }
            destroy() {
              et(this, y, null);
            }
          }
          y = new WeakMap(), n = new WeakMap(), l = new WeakMap(), s = new WeakMap(), h.CommandManager = M;
          class m {
            constructor(L) {
              Q(this, a);
              this.buffer = [], this.callbacks = /* @__PURE__ */ new Map(), this.allKeys = /* @__PURE__ */ new Set();
              const {
                isMac: ft
              } = o.FeatureTest.platform;
              for (const [Ct, Dt, Ot = {}] of L)
                for (const Pt of Ct) {
                  const w = Pt.startsWith("mac+");
                  ft && w ? (this.callbacks.set(Pt.slice(4), {
                    callback: Dt,
                    options: Ot
                  }), this.allKeys.add(Pt.split("+").at(-1))) : !ft && !w && (this.callbacks.set(Pt, {
                    callback: Dt,
                    options: Ot
                  }), this.allKeys.add(Pt.split("+").at(-1)));
                }
            }
            exec(L, ft) {
              if (!this.allKeys.has(ft.key))
                return;
              const Ct = this.callbacks.get(z(this, a, yi).call(this, ft));
              if (!Ct)
                return;
              const {
                callback: Dt,
                options: {
                  bubbles: Ot = !1,
                  args: Pt = [],
                  checker: w = null
                }
              } = Ct;
              w && !w(L, ft) || (Dt.bind(L, ...Pt)(), Ot || (ft.stopPropagation(), ft.preventDefault()));
            }
          }
          a = new WeakSet(), yi = function(L) {
            L.altKey && this.buffer.push("alt"), L.ctrlKey && this.buffer.push("ctrl"), L.metaKey && this.buffer.push("meta"), L.shiftKey && this.buffer.push("shift"), this.buffer.push(L.key);
            const ft = this.buffer.join("+");
            return this.buffer.length = 0, ft;
          }, h.KeyboardManager = m;
          const O = class O {
            get _colors() {
              const L = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
              return (0, T.getColorValues)(L), (0, o.shadow)(this, "_colors", L);
            }
            convert(L) {
              const ft = (0, T.getRGB)(L);
              if (!window.matchMedia("(forced-colors: active)").matches)
                return ft;
              for (const [Ct, Dt] of this._colors)
                if (Dt.every((Ot, Pt) => Ot === ft[Pt]))
                  return O._colorsMapping.get(Ct);
              return ft;
            }
            getHexCode(L) {
              const ft = this._colors.get(L);
              return ft ? o.Util.makeHexColor(...ft) : L;
            }
          };
          Kt(O, "_colorsMapping", /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]));
          let N = O;
          h.ColorManager = N;
          const zt = class zt {
            constructor(L, ft, Ct, Dt, Ot, Pt) {
              Q(this, V);
              Q(this, r, null);
              Q(this, A, /* @__PURE__ */ new Map());
              Q(this, F, /* @__PURE__ */ new Map());
              Q(this, nt, null);
              Q(this, W, null);
              Q(this, $, new M());
              Q(this, j, 0);
              Q(this, at, /* @__PURE__ */ new Set());
              Q(this, C, null);
              Q(this, U, null);
              Q(this, Y, /* @__PURE__ */ new Set());
              Q(this, S, null);
              Q(this, e, new gt());
              Q(this, i, !1);
              Q(this, u, !1);
              Q(this, x, null);
              Q(this, P, o.AnnotationEditorType.NONE);
              Q(this, k, /* @__PURE__ */ new Set());
              Q(this, G, null);
              Q(this, it, this.blur.bind(this));
              Q(this, ht, this.focus.bind(this));
              Q(this, dt, this.copy.bind(this));
              Q(this, mt, this.cut.bind(this));
              Q(this, At, this.paste.bind(this));
              Q(this, vt, this.keydown.bind(this));
              Q(this, K, this.onEditingAction.bind(this));
              Q(this, Z, this.onPageChanging.bind(this));
              Q(this, g, this.onScaleChanging.bind(this));
              Q(this, R, this.onRotationChanging.bind(this));
              Q(this, X, {
                isEditing: !1,
                isEmpty: !0,
                hasSomethingToUndo: !1,
                hasSomethingToRedo: !1,
                hasSelectedEditor: !1
              });
              Q(this, J, [0, 0]);
              Q(this, ut, null);
              Q(this, St, null);
              Q(this, yt, null);
              et(this, St, L), et(this, yt, ft), et(this, nt, Ct), this._eventBus = Dt, this._eventBus._on("editingaction", t(this, K)), this._eventBus._on("pagechanging", t(this, Z)), this._eventBus._on("scalechanging", t(this, g)), this._eventBus._on("rotationchanging", t(this, R)), et(this, W, Ot.annotationStorage), et(this, S, Ot.filterFactory), et(this, G, Pt), this.viewParameters = {
                realScale: T.PixelsPerInch.PDF_TO_CSS_UNITS,
                rotation: 0
              };
            }
            static get _keyboardManager() {
              const L = zt.prototype, ft = (Ot) => {
                const {
                  activeElement: Pt
                } = document;
                return Pt && t(Ot, St).contains(Pt) && Ot.hasSomethingToControl();
              }, Ct = this.TRANSLATE_SMALL, Dt = this.TRANSLATE_BIG;
              return (0, o.shadow)(this, "_keyboardManager", new m([[["ctrl+a", "mac+meta+a"], L.selectAll], [["ctrl+z", "mac+meta+z"], L.undo], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], L.redo], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], L.delete], [["Escape", "mac+Escape"], L.unselectAll], [["ArrowLeft", "mac+ArrowLeft"], L.translateSelectedEditors, {
                args: [-Ct, 0],
                checker: ft
              }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], L.translateSelectedEditors, {
                args: [-Dt, 0],
                checker: ft
              }], [["ArrowRight", "mac+ArrowRight"], L.translateSelectedEditors, {
                args: [Ct, 0],
                checker: ft
              }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], L.translateSelectedEditors, {
                args: [Dt, 0],
                checker: ft
              }], [["ArrowUp", "mac+ArrowUp"], L.translateSelectedEditors, {
                args: [0, -Ct],
                checker: ft
              }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], L.translateSelectedEditors, {
                args: [0, -Dt],
                checker: ft
              }], [["ArrowDown", "mac+ArrowDown"], L.translateSelectedEditors, {
                args: [0, Ct],
                checker: ft
              }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], L.translateSelectedEditors, {
                args: [0, Dt],
                checker: ft
              }]]));
            }
            destroy() {
              z(this, V, ye).call(this), z(this, V, je).call(this), this._eventBus._off("editingaction", t(this, K)), this._eventBus._off("pagechanging", t(this, Z)), this._eventBus._off("scalechanging", t(this, g)), this._eventBus._off("rotationchanging", t(this, R));
              for (const L of t(this, F).values())
                L.destroy();
              t(this, F).clear(), t(this, A).clear(), t(this, Y).clear(), et(this, r, null), t(this, k).clear(), t(this, $).destroy(), t(this, nt).destroy();
            }
            get hcmFilter() {
              return (0, o.shadow)(this, "hcmFilter", t(this, G) ? t(this, S).addHCMFilter(t(this, G).foreground, t(this, G).background) : "none");
            }
            get direction() {
              return (0, o.shadow)(this, "direction", getComputedStyle(t(this, St)).direction);
            }
            editAltText(L) {
              var ft;
              (ft = t(this, nt)) == null || ft.editAltText(this, L);
            }
            onPageChanging({
              pageNumber: L
            }) {
              et(this, j, L - 1);
            }
            focusMainContainer() {
              t(this, St).focus();
            }
            findParent(L, ft) {
              for (const Ct of t(this, F).values()) {
                const {
                  x: Dt,
                  y: Ot,
                  width: Pt,
                  height: w
                } = Ct.div.getBoundingClientRect();
                if (L >= Dt && L <= Dt + Pt && ft >= Ot && ft <= Ot + w)
                  return Ct;
              }
              return null;
            }
            disableUserSelect(L = !1) {
              t(this, yt).classList.toggle("noUserSelect", L);
            }
            addShouldRescale(L) {
              t(this, Y).add(L);
            }
            removeShouldRescale(L) {
              t(this, Y).delete(L);
            }
            onScaleChanging({
              scale: L
            }) {
              this.commitOrRemove(), this.viewParameters.realScale = L * T.PixelsPerInch.PDF_TO_CSS_UNITS;
              for (const ft of t(this, Y))
                ft.onScaleChanging();
            }
            onRotationChanging({
              pagesRotation: L
            }) {
              this.commitOrRemove(), this.viewParameters.rotation = L;
            }
            addToAnnotationStorage(L) {
              !L.isEmpty() && t(this, W) && !t(this, W).has(L.id) && t(this, W).setValue(L.id, L);
            }
            blur() {
              if (!this.hasSelection)
                return;
              const {
                activeElement: L
              } = document;
              for (const ft of t(this, k))
                if (ft.div.contains(L)) {
                  et(this, x, [ft, L]), ft._focusEventsAllowed = !1;
                  break;
                }
            }
            focus() {
              if (!t(this, x))
                return;
              const [L, ft] = t(this, x);
              et(this, x, null), ft.addEventListener("focusin", () => {
                L._focusEventsAllowed = !0;
              }, {
                once: !0
              }), ft.focus();
            }
            addEditListeners() {
              z(this, V, He).call(this), z(this, V, We).call(this);
            }
            removeEditListeners() {
              z(this, V, ye).call(this), z(this, V, Ge).call(this);
            }
            copy(L) {
              var Ct;
              if (L.preventDefault(), (Ct = t(this, r)) == null || Ct.commitOrRemove(), !this.hasSelection)
                return;
              const ft = [];
              for (const Dt of t(this, k)) {
                const Ot = Dt.serialize(!0);
                Ot && ft.push(Ot);
              }
              ft.length !== 0 && L.clipboardData.setData("application/pdfjs", JSON.stringify(ft));
            }
            cut(L) {
              this.copy(L), this.delete();
            }
            paste(L) {
              L.preventDefault();
              const {
                clipboardData: ft
              } = L;
              for (const Ot of ft.items)
                for (const Pt of t(this, U))
                  if (Pt.isHandlingMimeForPasting(Ot.type)) {
                    Pt.paste(Ot, this.currentLayer);
                    return;
                  }
              let Ct = ft.getData("application/pdfjs");
              if (!Ct)
                return;
              try {
                Ct = JSON.parse(Ct);
              } catch (Ot) {
                (0, o.warn)(`paste: "${Ot.message}".`);
                return;
              }
              if (!Array.isArray(Ct))
                return;
              this.unselectAll();
              const Dt = this.currentLayer;
              try {
                const Ot = [];
                for (const v of Ct) {
                  const H = Dt.deserialize(v);
                  if (!H)
                    return;
                  Ot.push(H);
                }
                const Pt = () => {
                  for (const v of Ot)
                    z(this, V, ze).call(this, v);
                  z(this, V, Xe).call(this, Ot);
                }, w = () => {
                  for (const v of Ot)
                    v.remove();
                };
                this.addCommands({
                  cmd: Pt,
                  undo: w,
                  mustExec: !0
                });
              } catch (Ot) {
                (0, o.warn)(`paste: "${Ot.message}".`);
              }
            }
            keydown(L) {
              var ft;
              (ft = this.getActive()) != null && ft.shouldGetKeyboardEvents() || zt._keyboardManager.exec(this, L);
            }
            onEditingAction(L) {
              ["undo", "redo", "delete", "selectAll"].includes(L.name) && this[L.name]();
            }
            setEditingState(L) {
              L ? (z(this, V, vi).call(this), z(this, V, He).call(this), z(this, V, We).call(this), z(this, V, Zt).call(this, {
                isEditing: t(this, P) !== o.AnnotationEditorType.NONE,
                isEmpty: z(this, V, ue).call(this),
                hasSomethingToUndo: t(this, $).hasSomethingToUndo(),
                hasSomethingToRedo: t(this, $).hasSomethingToRedo(),
                hasSelectedEditor: !1
              })) : (z(this, V, je).call(this), z(this, V, ye).call(this), z(this, V, Ge).call(this), z(this, V, Zt).call(this, {
                isEditing: !1
              }), this.disableUserSelect(!1));
            }
            registerEditorTypes(L) {
              if (!t(this, U)) {
                et(this, U, L);
                for (const ft of t(this, U))
                  z(this, V, de).call(this, ft.defaultPropertiesToUpdate);
              }
            }
            getId() {
              return t(this, e).getId();
            }
            get currentLayer() {
              return t(this, F).get(t(this, j));
            }
            getLayer(L) {
              return t(this, F).get(L);
            }
            get currentPageIndex() {
              return t(this, j);
            }
            addLayer(L) {
              t(this, F).set(L.pageIndex, L), t(this, i) ? L.enable() : L.disable();
            }
            removeLayer(L) {
              t(this, F).delete(L.pageIndex);
            }
            updateMode(L, ft = null) {
              if (t(this, P) !== L) {
                if (et(this, P, L), L === o.AnnotationEditorType.NONE) {
                  this.setEditingState(!1), z(this, V, Ei).call(this);
                  return;
                }
                this.setEditingState(!0), z(this, V, Si).call(this), this.unselectAll();
                for (const Ct of t(this, F).values())
                  Ct.updateMode(L);
                if (ft) {
                  for (const Ct of t(this, A).values())
                    if (Ct.annotationElementId === ft) {
                      this.setSelected(Ct), Ct.enterInEditMode();
                      break;
                    }
                }
              }
            }
            updateToolbar(L) {
              L !== t(this, P) && this._eventBus.dispatch("switchannotationeditormode", {
                source: this,
                mode: L
              });
            }
            updateParams(L, ft) {
              if (t(this, U)) {
                if (L === o.AnnotationEditorParamsType.CREATE) {
                  this.currentLayer.addNewEditor(L);
                  return;
                }
                for (const Ct of t(this, k))
                  Ct.updateParams(L, ft);
                for (const Ct of t(this, U))
                  Ct.updateDefaultParams(L, ft);
              }
            }
            enableWaiting(L = !1) {
              if (t(this, u) !== L) {
                et(this, u, L);
                for (const ft of t(this, F).values())
                  L ? ft.disableClick() : ft.enableClick(), ft.div.classList.toggle("waiting", L);
              }
            }
            getEditors(L) {
              const ft = [];
              for (const Ct of t(this, A).values())
                Ct.pageIndex === L && ft.push(Ct);
              return ft;
            }
            getEditor(L) {
              return t(this, A).get(L);
            }
            addEditor(L) {
              t(this, A).set(L.id, L);
            }
            removeEditor(L) {
              var ft;
              t(this, A).delete(L.id), this.unselect(L), (!L.annotationElementId || !t(this, at).has(L.annotationElementId)) && ((ft = t(this, W)) == null || ft.remove(L.id));
            }
            addDeletedAnnotationElement(L) {
              t(this, at).add(L.annotationElementId), L.deleted = !0;
            }
            isDeletedAnnotationElement(L) {
              return t(this, at).has(L);
            }
            removeDeletedAnnotationElement(L) {
              t(this, at).delete(L.annotationElementId), L.deleted = !1;
            }
            setActiveEditor(L) {
              t(this, r) !== L && (et(this, r, L), L && z(this, V, de).call(this, L.propertiesToUpdate));
            }
            toggleSelected(L) {
              if (t(this, k).has(L)) {
                t(this, k).delete(L), L.unselect(), z(this, V, Zt).call(this, {
                  hasSelectedEditor: this.hasSelection
                });
                return;
              }
              t(this, k).add(L), L.select(), z(this, V, de).call(this, L.propertiesToUpdate), z(this, V, Zt).call(this, {
                hasSelectedEditor: !0
              });
            }
            setSelected(L) {
              for (const ft of t(this, k))
                ft !== L && ft.unselect();
              t(this, k).clear(), t(this, k).add(L), L.select(), z(this, V, de).call(this, L.propertiesToUpdate), z(this, V, Zt).call(this, {
                hasSelectedEditor: !0
              });
            }
            isSelected(L) {
              return t(this, k).has(L);
            }
            unselect(L) {
              L.unselect(), t(this, k).delete(L), z(this, V, Zt).call(this, {
                hasSelectedEditor: this.hasSelection
              });
            }
            get hasSelection() {
              return t(this, k).size !== 0;
            }
            undo() {
              t(this, $).undo(), z(this, V, Zt).call(this, {
                hasSomethingToUndo: t(this, $).hasSomethingToUndo(),
                hasSomethingToRedo: !0,
                isEmpty: z(this, V, ue).call(this)
              });
            }
            redo() {
              t(this, $).redo(), z(this, V, Zt).call(this, {
                hasSomethingToUndo: !0,
                hasSomethingToRedo: t(this, $).hasSomethingToRedo(),
                isEmpty: z(this, V, ue).call(this)
              });
            }
            addCommands(L) {
              t(this, $).add(L), z(this, V, Zt).call(this, {
                hasSomethingToUndo: !0,
                hasSomethingToRedo: !1,
                isEmpty: z(this, V, ue).call(this)
              });
            }
            delete() {
              if (this.commitOrRemove(), !this.hasSelection)
                return;
              const L = [...t(this, k)], ft = () => {
                for (const Dt of L)
                  Dt.remove();
              }, Ct = () => {
                for (const Dt of L)
                  z(this, V, ze).call(this, Dt);
              };
              this.addCommands({
                cmd: ft,
                undo: Ct,
                mustExec: !0
              });
            }
            commitOrRemove() {
              var L;
              (L = t(this, r)) == null || L.commitOrRemove();
            }
            hasSomethingToControl() {
              return t(this, r) || this.hasSelection;
            }
            selectAll() {
              for (const L of t(this, k))
                L.commit();
              z(this, V, Xe).call(this, t(this, A).values());
            }
            unselectAll() {
              if (t(this, r)) {
                t(this, r).commitOrRemove();
                return;
              }
              if (this.hasSelection) {
                for (const L of t(this, k))
                  L.unselect();
                t(this, k).clear(), z(this, V, Zt).call(this, {
                  hasSelectedEditor: !1
                });
              }
            }
            translateSelectedEditors(L, ft, Ct = !1) {
              if (Ct || this.commitOrRemove(), !this.hasSelection)
                return;
              t(this, J)[0] += L, t(this, J)[1] += ft;
              const [Dt, Ot] = t(this, J), Pt = [...t(this, k)], w = 1e3;
              t(this, ut) && clearTimeout(t(this, ut)), et(this, ut, setTimeout(() => {
                et(this, ut, null), t(this, J)[0] = t(this, J)[1] = 0, this.addCommands({
                  cmd: () => {
                    for (const v of Pt)
                      t(this, A).has(v.id) && v.translateInPage(Dt, Ot);
                  },
                  undo: () => {
                    for (const v of Pt)
                      t(this, A).has(v.id) && v.translateInPage(-Dt, -Ot);
                  },
                  mustExec: !1
                });
              }, w));
              for (const v of Pt)
                v.translateInPage(L, ft);
            }
            setUpDragSession() {
              if (this.hasSelection) {
                this.disableUserSelect(!0), et(this, C, /* @__PURE__ */ new Map());
                for (const L of t(this, k))
                  t(this, C).set(L, {
                    savedX: L.x,
                    savedY: L.y,
                    savedPageIndex: L.pageIndex,
                    newX: 0,
                    newY: 0,
                    newPageIndex: -1
                  });
              }
            }
            endDragSession() {
              if (!t(this, C))
                return !1;
              this.disableUserSelect(!1);
              const L = t(this, C);
              et(this, C, null);
              let ft = !1;
              for (const [{
                x: Dt,
                y: Ot,
                pageIndex: Pt
              }, w] of L)
                w.newX = Dt, w.newY = Ot, w.newPageIndex = Pt, ft || (ft = Dt !== w.savedX || Ot !== w.savedY || Pt !== w.savedPageIndex);
              if (!ft)
                return !1;
              const Ct = (Dt, Ot, Pt, w) => {
                if (t(this, A).has(Dt.id)) {
                  const v = t(this, F).get(w);
                  v ? Dt._setParentAndPosition(v, Ot, Pt) : (Dt.pageIndex = w, Dt.x = Ot, Dt.y = Pt);
                }
              };
              return this.addCommands({
                cmd: () => {
                  for (const [Dt, {
                    newX: Ot,
                    newY: Pt,
                    newPageIndex: w
                  }] of L)
                    Ct(Dt, Ot, Pt, w);
                },
                undo: () => {
                  for (const [Dt, {
                    savedX: Ot,
                    savedY: Pt,
                    savedPageIndex: w
                  }] of L)
                    Ct(Dt, Ot, Pt, w);
                },
                mustExec: !0
              }), !0;
            }
            dragSelectedEditors(L, ft) {
              if (t(this, C))
                for (const Ct of t(this, C).keys())
                  Ct.drag(L, ft);
            }
            rebuild(L) {
              if (L.parent === null) {
                const ft = this.getLayer(L.pageIndex);
                ft ? (ft.changeParent(L), ft.addOrRebuild(L)) : (this.addEditor(L), this.addToAnnotationStorage(L), L.rebuild());
              } else
                L.parent.addOrRebuild(L);
            }
            isActive(L) {
              return t(this, r) === L;
            }
            getActive() {
              return t(this, r);
            }
            getMode() {
              return t(this, P);
            }
            get imageManager() {
              return (0, o.shadow)(this, "imageManager", new B());
            }
          };
          r = new WeakMap(), A = new WeakMap(), F = new WeakMap(), nt = new WeakMap(), W = new WeakMap(), $ = new WeakMap(), j = new WeakMap(), at = new WeakMap(), C = new WeakMap(), U = new WeakMap(), Y = new WeakMap(), S = new WeakMap(), e = new WeakMap(), i = new WeakMap(), u = new WeakMap(), x = new WeakMap(), P = new WeakMap(), k = new WeakMap(), G = new WeakMap(), it = new WeakMap(), ht = new WeakMap(), dt = new WeakMap(), mt = new WeakMap(), At = new WeakMap(), vt = new WeakMap(), K = new WeakMap(), Z = new WeakMap(), g = new WeakMap(), R = new WeakMap(), X = new WeakMap(), J = new WeakMap(), ut = new WeakMap(), St = new WeakMap(), yt = new WeakMap(), V = new WeakSet(), vi = function() {
            window.addEventListener("focus", t(this, ht)), window.addEventListener("blur", t(this, it));
          }, je = function() {
            window.removeEventListener("focus", t(this, ht)), window.removeEventListener("blur", t(this, it));
          }, He = function() {
            window.addEventListener("keydown", t(this, vt), {
              capture: !0
            });
          }, ye = function() {
            window.removeEventListener("keydown", t(this, vt), {
              capture: !0
            });
          }, We = function() {
            document.addEventListener("copy", t(this, dt)), document.addEventListener("cut", t(this, mt)), document.addEventListener("paste", t(this, At));
          }, Ge = function() {
            document.removeEventListener("copy", t(this, dt)), document.removeEventListener("cut", t(this, mt)), document.removeEventListener("paste", t(this, At));
          }, Zt = function(L) {
            Object.entries(L).some(([Ct, Dt]) => t(this, X)[Ct] !== Dt) && this._eventBus.dispatch("annotationeditorstateschanged", {
              source: this,
              details: Object.assign(t(this, X), L)
            });
          }, de = function(L) {
            this._eventBus.dispatch("annotationeditorparamschanged", {
              source: this,
              details: L
            });
          }, Si = function() {
            if (!t(this, i)) {
              et(this, i, !0);
              for (const L of t(this, F).values())
                L.enable();
            }
          }, Ei = function() {
            if (this.unselectAll(), t(this, i)) {
              et(this, i, !1);
              for (const L of t(this, F).values())
                L.disable();
            }
          }, ze = function(L) {
            const ft = t(this, F).get(L.pageIndex);
            ft ? ft.addOrRebuild(L) : this.addEditor(L);
          }, ue = function() {
            if (t(this, A).size === 0)
              return !0;
            if (t(this, A).size === 1)
              for (const L of t(this, A).values())
                return L.isEmpty();
            return !1;
          }, Xe = function(L) {
            t(this, k).clear();
            for (const ft of L)
              ft.isEmpty() || (t(this, k).add(ft), ft.select());
            z(this, V, Zt).call(this, {
              hasSelectedEditor: !0
            });
          }, Kt(zt, "TRANSLATE_SMALL", 1), Kt(zt, "TRANSLATE_BIG", 10);
          let I = zt;
          h.AnnotationEditorUIManager = I;
        },
        /* 6 */
        /***/
        (pt, h, rt) => {
          var j, at, C, U, Y, S, e, i, u, x, P, k, ae, oe, Ve, ve, Se, fe, pe;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.StatTimer = h.RenderingCancelledException = h.PixelsPerInch = h.PageViewport = h.PDFDateString = h.DOMStandardFontDataFactory = h.DOMSVGFactory = h.DOMFilterFactory = h.DOMCanvasFactory = h.DOMCMapReaderFactory = void 0, h.deprecated = s, h.getColorValues = A, h.getCurrentTransform = F, h.getCurrentTransformInverse = nt, h.getFilenameFromUrl = d, h.getPdfFilenameFromUrl = p, h.getRGB = r, h.getXfaPageViewport = O, h.isDataScheme = E, h.isPdfFile = f, h.isValidFetchUrl = y, h.loadScript = l, h.noContextMenu = n, h.setLayerDimensions = W;
          var o = rt(7), T = rt(1);
          const ct = "http://www.w3.org/2000/svg", $ = class $ {
          };
          Kt($, "CSS", 96), Kt($, "PDF", 72), Kt($, "PDF_TO_CSS_UNITS", $.CSS / $.PDF);
          let q = $;
          h.PixelsPerInch = q;
          class gt extends o.BaseFilterFactory {
            constructor({
              docId: g,
              ownerDocument: R = globalThis.document
            } = {}) {
              super();
              Q(this, k);
              Q(this, j);
              Q(this, at);
              Q(this, C);
              Q(this, U);
              Q(this, Y);
              Q(this, S);
              Q(this, e);
              Q(this, i);
              Q(this, u);
              Q(this, x);
              Q(this, P, 0);
              et(this, C, g), et(this, U, R);
            }
            addFilter(g) {
              if (!g)
                return "none";
              let R = t(this, k, ae).get(g);
              if (R)
                return R;
              let X, J, ut, St;
              if (g.length === 1) {
                const wt = g[0], jt = new Array(256);
                for (let Bt = 0; Bt < 256; Bt++)
                  jt[Bt] = wt[Bt] / 255;
                St = X = J = ut = jt.join(",");
              } else {
                const [wt, jt, Bt] = g, Xt = new Array(256), Ft = new Array(256), Nt = new Array(256);
                for (let Vt = 0; Vt < 256; Vt++)
                  Xt[Vt] = wt[Vt] / 255, Ft[Vt] = jt[Vt] / 255, Nt[Vt] = Bt[Vt] / 255;
                X = Xt.join(","), J = Ft.join(","), ut = Nt.join(","), St = `${X}${J}${ut}`;
              }
              if (R = t(this, k, ae).get(St), R)
                return t(this, k, ae).set(g, R), R;
              const yt = `g_${t(this, C)}_transfer_map_${he(this, P)._++}`, V = `url(#${yt})`;
              t(this, k, ae).set(g, V), t(this, k, ae).set(St, V);
              const Tt = z(this, k, ve).call(this, yt);
              return z(this, k, fe).call(this, X, J, ut, Tt), V;
            }
            addHCMFilter(g, R) {
              var jt;
              const X = `${g}-${R}`;
              if (t(this, S) === X)
                return t(this, e);
              if (et(this, S, X), et(this, e, "none"), (jt = t(this, Y)) == null || jt.remove(), !g || !R)
                return t(this, e);
              const J = z(this, k, pe).call(this, g);
              g = T.Util.makeHexColor(...J);
              const ut = z(this, k, pe).call(this, R);
              if (R = T.Util.makeHexColor(...ut), t(this, k, oe).style.color = "", g === "#000000" && R === "#ffffff" || g === R)
                return t(this, e);
              const St = new Array(256);
              for (let Bt = 0; Bt <= 255; Bt++) {
                const Xt = Bt / 255;
                St[Bt] = Xt <= 0.03928 ? Xt / 12.92 : ((Xt + 0.055) / 1.055) ** 2.4;
              }
              const yt = St.join(","), V = `g_${t(this, C)}_hcm_filter`, Tt = et(this, i, z(this, k, ve).call(this, V));
              z(this, k, fe).call(this, yt, yt, yt, Tt), z(this, k, Ve).call(this, Tt);
              const wt = (Bt, Xt) => {
                const Ft = J[Bt] / 255, Nt = ut[Bt] / 255, Vt = new Array(Xt + 1);
                for (let $t = 0; $t <= Xt; $t++)
                  Vt[$t] = Ft + $t / Xt * (Nt - Ft);
                return Vt.join(",");
              };
              return z(this, k, fe).call(this, wt(0, 5), wt(1, 5), wt(2, 5), Tt), et(this, e, `url(#${V})`), t(this, e);
            }
            addHighlightHCMFilter(g, R, X, J) {
              var Nt;
              const ut = `${g}-${R}-${X}-${J}`;
              if (t(this, u) === ut)
                return t(this, x);
              if (et(this, u, ut), et(this, x, "none"), (Nt = t(this, i)) == null || Nt.remove(), !g || !R)
                return t(this, x);
              const [St, yt] = [g, R].map(z(this, k, pe).bind(this));
              let V = Math.round(0.2126 * St[0] + 0.7152 * St[1] + 0.0722 * St[2]), Tt = Math.round(0.2126 * yt[0] + 0.7152 * yt[1] + 0.0722 * yt[2]), [wt, jt] = [X, J].map(z(this, k, pe).bind(this));
              Tt < V && ([V, Tt, wt, jt] = [Tt, V, jt, wt]), t(this, k, oe).style.color = "";
              const Bt = (Vt, $t, _t) => {
                const tt = new Array(256), st = (Tt - V) / _t, kt = Vt / 255, zt = ($t - Vt) / (255 * _t);
                let Gt = 0;
                for (let L = 0; L <= _t; L++) {
                  const ft = Math.round(V + L * st), Ct = kt + L * zt;
                  for (let Dt = Gt; Dt <= ft; Dt++)
                    tt[Dt] = Ct;
                  Gt = ft + 1;
                }
                for (let L = Gt; L < 256; L++)
                  tt[L] = tt[Gt - 1];
                return tt.join(",");
              }, Xt = `g_${t(this, C)}_hcm_highlight_filter`, Ft = et(this, i, z(this, k, ve).call(this, Xt));
              return z(this, k, Ve).call(this, Ft), z(this, k, fe).call(this, Bt(wt[0], jt[0], 5), Bt(wt[1], jt[1], 5), Bt(wt[2], jt[2], 5), Ft), et(this, x, `url(#${Xt})`), t(this, x);
            }
            destroy(g = !1) {
              g && (t(this, e) || t(this, x)) || (t(this, at) && (t(this, at).parentNode.parentNode.remove(), et(this, at, null)), t(this, j) && (t(this, j).clear(), et(this, j, null)), et(this, P, 0));
            }
          }
          j = new WeakMap(), at = new WeakMap(), C = new WeakMap(), U = new WeakMap(), Y = new WeakMap(), S = new WeakMap(), e = new WeakMap(), i = new WeakMap(), u = new WeakMap(), x = new WeakMap(), P = new WeakMap(), k = new WeakSet(), ae = function() {
            return t(this, j) || et(this, j, /* @__PURE__ */ new Map());
          }, oe = function() {
            if (!t(this, at)) {
              const g = t(this, U).createElement("div"), {
                style: R
              } = g;
              R.visibility = "hidden", R.contain = "strict", R.width = R.height = 0, R.position = "absolute", R.top = R.left = 0, R.zIndex = -1;
              const X = t(this, U).createElementNS(ct, "svg");
              X.setAttribute("width", 0), X.setAttribute("height", 0), et(this, at, t(this, U).createElementNS(ct, "defs")), g.append(X), X.append(t(this, at)), t(this, U).body.append(g);
            }
            return t(this, at);
          }, Ve = function(g) {
            const R = t(this, U).createElementNS(ct, "feColorMatrix");
            R.setAttribute("type", "matrix"), R.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), g.append(R);
          }, ve = function(g) {
            const R = t(this, U).createElementNS(ct, "filter");
            return R.setAttribute("color-interpolation-filters", "sRGB"), R.setAttribute("id", g), t(this, k, oe).append(R), R;
          }, Se = function(g, R, X) {
            const J = t(this, U).createElementNS(ct, R);
            J.setAttribute("type", "discrete"), J.setAttribute("tableValues", X), g.append(J);
          }, fe = function(g, R, X, J) {
            const ut = t(this, U).createElementNS(ct, "feComponentTransfer");
            J.append(ut), z(this, k, Se).call(this, ut, "feFuncR", g), z(this, k, Se).call(this, ut, "feFuncG", R), z(this, k, Se).call(this, ut, "feFuncB", X);
          }, pe = function(g) {
            return t(this, k, oe).style.color = g, r(getComputedStyle(t(this, k, oe)).getPropertyValue("color"));
          }, h.DOMFilterFactory = gt;
          class B extends o.BaseCanvasFactory {
            constructor({
              ownerDocument: Z = globalThis.document
            } = {}) {
              super(), this._document = Z;
            }
            _createCanvas(Z, g) {
              const R = this._document.createElement("canvas");
              return R.width = Z, R.height = g, R;
            }
          }
          h.DOMCanvasFactory = B;
          async function M(K, Z = !1) {
            if (y(K, document.baseURI)) {
              const g = await fetch(K);
              if (!g.ok)
                throw new Error(g.statusText);
              return Z ? new Uint8Array(await g.arrayBuffer()) : (0, T.stringToBytes)(await g.text());
            }
            return new Promise((g, R) => {
              const X = new XMLHttpRequest();
              X.open("GET", K, !0), Z && (X.responseType = "arraybuffer"), X.onreadystatechange = () => {
                if (X.readyState === XMLHttpRequest.DONE) {
                  if (X.status === 200 || X.status === 0) {
                    let J;
                    if (Z && X.response ? J = new Uint8Array(X.response) : !Z && X.responseText && (J = (0, T.stringToBytes)(X.responseText)), J) {
                      g(J);
                      return;
                    }
                  }
                  R(new Error(X.statusText));
                }
              }, X.send(null);
            });
          }
          class m extends o.BaseCMapReaderFactory {
            _fetchData(Z, g) {
              return M(Z, this.isCompressed).then((R) => ({
                cMapData: R,
                compressionType: g
              }));
            }
          }
          h.DOMCMapReaderFactory = m;
          class N extends o.BaseStandardFontDataFactory {
            _fetchData(Z) {
              return M(Z, !0);
            }
          }
          h.DOMStandardFontDataFactory = N;
          class I extends o.BaseSVGFactory {
            _createSVG(Z) {
              return document.createElementNS(ct, Z);
            }
          }
          h.DOMSVGFactory = I;
          class _ {
            constructor({
              viewBox: Z,
              scale: g,
              rotation: R,
              offsetX: X = 0,
              offsetY: J = 0,
              dontFlip: ut = !1
            }) {
              this.viewBox = Z, this.scale = g, this.rotation = R, this.offsetX = X, this.offsetY = J;
              const St = (Z[2] + Z[0]) / 2, yt = (Z[3] + Z[1]) / 2;
              let V, Tt, wt, jt;
              switch (R %= 360, R < 0 && (R += 360), R) {
                case 180:
                  V = -1, Tt = 0, wt = 0, jt = 1;
                  break;
                case 90:
                  V = 0, Tt = 1, wt = 1, jt = 0;
                  break;
                case 270:
                  V = 0, Tt = -1, wt = -1, jt = 0;
                  break;
                case 0:
                  V = 1, Tt = 0, wt = 0, jt = -1;
                  break;
                default:
                  throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
              }
              ut && (wt = -wt, jt = -jt);
              let Bt, Xt, Ft, Nt;
              V === 0 ? (Bt = Math.abs(yt - Z[1]) * g + X, Xt = Math.abs(St - Z[0]) * g + J, Ft = (Z[3] - Z[1]) * g, Nt = (Z[2] - Z[0]) * g) : (Bt = Math.abs(St - Z[0]) * g + X, Xt = Math.abs(yt - Z[1]) * g + J, Ft = (Z[2] - Z[0]) * g, Nt = (Z[3] - Z[1]) * g), this.transform = [V * g, Tt * g, wt * g, jt * g, Bt - V * g * St - wt * g * yt, Xt - Tt * g * St - jt * g * yt], this.width = Ft, this.height = Nt;
            }
            get rawDims() {
              const {
                viewBox: Z
              } = this;
              return (0, T.shadow)(this, "rawDims", {
                pageWidth: Z[2] - Z[0],
                pageHeight: Z[3] - Z[1],
                pageX: Z[0],
                pageY: Z[1]
              });
            }
            clone({
              scale: Z = this.scale,
              rotation: g = this.rotation,
              offsetX: R = this.offsetX,
              offsetY: X = this.offsetY,
              dontFlip: J = !1
            } = {}) {
              return new _({
                viewBox: this.viewBox.slice(),
                scale: Z,
                rotation: g,
                offsetX: R,
                offsetY: X,
                dontFlip: J
              });
            }
            convertToViewportPoint(Z, g) {
              return T.Util.applyTransform([Z, g], this.transform);
            }
            convertToViewportRectangle(Z) {
              const g = T.Util.applyTransform([Z[0], Z[1]], this.transform), R = T.Util.applyTransform([Z[2], Z[3]], this.transform);
              return [g[0], g[1], R[0], R[1]];
            }
            convertToPdfPoint(Z, g) {
              return T.Util.applyInverseTransform([Z, g], this.transform);
            }
          }
          h.PageViewport = _;
          class b extends T.BaseException {
            constructor(Z, g = 0) {
              super(Z, "RenderingCancelledException"), this.extraDelay = g;
            }
          }
          h.RenderingCancelledException = b;
          function E(K) {
            const Z = K.length;
            let g = 0;
            for (; g < Z && K[g].trim() === ""; )
              g++;
            return K.substring(g, g + 5).toLowerCase() === "data:";
          }
          function f(K) {
            return typeof K == "string" && /\.pdf$/i.test(K);
          }
          function d(K, Z = !1) {
            return Z || ([K] = K.split(/[#?]/, 1)), K.substring(K.lastIndexOf("/") + 1);
          }
          function p(K, Z = "document.pdf") {
            if (typeof K != "string")
              return Z;
            if (E(K))
              return (0, T.warn)('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), Z;
            const g = /^(?:(?:[^:]+:)?\/\/[^/]+)?([^?#]*)(\?[^#]*)?(#.*)?$/, R = /[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i, X = g.exec(K);
            let J = R.exec(X[1]) || R.exec(X[2]) || R.exec(X[3]);
            if (J && (J = J[0], J.includes("%")))
              try {
                J = R.exec(decodeURIComponent(J))[0];
              } catch {
              }
            return J || Z;
          }
          class D {
            constructor() {
              Kt(this, "started", /* @__PURE__ */ Object.create(null));
              Kt(this, "times", []);
            }
            time(Z) {
              Z in this.started && (0, T.warn)(`Timer is already running for ${Z}`), this.started[Z] = Date.now();
            }
            timeEnd(Z) {
              Z in this.started || (0, T.warn)(`Timer has not been started for ${Z}`), this.times.push({
                name: Z,
                start: this.started[Z],
                end: Date.now()
              }), delete this.started[Z];
            }
            toString() {
              const Z = [];
              let g = 0;
              for (const {
                name: R
              } of this.times)
                g = Math.max(R.length, g);
              for (const {
                name: R,
                start: X,
                end: J
              } of this.times)
                Z.push(`${R.padEnd(g)} ${J - X}ms
`);
              return Z.join("");
            }
          }
          h.StatTimer = D;
          function y(K, Z) {
            try {
              const {
                protocol: g
              } = Z ? new URL(K, Z) : new URL(K);
              return g === "http:" || g === "https:";
            } catch {
              return !1;
            }
          }
          function n(K) {
            K.preventDefault();
          }
          function l(K, Z = !1) {
            return new Promise((g, R) => {
              const X = document.createElement("script");
              X.src = K, X.onload = function(J) {
                Z && X.remove(), g(J);
              }, X.onerror = function() {
                R(new Error(`Cannot load script at: ${X.src}`));
              }, (document.head || document.documentElement).append(X);
            });
          }
          function s(K) {
            console.log("Deprecated API usage: " + K);
          }
          let a;
          class c {
            static toDateObject(Z) {
              if (!Z || typeof Z != "string")
                return null;
              a || (a = new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?"));
              const g = a.exec(Z);
              if (!g)
                return null;
              const R = parseInt(g[1], 10);
              let X = parseInt(g[2], 10);
              X = X >= 1 && X <= 12 ? X - 1 : 0;
              let J = parseInt(g[3], 10);
              J = J >= 1 && J <= 31 ? J : 1;
              let ut = parseInt(g[4], 10);
              ut = ut >= 0 && ut <= 23 ? ut : 0;
              let St = parseInt(g[5], 10);
              St = St >= 0 && St <= 59 ? St : 0;
              let yt = parseInt(g[6], 10);
              yt = yt >= 0 && yt <= 59 ? yt : 0;
              const V = g[7] || "Z";
              let Tt = parseInt(g[8], 10);
              Tt = Tt >= 0 && Tt <= 23 ? Tt : 0;
              let wt = parseInt(g[9], 10) || 0;
              return wt = wt >= 0 && wt <= 59 ? wt : 0, V === "-" ? (ut += Tt, St += wt) : V === "+" && (ut -= Tt, St -= wt), new Date(Date.UTC(R, X, J, ut, St, yt));
            }
          }
          h.PDFDateString = c;
          function O(K, {
            scale: Z = 1,
            rotation: g = 0
          }) {
            const {
              width: R,
              height: X
            } = K.attributes.style, J = [0, 0, parseInt(R), parseInt(X)];
            return new _({
              viewBox: J,
              scale: Z,
              rotation: g
            });
          }
          function r(K) {
            if (K.startsWith("#")) {
              const Z = parseInt(K.slice(1), 16);
              return [(Z & 16711680) >> 16, (Z & 65280) >> 8, Z & 255];
            }
            return K.startsWith("rgb(") ? K.slice(4, -1).split(",").map((Z) => parseInt(Z)) : K.startsWith("rgba(") ? K.slice(5, -1).split(",").map((Z) => parseInt(Z)).slice(0, 3) : ((0, T.warn)(`Not a valid color format: "${K}"`), [0, 0, 0]);
          }
          function A(K) {
            const Z = document.createElement("span");
            Z.style.visibility = "hidden", document.body.append(Z);
            for (const g of K.keys()) {
              Z.style.color = g;
              const R = window.getComputedStyle(Z).color;
              K.set(g, r(R));
            }
            Z.remove();
          }
          function F(K) {
            const {
              a: Z,
              b: g,
              c: R,
              d: X,
              e: J,
              f: ut
            } = K.getTransform();
            return [Z, g, R, X, J, ut];
          }
          function nt(K) {
            const {
              a: Z,
              b: g,
              c: R,
              d: X,
              e: J,
              f: ut
            } = K.getTransform().invertSelf();
            return [Z, g, R, X, J, ut];
          }
          function W(K, Z, g = !1, R = !0) {
            if (Z instanceof _) {
              const {
                pageWidth: X,
                pageHeight: J
              } = Z.rawDims, {
                style: ut
              } = K, St = T.FeatureTest.isCSSRoundSupported, yt = `var(--scale-factor) * ${X}px`, V = `var(--scale-factor) * ${J}px`, Tt = St ? `round(${yt}, 1px)` : `calc(${yt})`, wt = St ? `round(${V}, 1px)` : `calc(${V})`;
              !g || Z.rotation % 180 === 0 ? (ut.width = Tt, ut.height = wt) : (ut.width = wt, ut.height = Tt);
            }
            R && K.setAttribute("data-main-rotation", Z.rotation);
          }
        },
        /* 7 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.BaseStandardFontDataFactory = h.BaseSVGFactory = h.BaseFilterFactory = h.BaseCanvasFactory = h.BaseCMapReaderFactory = void 0;
          var o = rt(1);
          class T {
            constructor() {
              this.constructor === T && (0, o.unreachable)("Cannot initialize BaseFilterFactory.");
            }
            addFilter(m) {
              return "none";
            }
            addHCMFilter(m, N) {
              return "none";
            }
            addHighlightHCMFilter(m, N, I, _) {
              return "none";
            }
            destroy(m = !1) {
            }
          }
          h.BaseFilterFactory = T;
          class ct {
            constructor() {
              this.constructor === ct && (0, o.unreachable)("Cannot initialize BaseCanvasFactory.");
            }
            create(m, N) {
              if (m <= 0 || N <= 0)
                throw new Error("Invalid canvas size");
              const I = this._createCanvas(m, N);
              return {
                canvas: I,
                context: I.getContext("2d")
              };
            }
            reset(m, N, I) {
              if (!m.canvas)
                throw new Error("Canvas is not specified");
              if (N <= 0 || I <= 0)
                throw new Error("Invalid canvas size");
              m.canvas.width = N, m.canvas.height = I;
            }
            destroy(m) {
              if (!m.canvas)
                throw new Error("Canvas is not specified");
              m.canvas.width = 0, m.canvas.height = 0, m.canvas = null, m.context = null;
            }
            _createCanvas(m, N) {
              (0, o.unreachable)("Abstract method `_createCanvas` called.");
            }
          }
          h.BaseCanvasFactory = ct;
          class q {
            constructor({
              baseUrl: m = null,
              isCompressed: N = !0
            }) {
              this.constructor === q && (0, o.unreachable)("Cannot initialize BaseCMapReaderFactory."), this.baseUrl = m, this.isCompressed = N;
            }
            async fetch({
              name: m
            }) {
              if (!this.baseUrl)
                throw new Error('The CMap "baseUrl" parameter must be specified, ensure that the "cMapUrl" and "cMapPacked" API parameters are provided.');
              if (!m)
                throw new Error("CMap name must be specified.");
              const N = this.baseUrl + m + (this.isCompressed ? ".bcmap" : ""), I = this.isCompressed ? o.CMapCompressionType.BINARY : o.CMapCompressionType.NONE;
              return this._fetchData(N, I).catch((_) => {
                throw new Error(`Unable to load ${this.isCompressed ? "binary " : ""}CMap at: ${N}`);
              });
            }
            _fetchData(m, N) {
              (0, o.unreachable)("Abstract method `_fetchData` called.");
            }
          }
          h.BaseCMapReaderFactory = q;
          class gt {
            constructor({
              baseUrl: m = null
            }) {
              this.constructor === gt && (0, o.unreachable)("Cannot initialize BaseStandardFontDataFactory."), this.baseUrl = m;
            }
            async fetch({
              filename: m
            }) {
              if (!this.baseUrl)
                throw new Error('The standard font "baseUrl" parameter must be specified, ensure that the "standardFontDataUrl" API parameter is provided.');
              if (!m)
                throw new Error("Font filename must be specified.");
              const N = `${this.baseUrl}${m}`;
              return this._fetchData(N).catch((I) => {
                throw new Error(`Unable to load font data at: ${N}`);
              });
            }
            _fetchData(m) {
              (0, o.unreachable)("Abstract method `_fetchData` called.");
            }
          }
          h.BaseStandardFontDataFactory = gt;
          class B {
            constructor() {
              this.constructor === B && (0, o.unreachable)("Cannot initialize BaseSVGFactory.");
            }
            create(m, N, I = !1) {
              if (m <= 0 || N <= 0)
                throw new Error("Invalid SVG dimensions");
              const _ = this._createSVG("svg:svg");
              return _.setAttribute("version", "1.1"), I || (_.setAttribute("width", `${m}px`), _.setAttribute("height", `${N}px`)), _.setAttribute("preserveAspectRatio", "none"), _.setAttribute("viewBox", `0 0 ${m} ${N}`), _;
            }
            createElement(m) {
              if (typeof m != "string")
                throw new Error("Invalid SVG element type");
              return this._createSVG(m);
            }
            _createSVG(m) {
              (0, o.unreachable)("Abstract method `_createSVG` called.");
            }
          }
          h.BaseSVGFactory = B;
        },
        /* 8 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.MurmurHash3_64 = void 0;
          var o = rt(1);
          const T = 3285377520, ct = 4294901760, q = 65535;
          class gt {
            constructor(M) {
              this.h1 = M ? M & 4294967295 : T, this.h2 = M ? M & 4294967295 : T;
            }
            update(M) {
              let m, N;
              if (typeof M == "string") {
                m = new Uint8Array(M.length * 2), N = 0;
                for (let s = 0, a = M.length; s < a; s++) {
                  const c = M.charCodeAt(s);
                  c <= 255 ? m[N++] = c : (m[N++] = c >>> 8, m[N++] = c & 255);
                }
              } else if ((0, o.isArrayBuffer)(M))
                m = M.slice(), N = m.byteLength;
              else
                throw new Error("Wrong data format in MurmurHash3_64_update. Input must be a string or array.");
              const I = N >> 2, _ = N - I * 4, b = new Uint32Array(m.buffer, 0, I);
              let E = 0, f = 0, d = this.h1, p = this.h2;
              const D = 3432918353, y = 461845907, n = D & q, l = y & q;
              for (let s = 0; s < I; s++)
                s & 1 ? (E = b[s], E = E * D & ct | E * n & q, E = E << 15 | E >>> 17, E = E * y & ct | E * l & q, d ^= E, d = d << 13 | d >>> 19, d = d * 5 + 3864292196) : (f = b[s], f = f * D & ct | f * n & q, f = f << 15 | f >>> 17, f = f * y & ct | f * l & q, p ^= f, p = p << 13 | p >>> 19, p = p * 5 + 3864292196);
              switch (E = 0, _) {
                case 3:
                  E ^= m[I * 4 + 2] << 16;
                case 2:
                  E ^= m[I * 4 + 1] << 8;
                case 1:
                  E ^= m[I * 4], E = E * D & ct | E * n & q, E = E << 15 | E >>> 17, E = E * y & ct | E * l & q, I & 1 ? d ^= E : p ^= E;
              }
              this.h1 = d, this.h2 = p;
            }
            hexdigest() {
              let M = this.h1, m = this.h2;
              return M ^= m >>> 1, M = M * 3981806797 & ct | M * 36045 & q, m = m * 4283543511 & ct | ((m << 16 | M >>> 16) * 2950163797 & ct) >>> 16, M ^= m >>> 1, M = M * 444984403 & ct | M * 60499 & q, m = m * 3301882366 & ct | ((m << 16 | M >>> 16) * 3120437893 & ct) >>> 16, M ^= m >>> 1, (M >>> 0).toString(16).padStart(8, "0") + (m >>> 0).toString(16).padStart(8, "0");
            }
          }
          h.MurmurHash3_64 = gt;
        },
        /* 9 */
        /***/
        (pt, h, rt) => {
          var q;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.FontLoader = h.FontFaceObject = void 0;
          var o = rt(1);
          class T {
            constructor({
              ownerDocument: B = globalThis.document,
              styleElement: M = null
            }) {
              Q(this, q, /* @__PURE__ */ new Set());
              this._document = B, this.nativeFontFaces = /* @__PURE__ */ new Set(), this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
            }
            addNativeFontFace(B) {
              this.nativeFontFaces.add(B), this._document.fonts.add(B);
            }
            removeNativeFontFace(B) {
              this.nativeFontFaces.delete(B), this._document.fonts.delete(B);
            }
            insertRule(B) {
              this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));
              const M = this.styleElement.sheet;
              M.insertRule(B, M.cssRules.length);
            }
            clear() {
              for (const B of this.nativeFontFaces)
                this._document.fonts.delete(B);
              this.nativeFontFaces.clear(), t(this, q).clear(), this.styleElement && (this.styleElement.remove(), this.styleElement = null);
            }
            async loadSystemFont(B) {
              if (!(!B || t(this, q).has(B.loadedName))) {
                if ((0, o.assert)(!this.disableFontFace, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
                  const {
                    loadedName: M,
                    src: m,
                    style: N
                  } = B, I = new FontFace(M, m, N);
                  this.addNativeFontFace(I);
                  try {
                    await I.load(), t(this, q).add(M);
                  } catch {
                    (0, o.warn)(`Cannot load system font: ${B.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(I);
                  }
                  return;
                }
                (0, o.unreachable)("Not implemented: loadSystemFont without the Font Loading API.");
              }
            }
            async bind(B) {
              if (B.attached || B.missingFile && !B.systemFontInfo)
                return;
              if (B.attached = !0, B.systemFontInfo) {
                await this.loadSystemFont(B.systemFontInfo);
                return;
              }
              if (this.isFontLoadingAPISupported) {
                const m = B.createNativeFontFace();
                if (m) {
                  this.addNativeFontFace(m);
                  try {
                    await m.loaded;
                  } catch (N) {
                    throw (0, o.warn)(`Failed to load font '${m.family}': '${N}'.`), B.disableFontFace = !0, N;
                  }
                }
                return;
              }
              const M = B.createFontFaceRule();
              if (M) {
                if (this.insertRule(M), this.isSyncFontLoadingSupported)
                  return;
                await new Promise((m) => {
                  const N = this._queueLoadingCallback(m);
                  this._prepareFontLoadEvent(B, N);
                });
              }
            }
            get isFontLoadingAPISupported() {
              var M;
              const B = !!((M = this._document) != null && M.fonts);
              return (0, o.shadow)(this, "isFontLoadingAPISupported", B);
            }
            get isSyncFontLoadingSupported() {
              let B = !1;
              return (o.isNodeJS || typeof navigator < "u" && /Mozilla\/5.0.*?rv:\d+.*? Gecko/.test(navigator.userAgent)) && (B = !0), (0, o.shadow)(this, "isSyncFontLoadingSupported", B);
            }
            _queueLoadingCallback(B) {
              function M() {
                for ((0, o.assert)(!N.done, "completeRequest() cannot be called twice."), N.done = !0; m.length > 0 && m[0].done; ) {
                  const I = m.shift();
                  setTimeout(I.callback, 0);
                }
              }
              const {
                loadingRequests: m
              } = this, N = {
                done: !1,
                complete: M,
                callback: B
              };
              return m.push(N), N;
            }
            get _loadTestFont() {
              const B = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
              return (0, o.shadow)(this, "_loadTestFont", B);
            }
            _prepareFontLoadEvent(B, M) {
              function m(r, A) {
                return r.charCodeAt(A) << 24 | r.charCodeAt(A + 1) << 16 | r.charCodeAt(A + 2) << 8 | r.charCodeAt(A + 3) & 255;
              }
              function N(r, A, F, nt) {
                const W = r.substring(0, A), $ = r.substring(A + F);
                return W + nt + $;
              }
              let I, _;
              const b = this._document.createElement("canvas");
              b.width = 1, b.height = 1;
              const E = b.getContext("2d");
              let f = 0;
              function d(r, A) {
                if (++f > 30) {
                  (0, o.warn)("Load test font never loaded."), A();
                  return;
                }
                if (E.font = "30px " + r, E.fillText(".", 0, 20), E.getImageData(0, 0, 1, 1).data[3] > 0) {
                  A();
                  return;
                }
                setTimeout(d.bind(null, r, A));
              }
              const p = `lt${Date.now()}${this.loadTestFontId++}`;
              let D = this._loadTestFont;
              D = N(D, 976, p.length, p);
              const n = 16, l = 1482184792;
              let s = m(D, n);
              for (I = 0, _ = p.length - 3; I < _; I += 4)
                s = s - l + m(p, I) | 0;
              I < p.length && (s = s - l + m(p + "XXX", I) | 0), D = N(D, n, 4, (0, o.string32)(s));
              const a = `url(data:font/opentype;base64,${btoa(D)});`, c = `@font-face {font-family:"${p}";src:${a}}`;
              this.insertRule(c);
              const O = this._document.createElement("div");
              O.style.visibility = "hidden", O.style.width = O.style.height = "10px", O.style.position = "absolute", O.style.top = O.style.left = "0px";
              for (const r of [B.loadedName, p]) {
                const A = this._document.createElement("span");
                A.textContent = "Hi", A.style.fontFamily = r, O.append(A);
              }
              this._document.body.append(O), d(p, () => {
                O.remove(), M.complete();
              });
            }
          }
          q = new WeakMap(), h.FontLoader = T;
          class ct {
            constructor(B, {
              isEvalSupported: M = !0,
              disableFontFace: m = !1,
              ignoreErrors: N = !1,
              inspectFont: I = null
            }) {
              this.compiledGlyphs = /* @__PURE__ */ Object.create(null);
              for (const _ in B)
                this[_] = B[_];
              this.isEvalSupported = M !== !1, this.disableFontFace = m === !0, this.ignoreErrors = N === !0, this._inspectFont = I;
            }
            createNativeFontFace() {
              var M;
              if (!this.data || this.disableFontFace)
                return null;
              let B;
              if (!this.cssFontInfo)
                B = new FontFace(this.loadedName, this.data, {});
              else {
                const m = {
                  weight: this.cssFontInfo.fontWeight
                };
                this.cssFontInfo.italicAngle && (m.style = `oblique ${this.cssFontInfo.italicAngle}deg`), B = new FontFace(this.cssFontInfo.fontFamily, this.data, m);
              }
              return (M = this._inspectFont) == null || M.call(this, this), B;
            }
            createFontFaceRule() {
              var N;
              if (!this.data || this.disableFontFace)
                return null;
              const B = (0, o.bytesToString)(this.data), M = `url(data:${this.mimetype};base64,${btoa(B)});`;
              let m;
              if (!this.cssFontInfo)
                m = `@font-face {font-family:"${this.loadedName}";src:${M}}`;
              else {
                let I = `font-weight: ${this.cssFontInfo.fontWeight};`;
                this.cssFontInfo.italicAngle && (I += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), m = `@font-face {font-family:"${this.cssFontInfo.fontFamily}";${I}src:${M}}`;
              }
              return (N = this._inspectFont) == null || N.call(this, this, M), m;
            }
            getPathGenerator(B, M) {
              if (this.compiledGlyphs[M] !== void 0)
                return this.compiledGlyphs[M];
              let m;
              try {
                m = B.get(this.loadedName + "_path_" + M);
              } catch (N) {
                if (!this.ignoreErrors)
                  throw N;
                return (0, o.warn)(`getPathGenerator - ignoring character: "${N}".`), this.compiledGlyphs[M] = function(I, _) {
                };
              }
              if (this.isEvalSupported && o.FeatureTest.isEvalSupported) {
                const N = [];
                for (const I of m) {
                  const _ = I.args !== void 0 ? I.args.join(",") : "";
                  N.push("c.", I.cmd, "(", _, `);
`);
                }
                return this.compiledGlyphs[M] = new Function("c", "size", N.join(""));
              }
              return this.compiledGlyphs[M] = function(N, I) {
                for (const _ of m)
                  _.cmd === "scale" && (_.args = [I, -I]), N[_.cmd].apply(N, _.args);
              };
            }
          }
          h.FontFaceObject = ct;
        },
        /* 10 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.NodeStandardFontDataFactory = h.NodeFilterFactory = h.NodeCanvasFactory = h.NodeCMapReaderFactory = void 0;
          var o = rt(7);
          rt(1);
          const T = function(M) {
            return new Promise((m, N) => {
              require$$5.readFile(M, (_, b) => {
                if (_ || !b) {
                  N(new Error(_));
                  return;
                }
                m(new Uint8Array(b));
              });
            });
          };
          class ct extends o.BaseFilterFactory {
          }
          h.NodeFilterFactory = ct;
          class q extends o.BaseCanvasFactory {
            _createCanvas(m, N) {
              return require$$5.createCanvas(m, N);
            }
          }
          h.NodeCanvasFactory = q;
          class gt extends o.BaseCMapReaderFactory {
            _fetchData(m, N) {
              return T(m).then((I) => ({
                cMapData: I,
                compressionType: N
              }));
            }
          }
          h.NodeCMapReaderFactory = gt;
          class B extends o.BaseStandardFontDataFactory {
            _fetchData(m) {
              return T(m);
            }
          }
          h.NodeStandardFontDataFactory = B;
        },
        /* 11 */
        /***/
        (pt, h, rt) => {
          var at, qe, $e;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.CanvasGraphics = void 0;
          var o = rt(1), T = rt(6), ct = rt(12), q = rt(13);
          const gt = 16, B = 100, M = 4096, m = 15, N = 10, I = 1e3, _ = 16;
          function b(S, e) {
            if (S._removeMirroring)
              throw new Error("Context is already forwarding operations.");
            S.__originalSave = S.save, S.__originalRestore = S.restore, S.__originalRotate = S.rotate, S.__originalScale = S.scale, S.__originalTranslate = S.translate, S.__originalTransform = S.transform, S.__originalSetTransform = S.setTransform, S.__originalResetTransform = S.resetTransform, S.__originalClip = S.clip, S.__originalMoveTo = S.moveTo, S.__originalLineTo = S.lineTo, S.__originalBezierCurveTo = S.bezierCurveTo, S.__originalRect = S.rect, S.__originalClosePath = S.closePath, S.__originalBeginPath = S.beginPath, S._removeMirroring = () => {
              S.save = S.__originalSave, S.restore = S.__originalRestore, S.rotate = S.__originalRotate, S.scale = S.__originalScale, S.translate = S.__originalTranslate, S.transform = S.__originalTransform, S.setTransform = S.__originalSetTransform, S.resetTransform = S.__originalResetTransform, S.clip = S.__originalClip, S.moveTo = S.__originalMoveTo, S.lineTo = S.__originalLineTo, S.bezierCurveTo = S.__originalBezierCurveTo, S.rect = S.__originalRect, S.closePath = S.__originalClosePath, S.beginPath = S.__originalBeginPath, delete S._removeMirroring;
            }, S.save = function() {
              e.save(), this.__originalSave();
            }, S.restore = function() {
              e.restore(), this.__originalRestore();
            }, S.translate = function(u, x) {
              e.translate(u, x), this.__originalTranslate(u, x);
            }, S.scale = function(u, x) {
              e.scale(u, x), this.__originalScale(u, x);
            }, S.transform = function(u, x, P, k, G, it) {
              e.transform(u, x, P, k, G, it), this.__originalTransform(u, x, P, k, G, it);
            }, S.setTransform = function(u, x, P, k, G, it) {
              e.setTransform(u, x, P, k, G, it), this.__originalSetTransform(u, x, P, k, G, it);
            }, S.resetTransform = function() {
              e.resetTransform(), this.__originalResetTransform();
            }, S.rotate = function(u) {
              e.rotate(u), this.__originalRotate(u);
            }, S.clip = function(u) {
              e.clip(u), this.__originalClip(u);
            }, S.moveTo = function(i, u) {
              e.moveTo(i, u), this.__originalMoveTo(i, u);
            }, S.lineTo = function(i, u) {
              e.lineTo(i, u), this.__originalLineTo(i, u);
            }, S.bezierCurveTo = function(i, u, x, P, k, G) {
              e.bezierCurveTo(i, u, x, P, k, G), this.__originalBezierCurveTo(i, u, x, P, k, G);
            }, S.rect = function(i, u, x, P) {
              e.rect(i, u, x, P), this.__originalRect(i, u, x, P);
            }, S.closePath = function() {
              e.closePath(), this.__originalClosePath();
            }, S.beginPath = function() {
              e.beginPath(), this.__originalBeginPath();
            };
          }
          class E {
            constructor(e) {
              this.canvasFactory = e, this.cache = /* @__PURE__ */ Object.create(null);
            }
            getCanvas(e, i, u) {
              let x;
              return this.cache[e] !== void 0 ? (x = this.cache[e], this.canvasFactory.reset(x, i, u)) : (x = this.canvasFactory.create(i, u), this.cache[e] = x), x;
            }
            delete(e) {
              delete this.cache[e];
            }
            clear() {
              for (const e in this.cache) {
                const i = this.cache[e];
                this.canvasFactory.destroy(i), delete this.cache[e];
              }
            }
          }
          function f(S, e, i, u, x, P, k, G, it, ht) {
            const [dt, mt, At, vt, K, Z] = (0, T.getCurrentTransform)(S);
            if (mt === 0 && At === 0) {
              const X = k * dt + K, J = Math.round(X), ut = G * vt + Z, St = Math.round(ut), yt = (k + it) * dt + K, V = Math.abs(Math.round(yt) - J) || 1, Tt = (G + ht) * vt + Z, wt = Math.abs(Math.round(Tt) - St) || 1;
              return S.setTransform(Math.sign(dt), 0, 0, Math.sign(vt), J, St), S.drawImage(e, i, u, x, P, 0, 0, V, wt), S.setTransform(dt, mt, At, vt, K, Z), [V, wt];
            }
            if (dt === 0 && vt === 0) {
              const X = G * At + K, J = Math.round(X), ut = k * mt + Z, St = Math.round(ut), yt = (G + ht) * At + K, V = Math.abs(Math.round(yt) - J) || 1, Tt = (k + it) * mt + Z, wt = Math.abs(Math.round(Tt) - St) || 1;
              return S.setTransform(0, Math.sign(mt), Math.sign(At), 0, J, St), S.drawImage(e, i, u, x, P, 0, 0, wt, V), S.setTransform(dt, mt, At, vt, K, Z), [wt, V];
            }
            S.drawImage(e, i, u, x, P, k, G, it, ht);
            const g = Math.hypot(dt, mt), R = Math.hypot(At, vt);
            return [g * it, R * ht];
          }
          function d(S) {
            const {
              width: e,
              height: i
            } = S;
            if (e > I || i > I)
              return null;
            const u = 1e3, x = new Uint8Array([0, 2, 4, 0, 1, 0, 5, 4, 8, 10, 0, 8, 0, 2, 1, 0]), P = e + 1;
            let k = new Uint8Array(P * (i + 1)), G, it, ht;
            const dt = e + 7 & -8;
            let mt = new Uint8Array(dt * i), At = 0;
            for (const R of S.data) {
              let X = 128;
              for (; X > 0; )
                mt[At++] = R & X ? 0 : 255, X >>= 1;
            }
            let vt = 0;
            for (At = 0, mt[At] !== 0 && (k[0] = 1, ++vt), it = 1; it < e; it++)
              mt[At] !== mt[At + 1] && (k[it] = mt[At] ? 2 : 1, ++vt), At++;
            for (mt[At] !== 0 && (k[it] = 2, ++vt), G = 1; G < i; G++) {
              At = G * dt, ht = G * P, mt[At - dt] !== mt[At] && (k[ht] = mt[At] ? 1 : 8, ++vt);
              let R = (mt[At] ? 4 : 0) + (mt[At - dt] ? 8 : 0);
              for (it = 1; it < e; it++)
                R = (R >> 2) + (mt[At + 1] ? 4 : 0) + (mt[At - dt + 1] ? 8 : 0), x[R] && (k[ht + it] = x[R], ++vt), At++;
              if (mt[At - dt] !== mt[At] && (k[ht + it] = mt[At] ? 2 : 4, ++vt), vt > u)
                return null;
            }
            for (At = dt * (i - 1), ht = G * P, mt[At] !== 0 && (k[ht] = 8, ++vt), it = 1; it < e; it++)
              mt[At] !== mt[At + 1] && (k[ht + it] = mt[At] ? 4 : 8, ++vt), At++;
            if (mt[At] !== 0 && (k[ht + it] = 4, ++vt), vt > u)
              return null;
            const K = new Int32Array([0, P, -1, 0, -P, 0, 0, 0, 1]), Z = new Path2D();
            for (G = 0; vt && G <= i; G++) {
              let R = G * P;
              const X = R + e;
              for (; R < X && !k[R]; )
                R++;
              if (R === X)
                continue;
              Z.moveTo(R % P, G);
              const J = R;
              let ut = k[R];
              do {
                const St = K[ut];
                do
                  R += St;
                while (!k[R]);
                const yt = k[R];
                yt !== 5 && yt !== 10 ? (ut = yt, k[R] = 0) : (ut = yt & 51 * ut >> 4, k[R] &= ut >> 2 | ut << 2), Z.lineTo(R % P, R / P | 0), k[R] || --vt;
              } while (J !== R);
              --G;
            }
            return mt = null, k = null, function(R) {
              R.save(), R.scale(1 / e, -1 / i), R.translate(0, -i), R.fill(Z), R.beginPath(), R.restore();
            };
          }
          class p {
            constructor(e, i) {
              this.alphaIsShape = !1, this.fontSize = 0, this.fontSizeScale = 1, this.textMatrix = o.IDENTITY_MATRIX, this.textMatrixScale = 1, this.fontMatrix = o.FONT_IDENTITY_MATRIX, this.leading = 0, this.x = 0, this.y = 0, this.lineX = 0, this.lineY = 0, this.charSpacing = 0, this.wordSpacing = 0, this.textHScale = 1, this.textRenderingMode = o.TextRenderingMode.FILL, this.textRise = 0, this.fillColor = "#000000", this.strokeColor = "#000000", this.patternFill = !1, this.fillAlpha = 1, this.strokeAlpha = 1, this.lineWidth = 1, this.activeSMask = null, this.transferMaps = "none", this.startNewPathAndClipBox([0, 0, e, i]);
            }
            clone() {
              const e = Object.create(this);
              return e.clipBox = this.clipBox.slice(), e;
            }
            setCurrentPoint(e, i) {
              this.x = e, this.y = i;
            }
            updatePathMinMax(e, i, u) {
              [i, u] = o.Util.applyTransform([i, u], e), this.minX = Math.min(this.minX, i), this.minY = Math.min(this.minY, u), this.maxX = Math.max(this.maxX, i), this.maxY = Math.max(this.maxY, u);
            }
            updateRectMinMax(e, i) {
              const u = o.Util.applyTransform(i, e), x = o.Util.applyTransform(i.slice(2), e);
              this.minX = Math.min(this.minX, u[0], x[0]), this.minY = Math.min(this.minY, u[1], x[1]), this.maxX = Math.max(this.maxX, u[0], x[0]), this.maxY = Math.max(this.maxY, u[1], x[1]);
            }
            updateScalingPathMinMax(e, i) {
              o.Util.scaleMinMax(e, i), this.minX = Math.min(this.minX, i[0]), this.maxX = Math.max(this.maxX, i[1]), this.minY = Math.min(this.minY, i[2]), this.maxY = Math.max(this.maxY, i[3]);
            }
            updateCurvePathMinMax(e, i, u, x, P, k, G, it, ht, dt) {
              const mt = o.Util.bezierBoundingBox(i, u, x, P, k, G, it, ht);
              if (dt) {
                dt[0] = Math.min(dt[0], mt[0], mt[2]), dt[1] = Math.max(dt[1], mt[0], mt[2]), dt[2] = Math.min(dt[2], mt[1], mt[3]), dt[3] = Math.max(dt[3], mt[1], mt[3]);
                return;
              }
              this.updateRectMinMax(e, mt);
            }
            getPathBoundingBox(e = ct.PathType.FILL, i = null) {
              const u = [this.minX, this.minY, this.maxX, this.maxY];
              if (e === ct.PathType.STROKE) {
                i || (0, o.unreachable)("Stroke bounding box must include transform.");
                const x = o.Util.singularValueDecompose2dScale(i), P = x[0] * this.lineWidth / 2, k = x[1] * this.lineWidth / 2;
                u[0] -= P, u[1] -= k, u[2] += P, u[3] += k;
              }
              return u;
            }
            updateClipFromPath() {
              const e = o.Util.intersect(this.clipBox, this.getPathBoundingBox());
              this.startNewPathAndClipBox(e || [0, 0, 0, 0]);
            }
            isEmptyClip() {
              return this.minX === 1 / 0;
            }
            startNewPathAndClipBox(e) {
              this.clipBox = e, this.minX = 1 / 0, this.minY = 1 / 0, this.maxX = 0, this.maxY = 0;
            }
            getClippedPathBoundingBox(e = ct.PathType.FILL, i = null) {
              return o.Util.intersect(this.clipBox, this.getPathBoundingBox(e, i));
            }
          }
          function D(S, e) {
            if (typeof ImageData < "u" && e instanceof ImageData) {
              S.putImageData(e, 0, 0);
              return;
            }
            const i = e.height, u = e.width, x = i % _, P = (i - x) / _, k = x === 0 ? P : P + 1, G = S.createImageData(u, _);
            let it = 0, ht;
            const dt = e.data, mt = G.data;
            let At, vt, K, Z;
            if (e.kind === o.ImageKind.GRAYSCALE_1BPP) {
              const g = dt.byteLength, R = new Uint32Array(mt.buffer, 0, mt.byteLength >> 2), X = R.length, J = u + 7 >> 3, ut = 4294967295, St = o.FeatureTest.isLittleEndian ? 4278190080 : 255;
              for (At = 0; At < k; At++) {
                for (K = At < P ? _ : x, ht = 0, vt = 0; vt < K; vt++) {
                  const yt = g - it;
                  let V = 0;
                  const Tt = yt > J ? u : yt * 8 - 7, wt = Tt & -8;
                  let jt = 0, Bt = 0;
                  for (; V < wt; V += 8)
                    Bt = dt[it++], R[ht++] = Bt & 128 ? ut : St, R[ht++] = Bt & 64 ? ut : St, R[ht++] = Bt & 32 ? ut : St, R[ht++] = Bt & 16 ? ut : St, R[ht++] = Bt & 8 ? ut : St, R[ht++] = Bt & 4 ? ut : St, R[ht++] = Bt & 2 ? ut : St, R[ht++] = Bt & 1 ? ut : St;
                  for (; V < Tt; V++)
                    jt === 0 && (Bt = dt[it++], jt = 128), R[ht++] = Bt & jt ? ut : St, jt >>= 1;
                }
                for (; ht < X; )
                  R[ht++] = 0;
                S.putImageData(G, 0, At * _);
              }
            } else if (e.kind === o.ImageKind.RGBA_32BPP) {
              for (vt = 0, Z = u * _ * 4, At = 0; At < P; At++)
                mt.set(dt.subarray(it, it + Z)), it += Z, S.putImageData(G, 0, vt), vt += _;
              At < k && (Z = u * x * 4, mt.set(dt.subarray(it, it + Z)), S.putImageData(G, 0, vt));
            } else if (e.kind === o.ImageKind.RGB_24BPP)
              for (K = _, Z = u * K, At = 0; At < k; At++) {
                for (At >= P && (K = x, Z = u * K), ht = 0, vt = Z; vt--; )
                  mt[ht++] = dt[it++], mt[ht++] = dt[it++], mt[ht++] = dt[it++], mt[ht++] = 255;
                S.putImageData(G, 0, At * _);
              }
            else
              throw new Error(`bad image kind: ${e.kind}`);
          }
          function y(S, e) {
            if (e.bitmap) {
              S.drawImage(e.bitmap, 0, 0);
              return;
            }
            const i = e.height, u = e.width, x = i % _, P = (i - x) / _, k = x === 0 ? P : P + 1, G = S.createImageData(u, _);
            let it = 0;
            const ht = e.data, dt = G.data;
            for (let mt = 0; mt < k; mt++) {
              const At = mt < P ? _ : x;
              ({
                srcPos: it
              } = (0, q.convertBlackAndWhiteToRGBA)({
                src: ht,
                srcPos: it,
                dest: dt,
                width: u,
                height: At,
                nonBlackColor: 0
              })), S.putImageData(G, 0, mt * _);
            }
          }
          function n(S, e) {
            const i = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
            for (const u of i)
              S[u] !== void 0 && (e[u] = S[u]);
            S.setLineDash !== void 0 && (e.setLineDash(S.getLineDash()), e.lineDashOffset = S.lineDashOffset);
          }
          function l(S) {
            if (S.strokeStyle = S.fillStyle = "#000000", S.fillRule = "nonzero", S.globalAlpha = 1, S.lineWidth = 1, S.lineCap = "butt", S.lineJoin = "miter", S.miterLimit = 10, S.globalCompositeOperation = "source-over", S.font = "10px sans-serif", S.setLineDash !== void 0 && (S.setLineDash([]), S.lineDashOffset = 0), !o.isNodeJS) {
              const {
                filter: e
              } = S;
              e !== "none" && e !== "" && (S.filter = "none");
            }
          }
          function s(S, e, i, u) {
            const x = S.length;
            for (let P = 3; P < x; P += 4) {
              const k = S[P];
              if (k === 0)
                S[P - 3] = e, S[P - 2] = i, S[P - 1] = u;
              else if (k < 255) {
                const G = 255 - k;
                S[P - 3] = S[P - 3] * k + e * G >> 8, S[P - 2] = S[P - 2] * k + i * G >> 8, S[P - 1] = S[P - 1] * k + u * G >> 8;
              }
            }
          }
          function a(S, e, i) {
            const u = S.length, x = 1 / 255;
            for (let P = 3; P < u; P += 4) {
              const k = i ? i[S[P]] : S[P];
              e[P] = e[P] * k * x | 0;
            }
          }
          function c(S, e, i) {
            const u = S.length;
            for (let x = 3; x < u; x += 4) {
              const P = S[x - 3] * 77 + S[x - 2] * 152 + S[x - 1] * 28;
              e[x] = i ? e[x] * i[P >> 8] >> 8 : e[x] * P >> 16;
            }
          }
          function O(S, e, i, u, x, P, k, G, it, ht, dt) {
            const mt = !!P, At = mt ? P[0] : 0, vt = mt ? P[1] : 0, K = mt ? P[2] : 0, Z = x === "Luminosity" ? c : a, R = Math.min(u, Math.ceil(1048576 / i));
            for (let X = 0; X < u; X += R) {
              const J = Math.min(R, u - X), ut = S.getImageData(G - ht, X + (it - dt), i, J), St = e.getImageData(G, X + it, i, J);
              mt && s(ut.data, At, vt, K), Z(ut.data, St.data, k), e.putImageData(St, G, X + it);
            }
          }
          function r(S, e, i, u) {
            const x = u[0], P = u[1], k = u[2] - x, G = u[3] - P;
            k === 0 || G === 0 || (O(e.context, i, k, G, e.subtype, e.backdrop, e.transferMap, x, P, e.offsetX, e.offsetY), S.save(), S.globalAlpha = 1, S.globalCompositeOperation = "source-over", S.setTransform(1, 0, 0, 1, 0, 0), S.drawImage(i.canvas, 0, 0), S.restore());
          }
          function A(S, e) {
            const i = o.Util.singularValueDecompose2dScale(S);
            i[0] = Math.fround(i[0]), i[1] = Math.fround(i[1]);
            const u = Math.fround((globalThis.devicePixelRatio || 1) * T.PixelsPerInch.PDF_TO_CSS_UNITS);
            return e !== void 0 ? e : i[0] <= u || i[1] <= u;
          }
          const F = ["butt", "round", "square"], nt = ["miter", "round", "bevel"], W = {}, $ = {}, Y = class Y {
            constructor(e, i, u, x, P, {
              optionalContentConfig: k,
              markedContentStack: G = null
            }, it, ht) {
              Q(this, at);
              this.ctx = e, this.current = new p(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.res = null, this.xobjs = null, this.commonObjs = i, this.objs = u, this.canvasFactory = x, this.filterFactory = P, this.groupStack = [], this.processingType3 = null, this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.smaskCounter = 0, this.tempSMask = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = G || [], this.optionalContentConfig = k, this.cachedCanvases = new E(this.canvasFactory), this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = it, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = ht, this._cachedScaleForStroking = [-1, 0], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = /* @__PURE__ */ new Map();
            }
            getObject(e, i = null) {
              return typeof e == "string" ? e.startsWith("g_") ? this.commonObjs.get(e) : this.objs.get(e) : i;
            }
            beginDrawing({
              transform: e,
              viewport: i,
              transparency: u = !1,
              background: x = null
            }) {
              const P = this.ctx.canvas.width, k = this.ctx.canvas.height, G = this.ctx.fillStyle;
              if (this.ctx.fillStyle = x || "#ffffff", this.ctx.fillRect(0, 0, P, k), this.ctx.fillStyle = G, u) {
                const it = this.cachedCanvases.getCanvas("transparent", P, k);
                this.compositeCtx = this.ctx, this.transparentCanvas = it.canvas, this.ctx = it.context, this.ctx.save(), this.ctx.transform(...(0, T.getCurrentTransform)(this.compositeCtx));
              }
              this.ctx.save(), l(this.ctx), e && (this.ctx.transform(...e), this.outputScaleX = e[0], this.outputScaleY = e[0]), this.ctx.transform(...i.transform), this.viewportScale = i.scale, this.baseTransform = (0, T.getCurrentTransform)(this.ctx);
            }
            executeOperatorList(e, i, u, x) {
              const P = e.argsArray, k = e.fnArray;
              let G = i || 0;
              const it = P.length;
              if (it === G)
                return G;
              const ht = it - G > N && typeof u == "function", dt = ht ? Date.now() + m : 0;
              let mt = 0;
              const At = this.commonObjs, vt = this.objs;
              let K;
              for (; ; ) {
                if (x !== void 0 && G === x.nextBreakPoint)
                  return x.breakIt(G, u), G;
                if (K = k[G], K !== o.OPS.dependency)
                  this[K].apply(this, P[G]);
                else
                  for (const Z of P[G]) {
                    const g = Z.startsWith("g_") ? At : vt;
                    if (!g.has(Z))
                      return g.get(Z, u), G;
                  }
                if (G++, G === it)
                  return G;
                if (ht && ++mt > N) {
                  if (Date.now() > dt)
                    return u(), G;
                  mt = 0;
                }
              }
            }
            endDrawing() {
              z(this, at, qe).call(this), this.cachedCanvases.clear(), this.cachedPatterns.clear();
              for (const e of this._cachedBitmapsMap.values()) {
                for (const i of e.values())
                  typeof HTMLCanvasElement < "u" && i instanceof HTMLCanvasElement && (i.width = i.height = 0);
                e.clear();
              }
              this._cachedBitmapsMap.clear(), z(this, at, $e).call(this);
            }
            _scaleImage(e, i) {
              const u = e.width, x = e.height;
              let P = Math.max(Math.hypot(i[0], i[1]), 1), k = Math.max(Math.hypot(i[2], i[3]), 1), G = u, it = x, ht = "prescale1", dt, mt;
              for (; P > 2 && G > 1 || k > 2 && it > 1; ) {
                let At = G, vt = it;
                P > 2 && G > 1 && (At = G >= 16384 ? Math.floor(G / 2) - 1 || 1 : Math.ceil(G / 2), P /= G / At), k > 2 && it > 1 && (vt = it >= 16384 ? Math.floor(it / 2) - 1 || 1 : Math.ceil(it) / 2, k /= it / vt), dt = this.cachedCanvases.getCanvas(ht, At, vt), mt = dt.context, mt.clearRect(0, 0, At, vt), mt.drawImage(e, 0, 0, G, it, 0, 0, At, vt), e = dt.canvas, G = At, it = vt, ht = ht === "prescale1" ? "prescale2" : "prescale1";
              }
              return {
                img: e,
                paintWidth: G,
                paintHeight: it
              };
            }
            _createMaskCanvas(e) {
              const i = this.ctx, {
                width: u,
                height: x
              } = e, P = this.current.fillColor, k = this.current.patternFill, G = (0, T.getCurrentTransform)(i);
              let it, ht, dt, mt;
              if ((e.bitmap || e.data) && e.count > 1) {
                const V = e.bitmap || e.data.buffer;
                ht = JSON.stringify(k ? G : [G.slice(0, 4), P]), it = this._cachedBitmapsMap.get(V), it || (it = /* @__PURE__ */ new Map(), this._cachedBitmapsMap.set(V, it));
                const Tt = it.get(ht);
                if (Tt && !k) {
                  const wt = Math.round(Math.min(G[0], G[2]) + G[4]), jt = Math.round(Math.min(G[1], G[3]) + G[5]);
                  return {
                    canvas: Tt,
                    offsetX: wt,
                    offsetY: jt
                  };
                }
                dt = Tt;
              }
              dt || (mt = this.cachedCanvases.getCanvas("maskCanvas", u, x), y(mt.context, e));
              let At = o.Util.transform(G, [1 / u, 0, 0, -1 / x, 0, 0]);
              At = o.Util.transform(At, [1, 0, 0, 1, 0, -x]);
              const vt = o.Util.applyTransform([0, 0], At), K = o.Util.applyTransform([u, x], At), Z = o.Util.normalizeRect([vt[0], vt[1], K[0], K[1]]), g = Math.round(Z[2] - Z[0]) || 1, R = Math.round(Z[3] - Z[1]) || 1, X = this.cachedCanvases.getCanvas("fillCanvas", g, R), J = X.context, ut = Math.min(vt[0], K[0]), St = Math.min(vt[1], K[1]);
              J.translate(-ut, -St), J.transform(...At), dt || (dt = this._scaleImage(mt.canvas, (0, T.getCurrentTransformInverse)(J)), dt = dt.img, it && k && it.set(ht, dt)), J.imageSmoothingEnabled = A((0, T.getCurrentTransform)(J), e.interpolate), f(J, dt, 0, 0, dt.width, dt.height, 0, 0, u, x), J.globalCompositeOperation = "source-in";
              const yt = o.Util.transform((0, T.getCurrentTransformInverse)(J), [1, 0, 0, 1, -ut, -St]);
              return J.fillStyle = k ? P.getPattern(i, this, yt, ct.PathType.FILL) : P, J.fillRect(0, 0, u, x), it && !k && (this.cachedCanvases.delete("fillCanvas"), it.set(ht, X.canvas)), {
                canvas: X.canvas,
                offsetX: Math.round(ut),
                offsetY: Math.round(St)
              };
            }
            setLineWidth(e) {
              e !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = e, this.ctx.lineWidth = e;
            }
            setLineCap(e) {
              this.ctx.lineCap = F[e];
            }
            setLineJoin(e) {
              this.ctx.lineJoin = nt[e];
            }
            setMiterLimit(e) {
              this.ctx.miterLimit = e;
            }
            setDash(e, i) {
              const u = this.ctx;
              u.setLineDash !== void 0 && (u.setLineDash(e), u.lineDashOffset = i);
            }
            setRenderingIntent(e) {
            }
            setFlatness(e) {
            }
            setGState(e) {
              for (const [i, u] of e)
                switch (i) {
                  case "LW":
                    this.setLineWidth(u);
                    break;
                  case "LC":
                    this.setLineCap(u);
                    break;
                  case "LJ":
                    this.setLineJoin(u);
                    break;
                  case "ML":
                    this.setMiterLimit(u);
                    break;
                  case "D":
                    this.setDash(u[0], u[1]);
                    break;
                  case "RI":
                    this.setRenderingIntent(u);
                    break;
                  case "FL":
                    this.setFlatness(u);
                    break;
                  case "Font":
                    this.setFont(u[0], u[1]);
                    break;
                  case "CA":
                    this.current.strokeAlpha = u;
                    break;
                  case "ca":
                    this.current.fillAlpha = u, this.ctx.globalAlpha = u;
                    break;
                  case "BM":
                    this.ctx.globalCompositeOperation = u;
                    break;
                  case "SMask":
                    this.current.activeSMask = u ? this.tempSMask : null, this.tempSMask = null, this.checkSMaskState();
                    break;
                  case "TR":
                    this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(u);
                    break;
                }
            }
            get inSMaskMode() {
              return !!this.suspendedCtx;
            }
            checkSMaskState() {
              const e = this.inSMaskMode;
              this.current.activeSMask && !e ? this.beginSMaskMode() : !this.current.activeSMask && e && this.endSMaskMode();
            }
            beginSMaskMode() {
              if (this.inSMaskMode)
                throw new Error("beginSMaskMode called while already in smask mode");
              const e = this.ctx.canvas.width, i = this.ctx.canvas.height, u = "smaskGroupAt" + this.groupLevel, x = this.cachedCanvases.getCanvas(u, e, i);
              this.suspendedCtx = this.ctx, this.ctx = x.context;
              const P = this.ctx;
              P.setTransform(...(0, T.getCurrentTransform)(this.suspendedCtx)), n(this.suspendedCtx, P), b(P, this.suspendedCtx), this.setGState([["BM", "source-over"], ["ca", 1], ["CA", 1]]);
            }
            endSMaskMode() {
              if (!this.inSMaskMode)
                throw new Error("endSMaskMode called while not in smask mode");
              this.ctx._removeMirroring(), n(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null;
            }
            compose(e) {
              if (!this.current.activeSMask)
                return;
              e ? (e[0] = Math.floor(e[0]), e[1] = Math.floor(e[1]), e[2] = Math.ceil(e[2]), e[3] = Math.ceil(e[3])) : e = [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
              const i = this.current.activeSMask, u = this.suspendedCtx;
              r(u, i, this.ctx, e), this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore();
            }
            save() {
              this.inSMaskMode ? (n(this.ctx, this.suspendedCtx), this.suspendedCtx.save()) : this.ctx.save();
              const e = this.current;
              this.stateStack.push(e), this.current = e.clone();
            }
            restore() {
              this.stateStack.length === 0 && this.inSMaskMode && this.endSMaskMode(), this.stateStack.length !== 0 && (this.current = this.stateStack.pop(), this.inSMaskMode ? (this.suspendedCtx.restore(), n(this.suspendedCtx, this.ctx)) : this.ctx.restore(), this.checkSMaskState(), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null);
            }
            transform(e, i, u, x, P, k) {
              this.ctx.transform(e, i, u, x, P, k), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
            }
            constructPath(e, i, u) {
              const x = this.ctx, P = this.current;
              let k = P.x, G = P.y, it, ht;
              const dt = (0, T.getCurrentTransform)(x), mt = dt[0] === 0 && dt[3] === 0 || dt[1] === 0 && dt[2] === 0, At = mt ? u.slice(0) : null;
              for (let vt = 0, K = 0, Z = e.length; vt < Z; vt++)
                switch (e[vt] | 0) {
                  case o.OPS.rectangle:
                    k = i[K++], G = i[K++];
                    const g = i[K++], R = i[K++], X = k + g, J = G + R;
                    x.moveTo(k, G), g === 0 || R === 0 ? x.lineTo(X, J) : (x.lineTo(X, G), x.lineTo(X, J), x.lineTo(k, J)), mt || P.updateRectMinMax(dt, [k, G, X, J]), x.closePath();
                    break;
                  case o.OPS.moveTo:
                    k = i[K++], G = i[K++], x.moveTo(k, G), mt || P.updatePathMinMax(dt, k, G);
                    break;
                  case o.OPS.lineTo:
                    k = i[K++], G = i[K++], x.lineTo(k, G), mt || P.updatePathMinMax(dt, k, G);
                    break;
                  case o.OPS.curveTo:
                    it = k, ht = G, k = i[K + 4], G = i[K + 5], x.bezierCurveTo(i[K], i[K + 1], i[K + 2], i[K + 3], k, G), P.updateCurvePathMinMax(dt, it, ht, i[K], i[K + 1], i[K + 2], i[K + 3], k, G, At), K += 6;
                    break;
                  case o.OPS.curveTo2:
                    it = k, ht = G, x.bezierCurveTo(k, G, i[K], i[K + 1], i[K + 2], i[K + 3]), P.updateCurvePathMinMax(dt, it, ht, k, G, i[K], i[K + 1], i[K + 2], i[K + 3], At), k = i[K + 2], G = i[K + 3], K += 4;
                    break;
                  case o.OPS.curveTo3:
                    it = k, ht = G, k = i[K + 2], G = i[K + 3], x.bezierCurveTo(i[K], i[K + 1], k, G, k, G), P.updateCurvePathMinMax(dt, it, ht, i[K], i[K + 1], k, G, k, G, At), K += 4;
                    break;
                  case o.OPS.closePath:
                    x.closePath();
                    break;
                }
              mt && P.updateScalingPathMinMax(dt, At), P.setCurrentPoint(k, G);
            }
            closePath() {
              this.ctx.closePath();
            }
            stroke(e = !0) {
              const i = this.ctx, u = this.current.strokeColor;
              i.globalAlpha = this.current.strokeAlpha, this.contentVisible && (typeof u == "object" && (u != null && u.getPattern) ? (i.save(), i.strokeStyle = u.getPattern(i, this, (0, T.getCurrentTransformInverse)(i), ct.PathType.STROKE), this.rescaleAndStroke(!1), i.restore()) : this.rescaleAndStroke(!0)), e && this.consumePath(this.current.getClippedPathBoundingBox()), i.globalAlpha = this.current.fillAlpha;
            }
            closeStroke() {
              this.closePath(), this.stroke();
            }
            fill(e = !0) {
              const i = this.ctx, u = this.current.fillColor, x = this.current.patternFill;
              let P = !1;
              x && (i.save(), i.fillStyle = u.getPattern(i, this, (0, T.getCurrentTransformInverse)(i), ct.PathType.FILL), P = !0);
              const k = this.current.getClippedPathBoundingBox();
              this.contentVisible && k !== null && (this.pendingEOFill ? (i.fill("evenodd"), this.pendingEOFill = !1) : i.fill()), P && i.restore(), e && this.consumePath(k);
            }
            eoFill() {
              this.pendingEOFill = !0, this.fill();
            }
            fillStroke() {
              this.fill(!1), this.stroke(!1), this.consumePath();
            }
            eoFillStroke() {
              this.pendingEOFill = !0, this.fillStroke();
            }
            closeFillStroke() {
              this.closePath(), this.fillStroke();
            }
            closeEOFillStroke() {
              this.pendingEOFill = !0, this.closePath(), this.fillStroke();
            }
            endPath() {
              this.consumePath();
            }
            clip() {
              this.pendingClip = W;
            }
            eoClip() {
              this.pendingClip = $;
            }
            beginText() {
              this.current.textMatrix = o.IDENTITY_MATRIX, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
            }
            endText() {
              const e = this.pendingTextPaths, i = this.ctx;
              if (e === void 0) {
                i.beginPath();
                return;
              }
              i.save(), i.beginPath();
              for (const u of e)
                i.setTransform(...u.transform), i.translate(u.x, u.y), u.addToPath(i, u.fontSize);
              i.restore(), i.clip(), i.beginPath(), delete this.pendingTextPaths;
            }
            setCharSpacing(e) {
              this.current.charSpacing = e;
            }
            setWordSpacing(e) {
              this.current.wordSpacing = e;
            }
            setHScale(e) {
              this.current.textHScale = e / 100;
            }
            setLeading(e) {
              this.current.leading = -e;
            }
            setFont(e, i) {
              var dt;
              const u = this.commonObjs.get(e), x = this.current;
              if (!u)
                throw new Error(`Can't find font for ${e}`);
              if (x.fontMatrix = u.fontMatrix || o.FONT_IDENTITY_MATRIX, (x.fontMatrix[0] === 0 || x.fontMatrix[3] === 0) && (0, o.warn)("Invalid font matrix for font " + e), i < 0 ? (i = -i, x.fontDirection = -1) : x.fontDirection = 1, this.current.font = u, this.current.fontSize = i, u.isType3Font)
                return;
              const P = u.loadedName || "sans-serif", k = ((dt = u.systemFontInfo) == null ? void 0 : dt.css) || `"${P}", ${u.fallbackName}`;
              let G = "normal";
              u.black ? G = "900" : u.bold && (G = "bold");
              const it = u.italic ? "italic" : "normal";
              let ht = i;
              i < gt ? ht = gt : i > B && (ht = B), this.current.fontSizeScale = i / ht, this.ctx.font = `${it} ${G} ${ht}px ${k}`;
            }
            setTextRenderingMode(e) {
              this.current.textRenderingMode = e;
            }
            setTextRise(e) {
              this.current.textRise = e;
            }
            moveText(e, i) {
              this.current.x = this.current.lineX += e, this.current.y = this.current.lineY += i;
            }
            setLeadingMoveText(e, i) {
              this.setLeading(-i), this.moveText(e, i);
            }
            setTextMatrix(e, i, u, x, P, k) {
              this.current.textMatrix = [e, i, u, x, P, k], this.current.textMatrixScale = Math.hypot(e, i), this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
            }
            nextLine() {
              this.moveText(0, this.current.leading);
            }
            paintChar(e, i, u, x) {
              const P = this.ctx, k = this.current, G = k.font, it = k.textRenderingMode, ht = k.fontSize / k.fontSizeScale, dt = it & o.TextRenderingMode.FILL_STROKE_MASK, mt = !!(it & o.TextRenderingMode.ADD_TO_PATH_FLAG), At = k.patternFill && !G.missingFile;
              let vt;
              (G.disableFontFace || mt || At) && (vt = G.getPathGenerator(this.commonObjs, e)), G.disableFontFace || At ? (P.save(), P.translate(i, u), P.beginPath(), vt(P, ht), x && P.setTransform(...x), (dt === o.TextRenderingMode.FILL || dt === o.TextRenderingMode.FILL_STROKE) && P.fill(), (dt === o.TextRenderingMode.STROKE || dt === o.TextRenderingMode.FILL_STROKE) && P.stroke(), P.restore()) : ((dt === o.TextRenderingMode.FILL || dt === o.TextRenderingMode.FILL_STROKE) && P.fillText(e, i, u), (dt === o.TextRenderingMode.STROKE || dt === o.TextRenderingMode.FILL_STROKE) && P.strokeText(e, i, u)), mt && (this.pendingTextPaths || (this.pendingTextPaths = [])).push({
                transform: (0, T.getCurrentTransform)(P),
                x: i,
                y: u,
                fontSize: ht,
                addToPath: vt
              });
            }
            get isFontSubpixelAAEnabled() {
              const {
                context: e
              } = this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled", 10, 10);
              e.scale(1.5, 1), e.fillText("I", 0, 10);
              const i = e.getImageData(0, 0, 10, 10).data;
              let u = !1;
              for (let x = 3; x < i.length; x += 4)
                if (i[x] > 0 && i[x] < 255) {
                  u = !0;
                  break;
                }
              return (0, o.shadow)(this, "isFontSubpixelAAEnabled", u);
            }
            showText(e) {
              const i = this.current, u = i.font;
              if (u.isType3Font)
                return this.showType3Text(e);
              const x = i.fontSize;
              if (x === 0)
                return;
              const P = this.ctx, k = i.fontSizeScale, G = i.charSpacing, it = i.wordSpacing, ht = i.fontDirection, dt = i.textHScale * ht, mt = e.length, At = u.vertical, vt = At ? 1 : -1, K = u.defaultVMetrics, Z = x * i.fontMatrix[0], g = i.textRenderingMode === o.TextRenderingMode.FILL && !u.disableFontFace && !i.patternFill;
              P.save(), P.transform(...i.textMatrix), P.translate(i.x, i.y + i.textRise), ht > 0 ? P.scale(dt, -1) : P.scale(dt, 1);
              let R;
              if (i.patternFill) {
                P.save();
                const yt = i.fillColor.getPattern(P, this, (0, T.getCurrentTransformInverse)(P), ct.PathType.FILL);
                R = (0, T.getCurrentTransform)(P), P.restore(), P.fillStyle = yt;
              }
              let X = i.lineWidth;
              const J = i.textMatrixScale;
              if (J === 0 || X === 0) {
                const yt = i.textRenderingMode & o.TextRenderingMode.FILL_STROKE_MASK;
                (yt === o.TextRenderingMode.STROKE || yt === o.TextRenderingMode.FILL_STROKE) && (X = this.getSinglePixelWidth());
              } else
                X /= J;
              if (k !== 1 && (P.scale(k, k), X /= k), P.lineWidth = X, u.isInvalidPDFjsFont) {
                const yt = [];
                let V = 0;
                for (const Tt of e)
                  yt.push(Tt.unicode), V += Tt.width;
                P.fillText(yt.join(""), 0, 0), i.x += V * Z * dt, P.restore(), this.compose();
                return;
              }
              let ut = 0, St;
              for (St = 0; St < mt; ++St) {
                const yt = e[St];
                if (typeof yt == "number") {
                  ut += vt * yt * x / 1e3;
                  continue;
                }
                let V = !1;
                const Tt = (yt.isSpace ? it : 0) + G, wt = yt.fontChar, jt = yt.accent;
                let Bt, Xt, Ft = yt.width;
                if (At) {
                  const Vt = yt.vmetric || K, $t = -(yt.vmetric ? Vt[1] : Ft * 0.5) * Z, _t = Vt[2] * Z;
                  Ft = Vt ? -Vt[0] : Ft, Bt = $t / k, Xt = (ut + _t) / k;
                } else
                  Bt = ut / k, Xt = 0;
                if (u.remeasure && Ft > 0) {
                  const Vt = P.measureText(wt).width * 1e3 / x * k;
                  if (Ft < Vt && this.isFontSubpixelAAEnabled) {
                    const $t = Ft / Vt;
                    V = !0, P.save(), P.scale($t, 1), Bt /= $t;
                  } else Ft !== Vt && (Bt += (Ft - Vt) / 2e3 * x / k);
                }
                if (this.contentVisible && (yt.isInFont || u.missingFile)) {
                  if (g && !jt)
                    P.fillText(wt, Bt, Xt);
                  else if (this.paintChar(wt, Bt, Xt, R), jt) {
                    const Vt = Bt + x * jt.offset.x / k, $t = Xt - x * jt.offset.y / k;
                    this.paintChar(jt.fontChar, Vt, $t, R);
                  }
                }
                const Nt = At ? Ft * Z - Tt * ht : Ft * Z + Tt * ht;
                ut += Nt, V && P.restore();
              }
              At ? i.y -= ut : i.x += ut * dt, P.restore(), this.compose();
            }
            showType3Text(e) {
              const i = this.ctx, u = this.current, x = u.font, P = u.fontSize, k = u.fontDirection, G = x.vertical ? 1 : -1, it = u.charSpacing, ht = u.wordSpacing, dt = u.textHScale * k, mt = u.fontMatrix || o.FONT_IDENTITY_MATRIX, At = e.length, vt = u.textRenderingMode === o.TextRenderingMode.INVISIBLE;
              let K, Z, g, R;
              if (!(vt || P === 0)) {
                for (this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, i.save(), i.transform(...u.textMatrix), i.translate(u.x, u.y), i.scale(dt, k), K = 0; K < At; ++K) {
                  if (Z = e[K], typeof Z == "number") {
                    R = G * Z * P / 1e3, this.ctx.translate(R, 0), u.x += R * dt;
                    continue;
                  }
                  const X = (Z.isSpace ? ht : 0) + it, J = x.charProcOperatorList[Z.operatorListId];
                  if (!J) {
                    (0, o.warn)(`Type3 character "${Z.operatorListId}" is not available.`);
                    continue;
                  }
                  this.contentVisible && (this.processingType3 = Z, this.save(), i.scale(P, P), i.transform(...mt), this.executeOperatorList(J), this.restore()), g = o.Util.applyTransform([Z.width, 0], mt)[0] * P + X, i.translate(g, 0), u.x += g * dt;
                }
                i.restore(), this.processingType3 = null;
              }
            }
            setCharWidth(e, i) {
            }
            setCharWidthAndBounds(e, i, u, x, P, k) {
              this.ctx.rect(u, x, P - u, k - x), this.ctx.clip(), this.endPath();
            }
            getColorN_Pattern(e) {
              let i;
              if (e[0] === "TilingPattern") {
                const u = e[1], x = this.baseTransform || (0, T.getCurrentTransform)(this.ctx), P = {
                  createCanvasGraphics: (k) => new Y(k, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                    optionalContentConfig: this.optionalContentConfig,
                    markedContentStack: this.markedContentStack
                  })
                };
                i = new ct.TilingPattern(e, u, this.ctx, P, x);
              } else
                i = this._getPattern(e[1], e[2]);
              return i;
            }
            setStrokeColorN() {
              this.current.strokeColor = this.getColorN_Pattern(arguments);
            }
            setFillColorN() {
              this.current.fillColor = this.getColorN_Pattern(arguments), this.current.patternFill = !0;
            }
            setStrokeRGBColor(e, i, u) {
              const x = o.Util.makeHexColor(e, i, u);
              this.ctx.strokeStyle = x, this.current.strokeColor = x;
            }
            setFillRGBColor(e, i, u) {
              const x = o.Util.makeHexColor(e, i, u);
              this.ctx.fillStyle = x, this.current.fillColor = x, this.current.patternFill = !1;
            }
            _getPattern(e, i = null) {
              let u;
              return this.cachedPatterns.has(e) ? u = this.cachedPatterns.get(e) : (u = (0, ct.getShadingPattern)(this.getObject(e)), this.cachedPatterns.set(e, u)), i && (u.matrix = i), u;
            }
            shadingFill(e) {
              if (!this.contentVisible)
                return;
              const i = this.ctx;
              this.save();
              const u = this._getPattern(e);
              i.fillStyle = u.getPattern(i, this, (0, T.getCurrentTransformInverse)(i), ct.PathType.SHADING);
              const x = (0, T.getCurrentTransformInverse)(i);
              if (x) {
                const {
                  width: P,
                  height: k
                } = i.canvas, [G, it, ht, dt] = o.Util.getAxialAlignedBoundingBox([0, 0, P, k], x);
                this.ctx.fillRect(G, it, ht - G, dt - it);
              } else
                this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
              this.compose(this.current.getClippedPathBoundingBox()), this.restore();
            }
            beginInlineImage() {
              (0, o.unreachable)("Should not call beginInlineImage");
            }
            beginImageData() {
              (0, o.unreachable)("Should not call beginImageData");
            }
            paintFormXObjectBegin(e, i) {
              if (this.contentVisible && (this.save(), this.baseTransformStack.push(this.baseTransform), Array.isArray(e) && e.length === 6 && this.transform(...e), this.baseTransform = (0, T.getCurrentTransform)(this.ctx), i)) {
                const u = i[2] - i[0], x = i[3] - i[1];
                this.ctx.rect(i[0], i[1], u, x), this.current.updateRectMinMax((0, T.getCurrentTransform)(this.ctx), i), this.clip(), this.endPath();
              }
            }
            paintFormXObjectEnd() {
              this.contentVisible && (this.restore(), this.baseTransform = this.baseTransformStack.pop());
            }
            beginGroup(e) {
              if (!this.contentVisible)
                return;
              this.save(), this.inSMaskMode && (this.endSMaskMode(), this.current.activeSMask = null);
              const i = this.ctx;
              e.isolated || (0, o.info)("TODO: Support non-isolated groups."), e.knockout && (0, o.warn)("Knockout groups not supported.");
              const u = (0, T.getCurrentTransform)(i);
              if (e.matrix && i.transform(...e.matrix), !e.bbox)
                throw new Error("Bounding box is required.");
              let x = o.Util.getAxialAlignedBoundingBox(e.bbox, (0, T.getCurrentTransform)(i));
              const P = [0, 0, i.canvas.width, i.canvas.height];
              x = o.Util.intersect(x, P) || [0, 0, 0, 0];
              const k = Math.floor(x[0]), G = Math.floor(x[1]);
              let it = Math.max(Math.ceil(x[2]) - k, 1), ht = Math.max(Math.ceil(x[3]) - G, 1), dt = 1, mt = 1;
              it > M && (dt = it / M, it = M), ht > M && (mt = ht / M, ht = M), this.current.startNewPathAndClipBox([0, 0, it, ht]);
              let At = "groupAt" + this.groupLevel;
              e.smask && (At += "_smask_" + this.smaskCounter++ % 2);
              const vt = this.cachedCanvases.getCanvas(At, it, ht), K = vt.context;
              K.scale(1 / dt, 1 / mt), K.translate(-k, -G), K.transform(...u), e.smask ? this.smaskStack.push({
                canvas: vt.canvas,
                context: K,
                offsetX: k,
                offsetY: G,
                scaleX: dt,
                scaleY: mt,
                subtype: e.smask.subtype,
                backdrop: e.smask.backdrop,
                transferMap: e.smask.transferMap || null,
                startTransformInverse: null
              }) : (i.setTransform(1, 0, 0, 1, 0, 0), i.translate(k, G), i.scale(dt, mt), i.save()), n(i, K), this.ctx = K, this.setGState([["BM", "source-over"], ["ca", 1], ["CA", 1]]), this.groupStack.push(i), this.groupLevel++;
            }
            endGroup(e) {
              if (!this.contentVisible)
                return;
              this.groupLevel--;
              const i = this.ctx, u = this.groupStack.pop();
              if (this.ctx = u, this.ctx.imageSmoothingEnabled = !1, e.smask)
                this.tempSMask = this.smaskStack.pop(), this.restore();
              else {
                this.ctx.restore();
                const x = (0, T.getCurrentTransform)(this.ctx);
                this.restore(), this.ctx.save(), this.ctx.setTransform(...x);
                const P = o.Util.getAxialAlignedBoundingBox([0, 0, i.canvas.width, i.canvas.height], x);
                this.ctx.drawImage(i.canvas, 0, 0), this.ctx.restore(), this.compose(P);
              }
            }
            beginAnnotation(e, i, u, x, P) {
              if (z(this, at, qe).call(this), l(this.ctx), this.ctx.save(), this.save(), this.baseTransform && this.ctx.setTransform(...this.baseTransform), Array.isArray(i) && i.length === 4) {
                const k = i[2] - i[0], G = i[3] - i[1];
                if (P && this.annotationCanvasMap) {
                  u = u.slice(), u[4] -= i[0], u[5] -= i[1], i = i.slice(), i[0] = i[1] = 0, i[2] = k, i[3] = G;
                  const [it, ht] = o.Util.singularValueDecompose2dScale((0, T.getCurrentTransform)(this.ctx)), {
                    viewportScale: dt
                  } = this, mt = Math.ceil(k * this.outputScaleX * dt), At = Math.ceil(G * this.outputScaleY * dt);
                  this.annotationCanvas = this.canvasFactory.create(mt, At);
                  const {
                    canvas: vt,
                    context: K
                  } = this.annotationCanvas;
                  this.annotationCanvasMap.set(e, vt), this.annotationCanvas.savedCtx = this.ctx, this.ctx = K, this.ctx.save(), this.ctx.setTransform(it, 0, 0, -ht, 0, G * ht), l(this.ctx);
                } else
                  l(this.ctx), this.ctx.rect(i[0], i[1], k, G), this.ctx.clip(), this.endPath();
              }
              this.current = new p(this.ctx.canvas.width, this.ctx.canvas.height), this.transform(...u), this.transform(...x);
            }
            endAnnotation() {
              this.annotationCanvas && (this.ctx.restore(), z(this, at, $e).call(this), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas);
            }
            paintImageMaskXObject(e) {
              if (!this.contentVisible)
                return;
              const i = e.count;
              e = this.getObject(e.data, e), e.count = i;
              const u = this.ctx, x = this.processingType3;
              if (x && (x.compiled === void 0 && (x.compiled = d(e)), x.compiled)) {
                x.compiled(u);
                return;
              }
              const P = this._createMaskCanvas(e), k = P.canvas;
              u.save(), u.setTransform(1, 0, 0, 1, 0, 0), u.drawImage(k, P.offsetX, P.offsetY), u.restore(), this.compose();
            }
            paintImageMaskXObjectRepeat(e, i, u = 0, x = 0, P, k) {
              if (!this.contentVisible)
                return;
              e = this.getObject(e.data, e);
              const G = this.ctx;
              G.save();
              const it = (0, T.getCurrentTransform)(G);
              G.transform(i, u, x, P, 0, 0);
              const ht = this._createMaskCanvas(e);
              G.setTransform(1, 0, 0, 1, ht.offsetX - it[4], ht.offsetY - it[5]);
              for (let dt = 0, mt = k.length; dt < mt; dt += 2) {
                const At = o.Util.transform(it, [i, u, x, P, k[dt], k[dt + 1]]), [vt, K] = o.Util.applyTransform([0, 0], At);
                G.drawImage(ht.canvas, vt, K);
              }
              G.restore(), this.compose();
            }
            paintImageMaskXObjectGroup(e) {
              if (!this.contentVisible)
                return;
              const i = this.ctx, u = this.current.fillColor, x = this.current.patternFill;
              for (const P of e) {
                const {
                  data: k,
                  width: G,
                  height: it,
                  transform: ht
                } = P, dt = this.cachedCanvases.getCanvas("maskCanvas", G, it), mt = dt.context;
                mt.save();
                const At = this.getObject(k, P);
                y(mt, At), mt.globalCompositeOperation = "source-in", mt.fillStyle = x ? u.getPattern(mt, this, (0, T.getCurrentTransformInverse)(i), ct.PathType.FILL) : u, mt.fillRect(0, 0, G, it), mt.restore(), i.save(), i.transform(...ht), i.scale(1, -1), f(i, dt.canvas, 0, 0, G, it, 0, -1, 1, 1), i.restore();
              }
              this.compose();
            }
            paintImageXObject(e) {
              if (!this.contentVisible)
                return;
              const i = this.getObject(e);
              if (!i) {
                (0, o.warn)("Dependent image isn't ready yet");
                return;
              }
              this.paintInlineImageXObject(i);
            }
            paintImageXObjectRepeat(e, i, u, x) {
              if (!this.contentVisible)
                return;
              const P = this.getObject(e);
              if (!P) {
                (0, o.warn)("Dependent image isn't ready yet");
                return;
              }
              const k = P.width, G = P.height, it = [];
              for (let ht = 0, dt = x.length; ht < dt; ht += 2)
                it.push({
                  transform: [i, 0, 0, u, x[ht], x[ht + 1]],
                  x: 0,
                  y: 0,
                  w: k,
                  h: G
                });
              this.paintInlineImageXObjectGroup(P, it);
            }
            applyTransferMapsToCanvas(e) {
              return this.current.transferMaps !== "none" && (e.filter = this.current.transferMaps, e.drawImage(e.canvas, 0, 0), e.filter = "none"), e.canvas;
            }
            applyTransferMapsToBitmap(e) {
              if (this.current.transferMaps === "none")
                return e.bitmap;
              const {
                bitmap: i,
                width: u,
                height: x
              } = e, P = this.cachedCanvases.getCanvas("inlineImage", u, x), k = P.context;
              return k.filter = this.current.transferMaps, k.drawImage(i, 0, 0), k.filter = "none", P.canvas;
            }
            paintInlineImageXObject(e) {
              if (!this.contentVisible)
                return;
              const i = e.width, u = e.height, x = this.ctx;
              if (this.save(), !o.isNodeJS) {
                const {
                  filter: G
                } = x;
                G !== "none" && G !== "" && (x.filter = "none");
              }
              x.scale(1 / i, -1 / u);
              let P;
              if (e.bitmap)
                P = this.applyTransferMapsToBitmap(e);
              else if (typeof HTMLElement == "function" && e instanceof HTMLElement || !e.data)
                P = e;
              else {
                const it = this.cachedCanvases.getCanvas("inlineImage", i, u).context;
                D(it, e), P = this.applyTransferMapsToCanvas(it);
              }
              const k = this._scaleImage(P, (0, T.getCurrentTransformInverse)(x));
              x.imageSmoothingEnabled = A((0, T.getCurrentTransform)(x), e.interpolate), f(x, k.img, 0, 0, k.paintWidth, k.paintHeight, 0, -u, i, u), this.compose(), this.restore();
            }
            paintInlineImageXObjectGroup(e, i) {
              if (!this.contentVisible)
                return;
              const u = this.ctx;
              let x;
              if (e.bitmap)
                x = e.bitmap;
              else {
                const P = e.width, k = e.height, it = this.cachedCanvases.getCanvas("inlineImage", P, k).context;
                D(it, e), x = this.applyTransferMapsToCanvas(it);
              }
              for (const P of i)
                u.save(), u.transform(...P.transform), u.scale(1, -1), f(u, x, P.x, P.y, P.w, P.h, 0, -1, 1, 1), u.restore();
              this.compose();
            }
            paintSolidColorImageMask() {
              this.contentVisible && (this.ctx.fillRect(0, 0, 1, 1), this.compose());
            }
            markPoint(e) {
            }
            markPointProps(e, i) {
            }
            beginMarkedContent(e) {
              this.markedContentStack.push({
                visible: !0
              });
            }
            beginMarkedContentProps(e, i) {
              e === "OC" ? this.markedContentStack.push({
                visible: this.optionalContentConfig.isVisible(i)
              }) : this.markedContentStack.push({
                visible: !0
              }), this.contentVisible = this.isContentVisible();
            }
            endMarkedContent() {
              this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
            }
            beginCompat() {
            }
            endCompat() {
            }
            consumePath(e) {
              const i = this.current.isEmptyClip();
              this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(e);
              const u = this.ctx;
              this.pendingClip && (i || (this.pendingClip === $ ? u.clip("evenodd") : u.clip()), this.pendingClip = null), this.current.startNewPathAndClipBox(this.current.clipBox), u.beginPath();
            }
            getSinglePixelWidth() {
              if (!this._cachedGetSinglePixelWidth) {
                const e = (0, T.getCurrentTransform)(this.ctx);
                if (e[1] === 0 && e[2] === 0)
                  this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(e[0]), Math.abs(e[3]));
                else {
                  const i = Math.abs(e[0] * e[3] - e[2] * e[1]), u = Math.hypot(e[0], e[2]), x = Math.hypot(e[1], e[3]);
                  this._cachedGetSinglePixelWidth = Math.max(u, x) / i;
                }
              }
              return this._cachedGetSinglePixelWidth;
            }
            getScaleForStroking() {
              if (this._cachedScaleForStroking[0] === -1) {
                const {
                  lineWidth: e
                } = this.current, {
                  a: i,
                  b: u,
                  c: x,
                  d: P
                } = this.ctx.getTransform();
                let k, G;
                if (u === 0 && x === 0) {
                  const it = Math.abs(i), ht = Math.abs(P);
                  if (it === ht)
                    if (e === 0)
                      k = G = 1 / it;
                    else {
                      const dt = it * e;
                      k = G = dt < 1 ? 1 / dt : 1;
                    }
                  else if (e === 0)
                    k = 1 / it, G = 1 / ht;
                  else {
                    const dt = it * e, mt = ht * e;
                    k = dt < 1 ? 1 / dt : 1, G = mt < 1 ? 1 / mt : 1;
                  }
                } else {
                  const it = Math.abs(i * P - u * x), ht = Math.hypot(i, u), dt = Math.hypot(x, P);
                  if (e === 0)
                    k = dt / it, G = ht / it;
                  else {
                    const mt = e * it;
                    k = dt > mt ? dt / mt : 1, G = ht > mt ? ht / mt : 1;
                  }
                }
                this._cachedScaleForStroking[0] = k, this._cachedScaleForStroking[1] = G;
              }
              return this._cachedScaleForStroking;
            }
            rescaleAndStroke(e) {
              const {
                ctx: i
              } = this, {
                lineWidth: u
              } = this.current, [x, P] = this.getScaleForStroking();
              if (i.lineWidth = u || 1, x === 1 && P === 1) {
                i.stroke();
                return;
              }
              const k = i.getLineDash();
              if (e && i.save(), i.scale(x, P), k.length > 0) {
                const G = Math.max(x, P);
                i.setLineDash(k.map((it) => it / G)), i.lineDashOffset /= G;
              }
              i.stroke(), e && i.restore();
            }
            isContentVisible() {
              for (let e = this.markedContentStack.length - 1; e >= 0; e--)
                if (!this.markedContentStack[e].visible)
                  return !1;
              return !0;
            }
          };
          at = new WeakSet(), qe = function() {
            for (; this.stateStack.length || this.inSMaskMode; )
              this.restore();
            this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.transparentCanvas = null);
          }, $e = function() {
            if (this.pageColors) {
              const e = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
              if (e !== "none") {
                const i = this.ctx.filter;
                this.ctx.filter = e, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = i;
              }
            }
          };
          let j = Y;
          h.CanvasGraphics = j;
          for (const S in o.OPS)
            j.prototype[S] !== void 0 && (j.prototype[o.OPS[S]] = j.prototype[S]);
        },
        /* 12 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.TilingPattern = h.PathType = void 0, h.getShadingPattern = _;
          var o = rt(1), T = rt(6);
          const ct = {
            FILL: "Fill",
            STROKE: "Stroke",
            SHADING: "Shading"
          };
          h.PathType = ct;
          function q(d, p) {
            if (!p)
              return;
            const D = p[2] - p[0], y = p[3] - p[1], n = new Path2D();
            n.rect(p[0], p[1], D, y), d.clip(n);
          }
          class gt {
            constructor() {
              this.constructor === gt && (0, o.unreachable)("Cannot initialize BaseShadingPattern.");
            }
            getPattern() {
              (0, o.unreachable)("Abstract method `getPattern` called.");
            }
          }
          class B extends gt {
            constructor(p) {
              super(), this._type = p[1], this._bbox = p[2], this._colorStops = p[3], this._p0 = p[4], this._p1 = p[5], this._r0 = p[6], this._r1 = p[7], this.matrix = null;
            }
            _createGradient(p) {
              let D;
              this._type === "axial" ? D = p.createLinearGradient(this._p0[0], this._p0[1], this._p1[0], this._p1[1]) : this._type === "radial" && (D = p.createRadialGradient(this._p0[0], this._p0[1], this._r0, this._p1[0], this._p1[1], this._r1));
              for (const y of this._colorStops)
                D.addColorStop(y[0], y[1]);
              return D;
            }
            getPattern(p, D, y, n) {
              let l;
              if (n === ct.STROKE || n === ct.FILL) {
                const s = D.current.getClippedPathBoundingBox(n, (0, T.getCurrentTransform)(p)) || [0, 0, 0, 0], a = Math.ceil(s[2] - s[0]) || 1, c = Math.ceil(s[3] - s[1]) || 1, O = D.cachedCanvases.getCanvas("pattern", a, c, !0), r = O.context;
                r.clearRect(0, 0, r.canvas.width, r.canvas.height), r.beginPath(), r.rect(0, 0, r.canvas.width, r.canvas.height), r.translate(-s[0], -s[1]), y = o.Util.transform(y, [1, 0, 0, 1, s[0], s[1]]), r.transform(...D.baseTransform), this.matrix && r.transform(...this.matrix), q(r, this._bbox), r.fillStyle = this._createGradient(r), r.fill(), l = p.createPattern(O.canvas, "no-repeat");
                const A = new DOMMatrix(y);
                l.setTransform(A);
              } else
                q(p, this._bbox), l = this._createGradient(p);
              return l;
            }
          }
          function M(d, p, D, y, n, l, s, a) {
            const c = p.coords, O = p.colors, r = d.data, A = d.width * 4;
            let F;
            c[D + 1] > c[y + 1] && (F = D, D = y, y = F, F = l, l = s, s = F), c[y + 1] > c[n + 1] && (F = y, y = n, n = F, F = s, s = a, a = F), c[D + 1] > c[y + 1] && (F = D, D = y, y = F, F = l, l = s, s = F);
            const nt = (c[D] + p.offsetX) * p.scaleX, W = (c[D + 1] + p.offsetY) * p.scaleY, $ = (c[y] + p.offsetX) * p.scaleX, j = (c[y + 1] + p.offsetY) * p.scaleY, at = (c[n] + p.offsetX) * p.scaleX, C = (c[n + 1] + p.offsetY) * p.scaleY;
            if (W >= C)
              return;
            const U = O[l], Y = O[l + 1], S = O[l + 2], e = O[s], i = O[s + 1], u = O[s + 2], x = O[a], P = O[a + 1], k = O[a + 2], G = Math.round(W), it = Math.round(C);
            let ht, dt, mt, At, vt, K, Z, g;
            for (let R = G; R <= it; R++) {
              if (R < j) {
                const yt = R < W ? 0 : (W - R) / (W - j);
                ht = nt - (nt - $) * yt, dt = U - (U - e) * yt, mt = Y - (Y - i) * yt, At = S - (S - u) * yt;
              } else {
                let yt;
                R > C ? yt = 1 : j === C ? yt = 0 : yt = (j - R) / (j - C), ht = $ - ($ - at) * yt, dt = e - (e - x) * yt, mt = i - (i - P) * yt, At = u - (u - k) * yt;
              }
              let X;
              R < W ? X = 0 : R > C ? X = 1 : X = (W - R) / (W - C), vt = nt - (nt - at) * X, K = U - (U - x) * X, Z = Y - (Y - P) * X, g = S - (S - k) * X;
              const J = Math.round(Math.min(ht, vt)), ut = Math.round(Math.max(ht, vt));
              let St = A * R + J * 4;
              for (let yt = J; yt <= ut; yt++)
                X = (ht - yt) / (ht - vt), X < 0 ? X = 0 : X > 1 && (X = 1), r[St++] = dt - (dt - K) * X | 0, r[St++] = mt - (mt - Z) * X | 0, r[St++] = At - (At - g) * X | 0, r[St++] = 255;
            }
          }
          function m(d, p, D) {
            const y = p.coords, n = p.colors;
            let l, s;
            switch (p.type) {
              case "lattice":
                const a = p.verticesPerRow, c = Math.floor(y.length / a) - 1, O = a - 1;
                for (l = 0; l < c; l++) {
                  let r = l * a;
                  for (let A = 0; A < O; A++, r++)
                    M(d, D, y[r], y[r + 1], y[r + a], n[r], n[r + 1], n[r + a]), M(d, D, y[r + a + 1], y[r + 1], y[r + a], n[r + a + 1], n[r + 1], n[r + a]);
                }
                break;
              case "triangles":
                for (l = 0, s = y.length; l < s; l += 3)
                  M(d, D, y[l], y[l + 1], y[l + 2], n[l], n[l + 1], n[l + 2]);
                break;
              default:
                throw new Error("illegal figure");
            }
          }
          class N extends gt {
            constructor(p) {
              super(), this._coords = p[2], this._colors = p[3], this._figures = p[4], this._bounds = p[5], this._bbox = p[7], this._background = p[8], this.matrix = null;
            }
            _createMeshCanvas(p, D, y) {
              const a = Math.floor(this._bounds[0]), c = Math.floor(this._bounds[1]), O = Math.ceil(this._bounds[2]) - a, r = Math.ceil(this._bounds[3]) - c, A = Math.min(Math.ceil(Math.abs(O * p[0] * 1.1)), 3e3), F = Math.min(Math.ceil(Math.abs(r * p[1] * 1.1)), 3e3), nt = O / A, W = r / F, $ = {
                coords: this._coords,
                colors: this._colors,
                offsetX: -a,
                offsetY: -c,
                scaleX: 1 / nt,
                scaleY: 1 / W
              }, j = A + 2 * 2, at = F + 2 * 2, C = y.getCanvas("mesh", j, at, !1), U = C.context, Y = U.createImageData(A, F);
              if (D) {
                const e = Y.data;
                for (let i = 0, u = e.length; i < u; i += 4)
                  e[i] = D[0], e[i + 1] = D[1], e[i + 2] = D[2], e[i + 3] = 255;
              }
              for (const e of this._figures)
                m(Y, e, $);
              return U.putImageData(Y, 2, 2), {
                canvas: C.canvas,
                offsetX: a - 2 * nt,
                offsetY: c - 2 * W,
                scaleX: nt,
                scaleY: W
              };
            }
            getPattern(p, D, y, n) {
              q(p, this._bbox);
              let l;
              if (n === ct.SHADING)
                l = o.Util.singularValueDecompose2dScale((0, T.getCurrentTransform)(p));
              else if (l = o.Util.singularValueDecompose2dScale(D.baseTransform), this.matrix) {
                const a = o.Util.singularValueDecompose2dScale(this.matrix);
                l = [l[0] * a[0], l[1] * a[1]];
              }
              const s = this._createMeshCanvas(l, n === ct.SHADING ? null : this._background, D.cachedCanvases);
              return n !== ct.SHADING && (p.setTransform(...D.baseTransform), this.matrix && p.transform(...this.matrix)), p.translate(s.offsetX, s.offsetY), p.scale(s.scaleX, s.scaleY), p.createPattern(s.canvas, "no-repeat");
            }
          }
          class I extends gt {
            getPattern() {
              return "hotpink";
            }
          }
          function _(d) {
            switch (d[0]) {
              case "RadialAxial":
                return new B(d);
              case "Mesh":
                return new N(d);
              case "Dummy":
                return new I();
            }
            throw new Error(`Unknown IR type: ${d[0]}`);
          }
          const b = {
            COLORED: 1,
            UNCOLORED: 2
          }, f = class f {
            constructor(p, D, y, n, l) {
              this.operatorList = p[2], this.matrix = p[3] || [1, 0, 0, 1, 0, 0], this.bbox = p[4], this.xstep = p[5], this.ystep = p[6], this.paintType = p[7], this.tilingType = p[8], this.color = D, this.ctx = y, this.canvasGraphicsFactory = n, this.baseTransform = l;
            }
            createPatternCanvas(p) {
              const D = this.operatorList, y = this.bbox, n = this.xstep, l = this.ystep, s = this.paintType, a = this.tilingType, c = this.color, O = this.canvasGraphicsFactory;
              (0, o.info)("TilingType: " + a);
              const r = y[0], A = y[1], F = y[2], nt = y[3], W = o.Util.singularValueDecompose2dScale(this.matrix), $ = o.Util.singularValueDecompose2dScale(this.baseTransform), j = [W[0] * $[0], W[1] * $[1]], at = this.getSizeAndScale(n, this.ctx.canvas.width, j[0]), C = this.getSizeAndScale(l, this.ctx.canvas.height, j[1]), U = p.cachedCanvases.getCanvas("pattern", at.size, C.size, !0), Y = U.context, S = O.createCanvasGraphics(Y);
              S.groupLevel = p.groupLevel, this.setFillAndStrokeStyleToContext(S, s, c);
              let e = r, i = A, u = F, x = nt;
              return r < 0 && (e = 0, u += Math.abs(r)), A < 0 && (i = 0, x += Math.abs(A)), Y.translate(-(at.scale * e), -(C.scale * i)), S.transform(at.scale, 0, 0, C.scale, 0, 0), Y.save(), this.clipBbox(S, e, i, u, x), S.baseTransform = (0, T.getCurrentTransform)(S.ctx), S.executeOperatorList(D), S.endDrawing(), {
                canvas: U.canvas,
                scaleX: at.scale,
                scaleY: C.scale,
                offsetX: e,
                offsetY: i
              };
            }
            getSizeAndScale(p, D, y) {
              p = Math.abs(p);
              const n = Math.max(f.MAX_PATTERN_SIZE, D);
              let l = Math.ceil(p * y);
              return l >= n ? l = n : y = l / p, {
                scale: y,
                size: l
              };
            }
            clipBbox(p, D, y, n, l) {
              const s = n - D, a = l - y;
              p.ctx.rect(D, y, s, a), p.current.updateRectMinMax((0, T.getCurrentTransform)(p.ctx), [D, y, n, l]), p.clip(), p.endPath();
            }
            setFillAndStrokeStyleToContext(p, D, y) {
              const n = p.ctx, l = p.current;
              switch (D) {
                case b.COLORED:
                  const s = this.ctx;
                  n.fillStyle = s.fillStyle, n.strokeStyle = s.strokeStyle, l.fillColor = s.fillStyle, l.strokeColor = s.strokeStyle;
                  break;
                case b.UNCOLORED:
                  const a = o.Util.makeHexColor(y[0], y[1], y[2]);
                  n.fillStyle = a, n.strokeStyle = a, l.fillColor = a, l.strokeColor = a;
                  break;
                default:
                  throw new o.FormatError(`Unsupported paint type: ${D}`);
              }
            }
            getPattern(p, D, y, n) {
              let l = y;
              n !== ct.SHADING && (l = o.Util.transform(l, D.baseTransform), this.matrix && (l = o.Util.transform(l, this.matrix)));
              const s = this.createPatternCanvas(D);
              let a = new DOMMatrix(l);
              a = a.translate(s.offsetX, s.offsetY), a = a.scale(1 / s.scaleX, 1 / s.scaleY);
              const c = p.createPattern(s.canvas, "repeat");
              return c.setTransform(a), c;
            }
          };
          Kt(f, "MAX_PATTERN_SIZE", 3e3);
          let E = f;
          h.TilingPattern = E;
        },
        /* 13 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.convertBlackAndWhiteToRGBA = ct, h.convertToRGBA = T, h.grayToRGBA = gt;
          var o = rt(1);
          function T(B) {
            switch (B.kind) {
              case o.ImageKind.GRAYSCALE_1BPP:
                return ct(B);
              case o.ImageKind.RGB_24BPP:
                return q(B);
            }
            return null;
          }
          function ct({
            src: B,
            srcPos: M = 0,
            dest: m,
            width: N,
            height: I,
            nonBlackColor: _ = 4294967295,
            inverseDecode: b = !1
          }) {
            const E = o.FeatureTest.isLittleEndian ? 4278190080 : 255, [f, d] = b ? [_, E] : [E, _], p = N >> 3, D = N & 7, y = B.length;
            m = new Uint32Array(m.buffer);
            let n = 0;
            for (let l = 0; l < I; l++) {
              for (const a = M + p; M < a; M++) {
                const c = M < y ? B[M] : 255;
                m[n++] = c & 128 ? d : f, m[n++] = c & 64 ? d : f, m[n++] = c & 32 ? d : f, m[n++] = c & 16 ? d : f, m[n++] = c & 8 ? d : f, m[n++] = c & 4 ? d : f, m[n++] = c & 2 ? d : f, m[n++] = c & 1 ? d : f;
              }
              if (D === 0)
                continue;
              const s = M < y ? B[M++] : 255;
              for (let a = 0; a < D; a++)
                m[n++] = s & 1 << 7 - a ? d : f;
            }
            return {
              srcPos: M,
              destPos: n
            };
          }
          function q({
            src: B,
            srcPos: M = 0,
            dest: m,
            destPos: N = 0,
            width: I,
            height: _
          }) {
            let b = 0;
            const E = B.length >> 2, f = new Uint32Array(B.buffer, M, E);
            if (o.FeatureTest.isLittleEndian) {
              for (; b < E - 2; b += 3, N += 4) {
                const d = f[b], p = f[b + 1], D = f[b + 2];
                m[N] = d | 4278190080, m[N + 1] = d >>> 24 | p << 8 | 4278190080, m[N + 2] = p >>> 16 | D << 16 | 4278190080, m[N + 3] = D >>> 8 | 4278190080;
              }
              for (let d = b * 4, p = B.length; d < p; d += 3)
                m[N++] = B[d] | B[d + 1] << 8 | B[d + 2] << 16 | 4278190080;
            } else {
              for (; b < E - 2; b += 3, N += 4) {
                const d = f[b], p = f[b + 1], D = f[b + 2];
                m[N] = d | 255, m[N + 1] = d << 24 | p >>> 8 | 255, m[N + 2] = p << 16 | D >>> 16 | 255, m[N + 3] = D << 8 | 255;
              }
              for (let d = b * 4, p = B.length; d < p; d += 3)
                m[N++] = B[d] << 24 | B[d + 1] << 16 | B[d + 2] << 8 | 255;
            }
            return {
              srcPos: M,
              destPos: N
            };
          }
          function gt(B, M) {
            if (o.FeatureTest.isLittleEndian)
              for (let m = 0, N = B.length; m < N; m++)
                M[m] = B[m] * 65793 | 4278190080;
            else
              for (let m = 0, N = B.length; m < N; m++)
                M[m] = B[m] * 16843008 | 255;
          }
        },
        /* 14 */
        /***/
        (pt, h) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.GlobalWorkerOptions = void 0;
          const rt = /* @__PURE__ */ Object.create(null);
          h.GlobalWorkerOptions = rt, rt.workerPort = null, rt.workerSrc = "";
        },
        /* 15 */
        /***/
        (pt, h, rt) => {
          var B, wi, Ci, Ee;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.MessageHandler = void 0;
          var o = rt(1);
          const T = {
            UNKNOWN: 0,
            DATA: 1,
            ERROR: 2
          }, ct = {
            UNKNOWN: 0,
            CANCEL: 1,
            CANCEL_COMPLETE: 2,
            CLOSE: 3,
            ENQUEUE: 4,
            ERROR: 5,
            PULL: 6,
            PULL_COMPLETE: 7,
            START_COMPLETE: 8
          };
          function q(I) {
            switch (I instanceof Error || typeof I == "object" && I !== null || (0, o.unreachable)('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), I.name) {
              case "AbortException":
                return new o.AbortException(I.message);
              case "MissingPDFException":
                return new o.MissingPDFException(I.message);
              case "PasswordException":
                return new o.PasswordException(I.message, I.code);
              case "UnexpectedResponseException":
                return new o.UnexpectedResponseException(I.message, I.status);
              case "UnknownErrorException":
                return new o.UnknownErrorException(I.message, I.details);
              default:
                return new o.UnknownErrorException(I.message, I.toString());
            }
          }
          class gt {
            constructor(_, b, E) {
              Q(this, B);
              this.sourceName = _, this.targetName = b, this.comObj = E, this.callbackId = 1, this.streamId = 1, this.streamSinks = /* @__PURE__ */ Object.create(null), this.streamControllers = /* @__PURE__ */ Object.create(null), this.callbackCapabilities = /* @__PURE__ */ Object.create(null), this.actionHandler = /* @__PURE__ */ Object.create(null), this._onComObjOnMessage = (f) => {
                const d = f.data;
                if (d.targetName !== this.sourceName)
                  return;
                if (d.stream) {
                  z(this, B, Ci).call(this, d);
                  return;
                }
                if (d.callback) {
                  const D = d.callbackId, y = this.callbackCapabilities[D];
                  if (!y)
                    throw new Error(`Cannot resolve callback ${D}`);
                  if (delete this.callbackCapabilities[D], d.callback === T.DATA)
                    y.resolve(d.data);
                  else if (d.callback === T.ERROR)
                    y.reject(q(d.reason));
                  else
                    throw new Error("Unexpected callback case");
                  return;
                }
                const p = this.actionHandler[d.action];
                if (!p)
                  throw new Error(`Unknown action from worker: ${d.action}`);
                if (d.callbackId) {
                  const D = this.sourceName, y = d.sourceName;
                  new Promise(function(n) {
                    n(p(d.data));
                  }).then(function(n) {
                    E.postMessage({
                      sourceName: D,
                      targetName: y,
                      callback: T.DATA,
                      callbackId: d.callbackId,
                      data: n
                    });
                  }, function(n) {
                    E.postMessage({
                      sourceName: D,
                      targetName: y,
                      callback: T.ERROR,
                      callbackId: d.callbackId,
                      reason: q(n)
                    });
                  });
                  return;
                }
                if (d.streamId) {
                  z(this, B, wi).call(this, d);
                  return;
                }
                p(d.data);
              }, E.addEventListener("message", this._onComObjOnMessage);
            }
            on(_, b) {
              const E = this.actionHandler;
              if (E[_])
                throw new Error(`There is already an actionName called "${_}"`);
              E[_] = b;
            }
            send(_, b, E) {
              this.comObj.postMessage({
                sourceName: this.sourceName,
                targetName: this.targetName,
                action: _,
                data: b
              }, E);
            }
            sendWithPromise(_, b, E) {
              const f = this.callbackId++, d = new o.PromiseCapability();
              this.callbackCapabilities[f] = d;
              try {
                this.comObj.postMessage({
                  sourceName: this.sourceName,
                  targetName: this.targetName,
                  action: _,
                  callbackId: f,
                  data: b
                }, E);
              } catch (p) {
                d.reject(p);
              }
              return d.promise;
            }
            sendWithStream(_, b, E, f) {
              const d = this.streamId++, p = this.sourceName, D = this.targetName, y = this.comObj;
              return new ReadableStream({
                start: (n) => {
                  const l = new o.PromiseCapability();
                  return this.streamControllers[d] = {
                    controller: n,
                    startCall: l,
                    pullCall: null,
                    cancelCall: null,
                    isClosed: !1
                  }, y.postMessage({
                    sourceName: p,
                    targetName: D,
                    action: _,
                    streamId: d,
                    data: b,
                    desiredSize: n.desiredSize
                  }, f), l.promise;
                },
                pull: (n) => {
                  const l = new o.PromiseCapability();
                  return this.streamControllers[d].pullCall = l, y.postMessage({
                    sourceName: p,
                    targetName: D,
                    stream: ct.PULL,
                    streamId: d,
                    desiredSize: n.desiredSize
                  }), l.promise;
                },
                cancel: (n) => {
                  (0, o.assert)(n instanceof Error, "cancel must have a valid reason");
                  const l = new o.PromiseCapability();
                  return this.streamControllers[d].cancelCall = l, this.streamControllers[d].isClosed = !0, y.postMessage({
                    sourceName: p,
                    targetName: D,
                    stream: ct.CANCEL,
                    streamId: d,
                    reason: q(n)
                  }), l.promise;
                }
              }, E);
            }
            destroy() {
              this.comObj.removeEventListener("message", this._onComObjOnMessage);
            }
          }
          B = new WeakSet(), wi = function(_) {
            const b = _.streamId, E = this.sourceName, f = _.sourceName, d = this.comObj, p = this, D = this.actionHandler[_.action], y = {
              enqueue(n, l = 1, s) {
                if (this.isCancelled)
                  return;
                const a = this.desiredSize;
                this.desiredSize -= l, a > 0 && this.desiredSize <= 0 && (this.sinkCapability = new o.PromiseCapability(), this.ready = this.sinkCapability.promise), d.postMessage({
                  sourceName: E,
                  targetName: f,
                  stream: ct.ENQUEUE,
                  streamId: b,
                  chunk: n
                }, s);
              },
              close() {
                this.isCancelled || (this.isCancelled = !0, d.postMessage({
                  sourceName: E,
                  targetName: f,
                  stream: ct.CLOSE,
                  streamId: b
                }), delete p.streamSinks[b]);
              },
              error(n) {
                (0, o.assert)(n instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, d.postMessage({
                  sourceName: E,
                  targetName: f,
                  stream: ct.ERROR,
                  streamId: b,
                  reason: q(n)
                }));
              },
              sinkCapability: new o.PromiseCapability(),
              onPull: null,
              onCancel: null,
              isCancelled: !1,
              desiredSize: _.desiredSize,
              ready: null
            };
            y.sinkCapability.resolve(), y.ready = y.sinkCapability.promise, this.streamSinks[b] = y, new Promise(function(n) {
              n(D(_.data, y));
            }).then(function() {
              d.postMessage({
                sourceName: E,
                targetName: f,
                stream: ct.START_COMPLETE,
                streamId: b,
                success: !0
              });
            }, function(n) {
              d.postMessage({
                sourceName: E,
                targetName: f,
                stream: ct.START_COMPLETE,
                streamId: b,
                reason: q(n)
              });
            });
          }, Ci = function(_) {
            const b = _.streamId, E = this.sourceName, f = _.sourceName, d = this.comObj, p = this.streamControllers[b], D = this.streamSinks[b];
            switch (_.stream) {
              case ct.START_COMPLETE:
                _.success ? p.startCall.resolve() : p.startCall.reject(q(_.reason));
                break;
              case ct.PULL_COMPLETE:
                _.success ? p.pullCall.resolve() : p.pullCall.reject(q(_.reason));
                break;
              case ct.PULL:
                if (!D) {
                  d.postMessage({
                    sourceName: E,
                    targetName: f,
                    stream: ct.PULL_COMPLETE,
                    streamId: b,
                    success: !0
                  });
                  break;
                }
                D.desiredSize <= 0 && _.desiredSize > 0 && D.sinkCapability.resolve(), D.desiredSize = _.desiredSize, new Promise(function(y) {
                  var n;
                  y((n = D.onPull) == null ? void 0 : n.call(D));
                }).then(function() {
                  d.postMessage({
                    sourceName: E,
                    targetName: f,
                    stream: ct.PULL_COMPLETE,
                    streamId: b,
                    success: !0
                  });
                }, function(y) {
                  d.postMessage({
                    sourceName: E,
                    targetName: f,
                    stream: ct.PULL_COMPLETE,
                    streamId: b,
                    reason: q(y)
                  });
                });
                break;
              case ct.ENQUEUE:
                if ((0, o.assert)(p, "enqueue should have stream controller"), p.isClosed)
                  break;
                p.controller.enqueue(_.chunk);
                break;
              case ct.CLOSE:
                if ((0, o.assert)(p, "close should have stream controller"), p.isClosed)
                  break;
                p.isClosed = !0, p.controller.close(), z(this, B, Ee).call(this, p, b);
                break;
              case ct.ERROR:
                (0, o.assert)(p, "error should have stream controller"), p.controller.error(q(_.reason)), z(this, B, Ee).call(this, p, b);
                break;
              case ct.CANCEL_COMPLETE:
                _.success ? p.cancelCall.resolve() : p.cancelCall.reject(q(_.reason)), z(this, B, Ee).call(this, p, b);
                break;
              case ct.CANCEL:
                if (!D)
                  break;
                new Promise(function(y) {
                  var n;
                  y((n = D.onCancel) == null ? void 0 : n.call(D, q(_.reason)));
                }).then(function() {
                  d.postMessage({
                    sourceName: E,
                    targetName: f,
                    stream: ct.CANCEL_COMPLETE,
                    streamId: b,
                    success: !0
                  });
                }, function(y) {
                  d.postMessage({
                    sourceName: E,
                    targetName: f,
                    stream: ct.CANCEL_COMPLETE,
                    streamId: b,
                    reason: q(y)
                  });
                }), D.sinkCapability.reject(q(_.reason)), D.isCancelled = !0, delete this.streamSinks[b];
                break;
              default:
                throw new Error("Unexpected stream case");
            }
          }, Ee = async function(_, b) {
            var E, f, d;
            await Promise.allSettled([(E = _.startCall) == null ? void 0 : E.promise, (f = _.pullCall) == null ? void 0 : f.promise, (d = _.cancelCall) == null ? void 0 : d.promise]), delete this.streamControllers[b];
          }, h.MessageHandler = gt;
        },
        /* 16 */
        /***/
        (pt, h, rt) => {
          var ct, q;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.Metadata = void 0;
          var o = rt(1);
          class T {
            constructor({
              parsedData: B,
              rawData: M
            }) {
              Q(this, ct);
              Q(this, q);
              et(this, ct, B), et(this, q, M);
            }
            getRaw() {
              return t(this, q);
            }
            get(B) {
              return t(this, ct).get(B) ?? null;
            }
            getAll() {
              return (0, o.objectFromMap)(t(this, ct));
            }
            has(B) {
              return t(this, ct).has(B);
            }
          }
          ct = new WeakMap(), q = new WeakMap(), h.Metadata = T;
        },
        /* 17 */
        /***/
        (pt, h, rt) => {
          var B, M, m, N, I, _, Ye;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.OptionalContentConfig = void 0;
          var o = rt(1), T = rt(8);
          const ct = Symbol("INTERNAL");
          class q {
            constructor(f, d) {
              Q(this, B, !0);
              this.name = f, this.intent = d;
            }
            get visible() {
              return t(this, B);
            }
            _setVisible(f, d) {
              f !== ct && (0, o.unreachable)("Internal method `_setVisible` called."), et(this, B, d);
            }
          }
          B = new WeakMap();
          class gt {
            constructor(f) {
              Q(this, _);
              Q(this, M, null);
              Q(this, m, /* @__PURE__ */ new Map());
              Q(this, N, null);
              Q(this, I, null);
              if (this.name = null, this.creator = null, f !== null) {
                this.name = f.name, this.creator = f.creator, et(this, I, f.order);
                for (const d of f.groups)
                  t(this, m).set(d.id, new q(d.name, d.intent));
                if (f.baseState === "OFF")
                  for (const d of t(this, m).values())
                    d._setVisible(ct, !1);
                for (const d of f.on)
                  t(this, m).get(d)._setVisible(ct, !0);
                for (const d of f.off)
                  t(this, m).get(d)._setVisible(ct, !1);
                et(this, N, this.getHash());
              }
            }
            isVisible(f) {
              if (t(this, m).size === 0)
                return !0;
              if (!f)
                return (0, o.warn)("Optional content group not defined."), !0;
              if (f.type === "OCG")
                return t(this, m).has(f.id) ? t(this, m).get(f.id).visible : ((0, o.warn)(`Optional content group not found: ${f.id}`), !0);
              if (f.type === "OCMD") {
                if (f.expression)
                  return z(this, _, Ye).call(this, f.expression);
                if (!f.policy || f.policy === "AnyOn") {
                  for (const d of f.ids) {
                    if (!t(this, m).has(d))
                      return (0, o.warn)(`Optional content group not found: ${d}`), !0;
                    if (t(this, m).get(d).visible)
                      return !0;
                  }
                  return !1;
                } else if (f.policy === "AllOn") {
                  for (const d of f.ids) {
                    if (!t(this, m).has(d))
                      return (0, o.warn)(`Optional content group not found: ${d}`), !0;
                    if (!t(this, m).get(d).visible)
                      return !1;
                  }
                  return !0;
                } else if (f.policy === "AnyOff") {
                  for (const d of f.ids) {
                    if (!t(this, m).has(d))
                      return (0, o.warn)(`Optional content group not found: ${d}`), !0;
                    if (!t(this, m).get(d).visible)
                      return !0;
                  }
                  return !1;
                } else if (f.policy === "AllOff") {
                  for (const d of f.ids) {
                    if (!t(this, m).has(d))
                      return (0, o.warn)(`Optional content group not found: ${d}`), !0;
                    if (t(this, m).get(d).visible)
                      return !1;
                  }
                  return !0;
                }
                return (0, o.warn)(`Unknown optional content policy ${f.policy}.`), !0;
              }
              return (0, o.warn)(`Unknown group type ${f.type}.`), !0;
            }
            setVisibility(f, d = !0) {
              if (!t(this, m).has(f)) {
                (0, o.warn)(`Optional content group not found: ${f}`);
                return;
              }
              t(this, m).get(f)._setVisible(ct, !!d), et(this, M, null);
            }
            get hasInitialVisibility() {
              return t(this, N) === null || this.getHash() === t(this, N);
            }
            getOrder() {
              return t(this, m).size ? t(this, I) ? t(this, I).slice() : [...t(this, m).keys()] : null;
            }
            getGroups() {
              return t(this, m).size > 0 ? (0, o.objectFromMap)(t(this, m)) : null;
            }
            getGroup(f) {
              return t(this, m).get(f) || null;
            }
            getHash() {
              if (t(this, M) !== null)
                return t(this, M);
              const f = new T.MurmurHash3_64();
              for (const [d, p] of t(this, m))
                f.update(`${d}:${p.visible}`);
              return et(this, M, f.hexdigest());
            }
          }
          M = new WeakMap(), m = new WeakMap(), N = new WeakMap(), I = new WeakMap(), _ = new WeakSet(), Ye = function(f) {
            const d = f.length;
            if (d < 2)
              return !0;
            const p = f[0];
            for (let D = 1; D < d; D++) {
              const y = f[D];
              let n;
              if (Array.isArray(y))
                n = z(this, _, Ye).call(this, y);
              else if (t(this, m).has(y))
                n = t(this, m).get(y).visible;
              else
                return (0, o.warn)(`Optional content group not found: ${y}`), !0;
              switch (p) {
                case "And":
                  if (!n)
                    return !1;
                  break;
                case "Or":
                  if (n)
                    return !0;
                  break;
                case "Not":
                  return !n;
                default:
                  return !0;
              }
            }
            return p === "And";
          }, h.OptionalContentConfig = gt;
        },
        /* 18 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.PDFDataTransportStream = void 0;
          var o = rt(1), T = rt(6);
          class ct {
            constructor({
              length: M,
              initialData: m,
              progressiveDone: N = !1,
              contentDispositionFilename: I = null,
              disableRange: _ = !1,
              disableStream: b = !1
            }, E) {
              if ((0, o.assert)(E, 'PDFDataTransportStream - missing required "pdfDataRangeTransport" argument.'), this._queuedChunks = [], this._progressiveDone = N, this._contentDispositionFilename = I, (m == null ? void 0 : m.length) > 0) {
                const f = m instanceof Uint8Array && m.byteLength === m.buffer.byteLength ? m.buffer : new Uint8Array(m).buffer;
                this._queuedChunks.push(f);
              }
              this._pdfDataRangeTransport = E, this._isStreamingSupported = !b, this._isRangeSupported = !_, this._contentLength = M, this._fullRequestReader = null, this._rangeReaders = [], this._pdfDataRangeTransport.addRangeListener((f, d) => {
                this._onReceiveData({
                  begin: f,
                  chunk: d
                });
              }), this._pdfDataRangeTransport.addProgressListener((f, d) => {
                this._onProgress({
                  loaded: f,
                  total: d
                });
              }), this._pdfDataRangeTransport.addProgressiveReadListener((f) => {
                this._onReceiveData({
                  chunk: f
                });
              }), this._pdfDataRangeTransport.addProgressiveDoneListener(() => {
                this._onProgressiveDone();
              }), this._pdfDataRangeTransport.transportReady();
            }
            _onReceiveData({
              begin: M,
              chunk: m
            }) {
              const N = m instanceof Uint8Array && m.byteLength === m.buffer.byteLength ? m.buffer : new Uint8Array(m).buffer;
              if (M === void 0)
                this._fullRequestReader ? this._fullRequestReader._enqueue(N) : this._queuedChunks.push(N);
              else {
                const I = this._rangeReaders.some(function(_) {
                  return _._begin !== M ? !1 : (_._enqueue(N), !0);
                });
                (0, o.assert)(I, "_onReceiveData - no `PDFDataTransportStreamRangeReader` instance found.");
              }
            }
            get _progressiveDataLength() {
              var M;
              return ((M = this._fullRequestReader) == null ? void 0 : M._loaded) ?? 0;
            }
            _onProgress(M) {
              var m, N, I, _;
              M.total === void 0 ? (N = (m = this._rangeReaders[0]) == null ? void 0 : m.onProgress) == null || N.call(m, {
                loaded: M.loaded
              }) : (_ = (I = this._fullRequestReader) == null ? void 0 : I.onProgress) == null || _.call(I, {
                loaded: M.loaded,
                total: M.total
              });
            }
            _onProgressiveDone() {
              var M;
              (M = this._fullRequestReader) == null || M.progressiveDone(), this._progressiveDone = !0;
            }
            _removeRangeReader(M) {
              const m = this._rangeReaders.indexOf(M);
              m >= 0 && this._rangeReaders.splice(m, 1);
            }
            getFullReader() {
              (0, o.assert)(!this._fullRequestReader, "PDFDataTransportStream.getFullReader can only be called once.");
              const M = this._queuedChunks;
              return this._queuedChunks = null, new q(this, M, this._progressiveDone, this._contentDispositionFilename);
            }
            getRangeReader(M, m) {
              if (m <= this._progressiveDataLength)
                return null;
              const N = new gt(this, M, m);
              return this._pdfDataRangeTransport.requestDataRange(M, m), this._rangeReaders.push(N), N;
            }
            cancelAllRequests(M) {
              var m;
              (m = this._fullRequestReader) == null || m.cancel(M);
              for (const N of this._rangeReaders.slice(0))
                N.cancel(M);
              this._pdfDataRangeTransport.abort();
            }
          }
          h.PDFDataTransportStream = ct;
          class q {
            constructor(M, m, N = !1, I = null) {
              this._stream = M, this._done = N || !1, this._filename = (0, T.isPdfFile)(I) ? I : null, this._queuedChunks = m || [], this._loaded = 0;
              for (const _ of this._queuedChunks)
                this._loaded += _.byteLength;
              this._requests = [], this._headersReady = Promise.resolve(), M._fullRequestReader = this, this.onProgress = null;
            }
            _enqueue(M) {
              this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
                value: M,
                done: !1
              }) : this._queuedChunks.push(M), this._loaded += M.byteLength);
            }
            get headersReady() {
              return this._headersReady;
            }
            get filename() {
              return this._filename;
            }
            get isRangeSupported() {
              return this._stream._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._stream._isStreamingSupported;
            }
            get contentLength() {
              return this._stream._contentLength;
            }
            async read() {
              if (this._queuedChunks.length > 0)
                return {
                  value: this._queuedChunks.shift(),
                  done: !1
                };
              if (this._done)
                return {
                  value: void 0,
                  done: !0
                };
              const M = new o.PromiseCapability();
              return this._requests.push(M), M.promise;
            }
            cancel(M) {
              this._done = !0;
              for (const m of this._requests)
                m.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0;
            }
            progressiveDone() {
              this._done || (this._done = !0);
            }
          }
          class gt {
            constructor(M, m, N) {
              this._stream = M, this._begin = m, this._end = N, this._queuedChunk = null, this._requests = [], this._done = !1, this.onProgress = null;
            }
            _enqueue(M) {
              if (!this._done) {
                if (this._requests.length === 0)
                  this._queuedChunk = M;
                else {
                  this._requests.shift().resolve({
                    value: M,
                    done: !1
                  });
                  for (const N of this._requests)
                    N.resolve({
                      value: void 0,
                      done: !0
                    });
                  this._requests.length = 0;
                }
                this._done = !0, this._stream._removeRangeReader(this);
              }
            }
            get isStreamingSupported() {
              return !1;
            }
            async read() {
              if (this._queuedChunk) {
                const m = this._queuedChunk;
                return this._queuedChunk = null, {
                  value: m,
                  done: !1
                };
              }
              if (this._done)
                return {
                  value: void 0,
                  done: !0
                };
              const M = new o.PromiseCapability();
              return this._requests.push(M), M.promise;
            }
            cancel(M) {
              this._done = !0;
              for (const m of this._requests)
                m.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0, this._stream._removeRangeReader(this);
            }
          }
        },
        /* 19 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.PDFFetchStream = void 0;
          var o = rt(1), T = rt(20);
          function ct(N, I, _) {
            return {
              method: "GET",
              headers: N,
              signal: _.signal,
              mode: "cors",
              credentials: I ? "include" : "same-origin",
              redirect: "follow"
            };
          }
          function q(N) {
            const I = new Headers();
            for (const _ in N) {
              const b = N[_];
              b !== void 0 && I.append(_, b);
            }
            return I;
          }
          function gt(N) {
            return N instanceof Uint8Array ? N.buffer : N instanceof ArrayBuffer ? N : ((0, o.warn)(`getArrayBuffer - unexpected data format: ${N}`), new Uint8Array(N).buffer);
          }
          class B {
            constructor(I) {
              this.source = I, this.isHttp = /^https?:/i.test(I.url), this.httpHeaders = this.isHttp && I.httpHeaders || {}, this._fullRequestReader = null, this._rangeRequestReaders = [];
            }
            get _progressiveDataLength() {
              var I;
              return ((I = this._fullRequestReader) == null ? void 0 : I._loaded) ?? 0;
            }
            getFullReader() {
              return (0, o.assert)(!this._fullRequestReader, "PDFFetchStream.getFullReader can only be called once."), this._fullRequestReader = new M(this), this._fullRequestReader;
            }
            getRangeReader(I, _) {
              if (_ <= this._progressiveDataLength)
                return null;
              const b = new m(this, I, _);
              return this._rangeRequestReaders.push(b), b;
            }
            cancelAllRequests(I) {
              var _;
              (_ = this._fullRequestReader) == null || _.cancel(I);
              for (const b of this._rangeRequestReaders.slice(0))
                b.cancel(I);
            }
          }
          h.PDFFetchStream = B;
          class M {
            constructor(I) {
              this._stream = I, this._reader = null, this._loaded = 0, this._filename = null;
              const _ = I.source;
              this._withCredentials = _.withCredentials || !1, this._contentLength = _.length, this._headersCapability = new o.PromiseCapability(), this._disableRange = _.disableRange || !1, this._rangeChunkSize = _.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._abortController = new AbortController(), this._isStreamingSupported = !_.disableStream, this._isRangeSupported = !_.disableRange, this._headers = q(this._stream.httpHeaders);
              const b = _.url;
              fetch(b, ct(this._headers, this._withCredentials, this._abortController)).then((E) => {
                if (!(0, T.validateResponseStatus)(E.status))
                  throw (0, T.createResponseStatusError)(E.status, b);
                this._reader = E.body.getReader(), this._headersCapability.resolve();
                const f = (D) => E.headers.get(D), {
                  allowRangeRequests: d,
                  suggestedLength: p
                } = (0, T.validateRangeRequestCapabilities)({
                  getResponseHeader: f,
                  isHttp: this._stream.isHttp,
                  rangeChunkSize: this._rangeChunkSize,
                  disableRange: this._disableRange
                });
                this._isRangeSupported = d, this._contentLength = p || this._contentLength, this._filename = (0, T.extractFilenameFromHeader)(f), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new o.AbortException("Streaming is disabled."));
              }).catch(this._headersCapability.reject), this.onProgress = null;
            }
            get headersReady() {
              return this._headersCapability.promise;
            }
            get filename() {
              return this._filename;
            }
            get contentLength() {
              return this._contentLength;
            }
            get isRangeSupported() {
              return this._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              var b;
              await this._headersCapability.promise;
              const {
                value: I,
                done: _
              } = await this._reader.read();
              return _ ? {
                value: I,
                done: _
              } : (this._loaded += I.byteLength, (b = this.onProgress) == null || b.call(this, {
                loaded: this._loaded,
                total: this._contentLength
              }), {
                value: gt(I),
                done: !1
              });
            }
            cancel(I) {
              var _;
              (_ = this._reader) == null || _.cancel(I), this._abortController.abort();
            }
          }
          class m {
            constructor(I, _, b) {
              this._stream = I, this._reader = null, this._loaded = 0;
              const E = I.source;
              this._withCredentials = E.withCredentials || !1, this._readCapability = new o.PromiseCapability(), this._isStreamingSupported = !E.disableStream, this._abortController = new AbortController(), this._headers = q(this._stream.httpHeaders), this._headers.append("Range", `bytes=${_}-${b - 1}`);
              const f = E.url;
              fetch(f, ct(this._headers, this._withCredentials, this._abortController)).then((d) => {
                if (!(0, T.validateResponseStatus)(d.status))
                  throw (0, T.createResponseStatusError)(d.status, f);
                this._readCapability.resolve(), this._reader = d.body.getReader();
              }).catch(this._readCapability.reject), this.onProgress = null;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              var b;
              await this._readCapability.promise;
              const {
                value: I,
                done: _
              } = await this._reader.read();
              return _ ? {
                value: I,
                done: _
              } : (this._loaded += I.byteLength, (b = this.onProgress) == null || b.call(this, {
                loaded: this._loaded
              }), {
                value: gt(I),
                done: !1
              });
            }
            cancel(I) {
              var _;
              (_ = this._reader) == null || _.cancel(I), this._abortController.abort();
            }
          }
        },
        /* 20 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.createResponseStatusError = B, h.extractFilenameFromHeader = gt, h.validateRangeRequestCapabilities = q, h.validateResponseStatus = M;
          var o = rt(1), T = rt(21), ct = rt(6);
          function q({
            getResponseHeader: m,
            isHttp: N,
            rangeChunkSize: I,
            disableRange: _
          }) {
            const b = {
              allowRangeRequests: !1,
              suggestedLength: void 0
            }, E = parseInt(m("Content-Length"), 10);
            return !Number.isInteger(E) || (b.suggestedLength = E, E <= 2 * I) || _ || !N || m("Accept-Ranges") !== "bytes" || (m("Content-Encoding") || "identity") !== "identity" || (b.allowRangeRequests = !0), b;
          }
          function gt(m) {
            const N = m("Content-Disposition");
            if (N) {
              let I = (0, T.getFilenameFromContentDispositionHeader)(N);
              if (I.includes("%"))
                try {
                  I = decodeURIComponent(I);
                } catch {
                }
              if ((0, ct.isPdfFile)(I))
                return I;
            }
            return null;
          }
          function B(m, N) {
            return m === 404 || m === 0 && N.startsWith("file:") ? new o.MissingPDFException('Missing PDF "' + N + '".') : new o.UnexpectedResponseException(`Unexpected server response (${m}) while retrieving PDF "${N}".`, m);
          }
          function M(m) {
            return m === 200 || m === 206;
          }
        },
        /* 21 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.getFilenameFromContentDispositionHeader = T;
          var o = rt(1);
          function T(ct) {
            let q = !0, gt = B("filename\\*", "i").exec(ct);
            if (gt) {
              gt = gt[1];
              let E = I(gt);
              return E = unescape(E), E = _(E), E = b(E), m(E);
            }
            if (gt = N(ct), gt) {
              const E = b(gt);
              return m(E);
            }
            if (gt = B("filename", "i").exec(ct), gt) {
              gt = gt[1];
              let E = I(gt);
              return E = b(E), m(E);
            }
            function B(E, f) {
              return new RegExp("(?:^|;)\\s*" + E + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', f);
            }
            function M(E, f) {
              if (E) {
                if (!/^[\x00-\xFF]+$/.test(f))
                  return f;
                try {
                  const d = new TextDecoder(E, {
                    fatal: !0
                  }), p = (0, o.stringToBytes)(f);
                  f = d.decode(p), q = !1;
                } catch {
                }
              }
              return f;
            }
            function m(E) {
              return q && /[\x80-\xff]/.test(E) && (E = M("utf-8", E), q && (E = M("iso-8859-1", E))), E;
            }
            function N(E) {
              const f = [];
              let d;
              const p = B("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
              for (; (d = p.exec(E)) !== null; ) {
                let [, y, n, l] = d;
                if (y = parseInt(y, 10), y in f) {
                  if (y === 0)
                    break;
                  continue;
                }
                f[y] = [n, l];
              }
              const D = [];
              for (let y = 0; y < f.length && y in f; ++y) {
                let [n, l] = f[y];
                l = I(l), n && (l = unescape(l), y === 0 && (l = _(l))), D.push(l);
              }
              return D.join("");
            }
            function I(E) {
              if (E.startsWith('"')) {
                const f = E.slice(1).split('\\"');
                for (let d = 0; d < f.length; ++d) {
                  const p = f[d].indexOf('"');
                  p !== -1 && (f[d] = f[d].slice(0, p), f.length = d + 1), f[d] = f[d].replaceAll(/\\(.)/g, "$1");
                }
                E = f.join('"');
              }
              return E;
            }
            function _(E) {
              const f = E.indexOf("'");
              if (f === -1)
                return E;
              const d = E.slice(0, f), D = E.slice(f + 1).replace(/^[^']*'/, "");
              return M(d, D);
            }
            function b(E) {
              return !E.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(E) ? E : E.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g, function(f, d, p, D) {
                if (p === "q" || p === "Q")
                  return D = D.replaceAll("_", " "), D = D.replaceAll(/=([0-9a-fA-F]{2})/g, function(y, n) {
                    return String.fromCharCode(parseInt(n, 16));
                  }), M(d, D);
                try {
                  D = atob(D);
                } catch {
                }
                return M(d, D);
              });
            }
            return "";
          }
        },
        /* 22 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.PDFNetworkStream = void 0;
          var o = rt(1), T = rt(20);
          const ct = 200, q = 206;
          function gt(I) {
            const _ = I.response;
            return typeof _ != "string" ? _ : (0, o.stringToBytes)(_).buffer;
          }
          class B {
            constructor(_, b = {}) {
              this.url = _, this.isHttp = /^https?:/i.test(_), this.httpHeaders = this.isHttp && b.httpHeaders || /* @__PURE__ */ Object.create(null), this.withCredentials = b.withCredentials || !1, this.currXhrId = 0, this.pendingRequests = /* @__PURE__ */ Object.create(null);
            }
            requestRange(_, b, E) {
              const f = {
                begin: _,
                end: b
              };
              for (const d in E)
                f[d] = E[d];
              return this.request(f);
            }
            requestFull(_) {
              return this.request(_);
            }
            request(_) {
              const b = new XMLHttpRequest(), E = this.currXhrId++, f = this.pendingRequests[E] = {
                xhr: b
              };
              b.open("GET", this.url), b.withCredentials = this.withCredentials;
              for (const d in this.httpHeaders) {
                const p = this.httpHeaders[d];
                p !== void 0 && b.setRequestHeader(d, p);
              }
              return this.isHttp && "begin" in _ && "end" in _ ? (b.setRequestHeader("Range", `bytes=${_.begin}-${_.end - 1}`), f.expectedStatus = q) : f.expectedStatus = ct, b.responseType = "arraybuffer", _.onError && (b.onerror = function(d) {
                _.onError(b.status);
              }), b.onreadystatechange = this.onStateChange.bind(this, E), b.onprogress = this.onProgress.bind(this, E), f.onHeadersReceived = _.onHeadersReceived, f.onDone = _.onDone, f.onError = _.onError, f.onProgress = _.onProgress, b.send(null), E;
            }
            onProgress(_, b) {
              var f;
              const E = this.pendingRequests[_];
              E && ((f = E.onProgress) == null || f.call(E, b));
            }
            onStateChange(_, b) {
              var y, n, l;
              const E = this.pendingRequests[_];
              if (!E)
                return;
              const f = E.xhr;
              if (f.readyState >= 2 && E.onHeadersReceived && (E.onHeadersReceived(), delete E.onHeadersReceived), f.readyState !== 4 || !(_ in this.pendingRequests))
                return;
              if (delete this.pendingRequests[_], f.status === 0 && this.isHttp) {
                (y = E.onError) == null || y.call(E, f.status);
                return;
              }
              const d = f.status || ct;
              if (!(d === ct && E.expectedStatus === q) && d !== E.expectedStatus) {
                (n = E.onError) == null || n.call(E, f.status);
                return;
              }
              const D = gt(f);
              if (d === q) {
                const s = f.getResponseHeader("Content-Range"), a = /bytes (\d+)-(\d+)\/(\d+)/.exec(s);
                E.onDone({
                  begin: parseInt(a[1], 10),
                  chunk: D
                });
              } else D ? E.onDone({
                begin: 0,
                chunk: D
              }) : (l = E.onError) == null || l.call(E, f.status);
            }
            getRequestXhr(_) {
              return this.pendingRequests[_].xhr;
            }
            isPendingRequest(_) {
              return _ in this.pendingRequests;
            }
            abortRequest(_) {
              const b = this.pendingRequests[_].xhr;
              delete this.pendingRequests[_], b.abort();
            }
          }
          class M {
            constructor(_) {
              this._source = _, this._manager = new B(_.url, {
                httpHeaders: _.httpHeaders,
                withCredentials: _.withCredentials
              }), this._rangeChunkSize = _.rangeChunkSize, this._fullRequestReader = null, this._rangeRequestReaders = [];
            }
            _onRangeRequestReaderClosed(_) {
              const b = this._rangeRequestReaders.indexOf(_);
              b >= 0 && this._rangeRequestReaders.splice(b, 1);
            }
            getFullReader() {
              return (0, o.assert)(!this._fullRequestReader, "PDFNetworkStream.getFullReader can only be called once."), this._fullRequestReader = new m(this._manager, this._source), this._fullRequestReader;
            }
            getRangeReader(_, b) {
              const E = new N(this._manager, _, b);
              return E.onClosed = this._onRangeRequestReaderClosed.bind(this), this._rangeRequestReaders.push(E), E;
            }
            cancelAllRequests(_) {
              var b;
              (b = this._fullRequestReader) == null || b.cancel(_);
              for (const E of this._rangeRequestReaders.slice(0))
                E.cancel(_);
            }
          }
          h.PDFNetworkStream = M;
          class m {
            constructor(_, b) {
              this._manager = _;
              const E = {
                onHeadersReceived: this._onHeadersReceived.bind(this),
                onDone: this._onDone.bind(this),
                onError: this._onError.bind(this),
                onProgress: this._onProgress.bind(this)
              };
              this._url = b.url, this._fullRequestId = _.requestFull(E), this._headersReceivedCapability = new o.PromiseCapability(), this._disableRange = b.disableRange || !1, this._contentLength = b.length, this._rangeChunkSize = b.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !1, this._isRangeSupported = !1, this._cachedChunks = [], this._requests = [], this._done = !1, this._storedError = void 0, this._filename = null, this.onProgress = null;
            }
            _onHeadersReceived() {
              const _ = this._fullRequestId, b = this._manager.getRequestXhr(_), E = (p) => b.getResponseHeader(p), {
                allowRangeRequests: f,
                suggestedLength: d
              } = (0, T.validateRangeRequestCapabilities)({
                getResponseHeader: E,
                isHttp: this._manager.isHttp,
                rangeChunkSize: this._rangeChunkSize,
                disableRange: this._disableRange
              });
              f && (this._isRangeSupported = !0), this._contentLength = d || this._contentLength, this._filename = (0, T.extractFilenameFromHeader)(E), this._isRangeSupported && this._manager.abortRequest(_), this._headersReceivedCapability.resolve();
            }
            _onDone(_) {
              if (_ && (this._requests.length > 0 ? this._requests.shift().resolve({
                value: _.chunk,
                done: !1
              }) : this._cachedChunks.push(_.chunk)), this._done = !0, !(this._cachedChunks.length > 0)) {
                for (const b of this._requests)
                  b.resolve({
                    value: void 0,
                    done: !0
                  });
                this._requests.length = 0;
              }
            }
            _onError(_) {
              this._storedError = (0, T.createResponseStatusError)(_, this._url), this._headersReceivedCapability.reject(this._storedError);
              for (const b of this._requests)
                b.reject(this._storedError);
              this._requests.length = 0, this._cachedChunks.length = 0;
            }
            _onProgress(_) {
              var b;
              (b = this.onProgress) == null || b.call(this, {
                loaded: _.loaded,
                total: _.lengthComputable ? _.total : this._contentLength
              });
            }
            get filename() {
              return this._filename;
            }
            get isRangeSupported() {
              return this._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            get contentLength() {
              return this._contentLength;
            }
            get headersReady() {
              return this._headersReceivedCapability.promise;
            }
            async read() {
              if (this._storedError)
                throw this._storedError;
              if (this._cachedChunks.length > 0)
                return {
                  value: this._cachedChunks.shift(),
                  done: !1
                };
              if (this._done)
                return {
                  value: void 0,
                  done: !0
                };
              const _ = new o.PromiseCapability();
              return this._requests.push(_), _.promise;
            }
            cancel(_) {
              this._done = !0, this._headersReceivedCapability.reject(_);
              for (const b of this._requests)
                b.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0, this._manager.isPendingRequest(this._fullRequestId) && this._manager.abortRequest(this._fullRequestId), this._fullRequestReader = null;
            }
          }
          class N {
            constructor(_, b, E) {
              this._manager = _;
              const f = {
                onDone: this._onDone.bind(this),
                onError: this._onError.bind(this),
                onProgress: this._onProgress.bind(this)
              };
              this._url = _.url, this._requestId = _.requestRange(b, E, f), this._requests = [], this._queuedChunk = null, this._done = !1, this._storedError = void 0, this.onProgress = null, this.onClosed = null;
            }
            _close() {
              var _;
              (_ = this.onClosed) == null || _.call(this, this);
            }
            _onDone(_) {
              const b = _.chunk;
              this._requests.length > 0 ? this._requests.shift().resolve({
                value: b,
                done: !1
              }) : this._queuedChunk = b, this._done = !0;
              for (const E of this._requests)
                E.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0, this._close();
            }
            _onError(_) {
              this._storedError = (0, T.createResponseStatusError)(_, this._url);
              for (const b of this._requests)
                b.reject(this._storedError);
              this._requests.length = 0, this._queuedChunk = null;
            }
            _onProgress(_) {
              var b;
              this.isStreamingSupported || (b = this.onProgress) == null || b.call(this, {
                loaded: _.loaded
              });
            }
            get isStreamingSupported() {
              return !1;
            }
            async read() {
              if (this._storedError)
                throw this._storedError;
              if (this._queuedChunk !== null) {
                const b = this._queuedChunk;
                return this._queuedChunk = null, {
                  value: b,
                  done: !1
                };
              }
              if (this._done)
                return {
                  value: void 0,
                  done: !0
                };
              const _ = new o.PromiseCapability();
              return this._requests.push(_), _.promise;
            }
            cancel(_) {
              this._done = !0;
              for (const b of this._requests)
                b.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0, this._manager.isPendingRequest(this._requestId) && this._manager.abortRequest(this._requestId), this._close();
            }
          }
        },
        /* 23 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.PDFNodeStream = void 0;
          var o = rt(1), T = rt(20);
          const ct = /^file:\/\/\/[a-zA-Z]:\//;
          function q(E) {
            const f = require$$5, d = f.parse(E);
            return d.protocol === "file:" || d.host ? d : /^[a-z]:[/\\]/i.test(E) ? f.parse(`file:///${E}`) : (d.host || (d.protocol = "file:"), d);
          }
          class gt {
            constructor(f) {
              this.source = f, this.url = q(f.url), this.isHttp = this.url.protocol === "http:" || this.url.protocol === "https:", this.isFsUrl = this.url.protocol === "file:", this.httpHeaders = this.isHttp && f.httpHeaders || {}, this._fullRequestReader = null, this._rangeRequestReaders = [];
            }
            get _progressiveDataLength() {
              var f;
              return ((f = this._fullRequestReader) == null ? void 0 : f._loaded) ?? 0;
            }
            getFullReader() {
              return (0, o.assert)(!this._fullRequestReader, "PDFNodeStream.getFullReader can only be called once."), this._fullRequestReader = this.isFsUrl ? new _(this) : new N(this), this._fullRequestReader;
            }
            getRangeReader(f, d) {
              if (d <= this._progressiveDataLength)
                return null;
              const p = this.isFsUrl ? new b(this, f, d) : new I(this, f, d);
              return this._rangeRequestReaders.push(p), p;
            }
            cancelAllRequests(f) {
              var d;
              (d = this._fullRequestReader) == null || d.cancel(f);
              for (const p of this._rangeRequestReaders.slice(0))
                p.cancel(f);
            }
          }
          h.PDFNodeStream = gt;
          class B {
            constructor(f) {
              this._url = f.url, this._done = !1, this._storedError = null, this.onProgress = null;
              const d = f.source;
              this._contentLength = d.length, this._loaded = 0, this._filename = null, this._disableRange = d.disableRange || !1, this._rangeChunkSize = d.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !d.disableStream, this._isRangeSupported = !d.disableRange, this._readableStream = null, this._readCapability = new o.PromiseCapability(), this._headersCapability = new o.PromiseCapability();
            }
            get headersReady() {
              return this._headersCapability.promise;
            }
            get filename() {
              return this._filename;
            }
            get contentLength() {
              return this._contentLength;
            }
            get isRangeSupported() {
              return this._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              var p;
              if (await this._readCapability.promise, this._done)
                return {
                  value: void 0,
                  done: !0
                };
              if (this._storedError)
                throw this._storedError;
              const f = this._readableStream.read();
              return f === null ? (this._readCapability = new o.PromiseCapability(), this.read()) : (this._loaded += f.length, (p = this.onProgress) == null || p.call(this, {
                loaded: this._loaded,
                total: this._contentLength
              }), {
                value: new Uint8Array(f).buffer,
                done: !1
              });
            }
            cancel(f) {
              if (!this._readableStream) {
                this._error(f);
                return;
              }
              this._readableStream.destroy(f);
            }
            _error(f) {
              this._storedError = f, this._readCapability.resolve();
            }
            _setReadableStream(f) {
              this._readableStream = f, f.on("readable", () => {
                this._readCapability.resolve();
              }), f.on("end", () => {
                f.destroy(), this._done = !0, this._readCapability.resolve();
              }), f.on("error", (d) => {
                this._error(d);
              }), !this._isStreamingSupported && this._isRangeSupported && this._error(new o.AbortException("streaming is disabled")), this._storedError && this._readableStream.destroy(this._storedError);
            }
          }
          class M {
            constructor(f) {
              this._url = f.url, this._done = !1, this._storedError = null, this.onProgress = null, this._loaded = 0, this._readableStream = null, this._readCapability = new o.PromiseCapability();
              const d = f.source;
              this._isStreamingSupported = !d.disableStream;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              var p;
              if (await this._readCapability.promise, this._done)
                return {
                  value: void 0,
                  done: !0
                };
              if (this._storedError)
                throw this._storedError;
              const f = this._readableStream.read();
              return f === null ? (this._readCapability = new o.PromiseCapability(), this.read()) : (this._loaded += f.length, (p = this.onProgress) == null || p.call(this, {
                loaded: this._loaded
              }), {
                value: new Uint8Array(f).buffer,
                done: !1
              });
            }
            cancel(f) {
              if (!this._readableStream) {
                this._error(f);
                return;
              }
              this._readableStream.destroy(f);
            }
            _error(f) {
              this._storedError = f, this._readCapability.resolve();
            }
            _setReadableStream(f) {
              this._readableStream = f, f.on("readable", () => {
                this._readCapability.resolve();
              }), f.on("end", () => {
                f.destroy(), this._done = !0, this._readCapability.resolve();
              }), f.on("error", (d) => {
                this._error(d);
              }), this._storedError && this._readableStream.destroy(this._storedError);
            }
          }
          function m(E, f) {
            return {
              protocol: E.protocol,
              auth: E.auth,
              host: E.hostname,
              port: E.port,
              path: E.path,
              method: "GET",
              headers: f
            };
          }
          class N extends B {
            constructor(f) {
              super(f);
              const d = (p) => {
                if (p.statusCode === 404) {
                  const l = new o.MissingPDFException(`Missing PDF "${this._url}".`);
                  this._storedError = l, this._headersCapability.reject(l);
                  return;
                }
                this._headersCapability.resolve(), this._setReadableStream(p);
                const D = (l) => this._readableStream.headers[l.toLowerCase()], {
                  allowRangeRequests: y,
                  suggestedLength: n
                } = (0, T.validateRangeRequestCapabilities)({
                  getResponseHeader: D,
                  isHttp: f.isHttp,
                  rangeChunkSize: this._rangeChunkSize,
                  disableRange: this._disableRange
                });
                this._isRangeSupported = y, this._contentLength = n || this._contentLength, this._filename = (0, T.extractFilenameFromHeader)(D);
              };
              if (this._request = null, this._url.protocol === "http:") {
                const p = require$$5;
                this._request = p.request(m(this._url, f.httpHeaders), d);
              } else {
                const p = require$$5;
                this._request = p.request(m(this._url, f.httpHeaders), d);
              }
              this._request.on("error", (p) => {
                this._storedError = p, this._headersCapability.reject(p);
              }), this._request.end();
            }
          }
          class I extends M {
            constructor(f, d, p) {
              super(f), this._httpHeaders = {};
              for (const y in f.httpHeaders) {
                const n = f.httpHeaders[y];
                n !== void 0 && (this._httpHeaders[y] = n);
              }
              this._httpHeaders.Range = `bytes=${d}-${p - 1}`;
              const D = (y) => {
                if (y.statusCode === 404) {
                  const n = new o.MissingPDFException(`Missing PDF "${this._url}".`);
                  this._storedError = n;
                  return;
                }
                this._setReadableStream(y);
              };
              if (this._request = null, this._url.protocol === "http:") {
                const y = require$$5;
                this._request = y.request(m(this._url, this._httpHeaders), D);
              } else {
                const y = require$$5;
                this._request = y.request(m(this._url, this._httpHeaders), D);
              }
              this._request.on("error", (y) => {
                this._storedError = y;
              }), this._request.end();
            }
          }
          class _ extends B {
            constructor(f) {
              super(f);
              let d = decodeURIComponent(this._url.path);
              ct.test(this._url.href) && (d = d.replace(/^\//, ""));
              const p = require$$5;
              p.lstat(d, (D, y) => {
                if (D) {
                  D.code === "ENOENT" && (D = new o.MissingPDFException(`Missing PDF "${d}".`)), this._storedError = D, this._headersCapability.reject(D);
                  return;
                }
                this._contentLength = y.size, this._setReadableStream(p.createReadStream(d)), this._headersCapability.resolve();
              });
            }
          }
          class b extends M {
            constructor(f, d, p) {
              super(f);
              let D = decodeURIComponent(this._url.path);
              ct.test(this._url.href) && (D = D.replace(/^\//, ""));
              const y = require$$5;
              this._setReadableStream(y.createReadStream(D, {
                start: d,
                end: p - 1
              }));
            }
          }
        },
        /* 24 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.SVGGraphics = void 0;
          var o = rt(6), T = rt(1);
          const ct = {
            fontStyle: "normal",
            fontWeight: "normal",
            fillColor: "#000000"
          }, q = "http://www.w3.org/XML/1998/namespace", gt = "http://www.w3.org/1999/xlink", B = ["butt", "round", "square"], M = ["miter", "round", "bevel"], m = function(y, n = "", l = !1) {
            if (URL.createObjectURL && typeof Blob < "u" && !l)
              return URL.createObjectURL(new Blob([y], {
                type: n
              }));
            const s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
            let a = `data:${n};base64,`;
            for (let c = 0, O = y.length; c < O; c += 3) {
              const r = y[c] & 255, A = y[c + 1] & 255, F = y[c + 2] & 255, nt = r >> 2, W = (r & 3) << 4 | A >> 4, $ = c + 1 < O ? (A & 15) << 2 | F >> 6 : 64, j = c + 2 < O ? F & 63 : 64;
              a += s[nt] + s[W] + s[$] + s[j];
            }
            return a;
          }, N = function() {
            const y = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]), n = 12, l = new Int32Array(256);
            for (let F = 0; F < 256; F++) {
              let nt = F;
              for (let W = 0; W < 8; W++)
                nt = nt & 1 ? 3988292384 ^ nt >> 1 & 2147483647 : nt >> 1 & 2147483647;
              l[F] = nt;
            }
            function s(F, nt, W) {
              let $ = -1;
              for (let j = nt; j < W; j++) {
                const at = ($ ^ F[j]) & 255, C = l[at];
                $ = $ >>> 8 ^ C;
              }
              return $ ^ -1;
            }
            function a(F, nt, W, $) {
              let j = $;
              const at = nt.length;
              W[j] = at >> 24 & 255, W[j + 1] = at >> 16 & 255, W[j + 2] = at >> 8 & 255, W[j + 3] = at & 255, j += 4, W[j] = F.charCodeAt(0) & 255, W[j + 1] = F.charCodeAt(1) & 255, W[j + 2] = F.charCodeAt(2) & 255, W[j + 3] = F.charCodeAt(3) & 255, j += 4, W.set(nt, j), j += nt.length;
              const C = s(W, $ + 4, j);
              W[j] = C >> 24 & 255, W[j + 1] = C >> 16 & 255, W[j + 2] = C >> 8 & 255, W[j + 3] = C & 255;
            }
            function c(F, nt, W) {
              let $ = 1, j = 0;
              for (let at = nt; at < W; ++at)
                $ = ($ + (F[at] & 255)) % 65521, j = (j + $) % 65521;
              return j << 16 | $;
            }
            function O(F) {
              if (!T.isNodeJS)
                return r(F);
              try {
                const nt = parseInt(process.versions.node) >= 8 ? F : Buffer.from(F), W = require$$5.deflateSync(nt, {
                  level: 9
                });
                return W instanceof Uint8Array ? W : new Uint8Array(W);
              } catch (nt) {
                (0, T.warn)("Not compressing PNG because zlib.deflateSync is unavailable: " + nt);
              }
              return r(F);
            }
            function r(F) {
              let nt = F.length;
              const W = 65535, $ = Math.ceil(nt / W), j = new Uint8Array(2 + nt + $ * 5 + 4);
              let at = 0;
              j[at++] = 120, j[at++] = 156;
              let C = 0;
              for (; nt > W; )
                j[at++] = 0, j[at++] = 255, j[at++] = 255, j[at++] = 0, j[at++] = 0, j.set(F.subarray(C, C + W), at), at += W, C += W, nt -= W;
              j[at++] = 1, j[at++] = nt & 255, j[at++] = nt >> 8 & 255, j[at++] = ~nt & 65535 & 255, j[at++] = (~nt & 65535) >> 8 & 255, j.set(F.subarray(C), at), at += F.length - C;
              const U = c(F, 0, F.length);
              return j[at++] = U >> 24 & 255, j[at++] = U >> 16 & 255, j[at++] = U >> 8 & 255, j[at++] = U & 255, j;
            }
            function A(F, nt, W, $) {
              const j = F.width, at = F.height;
              let C, U, Y;
              const S = F.data;
              switch (nt) {
                case T.ImageKind.GRAYSCALE_1BPP:
                  U = 0, C = 1, Y = j + 7 >> 3;
                  break;
                case T.ImageKind.RGB_24BPP:
                  U = 2, C = 8, Y = j * 3;
                  break;
                case T.ImageKind.RGBA_32BPP:
                  U = 6, C = 8, Y = j * 4;
                  break;
                default:
                  throw new Error("invalid format");
              }
              const e = new Uint8Array((1 + Y) * at);
              let i = 0, u = 0;
              for (let ht = 0; ht < at; ++ht)
                e[i++] = 0, e.set(S.subarray(u, u + Y), i), u += Y, i += Y;
              if (nt === T.ImageKind.GRAYSCALE_1BPP && $) {
                i = 0;
                for (let ht = 0; ht < at; ht++) {
                  i++;
                  for (let dt = 0; dt < Y; dt++)
                    e[i++] ^= 255;
                }
              }
              const x = new Uint8Array([j >> 24 & 255, j >> 16 & 255, j >> 8 & 255, j & 255, at >> 24 & 255, at >> 16 & 255, at >> 8 & 255, at & 255, C, U, 0, 0, 0]), P = O(e), k = y.length + n * 3 + x.length + P.length, G = new Uint8Array(k);
              let it = 0;
              return G.set(y, it), it += y.length, a("IHDR", x, G, it), it += n + x.length, a("IDATA", P, G, it), it += n + P.length, a("IEND", new Uint8Array(0), G, it), m(G, "image/png", W);
            }
            return function(nt, W, $) {
              const j = nt.kind === void 0 ? T.ImageKind.GRAYSCALE_1BPP : nt.kind;
              return A(nt, j, W, $);
            };
          }();
          class I {
            constructor() {
              this.fontSizeScale = 1, this.fontWeight = ct.fontWeight, this.fontSize = 0, this.textMatrix = T.IDENTITY_MATRIX, this.fontMatrix = T.FONT_IDENTITY_MATRIX, this.leading = 0, this.textRenderingMode = T.TextRenderingMode.FILL, this.textMatrixScale = 1, this.x = 0, this.y = 0, this.lineX = 0, this.lineY = 0, this.charSpacing = 0, this.wordSpacing = 0, this.textHScale = 1, this.textRise = 0, this.fillColor = ct.fillColor, this.strokeColor = "#000000", this.fillAlpha = 1, this.strokeAlpha = 1, this.lineWidth = 1, this.lineJoin = "", this.lineCap = "", this.miterLimit = 0, this.dashArray = [], this.dashPhase = 0, this.dependencies = [], this.activeClipUrl = null, this.clipGroup = null, this.maskId = "";
            }
            clone() {
              return Object.create(this);
            }
            setCurrentPoint(n, l) {
              this.x = n, this.y = l;
            }
          }
          function _(y) {
            let n = [];
            const l = [];
            for (const s of y) {
              if (s.fn === "save") {
                n.push({
                  fnId: 92,
                  fn: "group",
                  items: []
                }), l.push(n), n = n.at(-1).items;
                continue;
              }
              s.fn === "restore" ? n = l.pop() : n.push(s);
            }
            return n;
          }
          function b(y) {
            if (Number.isInteger(y))
              return y.toString();
            const n = y.toFixed(10);
            let l = n.length - 1;
            if (n[l] !== "0")
              return n;
            do
              l--;
            while (n[l] === "0");
            return n.substring(0, n[l] === "." ? l : l + 1);
          }
          function E(y) {
            if (y[4] === 0 && y[5] === 0) {
              if (y[1] === 0 && y[2] === 0)
                return y[0] === 1 && y[3] === 1 ? "" : `scale(${b(y[0])} ${b(y[3])})`;
              if (y[0] === y[3] && y[1] === -y[2]) {
                const n = Math.acos(y[0]) * 180 / Math.PI;
                return `rotate(${b(n)})`;
              }
            } else if (y[0] === 1 && y[1] === 0 && y[2] === 0 && y[3] === 1)
              return `translate(${b(y[4])} ${b(y[5])})`;
            return `matrix(${b(y[0])} ${b(y[1])} ${b(y[2])} ${b(y[3])} ${b(y[4])} ${b(y[5])})`;
          }
          let f = 0, d = 0, p = 0;
          class D {
            constructor(n, l, s = !1) {
              (0, o.deprecated)("The SVG back-end is no longer maintained and *may* be removed in the future."), this.svgFactory = new o.DOMSVGFactory(), this.current = new I(), this.transformMatrix = T.IDENTITY_MATRIX, this.transformStack = [], this.extraStack = [], this.commonObjs = n, this.objs = l, this.pendingClip = null, this.pendingEOFill = !1, this.embedFonts = !1, this.embeddedFonts = /* @__PURE__ */ Object.create(null), this.cssStyle = null, this.forceDataSchema = !!s, this._operatorIdMapping = [];
              for (const a in T.OPS)
                this._operatorIdMapping[T.OPS[a]] = a;
            }
            getObject(n, l = null) {
              return typeof n == "string" ? n.startsWith("g_") ? this.commonObjs.get(n) : this.objs.get(n) : l;
            }
            save() {
              this.transformStack.push(this.transformMatrix);
              const n = this.current;
              this.extraStack.push(n), this.current = n.clone();
            }
            restore() {
              this.transformMatrix = this.transformStack.pop(), this.current = this.extraStack.pop(), this.pendingClip = null, this.tgrp = null;
            }
            group(n) {
              this.save(), this.executeOpTree(n), this.restore();
            }
            loadDependencies(n) {
              const l = n.fnArray, s = n.argsArray;
              for (let a = 0, c = l.length; a < c; a++)
                if (l[a] === T.OPS.dependency)
                  for (const O of s[a]) {
                    const r = O.startsWith("g_") ? this.commonObjs : this.objs, A = new Promise((F) => {
                      r.get(O, F);
                    });
                    this.current.dependencies.push(A);
                  }
              return Promise.all(this.current.dependencies);
            }
            transform(n, l, s, a, c, O) {
              const r = [n, l, s, a, c, O];
              this.transformMatrix = T.Util.transform(this.transformMatrix, r), this.tgrp = null;
            }
            getSVG(n, l) {
              this.viewport = l;
              const s = this._initialize(l);
              return this.loadDependencies(n).then(() => (this.transformMatrix = T.IDENTITY_MATRIX, this.executeOpTree(this.convertOpList(n)), s));
            }
            convertOpList(n) {
              const l = this._operatorIdMapping, s = n.argsArray, a = n.fnArray, c = [];
              for (let O = 0, r = a.length; O < r; O++) {
                const A = a[O];
                c.push({
                  fnId: A,
                  fn: l[A],
                  args: s[O]
                });
              }
              return _(c);
            }
            executeOpTree(n) {
              for (const l of n) {
                const s = l.fn, a = l.fnId, c = l.args;
                switch (a | 0) {
                  case T.OPS.beginText:
                    this.beginText();
                    break;
                  case T.OPS.dependency:
                    break;
                  case T.OPS.setLeading:
                    this.setLeading(c);
                    break;
                  case T.OPS.setLeadingMoveText:
                    this.setLeadingMoveText(c[0], c[1]);
                    break;
                  case T.OPS.setFont:
                    this.setFont(c);
                    break;
                  case T.OPS.showText:
                    this.showText(c[0]);
                    break;
                  case T.OPS.showSpacedText:
                    this.showText(c[0]);
                    break;
                  case T.OPS.endText:
                    this.endText();
                    break;
                  case T.OPS.moveText:
                    this.moveText(c[0], c[1]);
                    break;
                  case T.OPS.setCharSpacing:
                    this.setCharSpacing(c[0]);
                    break;
                  case T.OPS.setWordSpacing:
                    this.setWordSpacing(c[0]);
                    break;
                  case T.OPS.setHScale:
                    this.setHScale(c[0]);
                    break;
                  case T.OPS.setTextMatrix:
                    this.setTextMatrix(c[0], c[1], c[2], c[3], c[4], c[5]);
                    break;
                  case T.OPS.setTextRise:
                    this.setTextRise(c[0]);
                    break;
                  case T.OPS.setTextRenderingMode:
                    this.setTextRenderingMode(c[0]);
                    break;
                  case T.OPS.setLineWidth:
                    this.setLineWidth(c[0]);
                    break;
                  case T.OPS.setLineJoin:
                    this.setLineJoin(c[0]);
                    break;
                  case T.OPS.setLineCap:
                    this.setLineCap(c[0]);
                    break;
                  case T.OPS.setMiterLimit:
                    this.setMiterLimit(c[0]);
                    break;
                  case T.OPS.setFillRGBColor:
                    this.setFillRGBColor(c[0], c[1], c[2]);
                    break;
                  case T.OPS.setStrokeRGBColor:
                    this.setStrokeRGBColor(c[0], c[1], c[2]);
                    break;
                  case T.OPS.setStrokeColorN:
                    this.setStrokeColorN(c);
                    break;
                  case T.OPS.setFillColorN:
                    this.setFillColorN(c);
                    break;
                  case T.OPS.shadingFill:
                    this.shadingFill(c[0]);
                    break;
                  case T.OPS.setDash:
                    this.setDash(c[0], c[1]);
                    break;
                  case T.OPS.setRenderingIntent:
                    this.setRenderingIntent(c[0]);
                    break;
                  case T.OPS.setFlatness:
                    this.setFlatness(c[0]);
                    break;
                  case T.OPS.setGState:
                    this.setGState(c[0]);
                    break;
                  case T.OPS.fill:
                    this.fill();
                    break;
                  case T.OPS.eoFill:
                    this.eoFill();
                    break;
                  case T.OPS.stroke:
                    this.stroke();
                    break;
                  case T.OPS.fillStroke:
                    this.fillStroke();
                    break;
                  case T.OPS.eoFillStroke:
                    this.eoFillStroke();
                    break;
                  case T.OPS.clip:
                    this.clip("nonzero");
                    break;
                  case T.OPS.eoClip:
                    this.clip("evenodd");
                    break;
                  case T.OPS.paintSolidColorImageMask:
                    this.paintSolidColorImageMask();
                    break;
                  case T.OPS.paintImageXObject:
                    this.paintImageXObject(c[0]);
                    break;
                  case T.OPS.paintInlineImageXObject:
                    this.paintInlineImageXObject(c[0]);
                    break;
                  case T.OPS.paintImageMaskXObject:
                    this.paintImageMaskXObject(c[0]);
                    break;
                  case T.OPS.paintFormXObjectBegin:
                    this.paintFormXObjectBegin(c[0], c[1]);
                    break;
                  case T.OPS.paintFormXObjectEnd:
                    this.paintFormXObjectEnd();
                    break;
                  case T.OPS.closePath:
                    this.closePath();
                    break;
                  case T.OPS.closeStroke:
                    this.closeStroke();
                    break;
                  case T.OPS.closeFillStroke:
                    this.closeFillStroke();
                    break;
                  case T.OPS.closeEOFillStroke:
                    this.closeEOFillStroke();
                    break;
                  case T.OPS.nextLine:
                    this.nextLine();
                    break;
                  case T.OPS.transform:
                    this.transform(c[0], c[1], c[2], c[3], c[4], c[5]);
                    break;
                  case T.OPS.constructPath:
                    this.constructPath(c[0], c[1]);
                    break;
                  case T.OPS.endPath:
                    this.endPath();
                    break;
                  case 92:
                    this.group(l.items);
                    break;
                  default:
                    (0, T.warn)(`Unimplemented operator ${s}`);
                    break;
                }
              }
            }
            setWordSpacing(n) {
              this.current.wordSpacing = n;
            }
            setCharSpacing(n) {
              this.current.charSpacing = n;
            }
            nextLine() {
              this.moveText(0, this.current.leading);
            }
            setTextMatrix(n, l, s, a, c, O) {
              const r = this.current;
              r.textMatrix = r.lineMatrix = [n, l, s, a, c, O], r.textMatrixScale = Math.hypot(n, l), r.x = r.lineX = 0, r.y = r.lineY = 0, r.xcoords = [], r.ycoords = [], r.tspan = this.svgFactory.createElement("svg:tspan"), r.tspan.setAttributeNS(null, "font-family", r.fontFamily), r.tspan.setAttributeNS(null, "font-size", `${b(r.fontSize)}px`), r.tspan.setAttributeNS(null, "y", b(-r.y)), r.txtElement = this.svgFactory.createElement("svg:text"), r.txtElement.append(r.tspan);
            }
            beginText() {
              const n = this.current;
              n.x = n.lineX = 0, n.y = n.lineY = 0, n.textMatrix = T.IDENTITY_MATRIX, n.lineMatrix = T.IDENTITY_MATRIX, n.textMatrixScale = 1, n.tspan = this.svgFactory.createElement("svg:tspan"), n.txtElement = this.svgFactory.createElement("svg:text"), n.txtgrp = this.svgFactory.createElement("svg:g"), n.xcoords = [], n.ycoords = [];
            }
            moveText(n, l) {
              const s = this.current;
              s.x = s.lineX += n, s.y = s.lineY += l, s.xcoords = [], s.ycoords = [], s.tspan = this.svgFactory.createElement("svg:tspan"), s.tspan.setAttributeNS(null, "font-family", s.fontFamily), s.tspan.setAttributeNS(null, "font-size", `${b(s.fontSize)}px`), s.tspan.setAttributeNS(null, "y", b(-s.y));
            }
            showText(n) {
              const l = this.current, s = l.font, a = l.fontSize;
              if (a === 0)
                return;
              const c = l.fontSizeScale, O = l.charSpacing, r = l.wordSpacing, A = l.fontDirection, F = l.textHScale * A, nt = s.vertical, W = nt ? 1 : -1, $ = s.defaultVMetrics, j = a * l.fontMatrix[0];
              let at = 0;
              for (const Y of n) {
                if (Y === null) {
                  at += A * r;
                  continue;
                } else if (typeof Y == "number") {
                  at += W * Y * a / 1e3;
                  continue;
                }
                const S = (Y.isSpace ? r : 0) + O, e = Y.fontChar;
                let i, u, x = Y.width;
                if (nt) {
                  let k;
                  const G = Y.vmetric || $;
                  k = Y.vmetric ? G[1] : x * 0.5, k = -k * j;
                  const it = G[2] * j;
                  x = G ? -G[0] : x, i = k / c, u = (at + it) / c;
                } else
                  i = at / c, u = 0;
                (Y.isInFont || s.missingFile) && (l.xcoords.push(l.x + i), nt && l.ycoords.push(-l.y + u), l.tspan.textContent += e);
                const P = nt ? x * j - S * A : x * j + S * A;
                at += P;
              }
              l.tspan.setAttributeNS(null, "x", l.xcoords.map(b).join(" ")), nt ? l.tspan.setAttributeNS(null, "y", l.ycoords.map(b).join(" ")) : l.tspan.setAttributeNS(null, "y", b(-l.y)), nt ? l.y -= at : l.x += at * F, l.tspan.setAttributeNS(null, "font-family", l.fontFamily), l.tspan.setAttributeNS(null, "font-size", `${b(l.fontSize)}px`), l.fontStyle !== ct.fontStyle && l.tspan.setAttributeNS(null, "font-style", l.fontStyle), l.fontWeight !== ct.fontWeight && l.tspan.setAttributeNS(null, "font-weight", l.fontWeight);
              const C = l.textRenderingMode & T.TextRenderingMode.FILL_STROKE_MASK;
              if (C === T.TextRenderingMode.FILL || C === T.TextRenderingMode.FILL_STROKE ? (l.fillColor !== ct.fillColor && l.tspan.setAttributeNS(null, "fill", l.fillColor), l.fillAlpha < 1 && l.tspan.setAttributeNS(null, "fill-opacity", l.fillAlpha)) : l.textRenderingMode === T.TextRenderingMode.ADD_TO_PATH ? l.tspan.setAttributeNS(null, "fill", "transparent") : l.tspan.setAttributeNS(null, "fill", "none"), C === T.TextRenderingMode.STROKE || C === T.TextRenderingMode.FILL_STROKE) {
                const Y = 1 / (l.textMatrixScale || 1);
                this._setStrokeAttributes(l.tspan, Y);
              }
              let U = l.textMatrix;
              l.textRise !== 0 && (U = U.slice(), U[5] += l.textRise), l.txtElement.setAttributeNS(null, "transform", `${E(U)} scale(${b(F)}, -1)`), l.txtElement.setAttributeNS(q, "xml:space", "preserve"), l.txtElement.append(l.tspan), l.txtgrp.append(l.txtElement), this._ensureTransformGroup().append(l.txtElement);
            }
            setLeadingMoveText(n, l) {
              this.setLeading(-l), this.moveText(n, l);
            }
            addFontStyle(n) {
              if (!n.data)
                throw new Error('addFontStyle: No font data available, ensure that the "fontExtraProperties" API parameter is set.');
              this.cssStyle || (this.cssStyle = this.svgFactory.createElement("svg:style"), this.cssStyle.setAttributeNS(null, "type", "text/css"), this.defs.append(this.cssStyle));
              const l = m(n.data, n.mimetype, this.forceDataSchema);
              this.cssStyle.textContent += `@font-face { font-family: "${n.loadedName}"; src: url(${l}); }
`;
            }
            setFont(n) {
              const l = this.current, s = this.commonObjs.get(n[0]);
              let a = n[1];
              l.font = s, this.embedFonts && !s.missingFile && !this.embeddedFonts[s.loadedName] && (this.addFontStyle(s), this.embeddedFonts[s.loadedName] = s), l.fontMatrix = s.fontMatrix || T.FONT_IDENTITY_MATRIX;
              let c = "normal";
              s.black ? c = "900" : s.bold && (c = "bold");
              const O = s.italic ? "italic" : "normal";
              a < 0 ? (a = -a, l.fontDirection = -1) : l.fontDirection = 1, l.fontSize = a, l.fontFamily = s.loadedName, l.fontWeight = c, l.fontStyle = O, l.tspan = this.svgFactory.createElement("svg:tspan"), l.tspan.setAttributeNS(null, "y", b(-l.y)), l.xcoords = [], l.ycoords = [];
            }
            endText() {
              var l;
              const n = this.current;
              n.textRenderingMode & T.TextRenderingMode.ADD_TO_PATH_FLAG && ((l = n.txtElement) != null && l.hasChildNodes()) && (n.element = n.txtElement, this.clip("nonzero"), this.endPath());
            }
            setLineWidth(n) {
              n > 0 && (this.current.lineWidth = n);
            }
            setLineCap(n) {
              this.current.lineCap = B[n];
            }
            setLineJoin(n) {
              this.current.lineJoin = M[n];
            }
            setMiterLimit(n) {
              this.current.miterLimit = n;
            }
            setStrokeAlpha(n) {
              this.current.strokeAlpha = n;
            }
            setStrokeRGBColor(n, l, s) {
              this.current.strokeColor = T.Util.makeHexColor(n, l, s);
            }
            setFillAlpha(n) {
              this.current.fillAlpha = n;
            }
            setFillRGBColor(n, l, s) {
              this.current.fillColor = T.Util.makeHexColor(n, l, s), this.current.tspan = this.svgFactory.createElement("svg:tspan"), this.current.xcoords = [], this.current.ycoords = [];
            }
            setStrokeColorN(n) {
              this.current.strokeColor = this._makeColorN_Pattern(n);
            }
            setFillColorN(n) {
              this.current.fillColor = this._makeColorN_Pattern(n);
            }
            shadingFill(n) {
              const {
                width: l,
                height: s
              } = this.viewport, a = T.Util.inverseTransform(this.transformMatrix), [c, O, r, A] = T.Util.getAxialAlignedBoundingBox([0, 0, l, s], a), F = this.svgFactory.createElement("svg:rect");
              F.setAttributeNS(null, "x", c), F.setAttributeNS(null, "y", O), F.setAttributeNS(null, "width", r - c), F.setAttributeNS(null, "height", A - O), F.setAttributeNS(null, "fill", this._makeShadingPattern(n)), this.current.fillAlpha < 1 && F.setAttributeNS(null, "fill-opacity", this.current.fillAlpha), this._ensureTransformGroup().append(F);
            }
            _makeColorN_Pattern(n) {
              return n[0] === "TilingPattern" ? this._makeTilingPattern(n) : this._makeShadingPattern(n);
            }
            _makeTilingPattern(n) {
              const l = n[1], s = n[2], a = n[3] || T.IDENTITY_MATRIX, [c, O, r, A] = n[4], F = n[5], nt = n[6], W = n[7], $ = `shading${p++}`, [j, at, C, U] = T.Util.normalizeRect([...T.Util.applyTransform([c, O], a), ...T.Util.applyTransform([r, A], a)]), [Y, S] = T.Util.singularValueDecompose2dScale(a), e = F * Y, i = nt * S, u = this.svgFactory.createElement("svg:pattern");
              u.setAttributeNS(null, "id", $), u.setAttributeNS(null, "patternUnits", "userSpaceOnUse"), u.setAttributeNS(null, "width", e), u.setAttributeNS(null, "height", i), u.setAttributeNS(null, "x", `${j}`), u.setAttributeNS(null, "y", `${at}`);
              const x = this.svg, P = this.transformMatrix, k = this.current.fillColor, G = this.current.strokeColor, it = this.svgFactory.create(C - j, U - at);
              if (this.svg = it, this.transformMatrix = a, W === 2) {
                const ht = T.Util.makeHexColor(...l);
                this.current.fillColor = ht, this.current.strokeColor = ht;
              }
              return this.executeOpTree(this.convertOpList(s)), this.svg = x, this.transformMatrix = P, this.current.fillColor = k, this.current.strokeColor = G, u.append(it.childNodes[0]), this.defs.append(u), `url(#${$})`;
            }
            _makeShadingPattern(n) {
              switch (typeof n == "string" && (n = this.objs.get(n)), n[0]) {
                case "RadialAxial":
                  const l = `shading${p++}`, s = n[3];
                  let a;
                  switch (n[1]) {
                    case "axial":
                      const c = n[4], O = n[5];
                      a = this.svgFactory.createElement("svg:linearGradient"), a.setAttributeNS(null, "id", l), a.setAttributeNS(null, "gradientUnits", "userSpaceOnUse"), a.setAttributeNS(null, "x1", c[0]), a.setAttributeNS(null, "y1", c[1]), a.setAttributeNS(null, "x2", O[0]), a.setAttributeNS(null, "y2", O[1]);
                      break;
                    case "radial":
                      const r = n[4], A = n[5], F = n[6], nt = n[7];
                      a = this.svgFactory.createElement("svg:radialGradient"), a.setAttributeNS(null, "id", l), a.setAttributeNS(null, "gradientUnits", "userSpaceOnUse"), a.setAttributeNS(null, "cx", A[0]), a.setAttributeNS(null, "cy", A[1]), a.setAttributeNS(null, "r", nt), a.setAttributeNS(null, "fx", r[0]), a.setAttributeNS(null, "fy", r[1]), a.setAttributeNS(null, "fr", F);
                      break;
                    default:
                      throw new Error(`Unknown RadialAxial type: ${n[1]}`);
                  }
                  for (const c of s) {
                    const O = this.svgFactory.createElement("svg:stop");
                    O.setAttributeNS(null, "offset", c[0]), O.setAttributeNS(null, "stop-color", c[1]), a.append(O);
                  }
                  return this.defs.append(a), `url(#${l})`;
                case "Mesh":
                  return (0, T.warn)("Unimplemented pattern Mesh"), null;
                case "Dummy":
                  return "hotpink";
                default:
                  throw new Error(`Unknown IR type: ${n[0]}`);
              }
            }
            setDash(n, l) {
              this.current.dashArray = n, this.current.dashPhase = l;
            }
            constructPath(n, l) {
              const s = this.current;
              let a = s.x, c = s.y, O = [], r = 0;
              for (const A of n)
                switch (A | 0) {
                  case T.OPS.rectangle:
                    a = l[r++], c = l[r++];
                    const F = l[r++], nt = l[r++], W = a + F, $ = c + nt;
                    O.push("M", b(a), b(c), "L", b(W), b(c), "L", b(W), b($), "L", b(a), b($), "Z");
                    break;
                  case T.OPS.moveTo:
                    a = l[r++], c = l[r++], O.push("M", b(a), b(c));
                    break;
                  case T.OPS.lineTo:
                    a = l[r++], c = l[r++], O.push("L", b(a), b(c));
                    break;
                  case T.OPS.curveTo:
                    a = l[r + 4], c = l[r + 5], O.push("C", b(l[r]), b(l[r + 1]), b(l[r + 2]), b(l[r + 3]), b(a), b(c)), r += 6;
                    break;
                  case T.OPS.curveTo2:
                    O.push("C", b(a), b(c), b(l[r]), b(l[r + 1]), b(l[r + 2]), b(l[r + 3])), a = l[r + 2], c = l[r + 3], r += 4;
                    break;
                  case T.OPS.curveTo3:
                    a = l[r + 2], c = l[r + 3], O.push("C", b(l[r]), b(l[r + 1]), b(a), b(c), b(a), b(c)), r += 4;
                    break;
                  case T.OPS.closePath:
                    O.push("Z");
                    break;
                }
              O = O.join(" "), s.path && n.length > 0 && n[0] !== T.OPS.rectangle && n[0] !== T.OPS.moveTo ? O = s.path.getAttributeNS(null, "d") + O : (s.path = this.svgFactory.createElement("svg:path"), this._ensureTransformGroup().append(s.path)), s.path.setAttributeNS(null, "d", O), s.path.setAttributeNS(null, "fill", "none"), s.element = s.path, s.setCurrentPoint(a, c);
            }
            endPath() {
              const n = this.current;
              if (n.path = null, !this.pendingClip)
                return;
              if (!n.element) {
                this.pendingClip = null;
                return;
              }
              const l = `clippath${f++}`, s = this.svgFactory.createElement("svg:clipPath");
              s.setAttributeNS(null, "id", l), s.setAttributeNS(null, "transform", E(this.transformMatrix));
              const a = n.element.cloneNode(!0);
              if (this.pendingClip === "evenodd" ? a.setAttributeNS(null, "clip-rule", "evenodd") : a.setAttributeNS(null, "clip-rule", "nonzero"), this.pendingClip = null, s.append(a), this.defs.append(s), n.activeClipUrl) {
                n.clipGroup = null;
                for (const c of this.extraStack)
                  c.clipGroup = null;
                s.setAttributeNS(null, "clip-path", n.activeClipUrl);
              }
              n.activeClipUrl = `url(#${l})`, this.tgrp = null;
            }
            clip(n) {
              this.pendingClip = n;
            }
            closePath() {
              const n = this.current;
              if (n.path) {
                const l = `${n.path.getAttributeNS(null, "d")}Z`;
                n.path.setAttributeNS(null, "d", l);
              }
            }
            setLeading(n) {
              this.current.leading = -n;
            }
            setTextRise(n) {
              this.current.textRise = n;
            }
            setTextRenderingMode(n) {
              this.current.textRenderingMode = n;
            }
            setHScale(n) {
              this.current.textHScale = n / 100;
            }
            setRenderingIntent(n) {
            }
            setFlatness(n) {
            }
            setGState(n) {
              for (const [l, s] of n)
                switch (l) {
                  case "LW":
                    this.setLineWidth(s);
                    break;
                  case "LC":
                    this.setLineCap(s);
                    break;
                  case "LJ":
                    this.setLineJoin(s);
                    break;
                  case "ML":
                    this.setMiterLimit(s);
                    break;
                  case "D":
                    this.setDash(s[0], s[1]);
                    break;
                  case "RI":
                    this.setRenderingIntent(s);
                    break;
                  case "FL":
                    this.setFlatness(s);
                    break;
                  case "Font":
                    this.setFont(s);
                    break;
                  case "CA":
                    this.setStrokeAlpha(s);
                    break;
                  case "ca":
                    this.setFillAlpha(s);
                    break;
                  default:
                    (0, T.warn)(`Unimplemented graphic state operator ${l}`);
                    break;
                }
            }
            fill() {
              const n = this.current;
              n.element && (n.element.setAttributeNS(null, "fill", n.fillColor), n.element.setAttributeNS(null, "fill-opacity", n.fillAlpha), this.endPath());
            }
            stroke() {
              const n = this.current;
              n.element && (this._setStrokeAttributes(n.element), n.element.setAttributeNS(null, "fill", "none"), this.endPath());
            }
            _setStrokeAttributes(n, l = 1) {
              const s = this.current;
              let a = s.dashArray;
              l !== 1 && a.length > 0 && (a = a.map(function(c) {
                return l * c;
              })), n.setAttributeNS(null, "stroke", s.strokeColor), n.setAttributeNS(null, "stroke-opacity", s.strokeAlpha), n.setAttributeNS(null, "stroke-miterlimit", b(s.miterLimit)), n.setAttributeNS(null, "stroke-linecap", s.lineCap), n.setAttributeNS(null, "stroke-linejoin", s.lineJoin), n.setAttributeNS(null, "stroke-width", b(l * s.lineWidth) + "px"), n.setAttributeNS(null, "stroke-dasharray", a.map(b).join(" ")), n.setAttributeNS(null, "stroke-dashoffset", b(l * s.dashPhase) + "px");
            }
            eoFill() {
              var n;
              (n = this.current.element) == null || n.setAttributeNS(null, "fill-rule", "evenodd"), this.fill();
            }
            fillStroke() {
              this.stroke(), this.fill();
            }
            eoFillStroke() {
              var n;
              (n = this.current.element) == null || n.setAttributeNS(null, "fill-rule", "evenodd"), this.fillStroke();
            }
            closeStroke() {
              this.closePath(), this.stroke();
            }
            closeFillStroke() {
              this.closePath(), this.fillStroke();
            }
            closeEOFillStroke() {
              this.closePath(), this.eoFillStroke();
            }
            paintSolidColorImageMask() {
              const n = this.svgFactory.createElement("svg:rect");
              n.setAttributeNS(null, "x", "0"), n.setAttributeNS(null, "y", "0"), n.setAttributeNS(null, "width", "1px"), n.setAttributeNS(null, "height", "1px"), n.setAttributeNS(null, "fill", this.current.fillColor), this._ensureTransformGroup().append(n);
            }
            paintImageXObject(n) {
              const l = this.getObject(n);
              if (!l) {
                (0, T.warn)(`Dependent image with object ID ${n} is not ready yet`);
                return;
              }
              this.paintInlineImageXObject(l);
            }
            paintInlineImageXObject(n, l) {
              const s = n.width, a = n.height, c = N(n, this.forceDataSchema, !!l), O = this.svgFactory.createElement("svg:rect");
              O.setAttributeNS(null, "x", "0"), O.setAttributeNS(null, "y", "0"), O.setAttributeNS(null, "width", b(s)), O.setAttributeNS(null, "height", b(a)), this.current.element = O, this.clip("nonzero");
              const r = this.svgFactory.createElement("svg:image");
              r.setAttributeNS(gt, "xlink:href", c), r.setAttributeNS(null, "x", "0"), r.setAttributeNS(null, "y", b(-a)), r.setAttributeNS(null, "width", b(s) + "px"), r.setAttributeNS(null, "height", b(a) + "px"), r.setAttributeNS(null, "transform", `scale(${b(1 / s)} ${b(-1 / a)})`), l ? l.append(r) : this._ensureTransformGroup().append(r);
            }
            paintImageMaskXObject(n) {
              const l = this.getObject(n.data, n);
              if (l.bitmap) {
                (0, T.warn)("paintImageMaskXObject: ImageBitmap support is not implemented, ensure that the `isOffscreenCanvasSupported` API parameter is disabled.");
                return;
              }
              const s = this.current, a = l.width, c = l.height, O = s.fillColor;
              s.maskId = `mask${d++}`;
              const r = this.svgFactory.createElement("svg:mask");
              r.setAttributeNS(null, "id", s.maskId);
              const A = this.svgFactory.createElement("svg:rect");
              A.setAttributeNS(null, "x", "0"), A.setAttributeNS(null, "y", "0"), A.setAttributeNS(null, "width", b(a)), A.setAttributeNS(null, "height", b(c)), A.setAttributeNS(null, "fill", O), A.setAttributeNS(null, "mask", `url(#${s.maskId})`), this.defs.append(r), this._ensureTransformGroup().append(A), this.paintInlineImageXObject(l, r);
            }
            paintFormXObjectBegin(n, l) {
              if (Array.isArray(n) && n.length === 6 && this.transform(n[0], n[1], n[2], n[3], n[4], n[5]), l) {
                const s = l[2] - l[0], a = l[3] - l[1], c = this.svgFactory.createElement("svg:rect");
                c.setAttributeNS(null, "x", l[0]), c.setAttributeNS(null, "y", l[1]), c.setAttributeNS(null, "width", b(s)), c.setAttributeNS(null, "height", b(a)), this.current.element = c, this.clip("nonzero"), this.endPath();
              }
            }
            paintFormXObjectEnd() {
            }
            _initialize(n) {
              const l = this.svgFactory.create(n.width, n.height), s = this.svgFactory.createElement("svg:defs");
              l.append(s), this.defs = s;
              const a = this.svgFactory.createElement("svg:g");
              return a.setAttributeNS(null, "transform", E(n.transform)), l.append(a), this.svg = a, l;
            }
            _ensureClipGroup() {
              if (!this.current.clipGroup) {
                const n = this.svgFactory.createElement("svg:g");
                n.setAttributeNS(null, "clip-path", this.current.activeClipUrl), this.svg.append(n), this.current.clipGroup = n;
              }
              return this.current.clipGroup;
            }
            _ensureTransformGroup() {
              return this.tgrp || (this.tgrp = this.svgFactory.createElement("svg:g"), this.tgrp.setAttributeNS(null, "transform", E(this.transformMatrix)), this.current.activeClipUrl ? this._ensureClipGroup().append(this.tgrp) : this.svg.append(this.tgrp)), this.tgrp;
            }
          }
          h.SVGGraphics = D;
        },
        /* 25 */
        /***/
        (pt, h) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.XfaText = void 0;
          class rt {
            static textContent(T) {
              const ct = [], q = {
                items: ct,
                styles: /* @__PURE__ */ Object.create(null)
              };
              function gt(B) {
                var N;
                if (!B)
                  return;
                let M = null;
                const m = B.name;
                if (m === "#text")
                  M = B.value;
                else if (rt.shouldBuildText(m))
                  (N = B == null ? void 0 : B.attributes) != null && N.textContent ? M = B.attributes.textContent : B.value && (M = B.value);
                else return;
                if (M !== null && ct.push({
                  str: M
                }), !!B.children)
                  for (const I of B.children)
                    gt(I);
              }
              return gt(T), q;
            }
            static shouldBuildText(T) {
              return !(T === "textarea" || T === "input" || T === "option" || T === "select");
            }
          }
          h.XfaText = rt;
        },
        /* 26 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.TextLayerRenderTask = void 0, h.renderTextLayer = E, h.updateTextLayer = f;
          var o = rt(1), T = rt(6);
          const ct = 1e5, q = 30, gt = 0.8, B = /* @__PURE__ */ new Map();
          function M(d, p) {
            let D;
            if (p && o.FeatureTest.isOffscreenCanvasSupported)
              D = new OffscreenCanvas(d, d).getContext("2d", {
                alpha: !1
              });
            else {
              const y = document.createElement("canvas");
              y.width = y.height = d, D = y.getContext("2d", {
                alpha: !1
              });
            }
            return D;
          }
          function m(d, p) {
            const D = B.get(d);
            if (D)
              return D;
            const y = M(q, p);
            y.font = `${q}px ${d}`;
            const n = y.measureText("");
            let l = n.fontBoundingBoxAscent, s = Math.abs(n.fontBoundingBoxDescent);
            if (l) {
              const c = l / (l + s);
              return B.set(d, c), y.canvas.width = y.canvas.height = 0, c;
            }
            y.strokeStyle = "red", y.clearRect(0, 0, q, q), y.strokeText("g", 0, 0);
            let a = y.getImageData(0, 0, q, q).data;
            s = 0;
            for (let c = a.length - 1 - 3; c >= 0; c -= 4)
              if (a[c] > 0) {
                s = Math.ceil(c / 4 / q);
                break;
              }
            y.clearRect(0, 0, q, q), y.strokeText("A", 0, q), a = y.getImageData(0, 0, q, q).data, l = 0;
            for (let c = 0, O = a.length; c < O; c += 4)
              if (a[c] > 0) {
                l = q - Math.floor(c / 4 / q);
                break;
              }
            if (y.canvas.width = y.canvas.height = 0, l) {
              const c = l / (l + s);
              return B.set(d, c), c;
            }
            return B.set(d, gt), gt;
          }
          function N(d, p, D) {
            const y = document.createElement("span"), n = {
              angle: 0,
              canvasWidth: 0,
              hasText: p.str !== "",
              hasEOL: p.hasEOL,
              fontSize: 0
            };
            d._textDivs.push(y);
            const l = o.Util.transform(d._transform, p.transform);
            let s = Math.atan2(l[1], l[0]);
            const a = D[p.fontName];
            a.vertical && (s += Math.PI / 2);
            const c = Math.hypot(l[2], l[3]), O = c * m(a.fontFamily, d._isOffscreenCanvasSupported);
            let r, A;
            s === 0 ? (r = l[4], A = l[5] - O) : (r = l[4] + O * Math.sin(s), A = l[5] - O * Math.cos(s));
            const F = "calc(var(--scale-factor)*", nt = y.style;
            d._container === d._rootContainer ? (nt.left = `${(100 * r / d._pageWidth).toFixed(2)}%`, nt.top = `${(100 * A / d._pageHeight).toFixed(2)}%`) : (nt.left = `${F}${r.toFixed(2)}px)`, nt.top = `${F}${A.toFixed(2)}px)`), nt.fontSize = `${F}${c.toFixed(2)}px)`, nt.fontFamily = a.fontFamily, n.fontSize = c, y.setAttribute("role", "presentation"), y.textContent = p.str, y.dir = p.dir, d._fontInspectorEnabled && (y.dataset.fontName = p.fontName), s !== 0 && (n.angle = s * (180 / Math.PI));
            let W = !1;
            if (p.str.length > 1)
              W = !0;
            else if (p.str !== " " && p.transform[0] !== p.transform[3]) {
              const $ = Math.abs(p.transform[0]), j = Math.abs(p.transform[3]);
              $ !== j && Math.max($, j) / Math.min($, j) > 1.5 && (W = !0);
            }
            W && (n.canvasWidth = a.vertical ? p.height : p.width), d._textDivProperties.set(y, n), d._isReadableStream && d._layoutText(y);
          }
          function I(d) {
            const {
              div: p,
              scale: D,
              properties: y,
              ctx: n,
              prevFontSize: l,
              prevFontFamily: s
            } = d, {
              style: a
            } = p;
            let c = "";
            if (y.canvasWidth !== 0 && y.hasText) {
              const {
                fontFamily: O
              } = a, {
                canvasWidth: r,
                fontSize: A
              } = y;
              (l !== A || s !== O) && (n.font = `${A * D}px ${O}`, d.prevFontSize = A, d.prevFontFamily = O);
              const {
                width: F
              } = n.measureText(p.textContent);
              F > 0 && (c = `scaleX(${r * D / F})`);
            }
            y.angle !== 0 && (c = `rotate(${y.angle}deg) ${c}`), c.length > 0 && (a.transform = c);
          }
          function _(d) {
            if (d._canceled)
              return;
            const p = d._textDivs, D = d._capability;
            if (p.length > ct) {
              D.resolve();
              return;
            }
            if (!d._isReadableStream)
              for (const n of p)
                d._layoutText(n);
            D.resolve();
          }
          class b {
            constructor({
              textContentSource: p,
              container: D,
              viewport: y,
              textDivs: n,
              textDivProperties: l,
              textContentItemsStr: s,
              isOffscreenCanvasSupported: a
            }) {
              var F;
              this._textContentSource = p, this._isReadableStream = p instanceof ReadableStream, this._container = this._rootContainer = D, this._textDivs = n || [], this._textContentItemsStr = s || [], this._isOffscreenCanvasSupported = a, this._fontInspectorEnabled = !!((F = globalThis.FontInspector) != null && F.enabled), this._reader = null, this._textDivProperties = l || /* @__PURE__ */ new WeakMap(), this._canceled = !1, this._capability = new o.PromiseCapability(), this._layoutTextParams = {
                prevFontSize: null,
                prevFontFamily: null,
                div: null,
                scale: y.scale * (globalThis.devicePixelRatio || 1),
                properties: null,
                ctx: M(0, a)
              };
              const {
                pageWidth: c,
                pageHeight: O,
                pageX: r,
                pageY: A
              } = y.rawDims;
              this._transform = [1, 0, 0, -1, -r, A + O], this._pageWidth = c, this._pageHeight = O, (0, T.setLayerDimensions)(D, y), this._capability.promise.finally(() => {
                this._layoutTextParams = null;
              }).catch(() => {
              });
            }
            get promise() {
              return this._capability.promise;
            }
            cancel() {
              this._canceled = !0, this._reader && (this._reader.cancel(new o.AbortException("TextLayer task cancelled.")).catch(() => {
              }), this._reader = null), this._capability.reject(new o.AbortException("TextLayer task cancelled."));
            }
            _processItems(p, D) {
              for (const y of p) {
                if (y.str === void 0) {
                  if (y.type === "beginMarkedContentProps" || y.type === "beginMarkedContent") {
                    const n = this._container;
                    this._container = document.createElement("span"), this._container.classList.add("markedContent"), y.id !== null && this._container.setAttribute("id", `${y.id}`), n.append(this._container);
                  } else y.type === "endMarkedContent" && (this._container = this._container.parentNode);
                  continue;
                }
                this._textContentItemsStr.push(y.str), N(this, y, D);
              }
            }
            _layoutText(p) {
              const D = this._layoutTextParams.properties = this._textDivProperties.get(p);
              if (this._layoutTextParams.div = p, I(this._layoutTextParams), D.hasText && this._container.append(p), D.hasEOL) {
                const y = document.createElement("br");
                y.setAttribute("role", "presentation"), this._container.append(y);
              }
            }
            _render() {
              const p = new o.PromiseCapability();
              let D = /* @__PURE__ */ Object.create(null);
              if (this._isReadableStream) {
                const y = () => {
                  this._reader.read().then(({
                    value: n,
                    done: l
                  }) => {
                    if (l) {
                      p.resolve();
                      return;
                    }
                    Object.assign(D, n.styles), this._processItems(n.items, D), y();
                  }, p.reject);
                };
                this._reader = this._textContentSource.getReader(), y();
              } else if (this._textContentSource) {
                const {
                  items: y,
                  styles: n
                } = this._textContentSource;
                this._processItems(y, n), p.resolve();
              } else
                throw new Error('No "textContentSource" parameter specified.');
              p.promise.then(() => {
                D = null, _(this);
              }, this._capability.reject);
            }
          }
          h.TextLayerRenderTask = b;
          function E(d) {
            !d.textContentSource && (d.textContent || d.textContentStream) && ((0, T.deprecated)("The TextLayerRender `textContent`/`textContentStream` parameters will be removed in the future, please use `textContentSource` instead."), d.textContentSource = d.textContent || d.textContentStream);
            const {
              container: p,
              viewport: D
            } = d, y = getComputedStyle(p), n = y.getPropertyValue("visibility"), l = parseFloat(y.getPropertyValue("--scale-factor"));
            n === "visible" && (!l || Math.abs(l - D.scale) > 1e-5) && console.error("The `--scale-factor` CSS-variable must be set, to the same value as `viewport.scale`, either on the `container`-element itself or higher up in the DOM.");
            const s = new b(d);
            return s._render(), s;
          }
          function f({
            container: d,
            viewport: p,
            textDivs: D,
            textDivProperties: y,
            isOffscreenCanvasSupported: n,
            mustRotate: l = !0,
            mustRescale: s = !0
          }) {
            if (l && (0, T.setLayerDimensions)(d, {
              rotation: p.rotation
            }), s) {
              const a = M(0, n), O = {
                prevFontSize: null,
                prevFontFamily: null,
                div: null,
                scale: p.scale * (globalThis.devicePixelRatio || 1),
                properties: null,
                ctx: a
              };
              for (const r of D)
                O.properties = y.get(r), O.div = r, I(O);
            }
          }
        },
        /* 27 */
        /***/
        (pt, h, rt) => {
          var m, N, I, _, b, E, f, d, p, D, y, Ke, we, Je, Qe;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.AnnotationEditorLayer = void 0;
          var o = rt(1), T = rt(4), ct = rt(28), q = rt(33), gt = rt(6), B = rt(34);
          const c = class c {
            constructor({
              uiManager: r,
              pageIndex: A,
              div: F,
              accessibilityManager: nt,
              annotationLayer: W,
              viewport: $,
              l10n: j
            }) {
              Q(this, y);
              Q(this, m);
              Q(this, N, !1);
              Q(this, I, null);
              Q(this, _, this.pointerup.bind(this));
              Q(this, b, this.pointerdown.bind(this));
              Q(this, E, /* @__PURE__ */ new Map());
              Q(this, f, !1);
              Q(this, d, !1);
              Q(this, p, !1);
              Q(this, D);
              const at = [ct.FreeTextEditor, q.InkEditor, B.StampEditor];
              if (!c._initialized) {
                c._initialized = !0;
                for (const C of at)
                  C.initialize(j);
              }
              r.registerEditorTypes(at), et(this, D, r), this.pageIndex = A, this.div = F, et(this, m, nt), et(this, I, W), this.viewport = $, t(this, D).addLayer(this);
            }
            get isEmpty() {
              return t(this, E).size === 0;
            }
            updateToolbar(r) {
              t(this, D).updateToolbar(r);
            }
            updateMode(r = t(this, D).getMode()) {
              z(this, y, Qe).call(this), r === o.AnnotationEditorType.INK ? (this.addInkEditorIfNeeded(!1), this.disableClick()) : this.enableClick(), r !== o.AnnotationEditorType.NONE && (this.div.classList.toggle("freeTextEditing", r === o.AnnotationEditorType.FREETEXT), this.div.classList.toggle("inkEditing", r === o.AnnotationEditorType.INK), this.div.classList.toggle("stampEditing", r === o.AnnotationEditorType.STAMP), this.div.hidden = !1);
            }
            addInkEditorIfNeeded(r) {
              if (!r && t(this, D).getMode() !== o.AnnotationEditorType.INK)
                return;
              if (!r) {
                for (const F of t(this, E).values())
                  if (F.isEmpty()) {
                    F.setInBackground();
                    return;
                  }
              }
              z(this, y, we).call(this, {
                offsetX: 0,
                offsetY: 0
              }, !1).setInBackground();
            }
            setEditingState(r) {
              t(this, D).setEditingState(r);
            }
            addCommands(r) {
              t(this, D).addCommands(r);
            }
            enable() {
              this.div.style.pointerEvents = "auto";
              const r = /* @__PURE__ */ new Set();
              for (const F of t(this, E).values())
                F.enableEditing(), F.annotationElementId && r.add(F.annotationElementId);
              if (!t(this, I))
                return;
              const A = t(this, I).getEditableAnnotations();
              for (const F of A) {
                if (F.hide(), t(this, D).isDeletedAnnotationElement(F.data.id) || r.has(F.data.id))
                  continue;
                const nt = this.deserialize(F);
                nt && (this.addOrRebuild(nt), nt.enableEditing());
              }
            }
            disable() {
              var A;
              et(this, p, !0), this.div.style.pointerEvents = "none";
              const r = /* @__PURE__ */ new Set();
              for (const F of t(this, E).values()) {
                if (F.disableEditing(), !F.annotationElementId || F.serialize() !== null) {
                  r.add(F.annotationElementId);
                  continue;
                }
                (A = this.getEditableAnnotation(F.annotationElementId)) == null || A.show(), F.remove();
              }
              if (t(this, I)) {
                const F = t(this, I).getEditableAnnotations();
                for (const nt of F) {
                  const {
                    id: W
                  } = nt.data;
                  r.has(W) || t(this, D).isDeletedAnnotationElement(W) || nt.show();
                }
              }
              z(this, y, Qe).call(this), this.isEmpty && (this.div.hidden = !0), et(this, p, !1);
            }
            getEditableAnnotation(r) {
              var A;
              return ((A = t(this, I)) == null ? void 0 : A.getEditableAnnotation(r)) || null;
            }
            setActiveEditor(r) {
              t(this, D).getActive() !== r && t(this, D).setActiveEditor(r);
            }
            enableClick() {
              this.div.addEventListener("pointerdown", t(this, b)), this.div.addEventListener("pointerup", t(this, _));
            }
            disableClick() {
              this.div.removeEventListener("pointerdown", t(this, b)), this.div.removeEventListener("pointerup", t(this, _));
            }
            attach(r) {
              t(this, E).set(r.id, r);
              const {
                annotationElementId: A
              } = r;
              A && t(this, D).isDeletedAnnotationElement(A) && t(this, D).removeDeletedAnnotationElement(r);
            }
            detach(r) {
              var A;
              t(this, E).delete(r.id), (A = t(this, m)) == null || A.removePointerInTextLayer(r.contentDiv), !t(this, p) && r.annotationElementId && t(this, D).addDeletedAnnotationElement(r);
            }
            remove(r) {
              this.detach(r), t(this, D).removeEditor(r), r.div.contains(document.activeElement) && setTimeout(() => {
                t(this, D).focusMainContainer();
              }, 0), r.div.remove(), r.isAttachedToDOM = !1, t(this, d) || this.addInkEditorIfNeeded(!1);
            }
            changeParent(r) {
              var A;
              r.parent !== this && (r.annotationElementId && (t(this, D).addDeletedAnnotationElement(r.annotationElementId), T.AnnotationEditor.deleteAnnotationElement(r), r.annotationElementId = null), this.attach(r), (A = r.parent) == null || A.detach(r), r.setParent(this), r.div && r.isAttachedToDOM && (r.div.remove(), this.div.append(r.div)));
            }
            add(r) {
              if (this.changeParent(r), t(this, D).addEditor(r), this.attach(r), !r.isAttachedToDOM) {
                const A = r.render();
                this.div.append(A), r.isAttachedToDOM = !0;
              }
              r.fixAndSetPosition(), r.onceAdded(), t(this, D).addToAnnotationStorage(r);
            }
            moveEditorInDOM(r) {
              var F;
              if (!r.isAttachedToDOM)
                return;
              const {
                activeElement: A
              } = document;
              r.div.contains(A) && (r._focusEventsAllowed = !1, setTimeout(() => {
                r.div.contains(document.activeElement) ? r._focusEventsAllowed = !0 : (r.div.addEventListener("focusin", () => {
                  r._focusEventsAllowed = !0;
                }, {
                  once: !0
                }), A.focus());
              }, 0)), r._structTreeParentId = (F = t(this, m)) == null ? void 0 : F.moveElementInDOM(this.div, r.div, r.contentDiv, !0);
            }
            addOrRebuild(r) {
              r.needsToBeRebuilt() ? r.rebuild() : this.add(r);
            }
            addUndoableEditor(r) {
              const A = () => r._uiManager.rebuild(r), F = () => {
                r.remove();
              };
              this.addCommands({
                cmd: A,
                undo: F,
                mustExec: !1
              });
            }
            getNextId() {
              return t(this, D).getId();
            }
            pasteEditor(r, A) {
              t(this, D).updateToolbar(r), t(this, D).updateMode(r);
              const {
                offsetX: F,
                offsetY: nt
              } = z(this, y, Je).call(this), W = this.getNextId(), $ = z(this, y, Ke).call(this, {
                parent: this,
                id: W,
                x: F,
                y: nt,
                uiManager: t(this, D),
                isCentered: !0,
                ...A
              });
              $ && this.add($);
            }
            deserialize(r) {
              switch (r.annotationType ?? r.annotationEditorType) {
                case o.AnnotationEditorType.FREETEXT:
                  return ct.FreeTextEditor.deserialize(r, this, t(this, D));
                case o.AnnotationEditorType.INK:
                  return q.InkEditor.deserialize(r, this, t(this, D));
                case o.AnnotationEditorType.STAMP:
                  return B.StampEditor.deserialize(r, this, t(this, D));
              }
              return null;
            }
            addNewEditor() {
              z(this, y, we).call(this, z(this, y, Je).call(this), !0);
            }
            setSelected(r) {
              t(this, D).setSelected(r);
            }
            toggleSelected(r) {
              t(this, D).toggleSelected(r);
            }
            isSelected(r) {
              return t(this, D).isSelected(r);
            }
            unselect(r) {
              t(this, D).unselect(r);
            }
            pointerup(r) {
              const {
                isMac: A
              } = o.FeatureTest.platform;
              if (!(r.button !== 0 || r.ctrlKey && A) && r.target === this.div && t(this, f)) {
                if (et(this, f, !1), !t(this, N)) {
                  et(this, N, !0);
                  return;
                }
                if (t(this, D).getMode() === o.AnnotationEditorType.STAMP) {
                  t(this, D).unselectAll();
                  return;
                }
                z(this, y, we).call(this, r, !1);
              }
            }
            pointerdown(r) {
              if (t(this, f)) {
                et(this, f, !1);
                return;
              }
              const {
                isMac: A
              } = o.FeatureTest.platform;
              if (r.button !== 0 || r.ctrlKey && A || r.target !== this.div)
                return;
              et(this, f, !0);
              const F = t(this, D).getActive();
              et(this, N, !F || F.isEmpty());
            }
            findNewParent(r, A, F) {
              const nt = t(this, D).findParent(A, F);
              return nt === null || nt === this ? !1 : (nt.changeParent(r), !0);
            }
            destroy() {
              var r, A;
              ((r = t(this, D).getActive()) == null ? void 0 : r.parent) === this && (t(this, D).commitOrRemove(), t(this, D).setActiveEditor(null));
              for (const F of t(this, E).values())
                (A = t(this, m)) == null || A.removePointerInTextLayer(F.contentDiv), F.setParent(null), F.isAttachedToDOM = !1, F.div.remove();
              this.div = null, t(this, E).clear(), t(this, D).removeLayer(this);
            }
            render({
              viewport: r
            }) {
              this.viewport = r, (0, gt.setLayerDimensions)(this.div, r);
              for (const A of t(this, D).getEditors(this.pageIndex))
                this.add(A);
              this.updateMode();
            }
            update({
              viewport: r
            }) {
              t(this, D).commitOrRemove(), this.viewport = r, (0, gt.setLayerDimensions)(this.div, {
                rotation: r.rotation
              }), this.updateMode();
            }
            get pageDimensions() {
              const {
                pageWidth: r,
                pageHeight: A
              } = this.viewport.rawDims;
              return [r, A];
            }
          };
          m = new WeakMap(), N = new WeakMap(), I = new WeakMap(), _ = new WeakMap(), b = new WeakMap(), E = new WeakMap(), f = new WeakMap(), d = new WeakMap(), p = new WeakMap(), D = new WeakMap(), y = new WeakSet(), Ke = function(r) {
            switch (t(this, D).getMode()) {
              case o.AnnotationEditorType.FREETEXT:
                return new ct.FreeTextEditor(r);
              case o.AnnotationEditorType.INK:
                return new q.InkEditor(r);
              case o.AnnotationEditorType.STAMP:
                return new B.StampEditor(r);
            }
            return null;
          }, we = function(r, A) {
            const F = this.getNextId(), nt = z(this, y, Ke).call(this, {
              parent: this,
              id: F,
              x: r.offsetX,
              y: r.offsetY,
              uiManager: t(this, D),
              isCentered: A
            });
            return nt && this.add(nt), nt;
          }, Je = function() {
            const {
              x: r,
              y: A,
              width: F,
              height: nt
            } = this.div.getBoundingClientRect(), W = Math.max(0, r), $ = Math.max(0, A), j = Math.min(window.innerWidth, r + F), at = Math.min(window.innerHeight, A + nt), C = (W + j) / 2 - r, U = ($ + at) / 2 - A, [Y, S] = this.viewport.rotation % 180 === 0 ? [C, U] : [U, C];
            return {
              offsetX: Y,
              offsetY: S
            };
          }, Qe = function() {
            et(this, d, !0);
            for (const r of t(this, E).values())
              r.isEmpty() && r.remove();
            et(this, d, !1);
          }, Kt(c, "_initialized", !1);
          let M = c;
          h.AnnotationEditorLayer = M;
        },
        /* 28 */
        /***/
        (pt, h, rt) => {
          var B, M, m, N, I, _, b, E, f, d, Ti, xi, Pi, ge, Ze, ki, ti;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.FreeTextEditor = void 0;
          var o = rt(1), T = rt(5), ct = rt(4), q = rt(29);
          const c = class c extends ct.AnnotationEditor {
            constructor(A) {
              super({
                ...A,
                name: "freeTextEditor"
              });
              Q(this, d);
              Q(this, B, this.editorDivBlur.bind(this));
              Q(this, M, this.editorDivFocus.bind(this));
              Q(this, m, this.editorDivInput.bind(this));
              Q(this, N, this.editorDivKeydown.bind(this));
              Q(this, I);
              Q(this, _, "");
              Q(this, b, `${this.id}-editor`);
              Q(this, E);
              Q(this, f, null);
              et(this, I, A.color || c._defaultColor || ct.AnnotationEditor._defaultLineColor), et(this, E, A.fontSize || c._defaultFontSize);
            }
            static get _keyboardManager() {
              const A = c.prototype, F = ($) => $.isEmpty(), nt = T.AnnotationEditorUIManager.TRANSLATE_SMALL, W = T.AnnotationEditorUIManager.TRANSLATE_BIG;
              return (0, o.shadow)(this, "_keyboardManager", new T.KeyboardManager([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], A.commitOrRemove, {
                bubbles: !0
              }], [["ctrl+Enter", "mac+meta+Enter", "Escape", "mac+Escape"], A.commitOrRemove], [["ArrowLeft", "mac+ArrowLeft"], A._translateEmpty, {
                args: [-nt, 0],
                checker: F
              }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], A._translateEmpty, {
                args: [-W, 0],
                checker: F
              }], [["ArrowRight", "mac+ArrowRight"], A._translateEmpty, {
                args: [nt, 0],
                checker: F
              }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], A._translateEmpty, {
                args: [W, 0],
                checker: F
              }], [["ArrowUp", "mac+ArrowUp"], A._translateEmpty, {
                args: [0, -nt],
                checker: F
              }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], A._translateEmpty, {
                args: [0, -W],
                checker: F
              }], [["ArrowDown", "mac+ArrowDown"], A._translateEmpty, {
                args: [0, nt],
                checker: F
              }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], A._translateEmpty, {
                args: [0, W],
                checker: F
              }]]));
            }
            static initialize(A) {
              ct.AnnotationEditor.initialize(A, {
                strings: ["free_text2_default_content", "editor_free_text2_aria_label"]
              });
              const F = getComputedStyle(document.documentElement);
              this._internalPadding = parseFloat(F.getPropertyValue("--freetext-padding"));
            }
            static updateDefaultParams(A, F) {
              switch (A) {
                case o.AnnotationEditorParamsType.FREETEXT_SIZE:
                  c._defaultFontSize = F;
                  break;
                case o.AnnotationEditorParamsType.FREETEXT_COLOR:
                  c._defaultColor = F;
                  break;
              }
            }
            updateParams(A, F) {
              switch (A) {
                case o.AnnotationEditorParamsType.FREETEXT_SIZE:
                  z(this, d, Ti).call(this, F);
                  break;
                case o.AnnotationEditorParamsType.FREETEXT_COLOR:
                  z(this, d, xi).call(this, F);
                  break;
              }
            }
            static get defaultPropertiesToUpdate() {
              return [[o.AnnotationEditorParamsType.FREETEXT_SIZE, c._defaultFontSize], [o.AnnotationEditorParamsType.FREETEXT_COLOR, c._defaultColor || ct.AnnotationEditor._defaultLineColor]];
            }
            get propertiesToUpdate() {
              return [[o.AnnotationEditorParamsType.FREETEXT_SIZE, t(this, E)], [o.AnnotationEditorParamsType.FREETEXT_COLOR, t(this, I)]];
            }
            _translateEmpty(A, F) {
              this._uiManager.translateSelectedEditors(A, F, !0);
            }
            getInitialTranslation() {
              const A = this.parentScale;
              return [-c._internalPadding * A, -(c._internalPadding + t(this, E)) * A];
            }
            rebuild() {
              this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
            }
            enableEditMode() {
              this.isInEditMode() || (this.parent.setEditingState(!1), this.parent.updateToolbar(o.AnnotationEditorType.FREETEXT), super.enableEditMode(), this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), this.editorDiv.addEventListener("keydown", t(this, N)), this.editorDiv.addEventListener("focus", t(this, M)), this.editorDiv.addEventListener("blur", t(this, B)), this.editorDiv.addEventListener("input", t(this, m)));
            }
            disableEditMode() {
              this.isInEditMode() && (this.parent.setEditingState(!0), super.disableEditMode(), this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", t(this, b)), this._isDraggable = !0, this.editorDiv.removeEventListener("keydown", t(this, N)), this.editorDiv.removeEventListener("focus", t(this, M)), this.editorDiv.removeEventListener("blur", t(this, B)), this.editorDiv.removeEventListener("input", t(this, m)), this.div.focus({
                preventScroll: !0
              }), this.isEditing = !1, this.parent.div.classList.add("freeTextEditing"));
            }
            focusin(A) {
              this._focusEventsAllowed && (super.focusin(A), A.target !== this.editorDiv && this.editorDiv.focus());
            }
            onceAdded() {
              var A;
              if (this.width) {
                z(this, d, ti).call(this);
                return;
              }
              this.enableEditMode(), this.editorDiv.focus(), (A = this._initialOptions) != null && A.isCentered && this.center(), this._initialOptions = null;
            }
            isEmpty() {
              return !this.editorDiv || this.editorDiv.innerText.trim() === "";
            }
            remove() {
              this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freeTextEditing")), super.remove();
            }
            commit() {
              if (!this.isInEditMode())
                return;
              super.commit(), this.disableEditMode();
              const A = t(this, _), F = et(this, _, z(this, d, Pi).call(this).trimEnd());
              if (A === F)
                return;
              const nt = (W) => {
                if (et(this, _, W), !W) {
                  this.remove();
                  return;
                }
                z(this, d, Ze).call(this), this._uiManager.rebuild(this), z(this, d, ge).call(this);
              };
              this.addCommands({
                cmd: () => {
                  nt(F);
                },
                undo: () => {
                  nt(A);
                },
                mustExec: !1
              }), z(this, d, ge).call(this);
            }
            shouldGetKeyboardEvents() {
              return this.isInEditMode();
            }
            enterInEditMode() {
              this.enableEditMode(), this.editorDiv.focus();
            }
            dblclick(A) {
              this.enterInEditMode();
            }
            keydown(A) {
              A.target === this.div && A.key === "Enter" && (this.enterInEditMode(), A.preventDefault());
            }
            editorDivKeydown(A) {
              c._keyboardManager.exec(this, A);
            }
            editorDivFocus(A) {
              this.isEditing = !0;
            }
            editorDivBlur(A) {
              this.isEditing = !1;
            }
            editorDivInput(A) {
              this.parent.div.classList.toggle("freeTextEditing", this.isEmpty());
            }
            disableEditing() {
              this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
            }
            enableEditing() {
              this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
            }
            render() {
              if (this.div)
                return this.div;
              let A, F;
              this.width && (A = this.x, F = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", t(this, b)), this.enableEditing(), ct.AnnotationEditor._l10nPromise.get("editor_free_text2_aria_label").then((W) => {
                var $;
                return ($ = this.editorDiv) == null ? void 0 : $.setAttribute("aria-label", W);
              }), ct.AnnotationEditor._l10nPromise.get("free_text2_default_content").then((W) => {
                var $;
                return ($ = this.editorDiv) == null ? void 0 : $.setAttribute("default-content", W);
              }), this.editorDiv.contentEditable = !0;
              const {
                style: nt
              } = this.editorDiv;
              if (nt.fontSize = `calc(${t(this, E)}px * var(--scale-factor))`, nt.color = t(this, I), this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), (0, T.bindEvents)(this, this.div, ["dblclick", "keydown"]), this.width) {
                const [W, $] = this.parentDimensions;
                if (this.annotationElementId) {
                  const {
                    position: j
                  } = t(this, f);
                  let [at, C] = this.getInitialTranslation();
                  [at, C] = this.pageTranslationToScreen(at, C);
                  const [U, Y] = this.pageDimensions, [S, e] = this.pageTranslation;
                  let i, u;
                  switch (this.rotation) {
                    case 0:
                      i = A + (j[0] - S) / U, u = F + this.height - (j[1] - e) / Y;
                      break;
                    case 90:
                      i = A + (j[0] - S) / U, u = F - (j[1] - e) / Y, [at, C] = [C, -at];
                      break;
                    case 180:
                      i = A - this.width + (j[0] - S) / U, u = F - (j[1] - e) / Y, [at, C] = [-at, -C];
                      break;
                    case 270:
                      i = A + (j[0] - S - this.height * Y) / U, u = F + (j[1] - e - this.width * U) / Y, [at, C] = [-C, at];
                      break;
                  }
                  this.setAt(i * W, u * $, at, C);
                } else
                  this.setAt(A * W, F * $, this.width * W, this.height * $);
                z(this, d, Ze).call(this), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
              } else
                this._isDraggable = !1, this.editorDiv.contentEditable = !0;
              return this.div;
            }
            get contentDiv() {
              return this.editorDiv;
            }
            static deserialize(A, F, nt) {
              let W = null;
              if (A instanceof q.FreeTextAnnotationElement) {
                const {
                  data: {
                    defaultAppearanceData: {
                      fontSize: j,
                      fontColor: at
                    },
                    rect: C,
                    rotation: U,
                    id: Y
                  },
                  textContent: S,
                  textPosition: e,
                  parent: {
                    page: {
                      pageNumber: i
                    }
                  }
                } = A;
                if (!S || S.length === 0)
                  return null;
                W = A = {
                  annotationType: o.AnnotationEditorType.FREETEXT,
                  color: Array.from(at),
                  fontSize: j,
                  value: S.join(`
`),
                  position: e,
                  pageIndex: i - 1,
                  rect: C,
                  rotation: U,
                  id: Y,
                  deleted: !1
                };
              }
              const $ = super.deserialize(A, F, nt);
              return et($, E, A.fontSize), et($, I, o.Util.makeHexColor(...A.color)), et($, _, A.value), $.annotationElementId = A.id || null, et($, f, W), $;
            }
            serialize(A = !1) {
              if (this.isEmpty())
                return null;
              if (this.deleted)
                return {
                  pageIndex: this.pageIndex,
                  id: this.annotationElementId,
                  deleted: !0
                };
              const F = c._internalPadding * this.parentScale, nt = this.getRect(F, F), W = ct.AnnotationEditor._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : t(this, I)), $ = {
                annotationType: o.AnnotationEditorType.FREETEXT,
                color: W,
                fontSize: t(this, E),
                value: t(this, _),
                pageIndex: this.pageIndex,
                rect: nt,
                rotation: this.rotation,
                structTreeParentId: this._structTreeParentId
              };
              return A ? $ : this.annotationElementId && !z(this, d, ki).call(this, $) ? null : ($.id = this.annotationElementId, $);
            }
          };
          B = new WeakMap(), M = new WeakMap(), m = new WeakMap(), N = new WeakMap(), I = new WeakMap(), _ = new WeakMap(), b = new WeakMap(), E = new WeakMap(), f = new WeakMap(), d = new WeakSet(), Ti = function(A) {
            const F = (W) => {
              this.editorDiv.style.fontSize = `calc(${W}px * var(--scale-factor))`, this.translate(0, -(W - t(this, E)) * this.parentScale), et(this, E, W), z(this, d, ge).call(this);
            }, nt = t(this, E);
            this.addCommands({
              cmd: () => {
                F(A);
              },
              undo: () => {
                F(nt);
              },
              mustExec: !0,
              type: o.AnnotationEditorParamsType.FREETEXT_SIZE,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, xi = function(A) {
            const F = t(this, I);
            this.addCommands({
              cmd: () => {
                et(this, I, this.editorDiv.style.color = A);
              },
              undo: () => {
                et(this, I, this.editorDiv.style.color = F);
              },
              mustExec: !0,
              type: o.AnnotationEditorParamsType.FREETEXT_COLOR,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, Pi = function() {
            const A = this.editorDiv.getElementsByTagName("div");
            if (A.length === 0)
              return this.editorDiv.innerText;
            const F = [];
            for (const nt of A)
              F.push(nt.innerText.replace(/\r\n?|\n/, ""));
            return F.join(`
`);
          }, ge = function() {
            const [A, F] = this.parentDimensions;
            let nt;
            if (this.isAttachedToDOM)
              nt = this.div.getBoundingClientRect();
            else {
              const {
                currentLayer: W,
                div: $
              } = this, j = $.style.display;
              $.style.display = "hidden", W.div.append(this.div), nt = $.getBoundingClientRect(), $.remove(), $.style.display = j;
            }
            this.rotation % 180 === this.parentRotation % 180 ? (this.width = nt.width / A, this.height = nt.height / F) : (this.width = nt.height / A, this.height = nt.width / F), this.fixAndSetPosition();
          }, Ze = function() {
            if (this.editorDiv.replaceChildren(), !!t(this, _))
              for (const A of t(this, _).split(`
`)) {
                const F = document.createElement("div");
                F.append(A ? document.createTextNode(A) : document.createElement("br")), this.editorDiv.append(F);
              }
          }, ki = function(A) {
            const {
              value: F,
              fontSize: nt,
              color: W,
              rect: $,
              pageIndex: j
            } = t(this, f);
            return A.value !== F || A.fontSize !== nt || A.rect.some((at, C) => Math.abs(at - $[C]) >= 1) || A.color.some((at, C) => at !== W[C]) || A.pageIndex !== j;
          }, ti = function(A = !1) {
            if (!this.annotationElementId)
              return;
            if (z(this, d, ge).call(this), !A && (this.width === 0 || this.height === 0)) {
              setTimeout(() => z(this, d, ti).call(this, !0), 0);
              return;
            }
            const F = c._internalPadding * this.parentScale;
            t(this, f).rect = this.getRect(F, F);
          }, Kt(c, "_freeTextDefaultContent", ""), Kt(c, "_internalPadding", 0), Kt(c, "_defaultColor", null), Kt(c, "_defaultFontSize", 10), Kt(c, "_type", "freetext");
          let gt = c;
          h.FreeTextEditor = gt;
        },
        /* 29 */
        /***/
        (pt, h, rt) => {
          var u, P, ne, Fi, it, ht, dt, mt, At, vt, K, Z, g, R, X, J, ut, St, yt, V, Tt, wt, Mi, Ce, ei, ii, Nt, Vt, $t, _t, tt, st, kt, si, Gt, L, ft, Ct, Ri, ni;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.StampAnnotationElement = h.InkAnnotationElement = h.FreeTextAnnotationElement = h.AnnotationLayer = void 0;
          var o = rt(1), T = rt(6), ct = rt(3), q = rt(30), gt = rt(31), B = rt(32);
          const M = 1e3, m = 9, N = /* @__PURE__ */ new WeakSet();
          function I(Pt) {
            return {
              width: Pt[2] - Pt[0],
              height: Pt[3] - Pt[1]
            };
          }
          class _ {
            static create(w) {
              switch (w.data.annotationType) {
                case o.AnnotationType.LINK:
                  return new E(w);
                case o.AnnotationType.TEXT:
                  return new f(w);
                case o.AnnotationType.WIDGET:
                  switch (w.data.fieldType) {
                    case "Tx":
                      return new p(w);
                    case "Btn":
                      return w.data.radioButton ? new n(w) : w.data.checkBox ? new y(w) : new l(w);
                    case "Ch":
                      return new s(w);
                    case "Sig":
                      return new D(w);
                  }
                  return new d(w);
                case o.AnnotationType.POPUP:
                  return new a(w);
                case o.AnnotationType.FREETEXT:
                  return new O(w);
                case o.AnnotationType.LINE:
                  return new r(w);
                case o.AnnotationType.SQUARE:
                  return new A(w);
                case o.AnnotationType.CIRCLE:
                  return new F(w);
                case o.AnnotationType.POLYLINE:
                  return new nt(w);
                case o.AnnotationType.CARET:
                  return new $(w);
                case o.AnnotationType.INK:
                  return new j(w);
                case o.AnnotationType.POLYGON:
                  return new W(w);
                case o.AnnotationType.HIGHLIGHT:
                  return new at(w);
                case o.AnnotationType.UNDERLINE:
                  return new C(w);
                case o.AnnotationType.SQUIGGLY:
                  return new U(w);
                case o.AnnotationType.STRIKEOUT:
                  return new Y(w);
                case o.AnnotationType.STAMP:
                  return new S(w);
                case o.AnnotationType.FILEATTACHMENT:
                  return new e(w);
                default:
                  return new b(w);
              }
            }
          }
          const x = class x {
            constructor(w, {
              isRenderable: v = !1,
              ignoreBorder: H = !1,
              createQuadrilaterals: ot = !1
            } = {}) {
              Q(this, u, !1);
              this.isRenderable = v, this.data = w.data, this.layer = w.layer, this.linkService = w.linkService, this.downloadManager = w.downloadManager, this.imageResourcesPath = w.imageResourcesPath, this.renderForms = w.renderForms, this.svgFactory = w.svgFactory, this.annotationStorage = w.annotationStorage, this.enableScripting = w.enableScripting, this.hasJSActions = w.hasJSActions, this._fieldObjects = w.fieldObjects, this.parent = w.parent, v && (this.container = this._createContainer(H)), ot && this._createQuadrilaterals();
            }
            static _hasPopupData({
              titleObj: w,
              contentsObj: v,
              richText: H
            }) {
              return !!(w != null && w.str || v != null && v.str || H != null && H.str);
            }
            get hasPopupData() {
              return x._hasPopupData(this.data);
            }
            _createContainer(w) {
              const {
                data: v,
                parent: {
                  page: H,
                  viewport: ot
                }
              } = this, lt = document.createElement("section");
              lt.setAttribute("data-annotation-id", v.id), this instanceof d || (lt.tabIndex = M), lt.style.zIndex = this.parent.zIndex++, this.data.popupRef && lt.setAttribute("aria-haspopup", "dialog"), v.noRotate && lt.classList.add("norotate");
              const {
                pageWidth: bt,
                pageHeight: Et,
                pageX: It,
                pageY: Mt
              } = ot.rawDims;
              if (!v.rect || this instanceof a) {
                const {
                  rotation: Ut
                } = v;
                return !v.hasOwnCanvas && Ut !== 0 && this.setRotation(Ut, lt), lt;
              }
              const {
                width: xt,
                height: Ht
              } = I(v.rect), Rt = o.Util.normalizeRect([v.rect[0], H.view[3] - v.rect[1] + H.view[1], v.rect[2], H.view[3] - v.rect[3] + H.view[1]]);
              if (!w && v.borderStyle.width > 0) {
                lt.style.borderWidth = `${v.borderStyle.width}px`;
                const Ut = v.borderStyle.horizontalCornerRadius, Wt = v.borderStyle.verticalCornerRadius;
                if (Ut > 0 || Wt > 0) {
                  const Yt = `calc(${Ut}px * var(--scale-factor)) / calc(${Wt}px * var(--scale-factor))`;
                  lt.style.borderRadius = Yt;
                } else if (this instanceof n) {
                  const Yt = `calc(${xt}px * var(--scale-factor)) / calc(${Ht}px * var(--scale-factor))`;
                  lt.style.borderRadius = Yt;
                }
                switch (v.borderStyle.style) {
                  case o.AnnotationBorderStyleType.SOLID:
                    lt.style.borderStyle = "solid";
                    break;
                  case o.AnnotationBorderStyleType.DASHED:
                    lt.style.borderStyle = "dashed";
                    break;
                  case o.AnnotationBorderStyleType.BEVELED:
                    (0, o.warn)("Unimplemented border style: beveled");
                    break;
                  case o.AnnotationBorderStyleType.INSET:
                    (0, o.warn)("Unimplemented border style: inset");
                    break;
                  case o.AnnotationBorderStyleType.UNDERLINE:
                    lt.style.borderBottomStyle = "solid";
                    break;
                }
                const qt = v.borderColor || null;
                qt ? (et(this, u, !0), lt.style.borderColor = o.Util.makeHexColor(qt[0] | 0, qt[1] | 0, qt[2] | 0)) : lt.style.borderWidth = 0;
              }
              lt.style.left = `${100 * (Rt[0] - It) / bt}%`, lt.style.top = `${100 * (Rt[1] - Mt) / Et}%`;
              const {
                rotation: Lt
              } = v;
              return v.hasOwnCanvas || Lt === 0 ? (lt.style.width = `${100 * xt / bt}%`, lt.style.height = `${100 * Ht / Et}%`) : this.setRotation(Lt, lt), lt;
            }
            setRotation(w, v = this.container) {
              if (!this.data.rect)
                return;
              const {
                pageWidth: H,
                pageHeight: ot
              } = this.parent.viewport.rawDims, {
                width: lt,
                height: bt
              } = I(this.data.rect);
              let Et, It;
              w % 180 === 0 ? (Et = 100 * lt / H, It = 100 * bt / ot) : (Et = 100 * bt / H, It = 100 * lt / ot), v.style.width = `${Et}%`, v.style.height = `${It}%`, v.setAttribute("data-main-rotation", (360 - w) % 360);
            }
            get _commonActions() {
              const w = (v, H, ot) => {
                const lt = ot.detail[v], bt = lt[0], Et = lt.slice(1);
                ot.target.style[H] = q.ColorConverters[`${bt}_HTML`](Et), this.annotationStorage.setValue(this.data.id, {
                  [H]: q.ColorConverters[`${bt}_rgb`](Et)
                });
              };
              return (0, o.shadow)(this, "_commonActions", {
                display: (v) => {
                  const {
                    display: H
                  } = v.detail, ot = H % 2 === 1;
                  this.container.style.visibility = ot ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                    noView: ot,
                    noPrint: H === 1 || H === 2
                  });
                },
                print: (v) => {
                  this.annotationStorage.setValue(this.data.id, {
                    noPrint: !v.detail.print
                  });
                },
                hidden: (v) => {
                  const {
                    hidden: H
                  } = v.detail;
                  this.container.style.visibility = H ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                    noPrint: H,
                    noView: H
                  });
                },
                focus: (v) => {
                  setTimeout(() => v.target.focus({
                    preventScroll: !1
                  }), 0);
                },
                userName: (v) => {
                  v.target.title = v.detail.userName;
                },
                readonly: (v) => {
                  v.target.disabled = v.detail.readonly;
                },
                required: (v) => {
                  this._setRequired(v.target, v.detail.required);
                },
                bgColor: (v) => {
                  w("bgColor", "backgroundColor", v);
                },
                fillColor: (v) => {
                  w("fillColor", "backgroundColor", v);
                },
                fgColor: (v) => {
                  w("fgColor", "color", v);
                },
                textColor: (v) => {
                  w("textColor", "color", v);
                },
                borderColor: (v) => {
                  w("borderColor", "borderColor", v);
                },
                strokeColor: (v) => {
                  w("strokeColor", "borderColor", v);
                },
                rotation: (v) => {
                  const H = v.detail.rotation;
                  this.setRotation(H), this.annotationStorage.setValue(this.data.id, {
                    rotation: H
                  });
                }
              });
            }
            _dispatchEventFromSandbox(w, v) {
              const H = this._commonActions;
              for (const ot of Object.keys(v.detail)) {
                const lt = w[ot] || H[ot];
                lt == null || lt(v);
              }
            }
            _setDefaultPropertiesFromJS(w) {
              if (!this.enableScripting)
                return;
              const v = this.annotationStorage.getRawValue(this.data.id);
              if (!v)
                return;
              const H = this._commonActions;
              for (const [ot, lt] of Object.entries(v)) {
                const bt = H[ot];
                if (bt) {
                  const Et = {
                    detail: {
                      [ot]: lt
                    },
                    target: w
                  };
                  bt(Et), delete v[ot];
                }
              }
            }
            _createQuadrilaterals() {
              if (!this.container)
                return;
              const {
                quadPoints: w
              } = this.data;
              if (!w)
                return;
              const [v, H, ot, lt] = this.data.rect;
              if (w.length === 1) {
                const [, {
                  x: Wt,
                  y: qt
                }, {
                  x: Yt,
                  y: Qt
                }] = w[0];
                if (ot === Wt && lt === qt && v === Yt && H === Qt)
                  return;
              }
              const {
                style: bt
              } = this.container;
              let Et;
              if (t(this, u)) {
                const {
                  borderColor: Wt,
                  borderWidth: qt
                } = bt;
                bt.borderWidth = 0, Et = ["url('data:image/svg+xml;utf8,", '<svg xmlns="http://www.w3.org/2000/svg"', ' preserveAspectRatio="none" viewBox="0 0 1 1">', `<g fill="transparent" stroke="${Wt}" stroke-width="${qt}">`], this.container.classList.add("hasBorder");
              }
              const It = ot - v, Mt = lt - H, {
                svgFactory: xt
              } = this, Ht = xt.createElement("svg");
              Ht.classList.add("quadrilateralsContainer"), Ht.setAttribute("width", 0), Ht.setAttribute("height", 0);
              const Rt = xt.createElement("defs");
              Ht.append(Rt);
              const Lt = xt.createElement("clipPath"), Ut = `clippath_${this.data.id}`;
              Lt.setAttribute("id", Ut), Lt.setAttribute("clipPathUnits", "objectBoundingBox"), Rt.append(Lt);
              for (const [, {
                x: Wt,
                y: qt
              }, {
                x: Yt,
                y: Qt
              }] of w) {
                const Jt = xt.createElement("rect"), te = (Yt - v) / It, ie = (lt - qt) / Mt, se = (Wt - Yt) / It, fi = (qt - Qt) / Mt;
                Jt.setAttribute("x", te), Jt.setAttribute("y", ie), Jt.setAttribute("width", se), Jt.setAttribute("height", fi), Lt.append(Jt), Et == null || Et.push(`<rect vector-effect="non-scaling-stroke" x="${te}" y="${ie}" width="${se}" height="${fi}"/>`);
              }
              t(this, u) && (Et.push("</g></svg>')"), bt.backgroundImage = Et.join("")), this.container.append(Ht), this.container.style.clipPath = `url(#${Ut})`;
            }
            _createPopup() {
              const {
                container: w,
                data: v
              } = this;
              w.setAttribute("aria-haspopup", "dialog");
              const H = new a({
                data: {
                  color: v.color,
                  titleObj: v.titleObj,
                  modificationDate: v.modificationDate,
                  contentsObj: v.contentsObj,
                  richText: v.richText,
                  parentRect: v.rect,
                  borderStyle: 0,
                  id: `popup_${v.id}`,
                  rotation: v.rotation
                },
                parent: this.parent,
                elements: [this]
              });
              this.parent.div.append(H.render());
            }
            render() {
              (0, o.unreachable)("Abstract method `AnnotationElement.render` called");
            }
            _getElementsByName(w, v = null) {
              const H = [];
              if (this._fieldObjects) {
                const ot = this._fieldObjects[w];
                if (ot)
                  for (const {
                    page: lt,
                    id: bt,
                    exportValues: Et
                  } of ot) {
                    if (lt === -1 || bt === v)
                      continue;
                    const It = typeof Et == "string" ? Et : null, Mt = document.querySelector(`[data-element-id="${bt}"]`);
                    if (Mt && !N.has(Mt)) {
                      (0, o.warn)(`_getElementsByName - element not allowed: ${bt}`);
                      continue;
                    }
                    H.push({
                      id: bt,
                      exportValue: It,
                      domElement: Mt
                    });
                  }
                return H;
              }
              for (const ot of document.getElementsByName(w)) {
                const {
                  exportValue: lt
                } = ot, bt = ot.getAttribute("data-element-id");
                bt !== v && N.has(ot) && H.push({
                  id: bt,
                  exportValue: lt,
                  domElement: ot
                });
              }
              return H;
            }
            show() {
              var w;
              this.container && (this.container.hidden = !1), (w = this.popup) == null || w.maybeShow();
            }
            hide() {
              var w;
              this.container && (this.container.hidden = !0), (w = this.popup) == null || w.forceHide();
            }
            getElementsToTriggerPopup() {
              return this.container;
            }
            addHighlightArea() {
              const w = this.getElementsToTriggerPopup();
              if (Array.isArray(w))
                for (const v of w)
                  v.classList.add("highlightArea");
              else
                w.classList.add("highlightArea");
            }
            _editOnDoubleClick() {
              const {
                annotationEditorType: w,
                data: {
                  id: v
                }
              } = this;
              this.container.addEventListener("dblclick", () => {
                var H;
                (H = this.linkService.eventBus) == null || H.dispatch("switchannotationeditormode", {
                  source: this,
                  mode: w,
                  editId: v
                });
              });
            }
          };
          u = new WeakMap();
          let b = x;
          class E extends b {
            constructor(v, H = null) {
              super(v, {
                isRenderable: !0,
                ignoreBorder: !!(H != null && H.ignoreBorder),
                createQuadrilaterals: !0
              });
              Q(this, P);
              this.isTooltipOnly = v.data.isTooltipOnly;
            }
            render() {
              const {
                data: v,
                linkService: H
              } = this, ot = document.createElement("a");
              ot.setAttribute("data-element-id", v.id);
              let lt = !1;
              return v.url ? (H.addLinkAttributes(ot, v.url, v.newWindow), lt = !0) : v.action ? (this._bindNamedAction(ot, v.action), lt = !0) : v.attachment ? (this._bindAttachment(ot, v.attachment), lt = !0) : v.setOCGState ? (z(this, P, Fi).call(this, ot, v.setOCGState), lt = !0) : v.dest ? (this._bindLink(ot, v.dest), lt = !0) : (v.actions && (v.actions.Action || v.actions["Mouse Up"] || v.actions["Mouse Down"]) && this.enableScripting && this.hasJSActions && (this._bindJSAction(ot, v), lt = !0), v.resetForm ? (this._bindResetFormAction(ot, v.resetForm), lt = !0) : this.isTooltipOnly && !lt && (this._bindLink(ot, ""), lt = !0)), this.container.classList.add("linkAnnotation"), lt && this.container.append(ot), this.container;
            }
            _bindLink(v, H) {
              v.href = this.linkService.getDestinationHash(H), v.onclick = () => (H && this.linkService.goToDestination(H), !1), (H || H === "") && z(this, P, ne).call(this);
            }
            _bindNamedAction(v, H) {
              v.href = this.linkService.getAnchorUrl(""), v.onclick = () => (this.linkService.executeNamedAction(H), !1), z(this, P, ne).call(this);
            }
            _bindAttachment(v, H) {
              v.href = this.linkService.getAnchorUrl(""), v.onclick = () => {
                var ot;
                return (ot = this.downloadManager) == null || ot.openOrDownloadData(this.container, H.content, H.filename), !1;
              }, z(this, P, ne).call(this);
            }
            _bindJSAction(v, H) {
              v.href = this.linkService.getAnchorUrl("");
              const ot = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
              for (const lt of Object.keys(H.actions)) {
                const bt = ot.get(lt);
                bt && (v[bt] = () => {
                  var Et;
                  return (Et = this.linkService.eventBus) == null || Et.dispatch("dispatcheventinsandbox", {
                    source: this,
                    detail: {
                      id: H.id,
                      name: lt
                    }
                  }), !1;
                });
              }
              v.onclick || (v.onclick = () => !1), z(this, P, ne).call(this);
            }
            _bindResetFormAction(v, H) {
              const ot = v.onclick;
              if (ot || (v.href = this.linkService.getAnchorUrl("")), z(this, P, ne).call(this), !this._fieldObjects) {
                (0, o.warn)('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), ot || (v.onclick = () => !1);
                return;
              }
              v.onclick = () => {
                var Ht;
                ot == null || ot();
                const {
                  fields: lt,
                  refs: bt,
                  include: Et
                } = H, It = [];
                if (lt.length !== 0 || bt.length !== 0) {
                  const Rt = new Set(bt);
                  for (const Lt of lt) {
                    const Ut = this._fieldObjects[Lt] || [];
                    for (const {
                      id: Wt
                    } of Ut)
                      Rt.add(Wt);
                  }
                  for (const Lt of Object.values(this._fieldObjects))
                    for (const Ut of Lt)
                      Rt.has(Ut.id) === Et && It.push(Ut);
                } else
                  for (const Rt of Object.values(this._fieldObjects))
                    It.push(...Rt);
                const Mt = this.annotationStorage, xt = [];
                for (const Rt of It) {
                  const {
                    id: Lt
                  } = Rt;
                  switch (xt.push(Lt), Rt.type) {
                    case "text": {
                      const Wt = Rt.defaultValue || "";
                      Mt.setValue(Lt, {
                        value: Wt
                      });
                      break;
                    }
                    case "checkbox":
                    case "radiobutton": {
                      const Wt = Rt.defaultValue === Rt.exportValues;
                      Mt.setValue(Lt, {
                        value: Wt
                      });
                      break;
                    }
                    case "combobox":
                    case "listbox": {
                      const Wt = Rt.defaultValue || "";
                      Mt.setValue(Lt, {
                        value: Wt
                      });
                      break;
                    }
                    default:
                      continue;
                  }
                  const Ut = document.querySelector(`[data-element-id="${Lt}"]`);
                  if (Ut) {
                    if (!N.has(Ut)) {
                      (0, o.warn)(`_bindResetFormAction - element not allowed: ${Lt}`);
                      continue;
                    }
                  } else continue;
                  Ut.dispatchEvent(new Event("resetform"));
                }
                return this.enableScripting && ((Ht = this.linkService.eventBus) == null || Ht.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: "app",
                    ids: xt,
                    name: "ResetForm"
                  }
                })), !1;
              };
            }
          }
          P = new WeakSet(), ne = function() {
            this.container.setAttribute("data-internal-link", "");
          }, Fi = function(v, H) {
            v.href = this.linkService.getAnchorUrl(""), v.onclick = () => (this.linkService.executeSetOCGState(H), !1), z(this, P, ne).call(this);
          };
          class f extends b {
            constructor(w) {
              super(w, {
                isRenderable: !0
              });
            }
            render() {
              this.container.classList.add("textAnnotation");
              const w = document.createElement("img");
              return w.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", w.alt = "[{{type}} Annotation]", w.dataset.l10nId = "text_annotation_type", w.dataset.l10nArgs = JSON.stringify({
                type: this.data.name
              }), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.append(w), this.container;
            }
          }
          class d extends b {
            render() {
              return this.data.alternativeText && (this.container.title = this.data.alternativeText), this.container;
            }
            showElementAndHideCanvas(w) {
              var v;
              this.data.hasOwnCanvas && (((v = w.previousSibling) == null ? void 0 : v.nodeName) === "CANVAS" && (w.previousSibling.hidden = !0), w.hidden = !1);
            }
            _getKeyModifier(w) {
              const {
                isWin: v,
                isMac: H
              } = o.FeatureTest.platform;
              return v && w.ctrlKey || H && w.metaKey;
            }
            _setEventListener(w, v, H, ot, lt) {
              H.includes("mouse") ? w.addEventListener(H, (bt) => {
                var Et;
                (Et = this.linkService.eventBus) == null || Et.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: this.data.id,
                    name: ot,
                    value: lt(bt),
                    shift: bt.shiftKey,
                    modifier: this._getKeyModifier(bt)
                  }
                });
              }) : w.addEventListener(H, (bt) => {
                var Et;
                if (H === "blur") {
                  if (!v.focused || !bt.relatedTarget)
                    return;
                  v.focused = !1;
                } else if (H === "focus") {
                  if (v.focused)
                    return;
                  v.focused = !0;
                }
                lt && ((Et = this.linkService.eventBus) == null || Et.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: this.data.id,
                    name: ot,
                    value: lt(bt)
                  }
                }));
              });
            }
            _setEventListeners(w, v, H, ot) {
              var lt, bt, Et;
              for (const [It, Mt] of H)
                (Mt === "Action" || (lt = this.data.actions) != null && lt[Mt]) && ((Mt === "Focus" || Mt === "Blur") && (v || (v = {
                  focused: !1
                })), this._setEventListener(w, v, It, Mt, ot), Mt === "Focus" && !((bt = this.data.actions) != null && bt.Blur) ? this._setEventListener(w, v, "blur", "Blur", null) : Mt === "Blur" && !((Et = this.data.actions) != null && Et.Focus) && this._setEventListener(w, v, "focus", "Focus", null));
            }
            _setBackgroundColor(w) {
              const v = this.data.backgroundColor || null;
              w.style.backgroundColor = v === null ? "transparent" : o.Util.makeHexColor(v[0], v[1], v[2]);
            }
            _setTextStyle(w) {
              const v = ["left", "center", "right"], {
                fontColor: H
              } = this.data.defaultAppearanceData, ot = this.data.defaultAppearanceData.fontSize || m, lt = w.style;
              let bt;
              const Et = 2, It = (Mt) => Math.round(10 * Mt) / 10;
              if (this.data.multiLine) {
                const Mt = Math.abs(this.data.rect[3] - this.data.rect[1] - Et), xt = Math.round(Mt / (o.LINE_FACTOR * ot)) || 1, Ht = Mt / xt;
                bt = Math.min(ot, It(Ht / o.LINE_FACTOR));
              } else {
                const Mt = Math.abs(this.data.rect[3] - this.data.rect[1] - Et);
                bt = Math.min(ot, It(Mt / o.LINE_FACTOR));
              }
              lt.fontSize = `calc(${bt}px * var(--scale-factor))`, lt.color = o.Util.makeHexColor(H[0], H[1], H[2]), this.data.textAlignment !== null && (lt.textAlign = v[this.data.textAlignment]);
            }
            _setRequired(w, v) {
              v ? w.setAttribute("required", !0) : w.removeAttribute("required"), w.setAttribute("aria-required", v);
            }
          }
          class p extends d {
            constructor(w) {
              const v = w.renderForms || !w.data.hasAppearance && !!w.data.fieldValue;
              super(w, {
                isRenderable: v
              });
            }
            setPropertyOnSiblings(w, v, H, ot) {
              const lt = this.annotationStorage;
              for (const bt of this._getElementsByName(w.name, w.id))
                bt.domElement && (bt.domElement[v] = H), lt.setValue(bt.id, {
                  [ot]: H
                });
            }
            render() {
              var ot, lt;
              const w = this.annotationStorage, v = this.data.id;
              this.container.classList.add("textWidgetAnnotation");
              let H = null;
              if (this.renderForms) {
                const bt = w.getValue(v, {
                  value: this.data.fieldValue
                });
                let Et = bt.value || "";
                const It = w.getValue(v, {
                  charLimit: this.data.maxLen
                }).charLimit;
                It && Et.length > It && (Et = Et.slice(0, It));
                let Mt = bt.formattedValue || ((ot = this.data.textContent) == null ? void 0 : ot.join(`
`)) || null;
                Mt && this.data.comb && (Mt = Mt.replaceAll(/\s+/g, ""));
                const xt = {
                  userValue: Et,
                  formattedValue: Mt,
                  lastCommittedValue: null,
                  commitKey: 1,
                  focused: !1
                };
                this.data.multiLine ? (H = document.createElement("textarea"), H.textContent = Mt ?? Et, this.data.doNotScroll && (H.style.overflowY = "hidden")) : (H = document.createElement("input"), H.type = "text", H.setAttribute("value", Mt ?? Et), this.data.doNotScroll && (H.style.overflowX = "hidden")), this.data.hasOwnCanvas && (H.hidden = !0), N.add(H), H.setAttribute("data-element-id", v), H.disabled = this.data.readOnly, H.name = this.data.fieldName, H.tabIndex = M, this._setRequired(H, this.data.required), It && (H.maxLength = It), H.addEventListener("input", (Rt) => {
                  w.setValue(v, {
                    value: Rt.target.value
                  }), this.setPropertyOnSiblings(H, "value", Rt.target.value, "value"), xt.formattedValue = null;
                }), H.addEventListener("resetform", (Rt) => {
                  const Lt = this.data.defaultFieldValue ?? "";
                  H.value = xt.userValue = Lt, xt.formattedValue = null;
                });
                let Ht = (Rt) => {
                  const {
                    formattedValue: Lt
                  } = xt;
                  Lt != null && (Rt.target.value = Lt), Rt.target.scrollLeft = 0;
                };
                if (this.enableScripting && this.hasJSActions) {
                  H.addEventListener("focus", (Lt) => {
                    if (xt.focused)
                      return;
                    const {
                      target: Ut
                    } = Lt;
                    xt.userValue && (Ut.value = xt.userValue), xt.lastCommittedValue = Ut.value, xt.commitKey = 1, xt.focused = !0;
                  }), H.addEventListener("updatefromsandbox", (Lt) => {
                    this.showElementAndHideCanvas(Lt.target);
                    const Ut = {
                      value(Wt) {
                        xt.userValue = Wt.detail.value ?? "", w.setValue(v, {
                          value: xt.userValue.toString()
                        }), Wt.target.value = xt.userValue;
                      },
                      formattedValue(Wt) {
                        const {
                          formattedValue: qt
                        } = Wt.detail;
                        xt.formattedValue = qt, qt != null && Wt.target !== document.activeElement && (Wt.target.value = qt), w.setValue(v, {
                          formattedValue: qt
                        });
                      },
                      selRange(Wt) {
                        Wt.target.setSelectionRange(...Wt.detail.selRange);
                      },
                      charLimit: (Wt) => {
                        var Jt;
                        const {
                          charLimit: qt
                        } = Wt.detail, {
                          target: Yt
                        } = Wt;
                        if (qt === 0) {
                          Yt.removeAttribute("maxLength");
                          return;
                        }
                        Yt.setAttribute("maxLength", qt);
                        let Qt = xt.userValue;
                        !Qt || Qt.length <= qt || (Qt = Qt.slice(0, qt), Yt.value = xt.userValue = Qt, w.setValue(v, {
                          value: Qt
                        }), (Jt = this.linkService.eventBus) == null || Jt.dispatch("dispatcheventinsandbox", {
                          source: this,
                          detail: {
                            id: v,
                            name: "Keystroke",
                            value: Qt,
                            willCommit: !0,
                            commitKey: 1,
                            selStart: Yt.selectionStart,
                            selEnd: Yt.selectionEnd
                          }
                        }));
                      }
                    };
                    this._dispatchEventFromSandbox(Ut, Lt);
                  }), H.addEventListener("keydown", (Lt) => {
                    var qt;
                    xt.commitKey = 1;
                    let Ut = -1;
                    if (Lt.key === "Escape" ? Ut = 0 : Lt.key === "Enter" && !this.data.multiLine ? Ut = 2 : Lt.key === "Tab" && (xt.commitKey = 3), Ut === -1)
                      return;
                    const {
                      value: Wt
                    } = Lt.target;
                    xt.lastCommittedValue !== Wt && (xt.lastCommittedValue = Wt, xt.userValue = Wt, (qt = this.linkService.eventBus) == null || qt.dispatch("dispatcheventinsandbox", {
                      source: this,
                      detail: {
                        id: v,
                        name: "Keystroke",
                        value: Wt,
                        willCommit: !0,
                        commitKey: Ut,
                        selStart: Lt.target.selectionStart,
                        selEnd: Lt.target.selectionEnd
                      }
                    }));
                  });
                  const Rt = Ht;
                  Ht = null, H.addEventListener("blur", (Lt) => {
                    var Wt;
                    if (!xt.focused || !Lt.relatedTarget)
                      return;
                    xt.focused = !1;
                    const {
                      value: Ut
                    } = Lt.target;
                    xt.userValue = Ut, xt.lastCommittedValue !== Ut && ((Wt = this.linkService.eventBus) == null || Wt.dispatch("dispatcheventinsandbox", {
                      source: this,
                      detail: {
                        id: v,
                        name: "Keystroke",
                        value: Ut,
                        willCommit: !0,
                        commitKey: xt.commitKey,
                        selStart: Lt.target.selectionStart,
                        selEnd: Lt.target.selectionEnd
                      }
                    })), Rt(Lt);
                  }), (lt = this.data.actions) != null && lt.Keystroke && H.addEventListener("beforeinput", (Lt) => {
                    var ie;
                    xt.lastCommittedValue = null;
                    const {
                      data: Ut,
                      target: Wt
                    } = Lt, {
                      value: qt,
                      selectionStart: Yt,
                      selectionEnd: Qt
                    } = Wt;
                    let Jt = Yt, te = Qt;
                    switch (Lt.inputType) {
                      case "deleteWordBackward": {
                        const se = qt.substring(0, Yt).match(/\w*[^\w]*$/);
                        se && (Jt -= se[0].length);
                        break;
                      }
                      case "deleteWordForward": {
                        const se = qt.substring(Yt).match(/^[^\w]*\w*/);
                        se && (te += se[0].length);
                        break;
                      }
                      case "deleteContentBackward":
                        Yt === Qt && (Jt -= 1);
                        break;
                      case "deleteContentForward":
                        Yt === Qt && (te += 1);
                        break;
                    }
                    Lt.preventDefault(), (ie = this.linkService.eventBus) == null || ie.dispatch("dispatcheventinsandbox", {
                      source: this,
                      detail: {
                        id: v,
                        name: "Keystroke",
                        value: qt,
                        change: Ut || "",
                        willCommit: !1,
                        selStart: Jt,
                        selEnd: te
                      }
                    });
                  }), this._setEventListeners(H, xt, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (Lt) => Lt.target.value);
                }
                if (Ht && H.addEventListener("blur", Ht), this.data.comb) {
                  const Lt = (this.data.rect[2] - this.data.rect[0]) / It;
                  H.classList.add("comb"), H.style.letterSpacing = `calc(${Lt}px * var(--scale-factor) - 1ch)`;
                }
              } else
                H = document.createElement("div"), H.textContent = this.data.fieldValue, H.style.verticalAlign = "middle", H.style.display = "table-cell";
              return this._setTextStyle(H), this._setBackgroundColor(H), this._setDefaultPropertiesFromJS(H), this.container.append(H), this.container;
            }
          }
          class D extends d {
            constructor(w) {
              super(w, {
                isRenderable: !!w.data.hasOwnCanvas
              });
            }
          }
          class y extends d {
            constructor(w) {
              super(w, {
                isRenderable: w.renderForms
              });
            }
            render() {
              const w = this.annotationStorage, v = this.data, H = v.id;
              let ot = w.getValue(H, {
                value: v.exportValue === v.fieldValue
              }).value;
              typeof ot == "string" && (ot = ot !== "Off", w.setValue(H, {
                value: ot
              })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
              const lt = document.createElement("input");
              return N.add(lt), lt.setAttribute("data-element-id", H), lt.disabled = v.readOnly, this._setRequired(lt, this.data.required), lt.type = "checkbox", lt.name = v.fieldName, ot && lt.setAttribute("checked", !0), lt.setAttribute("exportValue", v.exportValue), lt.tabIndex = M, lt.addEventListener("change", (bt) => {
                const {
                  name: Et,
                  checked: It
                } = bt.target;
                for (const Mt of this._getElementsByName(Et, H)) {
                  const xt = It && Mt.exportValue === v.exportValue;
                  Mt.domElement && (Mt.domElement.checked = xt), w.setValue(Mt.id, {
                    value: xt
                  });
                }
                w.setValue(H, {
                  value: It
                });
              }), lt.addEventListener("resetform", (bt) => {
                const Et = v.defaultFieldValue || "Off";
                bt.target.checked = Et === v.exportValue;
              }), this.enableScripting && this.hasJSActions && (lt.addEventListener("updatefromsandbox", (bt) => {
                const Et = {
                  value(It) {
                    It.target.checked = It.detail.value !== "Off", w.setValue(H, {
                      value: It.target.checked
                    });
                  }
                };
                this._dispatchEventFromSandbox(Et, bt);
              }), this._setEventListeners(lt, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (bt) => bt.target.checked)), this._setBackgroundColor(lt), this._setDefaultPropertiesFromJS(lt), this.container.append(lt), this.container;
            }
          }
          class n extends d {
            constructor(w) {
              super(w, {
                isRenderable: w.renderForms
              });
            }
            render() {
              this.container.classList.add("buttonWidgetAnnotation", "radioButton");
              const w = this.annotationStorage, v = this.data, H = v.id;
              let ot = w.getValue(H, {
                value: v.fieldValue === v.buttonValue
              }).value;
              typeof ot == "string" && (ot = ot !== v.buttonValue, w.setValue(H, {
                value: ot
              }));
              const lt = document.createElement("input");
              if (N.add(lt), lt.setAttribute("data-element-id", H), lt.disabled = v.readOnly, this._setRequired(lt, this.data.required), lt.type = "radio", lt.name = v.fieldName, ot && lt.setAttribute("checked", !0), lt.tabIndex = M, lt.addEventListener("change", (bt) => {
                const {
                  name: Et,
                  checked: It
                } = bt.target;
                for (const Mt of this._getElementsByName(Et, H))
                  w.setValue(Mt.id, {
                    value: !1
                  });
                w.setValue(H, {
                  value: It
                });
              }), lt.addEventListener("resetform", (bt) => {
                const Et = v.defaultFieldValue;
                bt.target.checked = Et != null && Et === v.buttonValue;
              }), this.enableScripting && this.hasJSActions) {
                const bt = v.buttonValue;
                lt.addEventListener("updatefromsandbox", (Et) => {
                  const It = {
                    value: (Mt) => {
                      const xt = bt === Mt.detail.value;
                      for (const Ht of this._getElementsByName(Mt.target.name)) {
                        const Rt = xt && Ht.id === H;
                        Ht.domElement && (Ht.domElement.checked = Rt), w.setValue(Ht.id, {
                          value: Rt
                        });
                      }
                    }
                  };
                  this._dispatchEventFromSandbox(It, Et);
                }), this._setEventListeners(lt, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (Et) => Et.target.checked);
              }
              return this._setBackgroundColor(lt), this._setDefaultPropertiesFromJS(lt), this.container.append(lt), this.container;
            }
          }
          class l extends E {
            constructor(w) {
              super(w, {
                ignoreBorder: w.data.hasAppearance
              });
            }
            render() {
              const w = super.render();
              w.classList.add("buttonWidgetAnnotation", "pushButton"), this.data.alternativeText && (w.title = this.data.alternativeText);
              const v = w.lastChild;
              return this.enableScripting && this.hasJSActions && v && (this._setDefaultPropertiesFromJS(v), v.addEventListener("updatefromsandbox", (H) => {
                this._dispatchEventFromSandbox({}, H);
              })), w;
            }
          }
          class s extends d {
            constructor(w) {
              super(w, {
                isRenderable: w.renderForms
              });
            }
            render() {
              this.container.classList.add("choiceWidgetAnnotation");
              const w = this.annotationStorage, v = this.data.id, H = w.getValue(v, {
                value: this.data.fieldValue
              }), ot = document.createElement("select");
              N.add(ot), ot.setAttribute("data-element-id", v), ot.disabled = this.data.readOnly, this._setRequired(ot, this.data.required), ot.name = this.data.fieldName, ot.tabIndex = M;
              let lt = this.data.combo && this.data.options.length > 0;
              this.data.combo || (ot.size = this.data.options.length, this.data.multiSelect && (ot.multiple = !0)), ot.addEventListener("resetform", (xt) => {
                const Ht = this.data.defaultFieldValue;
                for (const Rt of ot.options)
                  Rt.selected = Rt.value === Ht;
              });
              for (const xt of this.data.options) {
                const Ht = document.createElement("option");
                Ht.textContent = xt.displayValue, Ht.value = xt.exportValue, H.value.includes(xt.exportValue) && (Ht.setAttribute("selected", !0), lt = !1), ot.append(Ht);
              }
              let bt = null;
              if (lt) {
                const xt = document.createElement("option");
                xt.value = " ", xt.setAttribute("hidden", !0), xt.setAttribute("selected", !0), ot.prepend(xt), bt = () => {
                  xt.remove(), ot.removeEventListener("input", bt), bt = null;
                }, ot.addEventListener("input", bt);
              }
              const Et = (xt) => {
                const Ht = xt ? "value" : "textContent", {
                  options: Rt,
                  multiple: Lt
                } = ot;
                return Lt ? Array.prototype.filter.call(Rt, (Ut) => Ut.selected).map((Ut) => Ut[Ht]) : Rt.selectedIndex === -1 ? null : Rt[Rt.selectedIndex][Ht];
              };
              let It = Et(!1);
              const Mt = (xt) => {
                const Ht = xt.target.options;
                return Array.prototype.map.call(Ht, (Rt) => ({
                  displayValue: Rt.textContent,
                  exportValue: Rt.value
                }));
              };
              return this.enableScripting && this.hasJSActions ? (ot.addEventListener("updatefromsandbox", (xt) => {
                const Ht = {
                  value(Rt) {
                    bt == null || bt();
                    const Lt = Rt.detail.value, Ut = new Set(Array.isArray(Lt) ? Lt : [Lt]);
                    for (const Wt of ot.options)
                      Wt.selected = Ut.has(Wt.value);
                    w.setValue(v, {
                      value: Et(!0)
                    }), It = Et(!1);
                  },
                  multipleSelection(Rt) {
                    ot.multiple = !0;
                  },
                  remove(Rt) {
                    const Lt = ot.options, Ut = Rt.detail.remove;
                    Lt[Ut].selected = !1, ot.remove(Ut), Lt.length > 0 && Array.prototype.findIndex.call(Lt, (qt) => qt.selected) === -1 && (Lt[0].selected = !0), w.setValue(v, {
                      value: Et(!0),
                      items: Mt(Rt)
                    }), It = Et(!1);
                  },
                  clear(Rt) {
                    for (; ot.length !== 0; )
                      ot.remove(0);
                    w.setValue(v, {
                      value: null,
                      items: []
                    }), It = Et(!1);
                  },
                  insert(Rt) {
                    const {
                      index: Lt,
                      displayValue: Ut,
                      exportValue: Wt
                    } = Rt.detail.insert, qt = ot.children[Lt], Yt = document.createElement("option");
                    Yt.textContent = Ut, Yt.value = Wt, qt ? qt.before(Yt) : ot.append(Yt), w.setValue(v, {
                      value: Et(!0),
                      items: Mt(Rt)
                    }), It = Et(!1);
                  },
                  items(Rt) {
                    const {
                      items: Lt
                    } = Rt.detail;
                    for (; ot.length !== 0; )
                      ot.remove(0);
                    for (const Ut of Lt) {
                      const {
                        displayValue: Wt,
                        exportValue: qt
                      } = Ut, Yt = document.createElement("option");
                      Yt.textContent = Wt, Yt.value = qt, ot.append(Yt);
                    }
                    ot.options.length > 0 && (ot.options[0].selected = !0), w.setValue(v, {
                      value: Et(!0),
                      items: Mt(Rt)
                    }), It = Et(!1);
                  },
                  indices(Rt) {
                    const Lt = new Set(Rt.detail.indices);
                    for (const Ut of Rt.target.options)
                      Ut.selected = Lt.has(Ut.index);
                    w.setValue(v, {
                      value: Et(!0)
                    }), It = Et(!1);
                  },
                  editable(Rt) {
                    Rt.target.disabled = !Rt.detail.editable;
                  }
                };
                this._dispatchEventFromSandbox(Ht, xt);
              }), ot.addEventListener("input", (xt) => {
                var Rt;
                const Ht = Et(!0);
                w.setValue(v, {
                  value: Ht
                }), xt.preventDefault(), (Rt = this.linkService.eventBus) == null || Rt.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: v,
                    name: "Keystroke",
                    value: It,
                    changeEx: Ht,
                    willCommit: !1,
                    commitKey: 1,
                    keyDown: !1
                  }
                });
              }), this._setEventListeners(ot, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (xt) => xt.target.value)) : ot.addEventListener("input", function(xt) {
                w.setValue(v, {
                  value: Et(!0)
                });
              }), this.data.combo && this._setTextStyle(ot), this._setBackgroundColor(ot), this._setDefaultPropertiesFromJS(ot), this.container.append(ot), this.container;
            }
          }
          class a extends b {
            constructor(w) {
              const {
                data: v,
                elements: H
              } = w;
              super(w, {
                isRenderable: b._hasPopupData(v)
              }), this.elements = H;
            }
            render() {
              this.container.classList.add("popupAnnotation");
              const w = new c({
                container: this.container,
                color: this.data.color,
                titleObj: this.data.titleObj,
                modificationDate: this.data.modificationDate,
                contentsObj: this.data.contentsObj,
                richText: this.data.richText,
                rect: this.data.rect,
                parentRect: this.data.parentRect || null,
                parent: this.parent,
                elements: this.elements,
                open: this.data.open
              }), v = [];
              for (const H of this.elements)
                H.popup = w, v.push(H.data.id), H.addHighlightArea();
              return this.container.setAttribute("aria-controls", v.map((H) => `${o.AnnotationPrefix}${H}`).join(",")), this.container;
            }
          }
          class c {
            constructor({
              container: w,
              color: v,
              elements: H,
              titleObj: ot,
              modificationDate: lt,
              contentsObj: bt,
              richText: Et,
              parent: It,
              rect: Mt,
              parentRect: xt,
              open: Ht
            }) {
              Q(this, wt);
              Q(this, it, null);
              Q(this, ht, z(this, wt, Mi).bind(this));
              Q(this, dt, z(this, wt, ii).bind(this));
              Q(this, mt, z(this, wt, ei).bind(this));
              Q(this, At, z(this, wt, Ce).bind(this));
              Q(this, vt, null);
              Q(this, K, null);
              Q(this, Z, null);
              Q(this, g, null);
              Q(this, R, null);
              Q(this, X, null);
              Q(this, J, !1);
              Q(this, ut, null);
              Q(this, St, null);
              Q(this, yt, null);
              Q(this, V, null);
              Q(this, Tt, !1);
              var Lt;
              et(this, K, w), et(this, V, ot), et(this, Z, bt), et(this, yt, Et), et(this, R, It), et(this, vt, v), et(this, St, Mt), et(this, X, xt), et(this, g, H);
              const Rt = T.PDFDateString.toDateObject(lt);
              Rt && et(this, it, It.l10n.get("annotation_date_string", {
                date: Rt.toLocaleDateString(),
                time: Rt.toLocaleTimeString()
              })), this.trigger = H.flatMap((Ut) => Ut.getElementsToTriggerPopup());
              for (const Ut of this.trigger)
                Ut.addEventListener("click", t(this, At)), Ut.addEventListener("mouseenter", t(this, mt)), Ut.addEventListener("mouseleave", t(this, dt)), Ut.classList.add("popupTriggerArea");
              for (const Ut of H)
                (Lt = Ut.container) == null || Lt.addEventListener("keydown", t(this, ht));
              t(this, K).hidden = !0, Ht && z(this, wt, Ce).call(this);
            }
            render() {
              if (t(this, ut))
                return;
              const {
                page: {
                  view: w
                },
                viewport: {
                  rawDims: {
                    pageWidth: v,
                    pageHeight: H,
                    pageX: ot,
                    pageY: lt
                  }
                }
              } = t(this, R), bt = et(this, ut, document.createElement("div"));
              if (bt.className = "popup", t(this, vt)) {
                const Jt = bt.style.outlineColor = o.Util.makeHexColor(...t(this, vt));
                CSS.supports("background-color", "color-mix(in srgb, red 30%, white)") ? bt.style.backgroundColor = `color-mix(in srgb, ${Jt} 30%, white)` : bt.style.backgroundColor = o.Util.makeHexColor(...t(this, vt).map((ie) => Math.floor(0.7 * (255 - ie) + ie)));
              }
              const Et = document.createElement("span");
              Et.className = "header";
              const It = document.createElement("h1");
              if (Et.append(It), {
                dir: It.dir,
                str: It.textContent
              } = t(this, V), bt.append(Et), t(this, it)) {
                const Jt = document.createElement("span");
                Jt.classList.add("popupDate"), t(this, it).then((te) => {
                  Jt.textContent = te;
                }), Et.append(Jt);
              }
              const Mt = t(this, Z), xt = t(this, yt);
              if (xt != null && xt.str && (!(Mt != null && Mt.str) || Mt.str === xt.str))
                B.XfaLayer.render({
                  xfaHtml: xt.html,
                  intent: "richText",
                  div: bt
                }), bt.lastChild.classList.add("richText", "popupContent");
              else {
                const Jt = this._formatContents(Mt);
                bt.append(Jt);
              }
              let Ht = !!t(this, X), Rt = Ht ? t(this, X) : t(this, St);
              for (const Jt of t(this, g))
                if (!Rt || o.Util.intersect(Jt.data.rect, Rt) !== null) {
                  Rt = Jt.data.rect, Ht = !0;
                  break;
                }
              const Lt = o.Util.normalizeRect([Rt[0], w[3] - Rt[1] + w[1], Rt[2], w[3] - Rt[3] + w[1]]), Wt = Ht ? Rt[2] - Rt[0] + 5 : 0, qt = Lt[0] + Wt, Yt = Lt[1], {
                style: Qt
              } = t(this, K);
              Qt.left = `${100 * (qt - ot) / v}%`, Qt.top = `${100 * (Yt - lt) / H}%`, t(this, K).append(bt);
            }
            _formatContents({
              str: w,
              dir: v
            }) {
              const H = document.createElement("p");
              H.classList.add("popupContent"), H.dir = v;
              const ot = w.split(/(?:\r\n?|\n)/);
              for (let lt = 0, bt = ot.length; lt < bt; ++lt) {
                const Et = ot[lt];
                H.append(document.createTextNode(Et)), lt < bt - 1 && H.append(document.createElement("br"));
              }
              return H;
            }
            forceHide() {
              et(this, Tt, this.isVisible), t(this, Tt) && (t(this, K).hidden = !0);
            }
            maybeShow() {
              t(this, Tt) && (et(this, Tt, !1), t(this, K).hidden = !1);
            }
            get isVisible() {
              return t(this, K).hidden === !1;
            }
          }
          it = new WeakMap(), ht = new WeakMap(), dt = new WeakMap(), mt = new WeakMap(), At = new WeakMap(), vt = new WeakMap(), K = new WeakMap(), Z = new WeakMap(), g = new WeakMap(), R = new WeakMap(), X = new WeakMap(), J = new WeakMap(), ut = new WeakMap(), St = new WeakMap(), yt = new WeakMap(), V = new WeakMap(), Tt = new WeakMap(), wt = new WeakSet(), Mi = function(w) {
            w.altKey || w.shiftKey || w.ctrlKey || w.metaKey || (w.key === "Enter" || w.key === "Escape" && t(this, J)) && z(this, wt, Ce).call(this);
          }, Ce = function() {
            et(this, J, !t(this, J)), t(this, J) ? (z(this, wt, ei).call(this), t(this, K).addEventListener("click", t(this, At)), t(this, K).addEventListener("keydown", t(this, ht))) : (z(this, wt, ii).call(this), t(this, K).removeEventListener("click", t(this, At)), t(this, K).removeEventListener("keydown", t(this, ht)));
          }, ei = function() {
            t(this, ut) || this.render(), this.isVisible ? t(this, J) && t(this, K).classList.add("focused") : (t(this, K).hidden = !1, t(this, K).style.zIndex = parseInt(t(this, K).style.zIndex) + 1e3);
          }, ii = function() {
            t(this, K).classList.remove("focused"), !(t(this, J) || !this.isVisible) && (t(this, K).hidden = !0, t(this, K).style.zIndex = parseInt(t(this, K).style.zIndex) - 1e3);
          };
          class O extends b {
            constructor(w) {
              super(w, {
                isRenderable: !0,
                ignoreBorder: !0
              }), this.textContent = w.data.textContent, this.textPosition = w.data.textPosition, this.annotationEditorType = o.AnnotationEditorType.FREETEXT;
            }
            render() {
              if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
                const w = document.createElement("div");
                w.classList.add("annotationTextContent"), w.setAttribute("role", "comment");
                for (const v of this.textContent) {
                  const H = document.createElement("span");
                  H.textContent = v, w.append(H);
                }
                this.container.append(w);
              }
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
            }
          }
          h.FreeTextAnnotationElement = O;
          class r extends b {
            constructor(v) {
              super(v, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              Q(this, Nt, null);
            }
            render() {
              this.container.classList.add("lineAnnotation");
              const v = this.data, {
                width: H,
                height: ot
              } = I(v.rect), lt = this.svgFactory.create(H, ot, !0), bt = et(this, Nt, this.svgFactory.createElement("svg:line"));
              return bt.setAttribute("x1", v.rect[2] - v.lineCoordinates[0]), bt.setAttribute("y1", v.rect[3] - v.lineCoordinates[1]), bt.setAttribute("x2", v.rect[2] - v.lineCoordinates[2]), bt.setAttribute("y2", v.rect[3] - v.lineCoordinates[3]), bt.setAttribute("stroke-width", v.borderStyle.width || 1), bt.setAttribute("stroke", "transparent"), bt.setAttribute("fill", "transparent"), lt.append(bt), this.container.append(lt), !v.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
            getElementsToTriggerPopup() {
              return t(this, Nt);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          Nt = new WeakMap();
          class A extends b {
            constructor(v) {
              super(v, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              Q(this, Vt, null);
            }
            render() {
              this.container.classList.add("squareAnnotation");
              const v = this.data, {
                width: H,
                height: ot
              } = I(v.rect), lt = this.svgFactory.create(H, ot, !0), bt = v.borderStyle.width, Et = et(this, Vt, this.svgFactory.createElement("svg:rect"));
              return Et.setAttribute("x", bt / 2), Et.setAttribute("y", bt / 2), Et.setAttribute("width", H - bt), Et.setAttribute("height", ot - bt), Et.setAttribute("stroke-width", bt || 1), Et.setAttribute("stroke", "transparent"), Et.setAttribute("fill", "transparent"), lt.append(Et), this.container.append(lt), !v.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
            getElementsToTriggerPopup() {
              return t(this, Vt);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          Vt = new WeakMap();
          class F extends b {
            constructor(v) {
              super(v, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              Q(this, $t, null);
            }
            render() {
              this.container.classList.add("circleAnnotation");
              const v = this.data, {
                width: H,
                height: ot
              } = I(v.rect), lt = this.svgFactory.create(H, ot, !0), bt = v.borderStyle.width, Et = et(this, $t, this.svgFactory.createElement("svg:ellipse"));
              return Et.setAttribute("cx", H / 2), Et.setAttribute("cy", ot / 2), Et.setAttribute("rx", H / 2 - bt / 2), Et.setAttribute("ry", ot / 2 - bt / 2), Et.setAttribute("stroke-width", bt || 1), Et.setAttribute("stroke", "transparent"), Et.setAttribute("fill", "transparent"), lt.append(Et), this.container.append(lt), !v.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
            getElementsToTriggerPopup() {
              return t(this, $t);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          $t = new WeakMap();
          class nt extends b {
            constructor(v) {
              super(v, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              Q(this, _t, null);
              this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
            }
            render() {
              this.container.classList.add(this.containerClassName);
              const v = this.data, {
                width: H,
                height: ot
              } = I(v.rect), lt = this.svgFactory.create(H, ot, !0);
              let bt = [];
              for (const It of v.vertices) {
                const Mt = It.x - v.rect[0], xt = v.rect[3] - It.y;
                bt.push(Mt + "," + xt);
              }
              bt = bt.join(" ");
              const Et = et(this, _t, this.svgFactory.createElement(this.svgElementName));
              return Et.setAttribute("points", bt), Et.setAttribute("stroke-width", v.borderStyle.width || 1), Et.setAttribute("stroke", "transparent"), Et.setAttribute("fill", "transparent"), lt.append(Et), this.container.append(lt), !v.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
            getElementsToTriggerPopup() {
              return t(this, _t);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          _t = new WeakMap();
          class W extends nt {
            constructor(w) {
              super(w), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
            }
          }
          class $ extends b {
            constructor(w) {
              super(w, {
                isRenderable: !0,
                ignoreBorder: !0
              });
            }
            render() {
              return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
          }
          class j extends b {
            constructor(v) {
              super(v, {
                isRenderable: !0,
                ignoreBorder: !0
              });
              Q(this, tt, []);
              this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = o.AnnotationEditorType.INK;
            }
            render() {
              this.container.classList.add(this.containerClassName);
              const v = this.data, {
                width: H,
                height: ot
              } = I(v.rect), lt = this.svgFactory.create(H, ot, !0);
              for (const bt of v.inkLists) {
                let Et = [];
                for (const Mt of bt) {
                  const xt = Mt.x - v.rect[0], Ht = v.rect[3] - Mt.y;
                  Et.push(`${xt},${Ht}`);
                }
                Et = Et.join(" ");
                const It = this.svgFactory.createElement(this.svgElementName);
                t(this, tt).push(It), It.setAttribute("points", Et), It.setAttribute("stroke-width", v.borderStyle.width || 1), It.setAttribute("stroke", "transparent"), It.setAttribute("fill", "transparent"), !v.popupRef && this.hasPopupData && this._createPopup(), lt.append(It);
              }
              return this.container.append(lt), this.container;
            }
            getElementsToTriggerPopup() {
              return t(this, tt);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          tt = new WeakMap(), h.InkAnnotationElement = j;
          class at extends b {
            constructor(w) {
              super(w, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
              });
            }
            render() {
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("highlightAnnotation"), this.container;
            }
          }
          class C extends b {
            constructor(w) {
              super(w, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
              });
            }
            render() {
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("underlineAnnotation"), this.container;
            }
          }
          class U extends b {
            constructor(w) {
              super(w, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
              });
            }
            render() {
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("squigglyAnnotation"), this.container;
            }
          }
          class Y extends b {
            constructor(w) {
              super(w, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
              });
            }
            render() {
              return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("strikeoutAnnotation"), this.container;
            }
          }
          class S extends b {
            constructor(w) {
              super(w, {
                isRenderable: !0,
                ignoreBorder: !0
              });
            }
            render() {
              return this.container.classList.add("stampAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
            }
          }
          h.StampAnnotationElement = S;
          class e extends b {
            constructor(v) {
              var lt;
              super(v, {
                isRenderable: !0
              });
              Q(this, kt);
              Q(this, st, null);
              const {
                filename: H,
                content: ot
              } = this.data.file;
              this.filename = (0, T.getFilenameFromUrl)(H, !0), this.content = ot, (lt = this.linkService.eventBus) == null || lt.dispatch("fileattachmentannotation", {
                source: this,
                filename: H,
                content: ot
              });
            }
            render() {
              this.container.classList.add("fileAttachmentAnnotation");
              const {
                container: v,
                data: H
              } = this;
              let ot;
              H.hasAppearance || H.fillAlpha === 0 ? ot = document.createElement("div") : (ot = document.createElement("img"), ot.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(H.name) ? "paperclip" : "pushpin"}.svg`, H.fillAlpha && H.fillAlpha < 1 && (ot.style = `filter: opacity(${Math.round(H.fillAlpha * 100)}%);`)), ot.addEventListener("dblclick", z(this, kt, si).bind(this)), et(this, st, ot);
              const {
                isMac: lt
              } = o.FeatureTest.platform;
              return v.addEventListener("keydown", (bt) => {
                bt.key === "Enter" && (lt ? bt.metaKey : bt.ctrlKey) && z(this, kt, si).call(this);
              }), !H.popupRef && this.hasPopupData ? this._createPopup() : ot.classList.add("popupTriggerArea"), v.append(ot), v;
            }
            getElementsToTriggerPopup() {
              return t(this, st);
            }
            addHighlightArea() {
              this.container.classList.add("highlightArea");
            }
          }
          st = new WeakMap(), kt = new WeakSet(), si = function() {
            var v;
            (v = this.downloadManager) == null || v.openOrDownloadData(this.container, this.content, this.filename);
          };
          class i {
            constructor({
              div: w,
              accessibilityManager: v,
              annotationCanvasMap: H,
              l10n: ot,
              page: lt,
              viewport: bt
            }) {
              Q(this, Ct);
              Q(this, Gt, null);
              Q(this, L, null);
              Q(this, ft, /* @__PURE__ */ new Map());
              this.div = w, et(this, Gt, v), et(this, L, H), this.l10n = ot, this.page = lt, this.viewport = bt, this.zIndex = 0, this.l10n || (this.l10n = gt.NullL10n);
            }
            async render(w) {
              const {
                annotations: v
              } = w, H = this.div;
              (0, T.setLayerDimensions)(H, this.viewport);
              const ot = /* @__PURE__ */ new Map(), lt = {
                data: null,
                layer: H,
                linkService: w.linkService,
                downloadManager: w.downloadManager,
                imageResourcesPath: w.imageResourcesPath || "",
                renderForms: w.renderForms !== !1,
                svgFactory: new T.DOMSVGFactory(),
                annotationStorage: w.annotationStorage || new ct.AnnotationStorage(),
                enableScripting: w.enableScripting === !0,
                hasJSActions: w.hasJSActions,
                fieldObjects: w.fieldObjects,
                parent: this,
                elements: null
              };
              for (const bt of v) {
                if (bt.noHTML)
                  continue;
                const Et = bt.annotationType === o.AnnotationType.POPUP;
                if (Et) {
                  const xt = ot.get(bt.id);
                  if (!xt)
                    continue;
                  lt.elements = xt;
                } else {
                  const {
                    width: xt,
                    height: Ht
                  } = I(bt.rect);
                  if (xt <= 0 || Ht <= 0)
                    continue;
                }
                lt.data = bt;
                const It = _.create(lt);
                if (!It.isRenderable)
                  continue;
                if (!Et && bt.popupRef) {
                  const xt = ot.get(bt.popupRef);
                  xt ? xt.push(It) : ot.set(bt.popupRef, [It]);
                }
                It.annotationEditorType > 0 && t(this, ft).set(It.data.id, It);
                const Mt = It.render();
                bt.hidden && (Mt.style.visibility = "hidden"), z(this, Ct, Ri).call(this, Mt, bt.id);
              }
              z(this, Ct, ni).call(this), await this.l10n.translate(H);
            }
            update({
              viewport: w
            }) {
              const v = this.div;
              this.viewport = w, (0, T.setLayerDimensions)(v, {
                rotation: w.rotation
              }), z(this, Ct, ni).call(this), v.hidden = !1;
            }
            getEditableAnnotations() {
              return Array.from(t(this, ft).values());
            }
            getEditableAnnotation(w) {
              return t(this, ft).get(w);
            }
          }
          Gt = new WeakMap(), L = new WeakMap(), ft = new WeakMap(), Ct = new WeakSet(), Ri = function(w, v) {
            var ot;
            const H = w.firstChild || w;
            H.id = `${o.AnnotationPrefix}${v}`, this.div.append(w), (ot = t(this, Gt)) == null || ot.moveElementInDOM(this.div, w, H, !1);
          }, ni = function() {
            if (!t(this, L))
              return;
            const w = this.div;
            for (const [v, H] of t(this, L)) {
              const ot = w.querySelector(`[data-annotation-id="${v}"]`);
              if (!ot)
                continue;
              const {
                firstChild: lt
              } = ot;
              lt ? lt.nodeName === "CANVAS" ? lt.replaceWith(H) : lt.before(H) : ot.append(H);
            }
            t(this, L).clear();
          }, h.AnnotationLayer = i;
        },
        /* 30 */
        /***/
        (pt, h) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.ColorConverters = void 0;
          function rt(ct) {
            return Math.floor(Math.max(0, Math.min(1, ct)) * 255).toString(16).padStart(2, "0");
          }
          function o(ct) {
            return Math.max(0, Math.min(255, 255 * ct));
          }
          class T {
            static CMYK_G([q, gt, B, M]) {
              return ["G", 1 - Math.min(1, 0.3 * q + 0.59 * B + 0.11 * gt + M)];
            }
            static G_CMYK([q]) {
              return ["CMYK", 0, 0, 0, 1 - q];
            }
            static G_RGB([q]) {
              return ["RGB", q, q, q];
            }
            static G_rgb([q]) {
              return q = o(q), [q, q, q];
            }
            static G_HTML([q]) {
              const gt = rt(q);
              return `#${gt}${gt}${gt}`;
            }
            static RGB_G([q, gt, B]) {
              return ["G", 0.3 * q + 0.59 * gt + 0.11 * B];
            }
            static RGB_rgb(q) {
              return q.map(o);
            }
            static RGB_HTML(q) {
              return `#${q.map(rt).join("")}`;
            }
            static T_HTML() {
              return "#00000000";
            }
            static T_rgb() {
              return [null];
            }
            static CMYK_RGB([q, gt, B, M]) {
              return ["RGB", 1 - Math.min(1, q + M), 1 - Math.min(1, B + M), 1 - Math.min(1, gt + M)];
            }
            static CMYK_rgb([q, gt, B, M]) {
              return [o(1 - Math.min(1, q + M)), o(1 - Math.min(1, B + M)), o(1 - Math.min(1, gt + M))];
            }
            static CMYK_HTML(q) {
              const gt = this.CMYK_RGB(q).slice(1);
              return this.RGB_HTML(gt);
            }
            static RGB_CMYK([q, gt, B]) {
              const M = 1 - q, m = 1 - gt, N = 1 - B, I = Math.min(M, m, N);
              return ["CMYK", M, m, N, I];
            }
          }
          h.ColorConverters = T;
        },
        /* 31 */
        /***/
        (pt, h) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.NullL10n = void 0, h.getL10nFallback = o;
          const rt = {
            of_pages: "of {{pagesCount}}",
            page_of_pages: "({{pageNumber}} of {{pagesCount}})",
            document_properties_kb: "{{size_kb}} KB ({{size_b}} bytes)",
            document_properties_mb: "{{size_mb}} MB ({{size_b}} bytes)",
            document_properties_date_string: "{{date}}, {{time}}",
            document_properties_page_size_unit_inches: "in",
            document_properties_page_size_unit_millimeters: "mm",
            document_properties_page_size_orientation_portrait: "portrait",
            document_properties_page_size_orientation_landscape: "landscape",
            document_properties_page_size_name_a3: "A3",
            document_properties_page_size_name_a4: "A4",
            document_properties_page_size_name_letter: "Letter",
            document_properties_page_size_name_legal: "Legal",
            document_properties_page_size_dimension_string: "{{width}} × {{height}} {{unit}} ({{orientation}})",
            document_properties_page_size_dimension_name_string: "{{width}} × {{height}} {{unit}} ({{name}}, {{orientation}})",
            document_properties_linearized_yes: "Yes",
            document_properties_linearized_no: "No",
            additional_layers: "Additional Layers",
            page_landmark: "Page {{page}}",
            thumb_page_title: "Page {{page}}",
            thumb_page_canvas: "Thumbnail of Page {{page}}",
            find_reached_top: "Reached top of document, continued from bottom",
            find_reached_bottom: "Reached end of document, continued from top",
            "find_match_count[one]": "{{current}} of {{total}} match",
            "find_match_count[other]": "{{current}} of {{total}} matches",
            "find_match_count_limit[one]": "More than {{limit}} match",
            "find_match_count_limit[other]": "More than {{limit}} matches",
            find_not_found: "Phrase not found",
            page_scale_width: "Page Width",
            page_scale_fit: "Page Fit",
            page_scale_auto: "Automatic Zoom",
            page_scale_actual: "Actual Size",
            page_scale_percent: "{{scale}}%",
            loading_error: "An error occurred while loading the PDF.",
            invalid_file_error: "Invalid or corrupted PDF file.",
            missing_file_error: "Missing PDF file.",
            unexpected_response_error: "Unexpected server response.",
            rendering_error: "An error occurred while rendering the page.",
            annotation_date_string: "{{date}}, {{time}}",
            printing_not_supported: "Warning: Printing is not fully supported by this browser.",
            printing_not_ready: "Warning: The PDF is not fully loaded for printing.",
            web_fonts_disabled: "Web fonts are disabled: unable to use embedded PDF fonts.",
            free_text2_default_content: "Start typing…",
            editor_free_text2_aria_label: "Text Editor",
            editor_ink2_aria_label: "Draw Editor",
            editor_ink_canvas_aria_label: "User-created image",
            editor_alt_text_button_label: "Alt text",
            editor_alt_text_edit_button_label: "Edit alt text",
            editor_alt_text_decorative_tooltip: "Marked as decorative"
          };
          rt.print_progress_percent = "{{progress}}%";
          function o(q, gt) {
            switch (q) {
              case "find_match_count":
                q = `find_match_count[${gt.total === 1 ? "one" : "other"}]`;
                break;
              case "find_match_count_limit":
                q = `find_match_count_limit[${gt.limit === 1 ? "one" : "other"}]`;
                break;
            }
            return rt[q] || "";
          }
          function T(q, gt) {
            return gt ? q.replaceAll(/\{\{\s*(\w+)\s*\}\}/g, (B, M) => M in gt ? gt[M] : "{{" + M + "}}") : q;
          }
          const ct = {
            async getLanguage() {
              return "en-us";
            },
            async getDirection() {
              return "ltr";
            },
            async get(q, gt = null, B = o(q, gt)) {
              return T(B, gt);
            },
            async translate(q) {
            }
          };
          h.NullL10n = ct;
        },
        /* 32 */
        /***/
        (pt, h, rt) => {
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.XfaLayer = void 0;
          var o = rt(25);
          class T {
            static setupStorage(q, gt, B, M, m) {
              const N = M.getValue(gt, {
                value: null
              });
              switch (B.name) {
                case "textarea":
                  if (N.value !== null && (q.textContent = N.value), m === "print")
                    break;
                  q.addEventListener("input", (I) => {
                    M.setValue(gt, {
                      value: I.target.value
                    });
                  });
                  break;
                case "input":
                  if (B.attributes.type === "radio" || B.attributes.type === "checkbox") {
                    if (N.value === B.attributes.xfaOn ? q.setAttribute("checked", !0) : N.value === B.attributes.xfaOff && q.removeAttribute("checked"), m === "print")
                      break;
                    q.addEventListener("change", (I) => {
                      M.setValue(gt, {
                        value: I.target.checked ? I.target.getAttribute("xfaOn") : I.target.getAttribute("xfaOff")
                      });
                    });
                  } else {
                    if (N.value !== null && q.setAttribute("value", N.value), m === "print")
                      break;
                    q.addEventListener("input", (I) => {
                      M.setValue(gt, {
                        value: I.target.value
                      });
                    });
                  }
                  break;
                case "select":
                  if (N.value !== null) {
                    q.setAttribute("value", N.value);
                    for (const I of B.children)
                      I.attributes.value === N.value ? I.attributes.selected = !0 : I.attributes.hasOwnProperty("selected") && delete I.attributes.selected;
                  }
                  q.addEventListener("input", (I) => {
                    const _ = I.target.options, b = _.selectedIndex === -1 ? "" : _[_.selectedIndex].value;
                    M.setValue(gt, {
                      value: b
                    });
                  });
                  break;
              }
            }
            static setAttributes({
              html: q,
              element: gt,
              storage: B = null,
              intent: M,
              linkService: m
            }) {
              const {
                attributes: N
              } = gt, I = q instanceof HTMLAnchorElement;
              N.type === "radio" && (N.name = `${N.name}-${M}`);
              for (const [_, b] of Object.entries(N))
                if (b != null)
                  switch (_) {
                    case "class":
                      b.length && q.setAttribute(_, b.join(" "));
                      break;
                    case "dataId":
                      break;
                    case "id":
                      q.setAttribute("data-element-id", b);
                      break;
                    case "style":
                      Object.assign(q.style, b);
                      break;
                    case "textContent":
                      q.textContent = b;
                      break;
                    default:
                      (!I || _ !== "href" && _ !== "newWindow") && q.setAttribute(_, b);
                  }
              I && m.addLinkAttributes(q, N.href, N.newWindow), B && N.dataId && this.setupStorage(q, N.dataId, gt, B);
            }
            static render(q) {
              var E;
              const gt = q.annotationStorage, B = q.linkService, M = q.xfaHtml, m = q.intent || "display", N = document.createElement(M.name);
              M.attributes && this.setAttributes({
                html: N,
                element: M,
                intent: m,
                linkService: B
              });
              const I = [[M, -1, N]], _ = q.div;
              if (_.append(N), q.viewport) {
                const f = `matrix(${q.viewport.transform.join(",")})`;
                _.style.transform = f;
              }
              m !== "richText" && _.setAttribute("class", "xfaLayer xfaFont");
              const b = [];
              for (; I.length > 0; ) {
                const [f, d, p] = I.at(-1);
                if (d + 1 === f.children.length) {
                  I.pop();
                  continue;
                }
                const D = f.children[++I.at(-1)[1]];
                if (D === null)
                  continue;
                const {
                  name: y
                } = D;
                if (y === "#text") {
                  const l = document.createTextNode(D.value);
                  b.push(l), p.append(l);
                  continue;
                }
                const n = (E = D == null ? void 0 : D.attributes) != null && E.xmlns ? document.createElementNS(D.attributes.xmlns, y) : document.createElement(y);
                if (p.append(n), D.attributes && this.setAttributes({
                  html: n,
                  element: D,
                  storage: gt,
                  intent: m,
                  linkService: B
                }), D.children && D.children.length > 0)
                  I.push([D, -1, n]);
                else if (D.value) {
                  const l = document.createTextNode(D.value);
                  o.XfaText.shouldBuildText(y) && b.push(l), n.append(l);
                }
              }
              for (const f of _.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
                f.setAttribute("readOnly", !0);
              return {
                textDivs: b
              };
            }
            static update(q) {
              const gt = `matrix(${q.viewport.transform.join(",")})`;
              q.div.style.transform = gt, q.div.hidden = !1;
            }
          }
          h.XfaLayer = T;
        },
        /* 33 */
        /***/
        (pt, h, rt) => {
          var M, m, N, I, _, b, E, f, d, p, D, y, n, l, s, Di, Ii, Li, Oi, ri, Ni, ai, Bi, Ui, ji, Hi, Wi, ee, oi, Te, xe, le, li, Pe, P, Gi, ci, zi, Xi, hi, ke, ce;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.InkEditor = void 0;
          var o = rt(1), T = rt(4), ct = rt(29), q = rt(6), gt = rt(5);
          const vt = class vt extends T.AnnotationEditor {
            constructor(g) {
              super({
                ...g,
                name: "inkEditor"
              });
              Q(this, s);
              Q(this, M, 0);
              Q(this, m, 0);
              Q(this, N, this.canvasPointermove.bind(this));
              Q(this, I, this.canvasPointerleave.bind(this));
              Q(this, _, this.canvasPointerup.bind(this));
              Q(this, b, this.canvasPointerdown.bind(this));
              Q(this, E, new Path2D());
              Q(this, f, !1);
              Q(this, d, !1);
              Q(this, p, !1);
              Q(this, D, null);
              Q(this, y, 0);
              Q(this, n, 0);
              Q(this, l, null);
              this.color = g.color || null, this.thickness = g.thickness || null, this.opacity = g.opacity || null, this.paths = [], this.bezierPath2D = [], this.allRawPaths = [], this.currentPath = [], this.scaleFactor = 1, this.translationX = this.translationY = 0, this.x = 0, this.y = 0, this._willKeepAspectRatio = !0;
            }
            static initialize(g) {
              T.AnnotationEditor.initialize(g, {
                strings: ["editor_ink_canvas_aria_label", "editor_ink2_aria_label"]
              });
            }
            static updateDefaultParams(g, R) {
              switch (g) {
                case o.AnnotationEditorParamsType.INK_THICKNESS:
                  vt._defaultThickness = R;
                  break;
                case o.AnnotationEditorParamsType.INK_COLOR:
                  vt._defaultColor = R;
                  break;
                case o.AnnotationEditorParamsType.INK_OPACITY:
                  vt._defaultOpacity = R / 100;
                  break;
              }
            }
            updateParams(g, R) {
              switch (g) {
                case o.AnnotationEditorParamsType.INK_THICKNESS:
                  z(this, s, Di).call(this, R);
                  break;
                case o.AnnotationEditorParamsType.INK_COLOR:
                  z(this, s, Ii).call(this, R);
                  break;
                case o.AnnotationEditorParamsType.INK_OPACITY:
                  z(this, s, Li).call(this, R);
                  break;
              }
            }
            static get defaultPropertiesToUpdate() {
              return [[o.AnnotationEditorParamsType.INK_THICKNESS, vt._defaultThickness], [o.AnnotationEditorParamsType.INK_COLOR, vt._defaultColor || T.AnnotationEditor._defaultLineColor], [o.AnnotationEditorParamsType.INK_OPACITY, Math.round(vt._defaultOpacity * 100)]];
            }
            get propertiesToUpdate() {
              return [[o.AnnotationEditorParamsType.INK_THICKNESS, this.thickness || vt._defaultThickness], [o.AnnotationEditorParamsType.INK_COLOR, this.color || vt._defaultColor || T.AnnotationEditor._defaultLineColor], [o.AnnotationEditorParamsType.INK_OPACITY, Math.round(100 * (this.opacity ?? vt._defaultOpacity))]];
            }
            rebuild() {
              this.parent && (super.rebuild(), this.div !== null && (this.canvas || (z(this, s, Te).call(this), z(this, s, xe).call(this)), this.isAttachedToDOM || (this.parent.add(this), z(this, s, le).call(this)), z(this, s, ce).call(this)));
            }
            remove() {
              this.canvas !== null && (this.isEmpty() || this.commit(), this.canvas.width = this.canvas.height = 0, this.canvas.remove(), this.canvas = null, t(this, D).disconnect(), et(this, D, null), super.remove());
            }
            setParent(g) {
              !this.parent && g ? this._uiManager.removeShouldRescale(this) : this.parent && g === null && this._uiManager.addShouldRescale(this), super.setParent(g);
            }
            onScaleChanging() {
              const [g, R] = this.parentDimensions, X = this.width * g, J = this.height * R;
              this.setDimensions(X, J);
            }
            enableEditMode() {
              t(this, f) || this.canvas === null || (super.enableEditMode(), this._isDraggable = !1, this.canvas.addEventListener("pointerdown", t(this, b)));
            }
            disableEditMode() {
              !this.isInEditMode() || this.canvas === null || (super.disableEditMode(), this._isDraggable = !this.isEmpty(), this.div.classList.remove("editing"), this.canvas.removeEventListener("pointerdown", t(this, b)));
            }
            onceAdded() {
              this._isDraggable = !this.isEmpty();
            }
            isEmpty() {
              return this.paths.length === 0 || this.paths.length === 1 && this.paths[0].length === 0;
            }
            commit() {
              t(this, f) || (super.commit(), this.isEditing = !1, this.disableEditMode(), this.setInForeground(), et(this, f, !0), this.div.classList.add("disabled"), z(this, s, ce).call(this, !0), this.makeResizable(), this.parent.addInkEditorIfNeeded(!0), this.moveInDOM(), this.div.focus({
                preventScroll: !0
              }));
            }
            focusin(g) {
              this._focusEventsAllowed && (super.focusin(g), this.enableEditMode());
            }
            canvasPointerdown(g) {
              g.button !== 0 || !this.isInEditMode() || t(this, f) || (this.setInForeground(), g.preventDefault(), g.type !== "mouse" && this.div.focus(), z(this, s, Ni).call(this, g.offsetX, g.offsetY));
            }
            canvasPointermove(g) {
              g.preventDefault(), z(this, s, ai).call(this, g.offsetX, g.offsetY);
            }
            canvasPointerup(g) {
              g.preventDefault(), z(this, s, oi).call(this, g);
            }
            canvasPointerleave(g) {
              z(this, s, oi).call(this, g);
            }
            get isResizable() {
              return !this.isEmpty() && t(this, f);
            }
            render() {
              if (this.div)
                return this.div;
              let g, R;
              this.width && (g = this.x, R = this.y), super.render(), T.AnnotationEditor._l10nPromise.get("editor_ink2_aria_label").then((yt) => {
                var V;
                return (V = this.div) == null ? void 0 : V.setAttribute("aria-label", yt);
              });
              const [X, J, ut, St] = z(this, s, Oi).call(this);
              if (this.setAt(X, J, 0, 0), this.setDims(ut, St), z(this, s, Te).call(this), this.width) {
                const [yt, V] = this.parentDimensions;
                this.setAspectRatio(this.width * yt, this.height * V), this.setAt(g * yt, R * V, this.width * yt, this.height * V), et(this, p, !0), z(this, s, le).call(this), this.setDims(this.width * yt, this.height * V), z(this, s, ee).call(this), this.div.classList.add("disabled");
              } else
                this.div.classList.add("editing"), this.enableEditMode();
              return z(this, s, xe).call(this), this.div;
            }
            setDimensions(g, R) {
              const X = Math.round(g), J = Math.round(R);
              if (t(this, y) === X && t(this, n) === J)
                return;
              et(this, y, X), et(this, n, J), this.canvas.style.visibility = "hidden";
              const [ut, St] = this.parentDimensions;
              this.width = g / ut, this.height = R / St, this.fixAndSetPosition(), t(this, f) && z(this, s, li).call(this, g, R), z(this, s, le).call(this), z(this, s, ee).call(this), this.canvas.style.visibility = "visible", this.fixDims();
            }
            static deserialize(g, R, X) {
              var Nt, Vt, $t;
              if (g instanceof ct.InkAnnotationElement)
                return null;
              const J = super.deserialize(g, R, X);
              J.thickness = g.thickness, J.color = o.Util.makeHexColor(...g.color), J.opacity = g.opacity;
              const [ut, St] = J.pageDimensions, yt = J.width * ut, V = J.height * St, Tt = J.parentScale, wt = g.thickness / 2;
              et(J, f, !0), et(J, y, Math.round(yt)), et(J, n, Math.round(V));
              const {
                paths: jt,
                rect: Bt,
                rotation: Xt
              } = g;
              for (let {
                bezier: _t
              } of jt) {
                _t = z(Nt = vt, P, zi).call(Nt, _t, Bt, Xt);
                const tt = [];
                J.paths.push(tt);
                let st = Tt * (_t[0] - wt), kt = Tt * (_t[1] - wt);
                for (let Gt = 2, L = _t.length; Gt < L; Gt += 6) {
                  const ft = Tt * (_t[Gt] - wt), Ct = Tt * (_t[Gt + 1] - wt), Dt = Tt * (_t[Gt + 2] - wt), Ot = Tt * (_t[Gt + 3] - wt), Pt = Tt * (_t[Gt + 4] - wt), w = Tt * (_t[Gt + 5] - wt);
                  tt.push([[st, kt], [ft, Ct], [Dt, Ot], [Pt, w]]), st = Pt, kt = w;
                }
                const zt = z(this, P, Gi).call(this, tt);
                J.bezierPath2D.push(zt);
              }
              const Ft = z(Vt = J, s, hi).call(Vt);
              return et(J, m, Math.max(T.AnnotationEditor.MIN_SIZE, Ft[2] - Ft[0])), et(J, M, Math.max(T.AnnotationEditor.MIN_SIZE, Ft[3] - Ft[1])), z($t = J, s, li).call($t, yt, V), J;
            }
            serialize() {
              if (this.isEmpty())
                return null;
              const g = this.getRect(0, 0), R = T.AnnotationEditor._colorManager.convert(this.ctx.strokeStyle);
              return {
                annotationType: o.AnnotationEditorType.INK,
                color: R,
                thickness: this.thickness,
                opacity: this.opacity,
                paths: z(this, s, Xi).call(this, this.scaleFactor / this.parentScale, this.translationX, this.translationY, g),
                pageIndex: this.pageIndex,
                rect: g,
                rotation: this.rotation,
                structTreeParentId: this._structTreeParentId
              };
            }
          };
          M = new WeakMap(), m = new WeakMap(), N = new WeakMap(), I = new WeakMap(), _ = new WeakMap(), b = new WeakMap(), E = new WeakMap(), f = new WeakMap(), d = new WeakMap(), p = new WeakMap(), D = new WeakMap(), y = new WeakMap(), n = new WeakMap(), l = new WeakMap(), s = new WeakSet(), Di = function(g) {
            const R = this.thickness;
            this.addCommands({
              cmd: () => {
                this.thickness = g, z(this, s, ce).call(this);
              },
              undo: () => {
                this.thickness = R, z(this, s, ce).call(this);
              },
              mustExec: !0,
              type: o.AnnotationEditorParamsType.INK_THICKNESS,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, Ii = function(g) {
            const R = this.color;
            this.addCommands({
              cmd: () => {
                this.color = g, z(this, s, ee).call(this);
              },
              undo: () => {
                this.color = R, z(this, s, ee).call(this);
              },
              mustExec: !0,
              type: o.AnnotationEditorParamsType.INK_COLOR,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, Li = function(g) {
            g /= 100;
            const R = this.opacity;
            this.addCommands({
              cmd: () => {
                this.opacity = g, z(this, s, ee).call(this);
              },
              undo: () => {
                this.opacity = R, z(this, s, ee).call(this);
              },
              mustExec: !0,
              type: o.AnnotationEditorParamsType.INK_OPACITY,
              overwriteIfSameType: !0,
              keepUndo: !0
            });
          }, Oi = function() {
            const {
              parentRotation: g,
              parentDimensions: [R, X]
            } = this;
            switch (g) {
              case 90:
                return [0, X, X, R];
              case 180:
                return [R, X, R, X];
              case 270:
                return [R, 0, X, R];
              default:
                return [0, 0, R, X];
            }
          }, ri = function() {
            const {
              ctx: g,
              color: R,
              opacity: X,
              thickness: J,
              parentScale: ut,
              scaleFactor: St
            } = this;
            g.lineWidth = J * ut / St, g.lineCap = "round", g.lineJoin = "round", g.miterLimit = 10, g.strokeStyle = `${R}${(0, gt.opacityToHex)(X)}`;
          }, Ni = function(g, R) {
            this.canvas.addEventListener("contextmenu", q.noContextMenu), this.canvas.addEventListener("pointerleave", t(this, I)), this.canvas.addEventListener("pointermove", t(this, N)), this.canvas.addEventListener("pointerup", t(this, _)), this.canvas.removeEventListener("pointerdown", t(this, b)), this.isEditing = !0, t(this, p) || (et(this, p, !0), z(this, s, le).call(this), this.thickness || (this.thickness = vt._defaultThickness), this.color || (this.color = vt._defaultColor || T.AnnotationEditor._defaultLineColor), this.opacity ?? (this.opacity = vt._defaultOpacity)), this.currentPath.push([g, R]), et(this, d, !1), z(this, s, ri).call(this), et(this, l, () => {
              z(this, s, ji).call(this), t(this, l) && window.requestAnimationFrame(t(this, l));
            }), window.requestAnimationFrame(t(this, l));
          }, ai = function(g, R) {
            const [X, J] = this.currentPath.at(-1);
            if (this.currentPath.length > 1 && g === X && R === J)
              return;
            const ut = this.currentPath;
            let St = t(this, E);
            if (ut.push([g, R]), et(this, d, !0), ut.length <= 2) {
              St.moveTo(...ut[0]), St.lineTo(g, R);
              return;
            }
            ut.length === 3 && (et(this, E, St = new Path2D()), St.moveTo(...ut[0])), z(this, s, Hi).call(this, St, ...ut.at(-3), ...ut.at(-2), g, R);
          }, Bi = function() {
            if (this.currentPath.length === 0)
              return;
            const g = this.currentPath.at(-1);
            t(this, E).lineTo(...g);
          }, Ui = function(g, R) {
            et(this, l, null), g = Math.min(Math.max(g, 0), this.canvas.width), R = Math.min(Math.max(R, 0), this.canvas.height), z(this, s, ai).call(this, g, R), z(this, s, Bi).call(this);
            let X;
            if (this.currentPath.length !== 1)
              X = z(this, s, Wi).call(this);
            else {
              const V = [g, R];
              X = [[V, V.slice(), V.slice(), V]];
            }
            const J = t(this, E), ut = this.currentPath;
            this.currentPath = [], et(this, E, new Path2D());
            const St = () => {
              this.allRawPaths.push(ut), this.paths.push(X), this.bezierPath2D.push(J), this.rebuild();
            }, yt = () => {
              this.allRawPaths.pop(), this.paths.pop(), this.bezierPath2D.pop(), this.paths.length === 0 ? this.remove() : (this.canvas || (z(this, s, Te).call(this), z(this, s, xe).call(this)), z(this, s, ce).call(this));
            };
            this.addCommands({
              cmd: St,
              undo: yt,
              mustExec: !0
            });
          }, ji = function() {
            if (!t(this, d))
              return;
            et(this, d, !1);
            const g = Math.ceil(this.thickness * this.parentScale), R = this.currentPath.slice(-3), X = R.map((St) => St[0]), J = R.map((St) => St[1]);
            Math.min(...X) - g, Math.max(...X) + g, Math.min(...J) - g, Math.max(...J) + g;
            const {
              ctx: ut
            } = this;
            ut.save(), ut.clearRect(0, 0, this.canvas.width, this.canvas.height);
            for (const St of this.bezierPath2D)
              ut.stroke(St);
            ut.stroke(t(this, E)), ut.restore();
          }, Hi = function(g, R, X, J, ut, St, yt) {
            const V = (R + J) / 2, Tt = (X + ut) / 2, wt = (J + St) / 2, jt = (ut + yt) / 2;
            g.bezierCurveTo(V + 2 * (J - V) / 3, Tt + 2 * (ut - Tt) / 3, wt + 2 * (J - wt) / 3, jt + 2 * (ut - jt) / 3, wt, jt);
          }, Wi = function() {
            const g = this.currentPath;
            if (g.length <= 2)
              return [[g[0], g[0], g.at(-1), g.at(-1)]];
            const R = [];
            let X, [J, ut] = g[0];
            for (X = 1; X < g.length - 2; X++) {
              const [Bt, Xt] = g[X], [Ft, Nt] = g[X + 1], Vt = (Bt + Ft) / 2, $t = (Xt + Nt) / 2, _t = [J + 2 * (Bt - J) / 3, ut + 2 * (Xt - ut) / 3], tt = [Vt + 2 * (Bt - Vt) / 3, $t + 2 * (Xt - $t) / 3];
              R.push([[J, ut], _t, tt, [Vt, $t]]), [J, ut] = [Vt, $t];
            }
            const [St, yt] = g[X], [V, Tt] = g[X + 1], wt = [J + 2 * (St - J) / 3, ut + 2 * (yt - ut) / 3], jt = [V + 2 * (St - V) / 3, Tt + 2 * (yt - Tt) / 3];
            return R.push([[J, ut], wt, jt, [V, Tt]]), R;
          }, ee = function() {
            if (this.isEmpty()) {
              z(this, s, Pe).call(this);
              return;
            }
            z(this, s, ri).call(this);
            const {
              canvas: g,
              ctx: R
            } = this;
            R.setTransform(1, 0, 0, 1, 0, 0), R.clearRect(0, 0, g.width, g.height), z(this, s, Pe).call(this);
            for (const X of this.bezierPath2D)
              R.stroke(X);
          }, oi = function(g) {
            this.canvas.removeEventListener("pointerleave", t(this, I)), this.canvas.removeEventListener("pointermove", t(this, N)), this.canvas.removeEventListener("pointerup", t(this, _)), this.canvas.addEventListener("pointerdown", t(this, b)), setTimeout(() => {
              this.canvas.removeEventListener("contextmenu", q.noContextMenu);
            }, 10), z(this, s, Ui).call(this, g.offsetX, g.offsetY), this.addToAnnotationStorage(), this.setInBackground();
          }, Te = function() {
            this.canvas = document.createElement("canvas"), this.canvas.width = this.canvas.height = 0, this.canvas.className = "inkEditorCanvas", T.AnnotationEditor._l10nPromise.get("editor_ink_canvas_aria_label").then((g) => {
              var R;
              return (R = this.canvas) == null ? void 0 : R.setAttribute("aria-label", g);
            }), this.div.append(this.canvas), this.ctx = this.canvas.getContext("2d");
          }, xe = function() {
            et(this, D, new ResizeObserver((g) => {
              const R = g[0].contentRect;
              R.width && R.height && this.setDimensions(R.width, R.height);
            })), t(this, D).observe(this.div);
          }, le = function() {
            if (!t(this, p))
              return;
            const [g, R] = this.parentDimensions;
            this.canvas.width = Math.ceil(this.width * g), this.canvas.height = Math.ceil(this.height * R), z(this, s, Pe).call(this);
          }, li = function(g, R) {
            const X = z(this, s, ke).call(this), J = (g - X) / t(this, m), ut = (R - X) / t(this, M);
            this.scaleFactor = Math.min(J, ut);
          }, Pe = function() {
            const g = z(this, s, ke).call(this) / 2;
            this.ctx.setTransform(this.scaleFactor, 0, 0, this.scaleFactor, this.translationX * this.scaleFactor + g, this.translationY * this.scaleFactor + g);
          }, P = new WeakSet(), Gi = function(g) {
            const R = new Path2D();
            for (let X = 0, J = g.length; X < J; X++) {
              const [ut, St, yt, V] = g[X];
              X === 0 && R.moveTo(...ut), R.bezierCurveTo(St[0], St[1], yt[0], yt[1], V[0], V[1]);
            }
            return R;
          }, ci = function(g, R, X) {
            const [J, ut, St, yt] = R;
            switch (X) {
              case 0:
                for (let V = 0, Tt = g.length; V < Tt; V += 2)
                  g[V] += J, g[V + 1] = yt - g[V + 1];
                break;
              case 90:
                for (let V = 0, Tt = g.length; V < Tt; V += 2) {
                  const wt = g[V];
                  g[V] = g[V + 1] + J, g[V + 1] = wt + ut;
                }
                break;
              case 180:
                for (let V = 0, Tt = g.length; V < Tt; V += 2)
                  g[V] = St - g[V], g[V + 1] += ut;
                break;
              case 270:
                for (let V = 0, Tt = g.length; V < Tt; V += 2) {
                  const wt = g[V];
                  g[V] = St - g[V + 1], g[V + 1] = yt - wt;
                }
                break;
              default:
                throw new Error("Invalid rotation");
            }
            return g;
          }, zi = function(g, R, X) {
            const [J, ut, St, yt] = R;
            switch (X) {
              case 0:
                for (let V = 0, Tt = g.length; V < Tt; V += 2)
                  g[V] -= J, g[V + 1] = yt - g[V + 1];
                break;
              case 90:
                for (let V = 0, Tt = g.length; V < Tt; V += 2) {
                  const wt = g[V];
                  g[V] = g[V + 1] - ut, g[V + 1] = wt - J;
                }
                break;
              case 180:
                for (let V = 0, Tt = g.length; V < Tt; V += 2)
                  g[V] = St - g[V], g[V + 1] -= ut;
                break;
              case 270:
                for (let V = 0, Tt = g.length; V < Tt; V += 2) {
                  const wt = g[V];
                  g[V] = yt - g[V + 1], g[V + 1] = St - wt;
                }
                break;
              default:
                throw new Error("Invalid rotation");
            }
            return g;
          }, Xi = function(g, R, X, J) {
            var Tt, wt;
            const ut = [], St = this.thickness / 2, yt = g * R + St, V = g * X + St;
            for (const jt of this.paths) {
              const Bt = [], Xt = [];
              for (let Ft = 0, Nt = jt.length; Ft < Nt; Ft++) {
                const [Vt, $t, _t, tt] = jt[Ft], st = g * Vt[0] + yt, kt = g * Vt[1] + V, zt = g * $t[0] + yt, Gt = g * $t[1] + V, L = g * _t[0] + yt, ft = g * _t[1] + V, Ct = g * tt[0] + yt, Dt = g * tt[1] + V;
                Ft === 0 && (Bt.push(st, kt), Xt.push(st, kt)), Bt.push(zt, Gt, L, ft, Ct, Dt), Xt.push(zt, Gt), Ft === Nt - 1 && Xt.push(Ct, Dt);
              }
              ut.push({
                bezier: z(Tt = vt, P, ci).call(Tt, Bt, J, this.rotation),
                points: z(wt = vt, P, ci).call(wt, Xt, J, this.rotation)
              });
            }
            return ut;
          }, hi = function() {
            let g = 1 / 0, R = -1 / 0, X = 1 / 0, J = -1 / 0;
            for (const ut of this.paths)
              for (const [St, yt, V, Tt] of ut) {
                const wt = o.Util.bezierBoundingBox(...St, ...yt, ...V, ...Tt);
                g = Math.min(g, wt[0]), X = Math.min(X, wt[1]), R = Math.max(R, wt[2]), J = Math.max(J, wt[3]);
              }
            return [g, X, R, J];
          }, ke = function() {
            return t(this, f) ? Math.ceil(this.thickness * this.parentScale) : 0;
          }, ce = function(g = !1) {
            if (this.isEmpty())
              return;
            if (!t(this, f)) {
              z(this, s, ee).call(this);
              return;
            }
            const R = z(this, s, hi).call(this), X = z(this, s, ke).call(this);
            et(this, m, Math.max(T.AnnotationEditor.MIN_SIZE, R[2] - R[0])), et(this, M, Math.max(T.AnnotationEditor.MIN_SIZE, R[3] - R[1]));
            const J = Math.ceil(X + t(this, m) * this.scaleFactor), ut = Math.ceil(X + t(this, M) * this.scaleFactor), [St, yt] = this.parentDimensions;
            this.width = J / St, this.height = ut / yt, this.setAspectRatio(J, ut);
            const V = this.translationX, Tt = this.translationY;
            this.translationX = -R[0], this.translationY = -R[1], z(this, s, le).call(this), z(this, s, ee).call(this), et(this, y, J), et(this, n, ut), this.setDims(J, ut);
            const wt = g ? X / this.scaleFactor / 2 : 0;
            this.translate(V - this.translationX - wt, Tt - this.translationY - wt);
          }, Q(vt, P), Kt(vt, "_defaultColor", null), Kt(vt, "_defaultOpacity", 1), Kt(vt, "_defaultThickness", 1), Kt(vt, "_type", "ink");
          let B = vt;
          h.InkEditor = B;
        },
        /* 34 */
        /***/
        (pt, h, rt) => {
          var B, M, m, N, I, _, b, E, f, d, p, me, be, Fe, di, Vi, qi, ui, Me, $i;
          Object.defineProperty(h, "__esModule", {
            value: !0
          }), h.StampEditor = void 0;
          var o = rt(1), T = rt(4), ct = rt(6), q = rt(29);
          const A = class A extends T.AnnotationEditor {
            constructor(W) {
              super({
                ...W,
                name: "stampEditor"
              });
              Q(this, p);
              Q(this, B, null);
              Q(this, M, null);
              Q(this, m, null);
              Q(this, N, null);
              Q(this, I, null);
              Q(this, _, null);
              Q(this, b, null);
              Q(this, E, null);
              Q(this, f, !1);
              Q(this, d, !1);
              et(this, N, W.bitmapUrl), et(this, I, W.bitmapFile);
            }
            static initialize(W) {
              T.AnnotationEditor.initialize(W);
            }
            static get supportedTypes() {
              const W = ["apng", "avif", "bmp", "gif", "jpeg", "png", "svg+xml", "webp", "x-icon"];
              return (0, o.shadow)(this, "supportedTypes", W.map(($) => `image/${$}`));
            }
            static get supportedTypesStr() {
              return (0, o.shadow)(this, "supportedTypesStr", this.supportedTypes.join(","));
            }
            static isHandlingMimeForPasting(W) {
              return this.supportedTypes.includes(W);
            }
            static paste(W, $) {
              $.pasteEditor(o.AnnotationEditorType.STAMP, {
                bitmapFile: W.getAsFile()
              });
            }
            remove() {
              var W, $;
              t(this, M) && (et(this, B, null), this._uiManager.imageManager.deleteId(t(this, M)), (W = t(this, _)) == null || W.remove(), et(this, _, null), ($ = t(this, b)) == null || $.disconnect(), et(this, b, null)), super.remove();
            }
            rebuild() {
              if (!this.parent) {
                t(this, M) && z(this, p, Fe).call(this);
                return;
              }
              super.rebuild(), this.div !== null && (t(this, M) && z(this, p, Fe).call(this), this.isAttachedToDOM || this.parent.add(this));
            }
            onceAdded() {
              this._isDraggable = !0, this.div.focus();
            }
            isEmpty() {
              return !(t(this, m) || t(this, B) || t(this, N) || t(this, I));
            }
            get isResizable() {
              return !0;
            }
            render() {
              if (this.div)
                return this.div;
              let W, $;
              if (this.width && (W = this.x, $ = this.y), super.render(), this.div.hidden = !0, t(this, B) ? z(this, p, di).call(this) : z(this, p, Fe).call(this), this.width) {
                const [j, at] = this.parentDimensions;
                this.setAt(W * j, $ * at, this.width * j, this.height * at);
              }
              return this.div;
            }
            static deserialize(W, $, j) {
              if (W instanceof q.StampAnnotationElement)
                return null;
              const at = super.deserialize(W, $, j), {
                rect: C,
                bitmapUrl: U,
                bitmapId: Y,
                isSvg: S,
                accessibilityData: e
              } = W;
              Y && j.imageManager.isValidId(Y) ? et(at, M, Y) : et(at, N, U), et(at, f, S);
              const [i, u] = at.pageDimensions;
              return at.width = (C[2] - C[0]) / i, at.height = (C[3] - C[1]) / u, e && (at.altTextData = e), at;
            }
            serialize(W = !1, $ = null) {
              if (this.isEmpty())
                return null;
              const j = {
                annotationType: o.AnnotationEditorType.STAMP,
                bitmapId: t(this, M),
                pageIndex: this.pageIndex,
                rect: this.getRect(0, 0),
                rotation: this.rotation,
                isSvg: t(this, f),
                structTreeParentId: this._structTreeParentId
              };
              if (W)
                return j.bitmapUrl = z(this, p, Me).call(this, !0), j.accessibilityData = this.altTextData, j;
              const {
                decorative: at,
                altText: C
              } = this.altTextData;
              if (!at && C && (j.accessibilityData = {
                type: "Figure",
                alt: C
              }), $ === null)
                return j;
              $.stamps || ($.stamps = /* @__PURE__ */ new Map());
              const U = t(this, f) ? (j.rect[2] - j.rect[0]) * (j.rect[3] - j.rect[1]) : null;
              if (!$.stamps.has(t(this, M)))
                $.stamps.set(t(this, M), {
                  area: U,
                  serialized: j
                }), j.bitmap = z(this, p, Me).call(this, !1);
              else if (t(this, f)) {
                const Y = $.stamps.get(t(this, M));
                U > Y.area && (Y.area = U, Y.serialized.bitmap.close(), Y.serialized.bitmap = z(this, p, Me).call(this, !1));
              }
              return j;
            }
          };
          B = new WeakMap(), M = new WeakMap(), m = new WeakMap(), N = new WeakMap(), I = new WeakMap(), _ = new WeakMap(), b = new WeakMap(), E = new WeakMap(), f = new WeakMap(), d = new WeakMap(), p = new WeakSet(), me = function(W, $ = !1) {
            if (!W) {
              this.remove();
              return;
            }
            et(this, B, W.bitmap), $ || (et(this, M, W.id), et(this, f, W.isSvg)), z(this, p, di).call(this);
          }, be = function() {
            et(this, m, null), this._uiManager.enableWaiting(!1), t(this, _) && this.div.focus();
          }, Fe = function() {
            if (t(this, M)) {
              this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(t(this, M)).then(($) => z(this, p, me).call(this, $, !0)).finally(() => z(this, p, be).call(this));
              return;
            }
            if (t(this, N)) {
              const $ = t(this, N);
              et(this, N, null), this._uiManager.enableWaiting(!0), et(this, m, this._uiManager.imageManager.getFromUrl($).then((j) => z(this, p, me).call(this, j)).finally(() => z(this, p, be).call(this)));
              return;
            }
            if (t(this, I)) {
              const $ = t(this, I);
              et(this, I, null), this._uiManager.enableWaiting(!0), et(this, m, this._uiManager.imageManager.getFromFile($).then((j) => z(this, p, me).call(this, j)).finally(() => z(this, p, be).call(this)));
              return;
            }
            const W = document.createElement("input");
            W.type = "file", W.accept = A.supportedTypesStr, et(this, m, new Promise(($) => {
              W.addEventListener("change", async () => {
                if (!W.files || W.files.length === 0)
                  this.remove();
                else {
                  this._uiManager.enableWaiting(!0);
                  const j = await this._uiManager.imageManager.getFromFile(W.files[0]);
                  z(this, p, me).call(this, j);
                }
                $();
              }), W.addEventListener("cancel", () => {
                this.remove(), $();
              });
            }).finally(() => z(this, p, be).call(this))), W.click();
          }, di = function() {
            const {
              div: W
            } = this;
            let {
              width: $,
              height: j
            } = t(this, B);
            const [at, C] = this.pageDimensions, U = 0.75;
            if (this.width)
              $ = this.width * at, j = this.height * C;
            else if ($ > U * at || j > U * C) {
              const i = Math.min(U * at / $, U * C / j);
              $ *= i, j *= i;
            }
            const [Y, S] = this.parentDimensions;
            this.setDims($ * Y / at, j * S / C), this._uiManager.enableWaiting(!1);
            const e = et(this, _, document.createElement("canvas"));
            W.append(e), W.hidden = !1, z(this, p, ui).call(this, $, j), z(this, p, $i).call(this), t(this, d) || (this.parent.addUndoableEditor(this), et(this, d, !0)), this._uiManager._eventBus.dispatch("reporttelemetry", {
              source: this,
              details: {
                type: "editing",
                subtype: this.editorType,
                data: {
                  action: "inserted_image"
                }
              }
            }), this.addAltTextButton();
          }, Vi = function(W, $) {
            var U;
            const [j, at] = this.parentDimensions;
            this.width = W / j, this.height = $ / at, this.setDims(W, $), (U = this._initialOptions) != null && U.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, t(this, E) !== null && clearTimeout(t(this, E)), et(this, E, setTimeout(() => {
              et(this, E, null), z(this, p, ui).call(this, W, $);
            }, 200));
          }, qi = function(W, $) {
            const {
              width: j,
              height: at
            } = t(this, B);
            let C = j, U = at, Y = t(this, B);
            for (; C > 2 * W || U > 2 * $; ) {
              const S = C, e = U;
              C > 2 * W && (C = C >= 16384 ? Math.floor(C / 2) - 1 : Math.ceil(C / 2)), U > 2 * $ && (U = U >= 16384 ? Math.floor(U / 2) - 1 : Math.ceil(U / 2));
              const i = new OffscreenCanvas(C, U);
              i.getContext("2d").drawImage(Y, 0, 0, S, e, 0, 0, C, U), Y = i.transferToImageBitmap();
            }
            return Y;
          }, ui = function(W, $) {
            W = Math.ceil(W), $ = Math.ceil($);
            const j = t(this, _);
            if (!j || j.width === W && j.height === $)
              return;
            j.width = W, j.height = $;
            const at = t(this, f) ? t(this, B) : z(this, p, qi).call(this, W, $), C = j.getContext("2d");
            C.filter = this._uiManager.hcmFilter, C.drawImage(at, 0, 0, at.width, at.height, 0, 0, W, $);
          }, Me = function(W) {
            if (W) {
              if (t(this, f)) {
                const at = this._uiManager.imageManager.getSvgUrl(t(this, M));
                if (at)
                  return at;
              }
              const $ = document.createElement("canvas");
              return {
                width: $.width,
                height: $.height
              } = t(this, B), $.getContext("2d").drawImage(t(this, B), 0, 0), $.toDataURL();
            }
            if (t(this, f)) {
              const [$, j] = this.pageDimensions, at = Math.round(this.width * $ * ct.PixelsPerInch.PDF_TO_CSS_UNITS), C = Math.round(this.height * j * ct.PixelsPerInch.PDF_TO_CSS_UNITS), U = new OffscreenCanvas(at, C);
              return U.getContext("2d").drawImage(t(this, B), 0, 0, t(this, B).width, t(this, B).height, 0, 0, at, C), U.transferToImageBitmap();
            }
            return structuredClone(t(this, B));
          }, $i = function() {
            et(this, b, new ResizeObserver((W) => {
              const $ = W[0].contentRect;
              $.width && $.height && z(this, p, Vi).call(this, $.width, $.height);
            })), t(this, b).observe(this.div);
          }, Kt(A, "_type", "stamp");
          let gt = A;
          h.StampEditor = gt;
        }
        /******/
      ], __webpack_module_cache__ = {};
      function __w_pdfjs_require__(pt) {
        var h = __webpack_module_cache__[pt];
        if (h !== void 0)
          return h.exports;
        var rt = __webpack_module_cache__[pt] = {
          /******/
          // no module.id needed
          /******/
          // no module.loaded needed
          /******/
          exports: {}
          /******/
        };
        return __webpack_modules__[pt](rt, rt.exports, __w_pdfjs_require__), rt.exports;
      }
      var __webpack_exports__ = {};
      return (() => {
        var pt = __webpack_exports__;
        Object.defineProperty(pt, "__esModule", {
          value: !0
        }), Object.defineProperty(pt, "AbortException", {
          enumerable: !0,
          get: function() {
            return h.AbortException;
          }
        }), Object.defineProperty(pt, "AnnotationEditorLayer", {
          enumerable: !0,
          get: function() {
            return ct.AnnotationEditorLayer;
          }
        }), Object.defineProperty(pt, "AnnotationEditorParamsType", {
          enumerable: !0,
          get: function() {
            return h.AnnotationEditorParamsType;
          }
        }), Object.defineProperty(pt, "AnnotationEditorType", {
          enumerable: !0,
          get: function() {
            return h.AnnotationEditorType;
          }
        }), Object.defineProperty(pt, "AnnotationEditorUIManager", {
          enumerable: !0,
          get: function() {
            return q.AnnotationEditorUIManager;
          }
        }), Object.defineProperty(pt, "AnnotationLayer", {
          enumerable: !0,
          get: function() {
            return gt.AnnotationLayer;
          }
        }), Object.defineProperty(pt, "AnnotationMode", {
          enumerable: !0,
          get: function() {
            return h.AnnotationMode;
          }
        }), Object.defineProperty(pt, "CMapCompressionType", {
          enumerable: !0,
          get: function() {
            return h.CMapCompressionType;
          }
        }), Object.defineProperty(pt, "DOMSVGFactory", {
          enumerable: !0,
          get: function() {
            return o.DOMSVGFactory;
          }
        }), Object.defineProperty(pt, "FeatureTest", {
          enumerable: !0,
          get: function() {
            return h.FeatureTest;
          }
        }), Object.defineProperty(pt, "GlobalWorkerOptions", {
          enumerable: !0,
          get: function() {
            return B.GlobalWorkerOptions;
          }
        }), Object.defineProperty(pt, "ImageKind", {
          enumerable: !0,
          get: function() {
            return h.ImageKind;
          }
        }), Object.defineProperty(pt, "InvalidPDFException", {
          enumerable: !0,
          get: function() {
            return h.InvalidPDFException;
          }
        }), Object.defineProperty(pt, "MissingPDFException", {
          enumerable: !0,
          get: function() {
            return h.MissingPDFException;
          }
        }), Object.defineProperty(pt, "OPS", {
          enumerable: !0,
          get: function() {
            return h.OPS;
          }
        }), Object.defineProperty(pt, "PDFDataRangeTransport", {
          enumerable: !0,
          get: function() {
            return rt.PDFDataRangeTransport;
          }
        }), Object.defineProperty(pt, "PDFDateString", {
          enumerable: !0,
          get: function() {
            return o.PDFDateString;
          }
        }), Object.defineProperty(pt, "PDFWorker", {
          enumerable: !0,
          get: function() {
            return rt.PDFWorker;
          }
        }), Object.defineProperty(pt, "PasswordResponses", {
          enumerable: !0,
          get: function() {
            return h.PasswordResponses;
          }
        }), Object.defineProperty(pt, "PermissionFlag", {
          enumerable: !0,
          get: function() {
            return h.PermissionFlag;
          }
        }), Object.defineProperty(pt, "PixelsPerInch", {
          enumerable: !0,
          get: function() {
            return o.PixelsPerInch;
          }
        }), Object.defineProperty(pt, "PromiseCapability", {
          enumerable: !0,
          get: function() {
            return h.PromiseCapability;
          }
        }), Object.defineProperty(pt, "RenderingCancelledException", {
          enumerable: !0,
          get: function() {
            return o.RenderingCancelledException;
          }
        }), Object.defineProperty(pt, "SVGGraphics", {
          enumerable: !0,
          get: function() {
            return rt.SVGGraphics;
          }
        }), Object.defineProperty(pt, "UnexpectedResponseException", {
          enumerable: !0,
          get: function() {
            return h.UnexpectedResponseException;
          }
        }), Object.defineProperty(pt, "Util", {
          enumerable: !0,
          get: function() {
            return h.Util;
          }
        }), Object.defineProperty(pt, "VerbosityLevel", {
          enumerable: !0,
          get: function() {
            return h.VerbosityLevel;
          }
        }), Object.defineProperty(pt, "XfaLayer", {
          enumerable: !0,
          get: function() {
            return M.XfaLayer;
          }
        }), Object.defineProperty(pt, "build", {
          enumerable: !0,
          get: function() {
            return rt.build;
          }
        }), Object.defineProperty(pt, "createValidAbsoluteUrl", {
          enumerable: !0,
          get: function() {
            return h.createValidAbsoluteUrl;
          }
        }), Object.defineProperty(pt, "getDocument", {
          enumerable: !0,
          get: function() {
            return rt.getDocument;
          }
        }), Object.defineProperty(pt, "getFilenameFromUrl", {
          enumerable: !0,
          get: function() {
            return o.getFilenameFromUrl;
          }
        }), Object.defineProperty(pt, "getPdfFilenameFromUrl", {
          enumerable: !0,
          get: function() {
            return o.getPdfFilenameFromUrl;
          }
        }), Object.defineProperty(pt, "getXfaPageViewport", {
          enumerable: !0,
          get: function() {
            return o.getXfaPageViewport;
          }
        }), Object.defineProperty(pt, "isDataScheme", {
          enumerable: !0,
          get: function() {
            return o.isDataScheme;
          }
        }), Object.defineProperty(pt, "isPdfFile", {
          enumerable: !0,
          get: function() {
            return o.isPdfFile;
          }
        }), Object.defineProperty(pt, "loadScript", {
          enumerable: !0,
          get: function() {
            return o.loadScript;
          }
        }), Object.defineProperty(pt, "noContextMenu", {
          enumerable: !0,
          get: function() {
            return o.noContextMenu;
          }
        }), Object.defineProperty(pt, "normalizeUnicode", {
          enumerable: !0,
          get: function() {
            return h.normalizeUnicode;
          }
        }), Object.defineProperty(pt, "renderTextLayer", {
          enumerable: !0,
          get: function() {
            return T.renderTextLayer;
          }
        }), Object.defineProperty(pt, "setLayerDimensions", {
          enumerable: !0,
          get: function() {
            return o.setLayerDimensions;
          }
        }), Object.defineProperty(pt, "shadow", {
          enumerable: !0,
          get: function() {
            return h.shadow;
          }
        }), Object.defineProperty(pt, "updateTextLayer", {
          enumerable: !0,
          get: function() {
            return T.updateTextLayer;
          }
        }), Object.defineProperty(pt, "version", {
          enumerable: !0,
          get: function() {
            return rt.version;
          }
        });
        var h = __w_pdfjs_require__(1), rt = __w_pdfjs_require__(2), o = __w_pdfjs_require__(6), T = __w_pdfjs_require__(26), ct = __w_pdfjs_require__(27), q = __w_pdfjs_require__(5), gt = __w_pdfjs_require__(29), B = __w_pdfjs_require__(14), M = __w_pdfjs_require__(32);
      })(), __webpack_exports__;
    })()
  ));
})(pdf);
var pdfExports = pdf.exports;
const pdfjsLib = /* @__PURE__ */ getDefaultExportFromCjs(pdfExports), {
  SvelteComponent,
  append,
  attr,
  binding_callbacks,
  detach,
  element,
  init,
  insert,
  noop,
  safe_not_equal,
  set_style,
  toggle_class
} = window.__gradio__svelte__internal;
function create_fragment(pt) {
  let h, rt;
  return {
    c() {
      h = element("div"), rt = element("canvas"), set_style(h, "justify-content", "center"), set_style(h, "align-items", "center"), set_style(h, "display", "flex"), set_style(h, "flex-direction", "column"), attr(h, "class", "svelte-1gecy8w"), toggle_class(
        h,
        "table",
        /*type*/
        pt[0] === "table"
      ), toggle_class(
        h,
        "gallery",
        /*type*/
        pt[0] === "gallery"
      ), toggle_class(
        h,
        "selected",
        /*selected*/
        pt[1]
      );
    },
    m(o, T) {
      insert(o, h, T), append(h, rt), pt[4](rt);
    },
    p(o, [T]) {
      T & /*type*/
      1 && toggle_class(
        h,
        "table",
        /*type*/
        o[0] === "table"
      ), T & /*type*/
      1 && toggle_class(
        h,
        "gallery",
        /*type*/
        o[0] === "gallery"
      ), T & /*selected*/
      2 && toggle_class(
        h,
        "selected",
        /*selected*/
        o[1]
      );
    },
    i: noop,
    o: noop,
    d(o) {
      o && detach(h), pt[4](null);
    }
  };
}
function instance(pt, h, rt) {
  var o = this && this.__awaiter || function(I, _, b, E) {
    function f(d) {
      return d instanceof b ? d : new b(function(p) {
        p(d);
      });
    }
    return new (b || (b = Promise))(function(d, p) {
      function D(l) {
        try {
          n(E.next(l));
        } catch (s) {
          p(s);
        }
      }
      function y(l) {
        try {
          n(E.throw(l));
        } catch (s) {
          p(s);
        }
      }
      function n(l) {
        l.done ? d(l.value) : f(l.value).then(D, y);
      }
      n((E = E.apply(I, _ || [])).next());
    });
  };
  let { value: T } = h, { type: ct } = h, { selected: q = !1 } = h;
  pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdn.bootcss.com/pdf.js/3.11.174/pdf.worker.js";
  let gt, B;
  function M(I) {
    return o(this, void 0, void 0, function* () {
      gt = yield pdfjsLib.getDocument(I).promise, m();
    });
  }
  function m() {
    gt.getPage(1).then((I) => {
      const _ = B.getContext("2d");
      let b = window.devicePixelRatio || 1, E = _.webkitBackingStorePixelRatio || _.mozBackingStorePixelRatio || _.msBackingStorePixelRatio || _.oBackingStorePixelRatio || _.backingStorePixelRatio || 1, f = b / E, d = I.getViewport({ scale: 1 });
      var p = I.getViewport({
        scale: screen.availWidth / d.width
      });
      p = d, p = d, rt(2, B.width = p.width * f, B), rt(2, B.height = p.height * f, B), rt(2, B.style.width = p.width + "px", B), rt(2, B.style.height = p.height + "px", B), _.setTransform(f, 0, 0, f, 0, 0);
      var D = {
        canvasContext: _,
        viewport: d
      };
      I.render(D);
    });
  }
  function N(I) {
    binding_callbacks[I ? "unshift" : "push"](() => {
      B = I, rt(2, B);
    });
  }
  return pt.$$set = (I) => {
    "value" in I && rt(3, T = I.value), "type" in I && rt(0, ct = I.type), "selected" in I && rt(1, q = I.selected);
  }, pt.$$.update = () => {
    pt.$$.dirty & /*value*/
    8 && M(T);
  }, [ct, q, B, T, N];
}
class Example extends SvelteComponent {
  constructor(h) {
    super(), init(this, h, instance, create_fragment, safe_not_equal, { value: 3, type: 0, selected: 1 });
  }
}
export {
  Example as default
};
